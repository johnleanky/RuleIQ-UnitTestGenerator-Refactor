# RuleIQ Unit Test Pipeline — Current Status

**Bundle date:** 2026-09-15  
**Authority:** this bundle is the sole current project version. `STATUS.md` describes only active behavior. `00_START_HERE/VALIDATION_HISTORY.md` is historical/non-authoritative.

## Current architecture

- **Scenario Author** owns RUT semantics, dependency closure, Scenario Compiler `I -> W -> F -> B -> A`, physical grouping and immutable `UnitTestProjectionV3` source materialization.
- **Unit Test Generator** deterministically compiles one persisted Projection into Candidate versions, owns Candidate repair/retry orchestration, consumes Validator outcome only from exact Candidate Memory state, and writes the terminal Generator outcome only to the exact source Projection lifecycle fields.
- **Validator** independently reads the exact Projection + Candidate, validates schema/fidelity/target invariants without redefining Author semantics, and is the sole writer of Candidate validation lifecycle state.
- Delegated Agent assistant responses are non-authoritative. Generator returns exactly `ACK`; Author ignores it. Memory row state is the correctness boundary.

## Exact case identity

`CASE_ID_RAW` is opaque case-sensitive text.

- Author owner: exact `GetCaseData.pyID`.
- Generator owner: exact `Invocation.CaseID` received from Author.
- Validator owner: exact `Invocation.CaseID` received from Generator.
- Every Memory `pxCaseID`, Validator `JsonValidationTool.CaseID`, and delegated Agent Invocation `CaseID` must preserve `CASE_ID_RAW` character-for-character.

Example: `GenUT-91051` must remain `GenUT-91051`; `GENUT-91051` is not equivalent for this contract even if another Pega layer treats case identifiers case-insensitively.

## Current execution order

```text
Global dependency closure + semantic execution
-> I -> W -> F
-> freeze complete physical group set
-> B -> A; require A=PASS

PREPARE_ALL
-> materialize + self-validate one complete UnitTestProjectionV3 per frozen group
-> require exact group/projection census
-> zero Memory writes / zero Generator calls on preparation failure

PERSIST_ALL
-> WriteMemory every prepared Projection in frozen order
-> freeze ordered PROJECTION_QUEUE(groupId, projectionPayload, projectionGUID, PENDING)
-> require exact census and distinct nonempty GUIDs
-> any write/correlation/census failure stops the run with zero Generator calls

GENERATE_ALL
-> NEXT = first PENDING queue row
-> invoke Generator exactly once; ignore assistant response
-> fresh GetMemory(exact Projection GUID)
-> Passed + OK + ProcessingFeedback="" => PENDING -> DONE
-> otherwise stop Failed; later persisted Projections remain unchanged/unprocessed
-> continue until no PENDING row remains

COMPLETE
-> legal only when DONE_COUNT == QUEUE_COUNT and PENDING_COUNT == 0
```

No UnitTestGenerator call is legal until **all** frozen physical groups have successfully persisted Projections. This makes the full ScenarioAuthor output set materially visible in Agent Memory before downstream generation begins.

## Active Memory / lifecycle contract

- Tool input case argument remains `pxCaseID`; successful Memory responses use `CaseID`.
- Canonical lifecycle fields: `pyStatusValue`, response `RouterKey`, input `pyRouterKey`, and `ProcessingFeedback`.
- Success terminal state requires exact `ProcessingFeedback=""`; failed/non-OK state requires nonempty feedback.
- `pyPayload`, identity, type, group, GUID and case ownership are immutable after create.
- **Candidate lifecycle owner:** Validator; **consumer:** Generator.
- **Projection terminal lifecycle owner:** Generator; **consumer:** Scenario Author.
- `GENERATOR_REPAIR` is internal to Generator <-> Validator and is invalid on Projection.

## Active Projection / target invariants

- Source `UnitTestProjectionV3.rut` has `{name,applyToClass}` only; source-side `singlePage` is absent.
- Physical `pyIsSinglePageImplementation` is target-owned.
- `physicalGroupKey/Gnnn` is correlation/group identity only and never participates in target naming.
- `CM-NAME-001` derives separator-free `TC_` names only from semantic labels, e.g. `City Not Valid Exit -> TC_CityNotValidExit`.
- ScenarioAuthor `_DWLPlan` requires one ordered `OUT=[KEY...]`, independently reconstructed `ACT=[KEY...]`, and literal ordered `OUT == ACT` before RuleCrawler.
- Validator target KnowledgeTool scope remains closed; semantic RUT/dependency adapters remain ScenarioAuthor-only.

## Active issue / repair behavior

- Validator and Generator share one closed active catalog with **12 reachable codes**.
- JsonValidation non-success shapes remain unverified and fail closed through `JSON_VALIDATION_TOOL_ERROR/HUMAN_REVIEW`.
- Validator writes Candidate lifecycle; Generator ignores Validator assistant response and fresh-reads Candidate Memory.
- Generator returns exactly `ACK`; Author ignores it and fresh-reads Projection Memory.

## Validation state

**Static refactoring status:** `R0-R16 PASS (STATIC)`  
**R15 final regression:** `172/172 PASS`  
**R15 ScenarioAuthor §2-§4 semantic coverage:** `133/133 PASS`  
**R16 core semantic/regression suite:** `139/139 PASS`  
**R16 final cross-bundle synchronization gate:** `147/147 PASS`  
**Analysis mode:** `TEXT_SEMANTIC_ONLY=true`

R16 change scope is orchestration/identity only:
- `CASE_ID_RAW` exact-case propagation;
- fixed Generator `ACK` response;
- projection-first `PREPARE_ALL -> PERSIST_ALL -> GENERATE_ALL` barrier;
- explicit local `PROJECTION_QUEUE` completion census.

ScenarioAuthor semantic sections §2-§5 are text-identical to R15. §6 differs only in selecting every frozen group during `PREPARE_ALL` instead of one current group. Target schemas/examples, Knowledge Areas, Memory tool contract/specification, runtime-tool documentation, README and historical validation file are text-identical to R15.

Current prompt word-count proxy versus R15:

| Prompt | R15 | R16 | Change |
|---|---:|---:|---:|
| ScenarioAuthor | 8,675 | 8,865 | +2.2% |
| Generator | 3,752 | 3,793 | +1.1% |
| Validator | 3,225 | 3,249 | +0.7% |
| **Total** | **15,652** | **15,907** | **+1.6%** |

The added text replaces ambiguous interleaved orchestration with one closed phase/queue state machine. No hash/checksum/fingerprint-based validation is used.

## External evidence still pending

Static validation does not prove live Pega behavior. Run a fresh multi-group E2E replay and verify:

1. `GetCaseData.pyID=GenUT-...` reaches Author -> Generator -> Validator and all tool-call arguments character-for-character unchanged;
2. all Projection rows are persisted before the first Generator invocation;
3. if a Projection write fails, no Generator is invoked;
4. Generator returns only `ACK`, and Author routing depends only on fresh Projection Memory;
5. when a Generator stops on an early group, later Projection rows remain visible and unprocessed;
6. all persisted queue entries are invoked exactly once on a successful run.

If the actual tool-call argument is already correct mixed-case `GenUT-...` but Pega itself stores/returns uppercase `GENUT-...`, treat that as a Pega implementation/mapping defect; prompt changes cannot repair runtime normalization after the call boundary.

## Exact next action

Deploy the three R16 prompts to live Pega and run a multi-group case with a mixed-case `pyID` such as `GenUT-...`. Capture tool arguments, Projection Memory rows and invocation order before changing any Pega Memory implementation.
