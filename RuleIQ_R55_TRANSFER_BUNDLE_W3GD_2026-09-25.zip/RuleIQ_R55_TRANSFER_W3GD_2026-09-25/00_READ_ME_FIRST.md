# RuleIQ R55 — Transfer Bundle (W3G-D, Data Transform only)

**Prepared:** 2026-09-25  
**Current active baseline:** R55 Wave 3G-D  
**Scope at handoff:** Data Transform / `Rule-Obj-Model` only  
**Latest live run:** `WAVE3GD.zip` — uploaded and **not yet analyzed to completion** in the source chat.

## Start here in the next chat

1. Treat `01_ACTIVE_BASELINE/RuleIQ_R55_WAVE3GD_DT_DETERMINISM_HARDENING_STAGED_2026-09-25.zip` as the current implementation baseline.
2. Production changes from W3G-C to W3G-D are intentionally limited to:
   - `ScenarioAuthor_SystemPrompt_R55_W3GD.txt`
   - `Rule-Obj-Model_KnowledgeArea_R55_W3GD.txt`
3. Do **not** change Decision Table, Data Page, When, RUF, Generator, Validator, Projection batching, schemas/examples unless a new live finding proves it is necessary.
4. The immediate task is to analyze `04_LATEST_LIVE_RUN_UNANALYZED/WAVE3GD.zip` (`PXCONV-228024`, `PXCONV-228037`, `PXCONV-229002`) against `02_VALIDATION/W3GD_LIVE_ACCEPTANCE.md`.
5. Compare only byte-identical `PrepareCustomerCommunication` Data Transform runs first. Do not expand scope to DetermineChannel yet.

## Architectural direction that must be preserved

- No external deterministic parser/extractor is introduced. The LLM agent still performs the semantic compilation, but under closed mechanical contracts.
- Semantic authority belongs in Knowledge Areas, not in hardcoded ScenarioAuthor operation tables.
- ScenarioAuthor is a generic compiler/consumer of semantic signatures.
- `APPEND/CURRENT/INSERT/LAST/PREPEND` are Rule-Obj-Property symbolic property-reference indexes, not Data Transform `pyActionName` operations.
- Current runtime semantics in the project Knowledge Areas are canonical when they conflict with Pega 26.1 authoring material, unless explicitly re-resolved by the user.
- Projection write batching must not be changed in this line of work.

## Latest unresolved task

The W3G-D live run has been uploaded but not yet fully inspected. The next session should establish whether W3G-D finally stabilizes:

`ROM context frame -> occurrence-level DEPIR -> XMAP ownership -> COVREQ -> frozen SCENARIO.covers -> AUDIT`

and identify only remaining Data Transform defects.
