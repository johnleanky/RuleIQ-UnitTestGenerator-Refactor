# R55 Wave 3G-A — KnowledgeArea Semantic Signature Audit

Baseline: **W3F-A.1**  
External reference: **Pega Infinity AI Plugins 26.1**, repository `pegasystems/infinity-ai-plugins`  
Observed GitHub snapshot in searches: commit `5b53502d248275295c3154b75f92165d0eb1823e`

## Audit rule

Each fact is classified as:

- **COVERED** — current KnowledgeArea already contains compatible runtime semantics.
- **MISSING** — Pega 26.1 exposes supported vocabulary/shape not normalized in the current KnowledgeArea; no contradictory current semantic was found.
- **CONFLICT** — Pega 26.1 description/schema contradicts a current canonical KnowledgeArea fact or a supported runtime form. No automatic merge.
- **N/A-AUTHORING** — Pega 26.1 material concerns authoring/UI payload details that are not needed for ScenarioAuthor runtime semantic compilation.

Pega 26.1 is used for vocabulary, field shapes and completeness review. Current confirmed RuleIQ runtime semantics remain canonical until a conflict is explicitly resolved.

---

## 1. Rule-Obj-Model

### COVERED

Current KA already covers:

- Clipboard operation collection `pyProperties`
- operation discriminator `pyActionName`
- execution ordering via `pyPropertyStepId`
- `SET`
- `APPLY_MODEL`
- `WHEN`
- `OTHERWISE`
- `UPDATE_PAGE`
- `FOR_EACH_PAGE_IN`
- `APPEND_AND_MAP_TO`
- `REMOVE`
- `SORT`
- `COMMENT`
- `EXIT_MODEL`
- `BLANK` / `WITH_VALUES_FROM`
- caller parameters and parameter-page inheritance
- current/source/target context
- Page/PageList context lineage
- list mutation effects
- rule termination

### MISSING

Pega 26.1 exposes additional Rule-Obj-Model vocabulary not normalized in the current KA:

- `OTHERWISE_WHEN`
- `APPEND_TO`
- `EXIT_FOR_EACH`
- JSON Data Transform body `pyMappingModel`
- JSON actions `AUTO_MAP`, `APPLY_DATA_TRANSFORM`
- `APPEND_TO` relationship modes `NEW_PAGE`, `EXISTING_PAGE`, `EXISTING_PAGE_LIST`, `CURRENT_SOURCE_PAGE`
- JSON-specific UPDATE_PAGE context via `pyUpdateContextOptions`

These can be added only as supplemental signatures; they must not alter existing runtime semantics.

### CONFLICT — resolved

**ROM-C1 — UPDATE_PAGE + WITH_VALUES_FROM copy semantics**

Current KA:
- target is created as an empty shell;
- `WITH_VALUES_FROM` replaces the active source for child scope;
- source properties/lists/groups are not automatically copied.

Pega 26.1 skill:
- says all source properties are copied onto target.

Resolution supplied by user:
- **Current KnowledgeArea is correct.**
- Pega 26.1 wording is not runtime authority for this behavior.

### CONFLICT — unresolved

**ROM-C2 — WITH_VALUES_FROM child operations**

Current KA and supported RUT structure:
- `UPDATE_PAGE ... WITH_VALUES_FROM` opens a child scope and child `WHEN/SET/APPEND...` operations execute there.

Pega 26.1 skill:
- says child `pyProperties` must be empty when `WITH_VALUES_FROM` is used.

**ROM-C3 — APPEND_AND_MAP_TO + EXISTING_PAGE**

Current KA / supported RUT:
- `APPEND_AND_MAP_TO` can use `EXISTING_PAGE`, with `pyPropertiesValue` as the active source page and a new target list item for child mappings.

Pega 26.1 skill:
- documents `EXISTING_PAGE` as `APPEND_TO` only.
- documents `APPEND_AND_MAP_TO` with `NEW_PAGE` or `EXISTING_PAGE_LIST`.

**ROM-C4 — operation vocabulary**

Current KA declares runtime values:
- `APPEND`
- `PREPEND`
- `INSERT`

Pega 26.1 Clipboard schema does not list these values and instead includes:
- `APPEND_TO`
- `OTHERWISE_WHEN`
- `EXIT_FOR_EACH`

Need to distinguish runtime RuleJSON values from 26.1 authoring-API vocabulary before signatures are finalized.

---

## 2. Rule-Declare-DecisionTable

### COVERED

Current KDT is materially deeper than the 26.1 authoring skill and already covers:

- `pyColumns[].pyProperty`
- aligned `pyCondition[]`
- `pyOrConditions`
- range columns `pyUseRange` / `pyUseRangeMax`
- `pyResults`
- `pyPropertyColumns`
- `pyDefaultResultPropSet`
- `pyDefaultResult`
- `pyEvaluateAllRowsStr`
- `pyAllowedToReturnValuesStr`
- first-match and evaluate-all execution
- parameters/pages/context
- nested dependency scan
- row/property-action execution evidence
- allowed-result property sets
- read-before-write handling for compound property actions

### MISSING

No Pega 26.1 runtime-semantic unit was found that clearly needs to replace an existing KDT unit. Most additional 26.1 material is authoring/schema validation detail.

### CONFLICT — unresolved

**KDT-C1 — `pyOrConditions[].pyRowNum` indexing**

Current KDT:
- stored `pyRowNum` is the **zero-based executable-row index**;
- value is copied verbatim;
- `pyRowNum=1` means the second executable row;
- `-1` is a sentinel.

Pega 26.1 schema:
- describes `pyRowNum` as a **1-based row number**.

**KDT-C2 — property-column operators**

Current KDT:
- `pyDefaultPropertySetOperator` may represent `=`, `+`, `-`, `*`, `/`, `%`;
- cell shorthand may produce `+=`, `-=`, `*=`, `/=`, `%=`;
- compound actions read target before writing.

Pega 26.1 authoring schema/reference:
- enum is only `"="` or empty;
- multi-result reference says operator is always `"="`.

Existing RuleIQ trace contains `pyDefaultPropertySetOperator:"+="`, so the external schema is at least narrower than supported readback/runtime data. Canonical runtime semantics still require confirmation.

---

## 3. Rule-Declare-Pages

### COVERED

Current KDP covers:

- Data Page identity/reference
- `pyStructure`
- `pyScope`
- parameter binding
- runtime access classification
- simulation eligibility
- simulation identity/signature
- simulation materialization
- simulation audit
- loader dependency boundary

### MISSING

Pega 26.1 exposes additional source vocabulary not currently normalized in KDP:

- `ObjOpen`
- `ReportDefinition`
- `AggregateSources`
- `GenAI`
- `KnowledgeBuddy`
- `RoboticAutomation`
- `RoboticDesktopAutomation`
- ordered multi-source resolution through `pySourceWhen`
- final `Always` fallback
- source-state fields such as active-source `pyIsSimulated` and preserved `pyDisabledSource`

These are candidates for structural/source signatures, not automatic new simulation semantics.

### CONFLICT — unresolved

**KDP-C1 — meaning of `pyClassName`**

Current KDP:
- calls `pyClassName` the "apply-to class of the Data Page payload".

Pega 26.1:
- says Data Pages are class-less constructors;
- `pyClassName` is the class of the page returned, or the element class for list Data Pages.

**KDP-C2 — `pyScope` wire values/casing**

Current KDP:
- canonical values are `Thread`, `Requestor`, `Node`;
- only lowercase `"thread"` is specially normalized.

Pega 26.1 schema:
- enum is lowercase `"thread"`, `"requestor"`, `"node"`.

Need the exact values returned by RuleCrawler/RuleJSON in the supported environment.

---

## 4. Rule-Obj-When

### COVERED

Current KW aligns well with Pega 26.1 on:

- `pyCondition[]`
- `pyConditionLabel`
- `pyConditionValue1`
- `pyConditionValue1Purpose`
- `pyFunctionData`
- bound function parameters
- rule-level `pyParameters`
- `pyLogic`
- label-based boolean composition
- parentheses / AND / OR forms
- free-form expression conditions
- function-derived dependencies
- nested When dependencies
- `pxIsInPageListWhen(whenName, lookIn)` argument order and role

### MISSING / N/A-AUTHORING

Pega 26.1 contains more authoring/UI metadata (`pyAllowedFunctions`, `pyUIParameters`, form-rendering conventions). These are not needed in Semantic Signatures for ScenarioAuthor unless they affect runtime evaluation.

### External-source inconsistency, not a KA conflict

The 26.1 `Rule-Obj-When` skill says to substitute values into `pyUIParameters`, while the 26.1 `library-function-builder` explicitly says values must **not** be written there. Since ScenarioAuthor does not depend on `pyUIParameters`, this should be excluded from runtime signatures rather than reconciled into KW.

No unresolved runtime conflict requiring user input was identified here.

---

## 5. Rule-Utility-Function

### COVERED

Current KRUF already has the correct generic runtime architecture:

- detect function call
- bind to exact `Rule-Utility-Function` reference
- fetch concrete RUF
- use ordered `pyParametersDefinition[]`
- consume `pyParameterType`, `pyPegaType`, `pyParameterUsage`, `pyParameterMode`
- use `pyDescription` / `pyUsage`
- avoid inference from function name/type alone
- derive transitive rule dependencies only from concrete contract evidence
- preserve UNKNOWN when return semantics are insufficient

Pega 26.1 `library-function-builder` supplies alias templates and validates known function-call shapes, but it is not a replacement for fetched concrete RUF runtime contracts.

The official `pxIsInPageListWhen` alias signature:
`IsInPageListWhen({whenName}, {lookIn})`
matches current KW/KRUF semantics.

### MISSING

The Pega alias library can be used as a supplemental **known-signature cache** for explicitly documented aliases, but only when it does not override fetched concrete RUF evidence.

### CONFLICT

No unresolved runtime conflict identified.

---

# 3G-A current verdict

| KnowledgeArea | Covered | Missing | Unresolved conflicts |
|---|---|---|---:|
| Rule-Obj-Model | strong | additional action/JSON vocabulary | 3 |
| Rule-Declare-DecisionTable | very strong | mostly authoring-only | 2 |
| Rule-Declare-Pages | strong for RuleIQ simulation | broader source vocabulary | 2 |
| Rule-Obj-When | strong | mostly authoring/UI-only | 0 |
| Rule-Utility-Function | strong generic contract | optional alias cache | 0 |

One earlier conflict (`UPDATE_PAGE + WITH_VALUES_FROM` copy semantics) is already resolved in favor of the current KnowledgeArea.

## External references

- Rule-Obj-Model skill:  
  `plugins/pega/infinity-ai-plugins/claude/resources/26-1/skills/rules-rule-obj-model/SKILL.md`
- Rule-Obj-Model schema:  
  `.../rules-rule-obj-model/schema/rule-obj-model.json`
- Decision Table skill/schema/reference:  
  `.../rules-rule-declare-decision-table/`
- Data Page skill/schema:  
  `.../rules-rule-declare-pages/`
- When skill/schema:  
  `.../rules-rule-obj-when/`
- Function alias library:  
  `.../library-function-builder/`

No KnowledgeArea or ScenarioAuthor file has been changed in 3G-A.
