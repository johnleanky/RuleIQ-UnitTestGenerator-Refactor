# R55 Wave 3G-D — Offline Regression

## Scope

Data Transform / `Rule-Obj-Model` determinism hardening over W3G-C. No changes to other rule-type Knowledge Areas.

## Live defects targeted from `Wave3GC.zip`

The three byte-identical `PrepareCustomerCommunication` runs showed that W3G-C stabilized EDGEIR and producer identity but still allowed:

- target/context drift (`Primary.Addresses` vs `CustomerCommunication.Addresses`, and dropped `<APPEND>`);
- variable DEPIR occurrence cardinality / fetched-holder dependency leakage;
- holder abbreviation;
- ROM COVREQ activation drift (`all_R` vs `always`);
- WITNESS `RESOLVE REALIZED` pointing to Scenarios whose `covers` did not contain the COV edge set;
- AUDIT false PASS by counting planned realization instead of mechanically recounting frozen coverage.

## Validation results

- W3G-B semantic signatures: **30/30 PASS**
- W3G-C mechanical IR: **39/39 PASS**
- W3G-D Data Transform validation: **33/33 PASS**
- R47 independent validation: **18/18 PASS**
- R47 source-gate fixtures: **6/6 PASS**
- R47 DetermineCondition E2E: **2/2 PASS**
- R47 final structural validation: **17/17 PASS**

## W3G-D targeted gates

- `KT.38` is the sole ROM context transition program consumed generically by ScenarioAuthor.
- Core contains no hardcoded `UPDATE_PAGE` or `APPEND_AND_MAP_TO` classification.
- Canonical append child target is preserved as `<targetList><APPEND>`.
- `KT.39` defines immutable `occurrenceRef=<unitLocator>#<rawFieldPath>#<role>#<ordinal>`.
- Same KEY at multiple syntactic locations remains multiple D/DEPIR identities; physical fetch may deduplicate.
- Fetched-holder dependencies cannot leak into caller XMAP source-local depRefs.
- Holders cannot be abbreviated with ellipsis.
- `KT.40` makes every ROM non-atomic COVREQ `activation=all_R`.
- WITNESS/FREEZE/AUDIT use mechanical set inclusion over persisted coverage ids.
- Synthetic replay rejects the two observed false-REALIZED mappings and recomputes the affected case as 7/8, not 8/8.

Offline gate: **PASS**. Next gate is live repetition of `PrepareCustomerCommunication` only.
