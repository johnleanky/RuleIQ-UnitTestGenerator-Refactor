# R55 Wave 3G-D — Data Transform Live Acceptance Target

Source basis: user-provided `Wave3GC.zip` (`PXCONV-228011`, `PXCONV-228010`, `PXCONV-228001`).

For the next repeated byte-identical Data Transform run, require:

1. identical canonical ROM frame-derived producer/read paths in every run;
2. `APPEND_AND_MAP_TO` child writes retain the named-page root and literal `<APPEND>`;
3. every syntactic dependency occurrence has its own stable occurrenceRef/D/DEPIR row;
4. same dependency KEY may repeat across occurrences while RuleCrawler physical fetch is deduplicated;
5. caller XMAP.depRefs contain only caller-holder source-local occurrence ids;
6. every persisted holder is exact and never abbreviated;
7. ROM COVREQ identity and `activation=all_R` are identical across runs;
8. every `RESOLVE REALIZED` references a Scenario whose frozen covers contain every required edge id;
9. AUDIT actualCovered/missing is independently recomputed from frozen `SCENARIO.covers`; false 8/8 PASS is impossible.
