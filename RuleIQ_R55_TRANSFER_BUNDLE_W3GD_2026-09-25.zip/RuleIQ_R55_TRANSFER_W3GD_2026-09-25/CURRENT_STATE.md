# Current State — RuleIQ R55 through W3G-D

## Architecture

Pipeline:

`ScenarioAuthor -> UnitTestProjectionV3 -> Generator -> Candidate -> Validator`

Semantic pipeline:

`CRAWL -> IR -> MAP -> WITNESS -> FREEZE -> ORACLE -> DECIDE -> BUILD -> AUDIT -> PREPARE_ALL -> PERSIST_ALL -> GENERATE_ALL`

The project is eliminating nondeterminism by consolidating semantic authority and making semantic compilation mechanical, rather than adding RUT-specific prompt exceptions.

## Key history

### W3F-A.1
Mandatory diagnostic XMAP localized the original nondeterminism to the mapping from structured RuleJSON nodes into semantic IR. Byte-identical Data Transform operation trees could classify `UPDATE_PAGE` or `EXIT_MODEL` differently.

### W3G-B
Introduced KnowledgeArea `SEMANTIC_SIGNATURE` registries and generic ScenarioAuthor consumption. Producer classification became stable. Rule-Obj-Property symbolic indexes were modeled as property-reference semantic modifiers and not producers.

### W3G-C
Hardened semantic-signature transcription:
- canonical locator;
- atomic edge rows;
- occurrence-level dependency intent;
- canonical targets;
- source-local XMAP dependency ownership;
- deterministic COVREQ serialization;
- KDT inverse seed and unknown write-boundary protection.

Fresh W3G-C Data Transform runs then showed that producer/edge classification was stable, but Data Transform still drifted in context resolution, dependency occurrence census, and WITNESS/AUDIT coverage reconciliation.

### W3G-D — current baseline
Scope was deliberately narrowed to Data Transform only. Only two production artifacts changed:

1. `ScenarioAuthor System Prompt`
2. `Rule-Obj-Model Knowledge Area`

Implemented:

1. **KT.38 deterministic ROM context-frame stack**
   - target/source/current context is pushed mechanically for `UPDATE_PAGE`, `WITH_VALUES_FROM`, `APPEND_AND_MAP_TO` and child scopes;
   - canonical named-page roots and literal `<APPEND>` are propagated from context, not re-inferred later.

2. **KT.39 physical dependency occurrence identity**
   - one syntactic occurrence -> one D/DEPIR occurrence;
   - canonical occurrence identity is based on exact source unit / raw field path / role / ordinal;
   - same KEY may be fetched once physically but occurrence identities are never merged;
   - fetched-holder transitive dependencies cannot leak into caller XMAP depRefs;
   - holder identity is exact and must never be abbreviated.

3. **KT.40 closed ROM coverage constructor**
   - Data Transform structural relations and activation are mechanically constructed;
   - activation is `all_R`, not agent-chosen prose.

4. **Coverage reconciliation hardening**
   - `RESOLVE REALIZED` requires `COV.requiredEdges` to be a subset of the referenced `SCENARIO.covers`;
   - FREEZE repeats the check after replay;
   - AUDIT independently recomputes actual coverage from frozen `SCENARIO.covers` and may not treat RESOLVE counts as coverage evidence.

## Canonical runtime decisions already resolved by the user

- `UPDATE_PAGE + WITH_VALUES_FROM`: current Knowledge Area semantics are canonical. Target is an empty shell; WITH_VALUES_FROM sets/binds the active source. It does not implicitly copy source state into the target.
- Child operations under `WITH_VALUES_FROM`: current KA semantics are canonical.
- `APPEND_AND_MAP_TO + EXISTING_PAGE`: current KA semantics are canonical.
- Decision Table `pyOrConditions.pyRowNum`: current KA semantics are canonical (zero-based executable-row indexing with project sentinel behavior).
- Decision Table compound property operations/read-before-write semantics: current KA semantics are canonical.
- Data Page `pyClassName` and `pyScope`: current KA semantics are canonical for this project/runtime environment.
- Correct Data Transform action vocabulary includes `APPEND_AND_MAP_TO` and `APPEND_TO`.
- `APPEND/CURRENT/INSERT/LAST/PREPEND` are symbolic indexes in property references and belong to Rule-Obj-Property semantics, not `pyActionName`.

## What must NOT be done without a new finding

- Do not revert to hardcoded ScenarioAuthor rules such as `UPDATE_PAGE -> PROD`.
- Do not create a separate Property Reference Knowledge Area; symbolic-index semantics belong in existing Rule-Obj-Property.
- Do not introduce runtime probes to settle semantic conflicts; if a new real conflict with Pega external material appears, ask the user.
- Do not change Projection batching.
- Do not expand the current live-analysis scope to Decision Table until Data Transform is stable.

## Latest live artifact pending analysis

`WAVE3GD.zip` contains:

- `PXCONV-228024.txt`
- `PXCONV-228037.txt`
- `PXCONV-229002.txt`

This run was uploaded after W3G-D was installed. It has **not been fully analyzed yet**. Use the acceptance criteria in `02_VALIDATION/W3GD_LIVE_ACCEPTANCE.md`.
