# Suggested first prompt for the next chat

Use the attached RuleIQ R55 transfer bundle as the source of truth. Continue from W3G-D and restrict the analysis to Data Transform / `PrepareCustomerCommunication` only.

First read:
- `00_READ_ME_FIRST.md`
- `CURRENT_STATE.md`
- `02_VALIDATION/W3GD_LIVE_ACCEPTANCE.md`

Then analyze `04_LATEST_LIVE_RUN_UNANALYZED/WAVE3GD.zip`, which contains `PXCONV-228024`, `PXCONV-228037`, and `PXCONV-229002`.

Compare the byte-identical Data Transform runs mechanically across:
1. RuleJSON hash / source structure;
2. ROM context-frame results and canonical producer/read paths;
3. occurrence-level D/DEPIR identity and count;
4. exact holder identity;
5. XMAP source-local depRefs;
6. EDGEIR/PROD/COVREQ identity;
7. COVREQ activation;
8. RESOLVE vs frozen `SCENARIO.covers` subset correctness;
9. independently recomputed AUDIT actual coverage.

Do not modify files before reporting the live findings. Do not analyze DetermineChannel yet. If a remaining defect is found, localize it to the smallest mechanical contract and propose the minimum Data-Transform-only patch.
