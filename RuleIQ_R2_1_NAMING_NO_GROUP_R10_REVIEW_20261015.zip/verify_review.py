#!/usr/bin/env python3
"""Reproduce the two JSON-schema exact replacements and bounded naming edge checks.
Static proxy only; does not run Pega or an LLM.
"""
from pathlib import Path
import json,re,hashlib
from jsonschema import Draft202012Validator
R=Path(__file__).resolve().parent
M=json.loads((R/'EXACT_OLD_NEW.json').read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def name(rut,label):
    b=''.join(c for c in rut if c not in ' \t\r\n\f\v')
    if not re.fullmatch('[A-Za-z0-9_]+',b):raise ValueError('bad rut')
    if not re.fullmatch('(?!TC_)(?=.*[A-Za-z0-9])[A-Za-z0-9 _]+',label):raise ValueError('bad label')
    parts=[x for x in re.split('[ _]+',label) if x]
    component=''.join((x[0].upper() if 'a'<=x[0]<='z' else x[0])+x[1:] for x in parts)
    budget=49-min(8,len(b))
    component=component[:budget]
    result='TC_'+b[:49-len(component)]+'_'+component
    assert len(result)<=53
    return result
for m in M:
    old=R/'baseline'/m['file']; new=R/'staged'/m['file']
    a=old.read_text(); b=new.read_text()
    oldrule=json.dumps(m['old'],ensure_ascii=False)[1:-1]
    newrule=json.dumps(m['new'],ensure_ascii=False)[1:-1]
    assert a.count(oldrule)==1,m['file']
    assert a.replace(oldrule,newrule,1)==b,m['file']
    assert sha(old)==m['old_sha256'] and sha(new)==m['new_sha256']
    d=json.loads(b);Draft202012Validator.check_schema(d)
    assert len([q for q in d['x-ruleiq-compilerMappings'] if q['id']=='CM-NAME-001'])==1
    assert 'No hash, suffix, counter, ordinal, physicalGroupKey' in m['new']
for n in (1,12,35,41,49,100,10000):
    assert len(name('IsAccessAllowed','A'*n))<=53
assert name('IsAccessAllowed','Check Order')==name('IsAccessAllowed','Check_Order')
assert name('IsAccessAllowed','Check Order')!=name('IsAccessAllowed','Check Payment')
assert name('IsAccessAllowed','A'*200+' X')==name('IsAccessAllowed','A'*200+' Y')
for f in ('Core.txt','Generator.txt','V3.md','KW.txt','KRUF.txt'):
    assert sha(R/'baseline'/f)==sha(R/'staged'/f)
print('PASS: 2 exact JSON replacements, schema validity, no group key in naming, bounded technical lengths; unchanged 5 other components.')
