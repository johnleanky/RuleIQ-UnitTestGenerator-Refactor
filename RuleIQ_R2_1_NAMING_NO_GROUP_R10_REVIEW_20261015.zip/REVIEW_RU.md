# RuleIQ R2.1 — CM-NAME-001 Naming Correction (NO physicalGroupKey)

## Decision

User explicitly rejected using `physicalGroupKey` for technical naming. The earlier proposed `_Gnnn` suffix and related Core/Generator/V3 changes are **withdrawn** and **not implemented**. This package branches from unchanged R8 staged files, not the rejected draft.

## Proposed scope

Only two `CM-NAME-001` mappings change: current Standard and MultInpComb JsonSchema. The selected Schema remains the sole mapping owner. Core, KW, KRUF, Generator, V3 are byte-identical to the R8 staged corpus. No new fields or group identifiers enter target names.

Preserve current result for ordinary short semantic labels. For long labels, reserve up to 8 RUT characters and truncate only the **technical Scenario component** inside `RULE_NAME` to stay within 53 characters. `scenarios[n].name` and Candidate `Scenarios[n].Name` stay EXACT, without truncation. This is a design choice, not a Pega limitation proof; RUT reserve 8 is a bounded readability trade-off and can be revised before approval.

## Collisions

The mapping is non-injective: `Check Order` and `Check_Order` normalize identically. Long names that share the technical prefix can also collide. No honest hash-free, suffix-free naming algorithm can guarantee uniqueness for all legal source labels in a shorter fixed technical alphabet. Existing Core §11/§12.7 requires checking cross-group technical uniqueness at pre-FROZEN when the mapping is accessible and returning proven collisions to the Author semantic naming owner. This proposal does not add another owner or automatic arbitrary suffix. When the mapping is not accessible pre-FROZEN, Core currently allows marking uniqueness unverified; no runtime guarantee is established. This residual is explicitly OPEN and should not be presented as fully solved.

## Tests and limitations

The included Python test applies an explicitly disclosed static implementation of the declarative mapping, checks short-name backward compatibility, 53-char maximum, long semantic labels, normalization/prefix collisions, preservation of source Scenario fields, and JsonSchema compatibility on synthetic modifications of user-provided MultInpComb examples. No actual LLM Generator or Pega run occurred. Full project acceptance remains open.

## Policy status

Review proposal only, not deployed and not automatically approved. Original R8 copies and Library generator remain unchanged; R9 previous static reports need targeted re-review if this proposal is approved. Do not mix with abandoned group-suffix draft.
