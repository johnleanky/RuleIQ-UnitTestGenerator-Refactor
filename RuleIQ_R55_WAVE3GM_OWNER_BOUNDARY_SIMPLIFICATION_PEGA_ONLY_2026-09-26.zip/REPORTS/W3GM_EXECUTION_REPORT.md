# W3GM Owner-Boundary Simplification

Status: **STAGED_OFFLINE / READY_FOR_LIVE_ACCEPTANCE**

## Production footprint
Exactly three production files changed from W3GL:
- `01_PROMPTS/ScenarioAuthor_SystemPrompt.txt`
- `02_KNOWLEDGE_AREAS/Rule-Declare-DecisionTable_KnowledgeArea_REFERENCE.txt`
- `02_KNOWLEDGE_AREAS/Rule-Obj-Model_KnowledgeArea_REFERENCE.txt`

No Generator, Validator, target contract, Property/When/DataPage/RUF KA change.

## Implemented mechanisms
1. Decision Table `DTM` is lossless/source-indexed. Raw `pyRowNum` and physical source paths are preserved; DTE evaluates only DTM. Condition/action lexical roles cannot substitute for one another.
2. EVALUATE_ALL with scalar disabled yields `NO_SCALAR_VALUE`; ORACLE keeps the target and DECIDE must OMIT with `inactive_evaluate_all_scalar`. Empty-string/null/false surrogate values are illegal.
3. Standard WITNESS owns the single final replay and commits `PATH/EFFECT` once. Standard FREEZE is removed. Invalid local drafts are discarded before MemoryTemp.
4. ORACLE is literal projection of committed WITNESS EFFECT plus surviving caller-visible DTA. Structural parent/item targets coexist with scalar child targets and cannot be dropped as redundant.
5. Rule-Obj-Model producer census is bijective: every signature `sourceUnit=YES` with producer YES|CONDITIONAL maps to one PROD. `UPDATE_PAGE` cannot disappear by relevance reasoning.
6. Model Scenario basis is literal outcome-vector mutation from REFERENCE. One legal alternative mutation at a time; diagonal `T2,T4,T6` is explicitly illegal for the PrepareCustomerCommunication topology.
7. DEPIR mirror is removed from ScenarioTrace. DWL remains the sole dependency authority.
8. Page assertion target preservation remains exact. Structural self-page presence that has no representable nonempty relative v3 path is OMIT, not replaced by a child-property proxy.
9. Scenario names are mechanical (`Scenario <id>`) and therefore construction-safe for the 50-character contract.

## Validation
`W3GM_VALIDATION.json`: **106/106 PASS**.
The suite uses the five fresh `2318.zip` runs and verifies the observed failure modes, including Decision Table row association, `Param.Run`, producer census, scenario-vector isolation, literal structural outputs, RuleCrawler wire preservation, and lifecycle cleanup.

This is offline validation. Required live acceptance: run `DetermineChannel` at least 3 times and `PrepareCustomerCommunication` at least 3 times and compare intermediate state, not only Generator PASS.
