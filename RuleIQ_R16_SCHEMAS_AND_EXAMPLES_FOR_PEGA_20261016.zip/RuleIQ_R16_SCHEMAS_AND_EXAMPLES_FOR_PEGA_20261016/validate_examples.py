#!/usr/bin/env python3
"""Offline consumer verification; requires jsonschema>=4.18.
Verifies every candidate in the Pega JsonExample document against its matching
staged JsonSchema plus cross-field executable/informational contract checks.
Does not execute Pega or prove Author's source facts.
"""
import json
from pathlib import Path
from jsonschema import Draft202012Validator

base=Path(__file__).resolve().parent/'PEGA_UPLOAD'
pairs=[
 ('Rule-Test-Unit-Case', 4),
 ('Rule-Test-Unit-Case_MultInpComb', 5)
]
count=0
for prefix, expected_count in pairs:
    schema=json.loads((base/f'{prefix}-JsonSchema.json').read_text(encoding='utf-8'))
    examples=json.loads((base/f'{prefix}-JsonExample.json').read_text(encoding='utf-8'))
    Draft202012Validator.check_schema(schema)
    assert len(examples['Examples']) == expected_count, prefix
    validator=Draft202012Validator(schema)
    for i, candidate in enumerate(examples['Examples'], 1):
        validator.validate(candidate)
        rule=candidate['UnitTestRules'][0]
        assert rule['Name']==rule['RuleCode']['pyLabel'], (prefix,i,'label mismatch')
        executable=[s for s in rule['Scenarios'] if s['Testability']!='NotTestable']
        informational=[s for s in rule['Scenarios'] if s['Testability']=='NotTestable']
        for s in informational:
            assert s['ReasoningConfidence']=='Low'
            assert s['EvidenceSummary']['BlockingGaps']
            assert all(g['pyValue'] for g in s['EvidenceSummary']['BlockingGaps'])
        if executable:
            assert rule['RuleCode']['pyPurpose']==rule['Name']
            if prefix.endswith('MultInpComb'):
                blocks=rule['RuleCode']['pyExpectedResults']
                assert len(blocks)==1
                rows=blocks[0]['pyExpectedResults']
                assert len(rows)==len(executable), (prefix,i,'row count')
                for row in rows:
                    cells=row['pyExpectedResults']
                    assert cells[-1]['pyPropertyType']=='result'
                    assert sum(c['pyPropertyType']=='result' for c in cells)==1
        else:
            assert set(rule['RuleCode'])=={'pyLabel'}
        count+=1
        print(f'PASS {prefix} Example {i}')
print(f'ALL PASS: {count}/{count} candidate instances; schemas Draft 2020-12 valid.')
