# RuleIQ — Schema + JsonExample, R10 Rev2 alignment (16 Oct 2026)

## Что использовать в Pega

В каталоге `PEGA_UPLOAD/` лежат **четыре файла `.txt`** для соответствующих KnowledgeTool/Knowledge Area записей и четыре эквивалентных файла `.json`:

| Pega Knowledge Area | Файл |
|---|---|
| `Rule-Test-Unit-Case-JsonSchema` | `Rule-Test-Unit-Case-JsonSchema.txt` |
| `Rule-Test-Unit-Case-JsonExample` | `Rule-Test-Unit-Case-JsonExample.txt` |
| `Rule-Test-Unit-Case_MultInpComb-JsonSchema` | `Rule-Test-Unit-Case_MultInpComb-JsonSchema.txt` |
| `Rule-Test-Unit-Case_MultInpComb-JsonExample` | `Rule-Test-Unit-Case_MultInpComb-JsonExample.txt` |

**Важно:** `.txt` и `.json` содержат одинаковые байты для каждой записи. Это полное содержимое, а не patch. Файлы `JsonExample` имеют формат `{ "Template": ..., "Examples": [ <candidate>, ... ] }`, как в предоставленных пользователем исходных Knowledge Area примерах. Именно **каждый элемент `Examples[]`** проверяется по соответствующей JsonSchema. Обёртка Examples/Template не является Candidate.

## Версионная основа и изменения

- **JsonSchema обеих веток:** побайтные копии `staged/StandardSchema.json` и `staged/MultInpCombSchema.json` из `RuleIQ_R2_1_NAMING_R10_REV2_WITH_JSON_EXAMPLES_20261015.zip`; никаких новых изменений схем нет.
- **JsonExample Standard:** сохранены первые 3 валидных R10 Rev2 примера; добавлен 4-й **синтетический** информационный `NotTestable/Low`, `EvidenceSummary.BlockingGaps[]`, display-only `RuleCode.pyLabel`.
- **JsonExample MultInpComb:** сохранены первые 3 валидных R10 Rev2 примера; добавлены 4-й **синтетический mixed-testability** пример (3 исполняемых сценария / 3 Decision rows + 1 NotTestable без строки) и 5-й **синтетический informational-only** пример (`NotTestable` с gaps, RuleCode только `pyLabel`). В mixed-примере техническое имя, исполняемые Scenario и Decision rows исходного примера сохранены, добавлен только диагностический Scenario.
- **Все расширения примеров SYNTHETIC**: нельзя выдавать их за доказательства поведения `IsAccessAllowed` или за данные из `PLAN/PROVED/FROZEN` реального RuleIQ.

## Почему именно эта версия

В `PXCONV-265881` `KnowledgeTool` вернул **старую** `Rule-Test-Unit-Case_MultInpComb-JsonSchema`, где `EvidenceSummary.additionalProperties=false` и отсутствует `BlockingGaps`. Это вызвало валидный `SEMANTIC_REJECT`. Предлагаемая R10 Rev2 MultInpComb-схема содержит `BlockingGaps`, display-only информационный `RuleCode`, mixed-testability и согласованное `CM-NAME-001`.

Схема из этого пакета ещё **не подтверждена как развернутая в Pega**. Перед заменой по Change Policy R2.1 сохраните текущие редакции обеих JsonSchema/JsonExample, сравните с этими файлами, согласуйте diff и затем загружайте полные согласованные пары. После обновления **запросите фактическую JsonSchema через KnowledgeTool** и удостоверьтесь, что возвращается новая версия, а не старая.

## Локальная проверка

- `VALIDATION_REPORT.json`: 54/54 локальных структурных и кросс-полевых проверок.
- `python validate_examples.py`: повторная проверка всех **9/9 Candidate examples** по JSON Schema Draft 2020-12 и ключевым невыраженным JSON Schema связям (RuleCode identity, mixed subset/rows, informational metadata).
- `R10_REFERENCE/`: неизменённые примеры-источники R10 Rev2; сохранены три исходных примера в каждом JsonExample.
- `SHA256SUMS.txt`: контроль целостности.

Ни один из этих тестов не запускает Pega и не доказывает семантическую корректность живых ScenarioAuthor/Generator/Validator.
