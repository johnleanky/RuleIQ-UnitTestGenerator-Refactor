# G3 — Control-only vector set + exact replay semantics — VALIDATED PASS

Changed ScenarioAuthor only.

Vector construction no longer consults carrier/data feasibility. Decision coordinates are exact groups of MAP OUTCOMEs sharing the same `OUTCOME.source`; reference is derived from static control reachability; every alternative is a byte-copy of reference with one coordinate changed, followed only by reachability pruning/extension.

Fresh Prepare topology simulation produces exactly, in order:
1. `T2,T3,T5`
2. `T1`
3. `T2,T4,T5`
4. `T2,T3,T6`

`T2,T4,T6` is unreachable as a constructed alternative.

Replay now consumes already-fetched RUF contracts literally. For a fetched contract stating “index of the first entry” and “1-based / -1 if no match”, list evaluation is 1..N and stops at the first matching item. Two matching items therefore deterministically return index 1, never 2.

## Final carrier-search refinement
Carrier assignments use finite grounded `DOMAIN(seed)` values and lexicographic Cartesian-product enumeration; first exact replay match wins. Vector is never modified by carrier failure.
