# G6 — Exact EFFECT/DTA -> assertion census — VALIDATED PASS

Changed ScenarioAuthor only.

`PROJECT_ASSERTIONS` now uses literal arrays `ORDER` and `CHAIN` populated only by committed original-RUT EFFECT targets plus allowed non-primary dependency-DTA targets. No parent/child/sibling/carrier-only target may be synthesized.

State mapping is mechanical:
- structural Page/PageList/PageGroup + PRESENT -> Page Exists;
- same structural target + ABSENT -> Page Not exists;
- concrete scalar -> Property via PROPERTY_SHAPE;
- Param -> Param;
- NO_SCALAR_VALUE / UNKNOWN -> existing terminal omission semantics.

Fresh fixture contains five executed P4 APPEND effects targeting exactly `CustomerCommunication.Addresses(1)`; the transform therefore yields five Page Exists claims and zero inferred parent `CustomerCommunication.Addresses` targets.
