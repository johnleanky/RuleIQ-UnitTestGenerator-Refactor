# G5 — Canonical physical Property compiler + pyPageName + packing — VALIDATED PASS

Changed Generator, Validator, Standard JsonSchema compiler mapping and Standard JsonExample.

Canonical physical algorithm:
- one Property block per `(effectiveStepPage,effectiveStepPageClass)` key;
- block created at first key occurrence, all later same-key Property/Param leaves append in source order;
- no split same-key blocks and no merge across different keys;
- regular Property child receives exact `pyPageName` from fullTarget minus final scalar segment;
- regular child copies source `applyToClass`, `mode`, optional `parentMode`, comparator and expected;
- Param keeps the primary Property block shape and omits `pyPageName`, `pyPropertyRealName`, `pyParentPropertyMode`;
- Page assertion family remains separate and continues to use full absolute page path without `pyPageName`.

Synthetic CustomerCommunication fixture: 3 nested scalar assertions -> 1 Property block, 3 children, all `pyPageName=CustomerCommunication.Addresses(1)`.
Standard examples validate under the updated Draft-2020-12 schema.
