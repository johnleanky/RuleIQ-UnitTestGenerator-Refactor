# G4 — Semantic Property projection metadata — VALIDATED PASS

ScenarioAuthor and Generator source grammar are synchronized.

For every scalar Property target, ScenarioAuthor now computes one exact `PROPERTY_SHAPE`:
- `page/path` from frozen TARGET_CONTEXT;
- `mode` from terminal scalar property definition;
- `applyToClass` required, from terminal property owner class;
- `parentMode` required iff the terminal scalar is nested under a collection ancestor, using the nearest ancestor's exact collection mode.

Fixture `CustomerCommunication.Addresses(1).pyCity` deterministically becomes:
`page=CustomerCommunication`, `path=.Addresses(1).pyCity`, `applyToClass=Data-Address-Postal`, `mode=Text`, `parentMode=PageList`.

The old phrase `parentMode only when needed` is removed.
