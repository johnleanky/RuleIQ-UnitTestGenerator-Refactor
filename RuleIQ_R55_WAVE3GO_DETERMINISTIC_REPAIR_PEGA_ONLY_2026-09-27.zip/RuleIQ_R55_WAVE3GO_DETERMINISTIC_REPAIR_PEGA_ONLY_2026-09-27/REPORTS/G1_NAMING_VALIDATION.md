# G1 — Deterministic semantic scenario naming — VALIDATED PASS

Changed ScenarioAuthor only.

Algorithm:
`SCENARIO.name = NAME50(SCENARIO.given)` where NAME50 performs ASCII sanitization, space collapse and longest whole-token prefix <=50. It never uses Scenario ids, group ids or hashes. A collision is resolved by making `given` semantically distinguishing from already-frozen VECTOR/CARRIER facts before WITNESS commit; downstream never renames.

Regression:
- removed hard-coded `Scenario S<n>` naming;
- four fresh-fixture givens produce four unique semantic names, all <=50;
- no Generator/target naming algorithm changed.
