# G2 — Exact static dependency census — VALIDATED PASS

Changed ScenarioAuthor only.

`STATIC_SCAN(holder)` is now a closed serialization algorithm over `KA.SOURCE_UNITS -> KA.DEPENDENCY_FIELDS -> KA.DEPENDENCY_TOKENS`, with D ids allocated only after the full tuple list exists.

Important deterministic consequence for the live Prepare fixture:
- the 8-READY run differed from both 10-READY runs by exactly two missing direct source occurrences: `RUF@@UTILITIES!ISINPAGELISTWHEN` and `RUF@@UTILITIES!INDEXINPAGELISTWHEN`;
- both calls occur as executable `@Function(...)` tokens in KT.39-active Model expressions;
- the new scan serializes every such token before any fetch dedup/reachability reasoning, so neither can be suppressed by Scenario selection or `pxRuleReferences` handling.
