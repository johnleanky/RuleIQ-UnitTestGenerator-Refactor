# G0 — Baseline / live failure census — VALIDATED PASS

Fresh fixture: `Wave3GN-2221.zip` with three runs: PXCONV-233001, 233011, 233020.

Stable/proven-good W3GN facts preserved for W3GO:
- exactly one WITNESS commit/run;
- zero INVALIDATE, Standard ORACLE, Standard DECIDE commits;
- IR producer census = 9 in all runs;
- RuleCrawler W3GK wire remains valid;
- source-indexed DTM / NO_SCALAR_VALUE / live-Pega Page parent+Property-child mapping retained.

Confirmed regressions to repair:
- first-wave READY census 8/10/10: direct RUF occurrences may disappear;
- only one run has the canonical vector set {T1,T2,T3,T5,T2,T4,T5,T2,T3,T6};
- semantic scenario names are missing/generic (`-` or `Scenario S<n>`);
- one replay resolves IndexInPageListWhen to 2 although item 1 satisfies the invoked When;
- Property Projection metadata (`parentMode`) drifts across identical RUT runs;
- physical Property children can omit pyPageName and same-step-page Property leaves are split into separate top-level blocks;
- PROJECT_ASSERTIONS may miss an executed append Page target and may introduce a structural target absent from EFFECT.
