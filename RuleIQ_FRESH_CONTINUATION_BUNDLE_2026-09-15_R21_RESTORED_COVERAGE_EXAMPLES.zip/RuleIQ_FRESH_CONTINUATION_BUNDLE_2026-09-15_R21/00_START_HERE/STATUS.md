# RuleIQ Unit Test Pipeline — Current Status

**Bundle date:** 2026-09-15  
**Authority:** this bundle is the sole current project version. `STATUS.md` describes only active behavior. `00_START_HERE/VALIDATION_HISTORY.md` is historical/non-authoritative.

## Current architecture

- **Scenario Author** owns RUT semantics, dependency closure, Scenario Compiler `I -> W -> F -> B -> A`, physical grouping and immutable `UnitTestProjectionV3` source materialization.
- **Unit Test Generator** deterministically compiles one persisted Projection into Candidate versions, owns Candidate repair/retry orchestration, consumes Validator outcome only from exact Candidate Memory state, and writes the terminal Generator outcome only to the exact source Projection lifecycle fields.
- **Validator** independently reads the exact Projection + Candidate, validates schema/fidelity/target invariants without redefining Author semantics, and is the sole writer of Candidate validation lifecycle state.
- Delegated Agent assistant responses are non-authoritative. Generator returns exactly `ACK`; Author ignores it. Memory row state is the correctness boundary.

## Exact case identity

`CASE_ID_RAW` is opaque case-sensitive text.

- Author owner: exact `application_context.caseID`.
- Generator owner: exact `Invocation.CaseID` received from Author.
- Validator owner: exact `Invocation.CaseID` received from Generator.
- Every Memory `pxCaseID`, Validator `JsonValidationTool.CaseID`, and delegated Agent Invocation `CaseID` must preserve `CASE_ID_RAW` character-for-character.

Example: if `application_context.caseID` is `RULEIQ-WORK GENUT-91061`, that exact full value must propagate; bare `GetCaseData.pyID=GENUT-91061` is not an equivalent Memory/transport CaseID.

## Current execution order

```text
Global dependency closure + semantic execution
-> I -> W -> F
-> freeze complete physical group set
-> B -> A; require A=PASS

PREPARE_ALL
-> materialize + self-validate one complete UnitTestProjectionV3 per frozen group
-> require exact group/projection census
-> zero Memory writes / zero Generator calls on preparation failure

PERSIST_ALL
-> WriteMemory every prepared Projection in frozen order
-> freeze ordered PROJECTION_QUEUE(groupId, projectionPayload, projectionGUID, PENDING)
-> require exact census and distinct nonempty GUIDs
-> any write/correlation/census failure stops the run with zero Generator calls

GENERATE_ALL
-> NEXT = first PENDING queue row
-> invoke Generator exactly once; ignore assistant response
-> fresh GetMemory(exact Projection GUID)
-> Passed + OK + ProcessingFeedback="" => PENDING -> DONE
-> otherwise stop Failed; later persisted Projections remain unchanged/unprocessed
-> continue until no PENDING row remains

COMPLETE
-> legal only when DONE_COUNT == QUEUE_COUNT and PENDING_COUNT == 0
```

No UnitTestGenerator call is legal until **all** frozen physical groups have successfully persisted Projections. This makes the full ScenarioAuthor output set materially visible in Agent Memory before downstream generation begins.

## Active Memory / lifecycle contract

- Tool input case argument remains `pxCaseID`; successful Memory responses use `CaseID`.
- Canonical lifecycle fields: `pyStatusValue`, response `RouterKey`, input `pyRouterKey`, and `ProcessingFeedback`.
- Success terminal state requires exact `ProcessingFeedback=""`; failed/non-OK state requires nonempty feedback.
- `pyPayload`, identity, type, group, GUID and case ownership are immutable after create.
- **Candidate lifecycle owner:** Validator; **consumer:** Generator.
- **Projection terminal lifecycle owner:** Generator; **consumer:** Scenario Author.
- `GENERATOR_REPAIR` is internal to Generator <-> Validator and is invalid on Projection.

## Active Projection / target invariants

- Source `UnitTestProjectionV3.rut` has `{name,applyToClass}` only; source-side `singlePage` is absent.
- Every frozen non-primary runtime page used by setup/action/assertion/CTX is emitted in Projection `pages` with its grounded class and becomes `pyPagesAndClasses` downstream.
- Data Page simulation setup source is `{class,data}`; root `data` omits `pxObjClass`, while resolved nested Page/PageList/PageGroup instances retain exact `pxObjClass`.
- Generator serializes every Data Page simulation setup with fixed `pySetupPageName="PrimaryPage"` and `pyPageDetails.pxObjClass=class`; it does not infer classes.
- Physical `pyIsSinglePageImplementation` is target-owned.
- `physicalGroupKey/Gnnn` is correlation/group identity only and never participates in target naming.
- `CM-NAME-001` derives separator-free `TC_` names only from semantic labels, e.g. `City Not Valid Exit -> TC_CityNotValidExit`.
- ScenarioAuthor `_DWLPlan` requires one ordered `OUT=[KEY...]`, independently reconstructed `ACT=[KEY...]`, and literal ordered `OUT == ACT` before RuleCrawler.
- Executable target compilation is schema-owned: Generator/Validator request only selected JsonSchema + JsonExample; target KnowledgeArea is not part of runtime.
- JsonExample envelope is `{Template,Examples[]}`: `Template` alone owns `pyRuleSet`/`pyRuleSetVersion`; `Examples[]` is non-authoritative serialization illustration. `Examples[0]` preserves the pre-R20 coverage-rich Standard/MultInpComb canonical example; `Examples[1]` and `[2]` add causally coupled Page-DP and List-DP simulation candidates.
- Semantic RUT/dependency Knowledge Areas remain ScenarioAuthor-only.

## Active issue / repair behavior

- Validator and Generator share one closed active catalog with **12 reachable codes**.
- JsonValidation non-success shapes remain unverified and fail closed through `JSON_VALIDATION_TOOL_ERROR/HUMAN_REVIEW`.
- Validator writes Candidate lifecycle; Generator ignores Validator assistant response and fresh-reads Candidate Memory.
- Generator returns exactly `ACK`; Author ignores it and fresh-reads Projection Memory.

## Validation state

**Historical static baseline:** `R0-R16 PASS (STATIC)`  
**R15 final regression:** `172/172 PASS`  
**R15 ScenarioAuthor §2-§4 semantic coverage:** `133/133 PASS`  
**R16 core semantic/regression suite:** `139/139 PASS`  
**R16 final cross-bundle synchronization gate:** `147/147 PASS`  
**R17 CaseID-source validation:** `PASS (contextual/textual semantic review)`  
**R18 simulation/page materialization validation:** `PASS (static semantic/schema review; live Pega replay pending)`
**R19 schema-owned target compiler validation:** `PASS (static semantic/schema review; live Pega replay pending)`  
**R20 JsonExample illustration-library validation:** `PASS (6/6 example candidates schema-valid; static semantic review; live Pega replay pending)`  
**Analysis mode:** `TEXT_SEMANTIC_ONLY=true`

R20 changes only target-example consumption on top of R19:
- both executable JsonExample artifacts use `{Template,Examples[]}`;
- `Template` preserves the existing two target-owned ruleset fields;
- each `Examples[]` library contains compact no-simulation, Page DP, and List DP full candidates with synthetic `ZqxExample-*` names;
- Generator may use examples only to illustrate HOW an already-required schema mapping is serialized; Validator ignores examples for validation.

R18 adds one projection/materialization correction on top of R17:
- Author carries already-resolved simulation setup-page class as `{class,data}` and preserves resolved nested page classes in `data`;
- frozen non-primary runtime named pages must reach Projection `pages`;
- Generator maps simulation setup deterministically to fixed `PrimaryPage` plus `pyPageDetails.pxObjClass=class`;
- Standard/MultiInput target schemas enforce `PrimaryPage` and root simulation `pxObjClass`.

R19 moves target compiler mapping from target Knowledge Areas into selected JsonSchema extensions; JsonExample remains template-only (`pyRuleSet`/`pyRuleSetVersion`).

R19 prompt word-count proxy versus R18 (word proxy only, not exact Claude tokenization):

| Prompt | R18 | R19 | Delta |
|---|---:|---:|---:|
| ScenarioAuthor | 8,934 | 8,934 | 0 |
| Generator | 3,797 | 3,269 | -528 |
| Validator | 3,249 | 2,888 | -361 |
| **Total** | **15,980** | **15,091** | **-889** |

Historical R18 prompt word-count proxy versus R17:

| Prompt | R17 | R18 | Delta |
|---|---:|---:|---:|
| ScenarioAuthor | 8,863 | 8,934 | +71 |
| Generator | 3,793 | 3,797 | +4 |
| Validator | 3,249 | 3,249 | 0 |
| **Total** | **15,905** | **15,980** | **+75** |

R18 execution/validation checkpoints completed:
- Author simulation source grammar and nested-class materialization reviewed in context;
- named runtime page -> Projection `pages` propagation reviewed against ROOT/CTX/assertion rules;
- Generator grammar and both target schema mappings synchronized;
- Standard/MultiInput schemas parse as JSON and their canonical examples still validate;
- whole-bundle contextual search found no active `{name,data}` simulation setup-page source contract or rule preserving a runtime page name as Data Page `pySetupPageName`.

No fixtures were created/updated and no SHA/hash/checksum/fingerprint acceptance checks were used.

## External evidence still pending

Static validation does not prove live Pega behavior. Run a fresh multi-group E2E replay and verify:

1. exact `application_context.caseID` reaches Author Memory calls -> Generator Invocation/Memory calls -> Validator Invocation/JsonValidationTool/Memory calls character-for-character unchanged, even when `GetCaseData.pyID` differs;
2. all Projection rows are persisted before the first Generator invocation;
3. if a Projection write fails, no Generator is invoked;
4. Generator returns only `ACK`, and Author routing depends only on fresh Projection Memory;
5. when a Generator stops on an early group, later Projection rows remain visible and unprocessed;
6. all persisted queue entries are invoked exactly once on a successful run.

If the actual tool-call argument already equals exact `application_context.caseID` but Pega itself stores/returns a different value, treat that as a Pega implementation/mapping defect; prompt changes cannot repair runtime changes after the call boundary.

## Exact next action

Deploy R19 and replay the reported Data Page case. Verify Projection carries `pages.CustomerCommunication=<resolved class>` and simulation `{class:"Data-Customer",data:...}` with nested `Addresses[].pxObjClass`; Candidate must emit `CustomerCommunication` in `pyPagesAndClasses`, `pySetupPageName="PrimaryPage"`, and root/nested simulation classes. Also retain the R17 exact CaseID propagation check.


## R19 target-compiler migration

- `Rule-Test-Unit-Case*_KnowledgeArea` runtime artifacts removed.
- Standard schema owns `CM-EXEC-001` + `CM-ASSERT-STD-001`; MultiInput owns `CM-EXEC-001` + `CM-WHEN-001`; both retain `CM-NAME-001`.
- Generator/Validator executable KnowledgeTool batches are now JsonSchema + JsonExample only.
- JsonExamples were not changed.
- No fixtures or SHA/hash/checksum/fingerprint acceptance checks were used.
