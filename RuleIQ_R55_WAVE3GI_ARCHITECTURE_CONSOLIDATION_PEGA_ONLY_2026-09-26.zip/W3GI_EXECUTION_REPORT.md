# RuleIQ R55 W3GI — Architecture Consolidation Execution Report

Status: **STAGED_OFFLINE / LIVE PEGA REGRESSION PENDING**
Date: 2026-09-26

## Goal
Reduce the ScenarioAuthor execution space rather than add gates: one semantic owner per fact, structured evidence at the owner phase, downstream copy/reconciliation only, and AUDIT as a lineage checker rather than a second semantic compiler.

## Baselines
- ScenarioAuthor baseline: W3GH `ScenarioAuthor_SystemPrompt.txt`, SHA-256 `3b57dad13a85c41fa96bc7b1c06a1de984eb6d4712435bee5406fcf33d9fcd3e`.
- Model KA baseline: exact live KnowledgeTool text observed in GENUT-103004, SHA-256 `35458710cb727f36b79eb72f8dbd2e9dec768e0f1c6bfce5725541b8a5e3ed4b`.
- Decision Table KA baseline: exact live KnowledgeTool text observed in GENUT-103004, SHA-256 `720143d9828b51aeb743182e23d99c301ff226446f7a97ea12988d64c4e62a39`.

## Production footprint
Exactly three production artifacts changed:
1. `01_PROMPTS/ScenarioAuthor_SystemPrompt.txt`
2. `02_KNOWLEDGE_AREAS/Rule-Obj-Model_KnowledgeArea_REFERENCE.txt`
3. `02_KNOWLEDGE_AREAS/Rule-Declare-DecisionTable_KnowledgeArea_REFERENCE.txt`

Not changed: Rule-Obj-Property KA, Rule-Declare-Pages KA, Rule-Obj-When KA, RUF KA, UnitTestGenerator prompt, Validator prompt, target schemas/contracts.

## Executed stages

### Stage 0 — ownership audit
Completed. Main contradictions found:
- DT evidence was required conceptually but WITNESS could not persist DTM/DTE/DTA while FREEZE/AUDIT were expected to use/reconstruct it.
- helper-derived When class had more than one plausible derivation path despite CTX_READY/KEY_STABLE.
- Property mode was known but simulation CARRIER shape was still freely authored.
- dependency DTA effects and original Param writes could disappear before ORACLE.
- AUDIT repeated semantic reasoning and therefore reproduced upstream mistakes.

### Stage 1 — KA/Core boundary
Completed.
- Model KA retains domain semantics but removes workflow/assertion prose where it competed with Core.
- Decision Table KA supplies exact existing DTM/DTE/DTA records as internal execution evidence; narrative cannot substitute for them.
- No new KA mechanism or marker family was added.

### Stage 2 — DWL context-derived key ownership
Completed.
- Page/list helper When occurrence remains `key=?`, `state=CTX` until the final provider Property definition proves `pyPageClass`.
- Caller class, holder class, Data Page root class and raw reference class cannot independently promote that occurrence.
- Promotion updates the same D row only.

### Stage 3 — Decision Table structured evidence
Completed using existing KDT contracts.
- WITNESS owns persisted DTM/DTE/DTA evidence.
- WHY is summary only.
- FREEZE consumes the persisted evidence and does not recompute DT rows/actions.
- KDT.12 remains a domain-local consistency check on one frozen input, not a downstream second execution path.

### Stage 4 — typed execution CARRIER
Completed.
- Nested CARRIER payload shape must follow already-CLOSED Property mode.
- PageList is an ordered array of page objects.
- `pxResults` cannot be inserted as a generic PageList wrapper unless that segment literally exists in the source/seed path.
- Projection preserves the frozen CARRIER shape exactly.

### Stage 5 — effect/output propagation
Completed.
- Every executed original-RUT `Param.*` write remains in OUTPUT membership, even when DECIDE later has to OMIT its value.
- Caller-visible FINAL DTA targets surviving caller execution enter RUT output lineage.
- `sourceRefs` support either PROD/PATH/EFFECT lineage or persisted DTE/DTA lineage; no target-name inference.

### Stage 6 — scenario algorithm preservation
Completed.
- W3GH REFERENCE + single-change isolation + interaction closure remains intact.
- No return to neutral/profile-only replacement logic.
- PrepareCustomerCommunication fixture derives four canonical basis profiles; diagonal three does not satisfy the basis.

### Stage 7 — AUDIT simplification
Completed.
- AUDIT is read-only reconciliation.
- It does not reconstruct scenarios, re-evaluate DT, re-resolve classes, reinterpret Property modes, or reselect assertions.
- Existing AUDIT counters are now mechanically derived from active structured rows.
- Missing required evidence is FAIL; AUDIT never fills the gap by reasoning.

### Stage 8 — Projection
Completed.
- Projection remains mechanical compilation/copy.
- It cannot repair class, Page/PageList shape, missing OUTPUT, or assertion choice.

### Stage 9 — residual cleanup
Completed.
- Removed contradictory “DT records are internal reasoning only / do not persist” language.
- Removed PROD-only sourceRefs assumptions.
- Removed Model KA assertion/workflow wording where domain facts were sufficient.

## Regression result
`W3GI_OFFLINE_VALIDATION.json`: **42/42 PASS**.

Covered regressions include:
- canonical four-scenario basis and rejection of diagonal three;
- page-list helper class resolution;
- GENUT-103004 DT row matching (`pyText=2`, `pyTempInteger=6` => both rows; no-match fixture => no rows);
- bad `Addresses` Page-shaped simulation rejected for PageList;
- correct PageList array shape accepted;
- `Param.Run`, `Primary.pyName`, `Primary.pyValue` output census preservation;
- missing DTE, wrong carrier shape, missing OUTPUT and missing DECISION route to FAIL;
- mechanical AUDIT counters;
- DTA source lineage;
- no RuleCode contract in live Decision Table KA.

## Unchanged contracts verified byte-for-byte against W3GH
- §3.6 Property/assertion physical semantics
- §6.4.3 Executable Standard assertion grammar
- §7 Projection-first persistence and Generator handoff

## Token/size effect
ScenarioAuthor prompt:
- W3GH: 195,855 bytes / 23,542 whitespace-delimited words
- W3GI: 186,619 bytes / 22,351 whitespace-delimited words
- reduction: 9,236 bytes (~4.7%) and 1,191 words (~5.1%)

## Required live acceptance
This bundle is not yet live-Pega verified. Run at minimum:
1. PrepareCustomerCommunication twice: exact same DEPIR and canonical four scenarios; AUDIT PASS only on exact basis.
2. DetermineChannel: DTM/DTE/DTA present; S1 both rows with temp=6; S2 no-row path; `.pyName` and `Param.Run` remain in output lineage.
3. GENUT-103004 simulation: `Addresses` must materialize as PageList-compatible structure with no Page/PageList mode warning.
4. Negative mutation: wrong helper When class, wrong PageList shape, missing DTE, or missing OUTPUT must fail before persistence.
