# RuleIQ Unit Test Pipeline — Current Deployment Package

Clean deployment package containing only current promoted prompts and runtime/reference artifacts. Historical remediation material, validation scripts, hashes/checksums, and offline regression fixtures are intentionally excluded.

## 01_PROMPTS

- `ScenarioAuthor_SystemPrompt.txt` — current A8E Author prompt.
- `UnitTestGenerator_SystemPrompt.txt` — current Generator prompt.
- `Validator_SystemPrompt.txt` — current Validator prompt.

## 02_KNOWLEDGE_AREAS

- `Rule-Test-Unit-Case_KnowledgeArea.txt` — shared Standard target/compiler reference for Generator + Validator.
- `Rule-Test-Unit-Case_MultInpComb-KnowledgeArea.txt` — shared Rule-Obj-When / MultiInput target/compiler reference for Generator + Validator.
- `Rule-Obj-When_KnowledgeArea_REFERENCE.txt` — source-rule reference used by Author when applicable.

## 03_TARGET_CONTRACTS

Exact logical KnowledgeTool target-contract keys:

- `Rule-Test-Unit-Case_JsonSchema.txt`
- `Rule-Test-Unit-Case_JsonExample.txt`
- `Rule-Test-Unit-Case_MultInpComb-JsonSchema.txt`
- `Rule-Test-Unit-Case_MultInpComb-JsonExample.txt`

The JsonExamples are deliberately coverage-rich canonical examples, not minimal fixtures. They demonstrate multiple supported assertion/comparator/type patterns while remaining compatible with the current Generator mapping and schemas.

## 05_TOOLS

- `Memory_GenAI_Tools_Contract.md` — authoritative single-record Memory tool contract.
- `Memory_GenAI_Tools_Pega_Implementation_Spec.md` — Pega implementation specification.
- `Required_Runtime_Tools.md` — runtime tool dependency list.

## Scope boundary

Offline Projection→Candidate fixtures are not included because they are regression/testing artifacts rather than Pega deployment artifacts. Live A4 KnowledgeTool verification and A9 runtime execution remain separate evidence steps.
