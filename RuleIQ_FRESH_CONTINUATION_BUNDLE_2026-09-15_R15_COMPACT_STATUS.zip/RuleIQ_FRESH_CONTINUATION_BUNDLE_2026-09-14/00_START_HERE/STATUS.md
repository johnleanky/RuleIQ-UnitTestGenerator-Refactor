# RuleIQ Unit Test Pipeline — Current Status

**Bundle date:** 2026-09-15  
**Authority:** this bundle is the sole current project version. `STATUS.md` describes only the active state. Historical refactoring/evidence is retained separately in `00_START_HERE/VALIDATION_HISTORY.md` and is non-authoritative for runtime behavior.

## Current architecture

- **Scenario Author** owns RUT semantics, dependency closure, Pega casting/type semantics, scenario construction/grouping, assertions/simulations, and `UnitTestProjectionV3`.
- **Unit Test Generator** deterministically compiles `UnitTestProjectionV3 -> UnitTestCandidate`, owns Candidate repair/retry orchestration, consumes Validator outcome only from exact Candidate Memory state, and writes terminal Generator outcome only to the exact source Projection lifecycle fields.
- **Validator** independently reads the exact Projection + Candidate, checks schema/fidelity/target invariants without redefining Author semantics, and is the sole writer of Candidate validation lifecycle state.
- Delegated Agent assistant responses are **non-authoritative transport noise** at both inter-agent boundaries. Exact Memory row state is authoritative.

## Current execution order

```text
Global dependency closure + semantic execution
-> I -> W -> F
-> freeze complete physical group set
-> B -> A, require A=PASS
-> for each frozen physical group in order:
     Author materializes + self-validates one Projection
     -> WriteMemory(Projection; lifecycle empty)
     -> invoke Generator once; ignore Generator assistant response
        -> Generator reads exact Projection
        -> compile + WriteMemory(Candidate; lifecycle empty)
        -> invoke Validator; ignore Validator assistant response
           -> Validator validates exact Projection + Candidate
           -> UpdateMemory(Candidate status/router/ProcessingFeedback)
        -> Generator fresh GetMemory(exact Candidate GUID)
        -> repair/new Candidate loop only for GENERATOR_REPAIR
        -> UpdateMemory(exact Projection terminal status/router/ProcessingFeedback)
     -> Author fresh GetMemory(exact Projection GUID)
     -> next group only on Passed + OK + ProcessingFeedback=""
```

Dependencies are resolved globally before Projection processing. Reused dependencies reuse already resolved evidence rather than being re-crawled per Projection. After the first successful Projection `WriteMemory`, any need for semantic regrouping/reinterpretation terminates that Author run; persisted artifacts remain immutable.

## Active Memory / lifecycle contract

- Logical operations: `WriteMemory`, `GetMemory`, `UpdateMemory`.
- Tool input case argument remains `pxCaseID`; **all successful Memory responses use `CaseID`**.
- Canonical lifecycle fields: `pyStatusValue`, response `RouterKey`, input `pyRouterKey`, and `ProcessingFeedback`.
- `ProcessingFeedback` is exact Text:
  - success terminal state -> `""`;
  - failed/non-OK state -> nonempty;
  - Validator multi-issue feedback -> one issue per LF line; one issue line contains no CR/LF.
- `UpdateMemory` atomically updates only lifecycle/router/feedback plus implementation-owned timestamp. `pyPayload`, identity, type, group, GUID and case ownership are immutable after create.
- **Candidate lifecycle owner:** Validator. **Consumer:** Generator.
- **Projection terminal lifecycle owner:** Generator. **Consumer:** Scenario Author.
- Generator and Author always perform fresh exact-row `GetMemory` after delegated downstream agents return; they never recover state from assistant response text.

## Active Projection / target invariants

- `UnitTestProjectionV3.rut` has `{name,applyToClass}` only; source-side `singlePage` is absent.
- Physical `pyIsSinglePageImplementation` is target-owned. Standard `Rule-Obj-Model` and MultiInput `Rule-Obj-When` contracts currently determine `"false"` where applicable.
- `physicalGroupKey` / `Gnnn` is correlation/group identity only and never participates in test/scenario naming.
- `CM-NAME-001` uses semantic scenario/test label only and serializes separator-free `TC_` Pascal-token names, e.g. `City Not Valid Exit -> TC_CityNotValidExit`.
- Scenario labels must be semantically unique after canonical naming; counters/group IDs/hashes are not collision suffixes.
- Validator KnowledgeTool acquisition is closed to the selected **target** contract batch. RUT semantic KnowledgeAreas such as `Rule-Obj-Model_KnowledgeArea` are forbidden to Validator.
- ScenarioAuthor `_DWLPlan` materializes exactly one ordered `OUT=[KEY...]` and one independently reconstructed ordered `ACT=[KEY...]`; RuleCrawler is eligible only when literal ordered `OUT == ACT`. Numeric substitutes such as `OUT=12` / `ACT=12` are invalid.
- Target payload semantics, mappings, examples, lifecycle ownership and repair boundaries are defined only by the active prompts/contracts in this bundle.

## Active issue / repair behavior

- Validator/Generator use one synchronized closed active issue catalog with **12 reachable codes**.
- Unverified JsonValidation non-success shapes do not produce inferred schema-repair dispositions; they fail closed through `JSON_VALIDATION_TOOL_ERROR/HUMAN_REVIEW` until live evidence defines another contract.
- `GENERATOR_REPAIR` is internal to Generator <-> Validator and never appears as a Projection terminal route to Scenario Author.
- Success always clears stale `ProcessingFeedback` to exact `""`.

## Validation state

**Static refactoring status:** `R0-R15 PASS (STATIC)`  
**Final R15 cross-bundle regression:** `172/172 PASS`  
**ScenarioAuthor §2-§4 semantic coverage gate:** `133/133 PASS`  
**Analysis mode:** `TEXT_SEMANTIC_ONLY=true`

R15 was representation-only/token optimization: runtime architecture, ownership, target contracts, Knowledge Areas, Memory contract, naming and lifecycle semantics from R0-R14 were preserved. Current prompt word-count proxy versus R14:

| Prompt | R14 | Current R15 | Change |
|---|---:|---:|---:|
| ScenarioAuthor | 12,695 | 8,675 | -31.7% |
| Generator | 3,820 | 3,752 | -1.8% |
| Validator | 3,353 | 3,225 | -3.8% |
| **Total** | **19,868** | **15,652** | **-21.2%** |

No SHA/SHA-2/MD5/CRC/checksum/content-hash/fingerprint/hash-based equality or provenance is permitted for project validation. Use direct textual, structural and semantic comparison.

## External evidence still pending

Static validation does **not** prove live runtime deployment. Before claiming live end-to-end completion, externally verify in Pega:

1. deploy the current prompts;
2. deploy/confirm the current Memory tool/property contract, especially response `CaseID` and persisted `ProcessingFeedback`;
3. verify current KnowledgeTool content is the bundle's intended deployed target content;
4. run a fresh Author -> Generator -> Validator -> Generator -> Author E2E replay, including at least one successful Candidate and one Validator repair cycle;
5. confirm delegated assistant prose cannot affect downstream routing because only fresh Memory state is consumed.

## Exact next action

**Deploy the R15 bundle contracts/prompts to live Pega and run a fresh end-to-end runtime replay.** Record live evidence separately; do not modify the static PASS claims unless runtime evidence exposes a contract mismatch.
