# RuleIQ Unit Test Pipeline — Current Deployment Package

This is a clean package containing only the latest promoted prompts and the artifacts directly associated with them. Historical prompts, remediation drafts, SHA/hash evidence and intermediate validation files are intentionally excluded.

## Current agent prompts

`01_PROMPTS/`

- `ScenarioAuthor_SystemPrompt.txt` — current Author prompt (A8E sequential physical-group execution).
- `UnitTestGenerator_SystemPrompt.txt` — current Generator prompt (A8D single-record Memory + A8C compiler behavior).
- `Validator_SystemPrompt.txt` — current Validator prompt (A8D single-record Memory + A8C independent fidelity validation).

## Knowledge Areas

`02_KNOWLEDGE_AREAS/`

- `Rule-Test-Unit-Case_KnowledgeArea.txt` — shared Standard target/compiler reference for Generator + Validator.
- `Rule-Test-Unit-Case_MultInpComb-KnowledgeArea.txt` — shared Rule-Obj-When / MultiInput target/compiler reference for Generator + Validator.
- `Rule-Obj-When_KnowledgeArea_REFERENCE.txt` — current Rule-Obj-When source-rule reference retained from the working target-contract set. Other generic RUT/dependency KnowledgeAreas used by Author are expected to be supplied by the deployed Pega KnowledgeTool/library and are not duplicated here.

## Target KnowledgeTool contracts

`03_TARGET_CONTRACTS/`

The file names match the exact logical keys referenced by Generator/Validator prompts:

- `Rule-Test-Unit-Case_JsonSchema.txt`
- `Rule-Test-Unit-Case_JsonExample.txt`
- `Rule-Test-Unit-Case_MultInpComb-JsonSchema.txt`
- `Rule-Test-Unit-Case_MultInpComb-JsonExample.txt`

## Canonical fixtures

`04_FIXTURES/`

- Standard: `standard_projection.json` -> `standard_candidate.json`
- Rule-Obj-When: `when_projection.json` -> `when_candidate.json`

These are canonical reference pairs for the deterministic Projection -> Candidate contract.

## GenAI Tools

`05_TOOLS/`

- `Memory_GenAI_Tools_Contract.md` — current authoritative single-record Memory tool contract.
- `Memory_GenAI_Tools_Pega_Implementation_Spec.md` — implementation specification for Pega Activities/Data Type.
- `Required_Runtime_Tools.md` — complete runtime tool dependency list and scope boundary.

## Important status boundary

The prompt/contract architecture is statically validated and promoted. Live A4 KnowledgeTool verification and A9 Claude/Pega runtime execution remain separate evidence steps.
