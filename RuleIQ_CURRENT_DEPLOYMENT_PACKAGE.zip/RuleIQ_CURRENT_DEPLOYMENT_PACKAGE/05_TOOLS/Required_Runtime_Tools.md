# Runtime Tool Dependencies

## Implemented / specified in this package

- `WriteMemory` — single-record create-only persistence. See `Memory_GenAI_Tools_Contract.md` and `Memory_GenAI_Tools_Pega_Implementation_Spec.md`.
- `GetMemory` — single-record exact read by `pyGUID` with `pxCaseID` guard.
- `UpdateMemory` — single-record lifecycle-only update.

## Existing external tools referenced by the current prompts

The following tools are required by the prompts but their implementations are not redefined in this package:

- `KnowledgeTool` — retrieves KnowledgeArea / JsonSchema / JsonExample content by exact configured key.
- `RuleCrawler` — retrieves RUT/dependency rule information for Author semantic analysis.
- `JsonValidationTool` — validates candidate JSON against the selected target JSON Schema.
- Pega Agent invocation / `question` mechanism — used by Author -> Generator and Generator -> Validator.

The current prompts are authoritative for when these tools are called and how their results are consumed.
