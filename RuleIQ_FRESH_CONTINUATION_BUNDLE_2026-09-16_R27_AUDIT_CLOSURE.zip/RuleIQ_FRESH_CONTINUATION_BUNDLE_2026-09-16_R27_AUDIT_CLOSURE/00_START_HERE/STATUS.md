# RuleIQ Unit Test Pipeline — Current Status

**Bundle date:** 2026-09-16  
**Current release:** R27  
**Authority:** this bundle is the sole current project version. `STATUS.md` describes only active behavior. `00_START_HERE/VALIDATION_HISTORY.md` is historical/non-authoritative.

## Current architecture

- **Scenario Author** owns RUT semantics, dependency closure, Scenario Compiler `I -> W -> F -> B -> A`, physical grouping and immutable `UnitTestProjectionV3` source materialization.
- **Unit Test Generator** deterministically compiles one persisted Projection into Candidate versions, owns Candidate repair/retry orchestration, consumes Validator outcome only from exact Candidate Memory state, and writes the terminal Generator outcome only to the exact source Projection lifecycle fields.
- **Validator** independently reads the exact Projection + Candidate, validates schema/fidelity/target invariants without redefining Author semantics, and is the sole writer of Candidate validation lifecycle state.
- Delegated Agent assistant responses are non-authoritative. Generator returns exactly `ACK`; Author ignores it. Memory row state is the correctness boundary.

## Exact case identity

`CASE_ID_RAW` is opaque case-sensitive text.

- Author owner: exact `application_context.caseID`.
- Generator owner: exact `Invocation.CaseID` received from Author.
- Validator owner: exact `Invocation.CaseID` received from Generator.
- Every Memory `pxCaseID`, Validator `JsonValidationTool.CaseID`, and delegated Agent Invocation `CaseID` must preserve `CASE_ID_RAW` character-for-character.

Example: if `application_context.caseID` is `RULEIQ-WORK GENUT-91061`, that exact full value must propagate; bare `GetCaseData.pyID=GENUT-91061` is not an equivalent Memory/transport CaseID.

## Current execution order

```text
Global dependency closure + semantic execution
-> I -> W -> F
-> freeze complete physical group set
-> B -> A; require A=PASS

PREPARE_ALL
-> materialize + self-validate one complete UnitTestProjectionV3 per frozen group
-> require exact group/projection census
-> zero Memory writes / zero Generator calls on preparation failure

PERSIST_ALL
-> WriteMemory every prepared Projection in frozen order
-> freeze ordered PROJECTION_QUEUE(groupId, projectionPayload, projectionGUID, PENDING)
-> require exact census and distinct nonempty GUIDs
-> any write/correlation/census failure stops the run with zero Generator calls

GENERATE_ALL
-> NEXT = first PENDING queue row
-> invoke Generator exactly once; ignore assistant response
-> fresh GetMemory(exact Projection GUID)
-> Passed + OK + ProcessingFeedback="" => PENDING -> DONE
-> otherwise stop Failed; later persisted Projections remain unchanged/unprocessed
-> continue until no PENDING row remains

COMPLETE
-> legal only when DONE_COUNT == QUEUE_COUNT and PENDING_COUNT == 0
```

No UnitTestGenerator call is legal until **all** frozen physical groups have successfully persisted Projections. This makes the full ScenarioAuthor output set materially visible in Agent Memory before downstream generation begins.

## Active Memory / lifecycle contract

- Tool input case argument remains `pxCaseID`; successful Memory responses use `CaseID`.
- Canonical lifecycle fields: `pyStatusValue`, response `RouterKey`, input `pyRouterKey`, and `ProcessingFeedback`.
- Success terminal state requires exact `ProcessingFeedback=""`; failed/non-OK state requires nonempty feedback.
- `pyPayload`, identity, type, group, GUID and case ownership are immutable after create.
- **Candidate lifecycle owner:** Validator; **consumer:** Generator.
- **Projection terminal lifecycle owner:** Generator; **consumer:** Scenario Author.
- `GENERATOR_REPAIR` is internal to Generator <-> Validator and is invalid on Projection.

## Active Projection / target invariants

- Source `UnitTestProjectionV3.rut` has `{name,applyToClass}` only; source-side `singlePage` is absent.
- Every frozen non-primary runtime page used by setup/action/assertion/CTX is emitted in Projection `pages` with its grounded class and becomes `pyPagesAndClasses` downstream.
- Assertion page context is provenance-locked: `Primary.*` resolves from ROOT; leading-dot paths resolve through active rule-defined runtime CTX. Every non-Param assertion derives its base from final CTX/APB; non-primary assertions require exact `page` plus the matching grounded `Projection.pages` binding, and assertion-kind conversion cannot change owner page.
- Data Page simulation setup source is `{class,data}`; root `data` omits `pxObjClass`, while resolved nested Page/PageList/PageGroup instances retain exact `pxObjClass`.
- Generator serializes every Data Page simulation setup with fixed `pySetupPageName="PrimaryPage"` and `pyPageDetails.pxObjClass=class`; it does not infer classes.
- Physical `pyIsSinglePageImplementation` is target-owned.
- `physicalGroupKey/Gnnn` is correlation/group identity only and never participates in target naming.
- `CM-NAME-001` derives separator-free `TC_` names only from semantic labels, e.g. `City Not Valid Exit -> TC_CityNotValidExit`.
- ScenarioAuthor `_DWLPlan` requires one ordered `OUT=[KEY...]`, independently reconstructed `ACT=[KEY...]`, and literal ordered `OUT == ACT` before RuleCrawler.
- Executable target compilation is schema-owned: Generator/Validator request only selected JsonSchema + JsonExample; target KnowledgeArea is not part of runtime.
- JsonExample envelope is `{Template,Examples[]}`: `Template` alone owns `pyRuleSet`/`pyRuleSetVersion`; `Examples[]` is non-authoritative serialization illustration. `Examples[0]` preserves the pre-R20 coverage-rich Standard/MultInpComb canonical example; `Examples[1]` and `[2]` add causally coupled Page-DP and List-DP simulation candidates.
- Semantic RUT/dependency Knowledge Areas remain ScenarioAuthor-only.


## Active semantic KnowledgeArea references

Current bundle contains semantic references for `Rule-Obj-When`, `Rule-Obj-Model`, `Rule-Declare-Pages`, `Rule-Declare-DecisionTable`, and `Rule-Utility-Function`; ScenarioAuthor is their only runtime consumer. R26 resolved the R24/R25 ownership conflicts without changing Generator/Validator/target contracts. R27 closes the R26 audit finding by making KDT evidence handling deterministic: missing/inconsistent evidence invalidates/rebuilds; terminal UNKNOWN effects localize.

- Model KT.11/KT.12 no longer mix test-target parameter fields into Model RuleJSON semantics; KT.26 emits semantic error-ASSERT intent; KT.29 emits PAGE source/setup obligations only and leaves target serialization downstream.
- Decision Table KDT.6/KDT.11/KDT.12 now stop at semantic setup/evidence/ASSERT-OMIT obligations. KDT.12 is a pre-Projection audit; no KDT rule reads, builds or repairs Candidate/RuleCode. DTM/DTA/DTE, OR/raw-pyRowNum, range, inverse-seed, inactive-scalar and existence semantics are retained.
- KRUF.0 now explicitly splits ownership: caller owns holder/DWL/dedup/retry/transport; KRUF owns RUF field semantics, canonical request projection and fetched-contract evaluation.
- Rule-Declare-Pages and Rule-Obj-When KnowledgeAreas are unchanged from R25.

## Active issue / repair behavior

- Validator and Generator share one closed active catalog with **12 reachable codes**.
- JsonValidation non-success shapes remain unverified and fail closed through `JSON_VALIDATION_TOOL_ERROR/HUMAN_REVIEW`.
- Validator writes Candidate lifecycle; Generator ignores Validator assistant response and fresh-reads Candidate Memory.
- Generator returns exactly `ACK`; Author ignores it and fresh-reads Projection Memory.

## Validation state

**Historical static baseline:** `R0-R16 PASS (STATIC)`  
**R15 final regression:** `172/172 PASS`  
**R15 ScenarioAuthor §2-§4 semantic coverage:** `133/133 PASS`  
**R16 core semantic/regression suite:** `139/139 PASS`  
**R16 final cross-bundle synchronization gate:** `147/147 PASS`  
**R17 CaseID-source validation:** `PASS (contextual/textual semantic review)`  
**R18 simulation/page materialization validation:** `PASS (static semantic/schema review; live Pega replay pending)`
**R19 schema-owned target compiler validation:** `PASS (static semantic/schema review; live Pega replay pending)`  
**R20 JsonExample illustration-library validation:** `PASS (6/6 example candidates schema-valid; static semantic review; live Pega replay pending)`  
**R21 restored-coverage example validation:** `PASS (6/6 candidates schema-valid; restored Examples[0] equal R19 content by direct structural comparison)`  
**R23 merged metadata + R22 assertion-page provenance validation:** `PASS (static semantic regression + supplied live PXCONV-160066 acceptance analysis; fresh live Pega replay pending)`  
**R24 KnowledgeArea reference integration:** `PASS (Rule-Obj-Model/Rule-Declare-Pages/Rule-Declare-DecisionTable added verbatim; compatibility audit recorded; runtime prompts unchanged)`  
**R25 RUF KnowledgeArea reference integration:** `PASS (Rule-Utility-Function added verbatim; KRUF contract compatible with current RUF flow; runtime prompts unchanged)`  
**R26 semantic KnowledgeArea boundary cleanup:** `PASS (65/65 static architecture/semantic checks; 6/6 target examples schema-valid; later 31-stage audit found one wording precision issue)`  
**R27 R26-audit closure:** `PASS (31/31 planned stages satisfied; runtime delta from R26 is one deterministic ScenarioAuthor wording replacement; 6/6 examples schema-valid; fresh live Pega replay pending)`  
**Analysis mode:** `TEXT_SEMANTIC_ONLY=true`

R23 preserves all R22 assertion-page provenance behavior and adds only Scenario UI metadata plus required RuleCode target metadata/constants:
- remove the contradictory global `leading-dot -> ROOT` rule; `Primary.*` remains ROOT while relative paths follow active rule-defined CTX;
- add one `ASSERT_PAGE_CONTEXT` owner across Property/Page/List/ResultCount; non-primary `page` and matching `Projection.pages` class binding are mandatory;
- pre-projection validation compares each non-Param assertion to final CTX/APB provenance and forbids ROOT rebasing repair;
- Generator, Validator, both production schemas, and both JsonExample libraries are unchanged from R21.

R22 prompt word-count proxy versus R21 remains historical context; R23 additionally extends Scenario metadata contracts and deterministic target mappings.

| Prompt | R21 | R22 | Delta |
|---|---:|---:|---:|
| ScenarioAuthor | 8,934 | 9,095 | +161 |
| Generator | 3,289 | 3,289 | 0 |
| Validator | 2,846 | 2,846 | 0 |
| **Total** | **15,069** | **15,230** | **+161** |

R20 changes only target-example consumption on top of R19:
- both executable JsonExample artifacts use `{Template,Examples[]}`;
- `Template` preserves the existing two target-owned ruleset fields;
- each `Examples[]` library contains compact no-simulation, Page DP, and List DP full candidates with synthetic `ZqxExample-*` names;
- Generator may use examples only to illustrate HOW an already-required schema mapping is serialized; Validator ignores examples for validation.

R18 adds one projection/materialization correction on top of R17:
- Author carries already-resolved simulation setup-page class as `{class,data}` and preserves resolved nested page classes in `data`;
- frozen non-primary runtime named pages must reach Projection `pages`;
- Generator maps simulation setup deterministically to fixed `PrimaryPage` plus `pyPageDetails.pxObjClass=class`;
- Standard/MultiInput target schemas enforce `PrimaryPage` and root simulation `pxObjClass`.

R19 moves target compiler mapping from target Knowledge Areas into selected JsonSchema extensions; JsonExample remains template-only (`pyRuleSet`/`pyRuleSetVersion`).

R19 prompt word-count proxy versus R18 (word proxy only, not exact Claude tokenization):

| Prompt | R18 | R19 | Delta |
|---|---:|---:|---:|
| ScenarioAuthor | 8,934 | 8,934 | 0 |
| Generator | 3,797 | 3,269 | -528 |
| Validator | 3,249 | 2,888 | -361 |
| **Total** | **15,980** | **15,091** | **-889** |

Historical R18 prompt word-count proxy versus R17:

| Prompt | R17 | R18 | Delta |
|---|---:|---:|---:|
| ScenarioAuthor | 8,863 | 8,934 | +71 |
| Generator | 3,793 | 3,797 | +4 |
| Validator | 3,249 | 3,249 | 0 |
| **Total** | **15,905** | **15,980** | **+75** |

R18 execution/validation checkpoints completed:
- Author simulation source grammar and nested-class materialization reviewed in context;
- named runtime page -> Projection `pages` propagation reviewed against ROOT/CTX/assertion rules;
- Generator grammar and both target schema mappings synchronized;
- Standard/MultiInput schemas parse as JSON and their canonical examples still validate;
- whole-bundle contextual search found no active `{name,data}` simulation setup-page source contract or rule preserving a runtime page name as Data Page `pySetupPageName`.

No fixtures were created/updated and no SHA/hash/checksum/fingerprint acceptance checks were used.

## External evidence still pending

Static validation does not prove live Pega behavior. Run a fresh multi-group E2E replay and verify:

1. exact `application_context.caseID` reaches Author Memory calls -> Generator Invocation/Memory calls -> Validator Invocation/JsonValidationTool/Memory calls character-for-character unchanged, even when `GetCaseData.pyID` differs;
2. all Projection rows are persisted before the first Generator invocation;
3. if a Projection write fails, no Generator is invoked;
4. Generator returns only `ACK`, and Author routing depends only on fresh Projection Memory;
5. when a Generator stops on an early group, later Projection rows remain visible and unprocessed;
6. all persisted queue entries are invoked exactly once on a successful run.

If the actual tool-call argument already equals exact `application_context.caseID` but Pega itself stores/returns a different value, treat that as a Pega implementation/mapping defect; prompt changes cannot repair runtime changes after the call boundary.

## Exact next action

Deploy R27 and replay `PrepareCustomerCommunication`; require the appended-address Projection assertion to use `page="CustomerCommunication"`, `list=".Addresses"`, and `pages.CustomerCommunication="Data-Customer"`, then verify Candidate step-page/Pages-and-Classes fidelity. Also exercise at least one Decision Table path with DTA setup/inactive-scalar or range/OR evidence and one PAGE-parameter Model path. Confirm Scenario metadata, Data Page simulation, Generator/Validator behavior and exact CaseID propagation remain unchanged.


## R19 target-compiler migration

- `Rule-Test-Unit-Case*_KnowledgeArea` runtime artifacts removed.
- Standard schema owns `CM-EXEC-001` + `CM-ASSERT-STD-001`; MultiInput owns `CM-EXEC-001` + `CM-WHEN-001`; both retain `CM-NAME-001`.
- Generator/Validator executable KnowledgeTool batches are now JsonSchema + JsonExample only.
- JsonExamples were not changed.
- No fixtures or SHA/hash/checksum/fingerprint acceptance checks were used.


## R24 KnowledgeArea references added
- Added verbatim Rule-Obj-Model, Rule-Declare-Pages and Rule-Declare-DecisionTable reference files under `02_KNOWLEDGE_AREAS`.
- Runtime prompts/contracts remain R23-equivalent. See `00_START_HERE/KNOWLEDGEAREA_COMPATIBILITY_R24.md` for compatibility findings.


## R26 semantic KnowledgeArea boundary cleanup
- ScenarioAuthor runtime behavior is unchanged except `repair` wording is narrowed to `rebuild/localize` for KDT evidence.
- Generator, Validator, both target schemas/examples, Rule-Declare-Pages KA and Rule-Obj-When KA are unchanged from R25.
- Changed-runtime word proxy: 18,039 -> 17,535 (-504); ScenarioAuthor remains 9,212.
- Static validation: 65/65 PASS; all 6 target examples validate. No new fields, fixtures or runtime tools were introduced.


## R27 R26-audit closure
- Closed the only two PARTIAL results from the explicit R26 31-stage audit; both came from one ambiguous ScenarioAuthor phrase.
- Replaced `KDT.11-KDT.12 rebuild/localize missing/inconsistent/UNKNOWN evidence.` with deterministic `KDT.11-KDT.12: missing/inconsistent→invalidate/rebuild; terminal UNKNOWN→localize.`
- ScenarioAuthor word proxy remains 9,212; Model/DecisionTable/RUF KnowledgeAreas are byte-identical to R26.
- Generator, Validator, both target schemas/examples, Data Page KA and When KA remain unchanged.
- Full R27 audit: 31/31 PASS (static/textual/structural); fresh live Pega replay remains pending.
