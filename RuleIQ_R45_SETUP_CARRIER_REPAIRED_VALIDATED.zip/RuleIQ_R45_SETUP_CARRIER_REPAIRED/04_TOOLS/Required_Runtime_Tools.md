# Runtime Tool Dependencies

## Implemented / specified in this package

- `WriteMemory` — single-record create-only persistence. See `Memory_GenAI_Tools_Contract.md` and `Memory_GenAI_Tools_Pega_Implementation_Spec.md`.
- `GetAgentMemory(pyGUID,SkipPayload=false)` — single-record exact read; response `CaseID` supplies case correlation. `SkipPayload=true` requests a status-only response.
- `UpdateMemory` — single-record atomic lifecycle/router/`ProcessingFeedback` update.


## R9 synchronized Memory boundary

All Memory success responses use exact response field `CaseID`; Write/Update input calls use `pxCaseID`, while `GetAgentMemory` uses `pyGUID` and optional `SkipPayload`. `GetAgentMemory` returns exact Text `ProcessingFeedback`. `UpdateMemory(pxCaseID,pyGUID,pyStatusValue,pyRouterKey,ProcessingFeedback)` atomically updates status/router/feedback and echoes response `CaseID`, `RouterKey`, and exact `ProcessingFeedback`. Create initializes feedback to `""`; success terminal updates clear it to `""`; failed/non-OK updates require nonempty feedback. No alias/coercion is allowed.

The Memory success-response contract is runtime-evidenced and uses the actual observed Pega fields/wrappers. Non-success/failure Memory response shapes remain `UNVERIFIED_RUNTIME_SHAPE` until a live failure trace is captured.

## Existing external tools referenced by the current prompts

The following tools are required by the prompts but their implementations are not redefined in this package:

- `KnowledgeTool` — retrieves KnowledgeArea / JsonSchema / JsonExample content by exact configured key.
- `RuleCrawler` — retrieves RUT/dependency rule information for Author semantic analysis.
- `JsonValidationTool` — validates candidate JSON against the selected target JSON Schema.
- Pega Agent invocation / `question` mechanism — used by Author -> Generator and Generator -> Validator.

## JsonValidationTool — R1 observed response boundary

Supplied live success response:

```json
{
  "message": "JSON_VALID| JSON is valid against the schema",
  "IsValid": true
}
```

Canonical R1 success parser:
- top-level `IsValid` must be boolean `true`;
- top-level `message` must be a string beginning with `JSON_VALID|`;
- no `Success`, `ValidationMessage`, `ErrorCode`, or `ErrorMessage` field is required or inferred.

No supplied trace establishes the exact response for:
- schema-invalid candidate (`IsValid=false` or another shape);
- transport/tool exception;
- any error-code/message envelope.

Those paths are `UNVERIFIED_RUNTIME_SHAPE`. Until live evidence exists, Validator must fail closed to its tool-error/HUMAN path rather than invent an invalid-schema disposition from undocumented fields or message text.

The current prompts remain authoritative for call timing. This file is authoritative for the external JsonValidation response boundary evidenced in R1.

## Inter-agent Memory-state boundary — R13 current runtime contract

Delegated Pega Agent assistant responses are not correctness/data interfaces. Author -> Generator and Generator -> Validator still use the Agent `question` mechanism for invocation, but downstream results are consumed only from exact Memory rows after the delegated call returns.

- Validator is the sole writer of Candidate validation lifecycle state through `UpdateMemory`; Generator ignores Validator assistant response and then reads the exact Candidate GUID with `GetAgentMemory(...,SkipPayload=true)`.
- Generator is the sole writer of Projection terminal generation state through `UpdateMemory`; ScenarioAuthor ignores Generator assistant response and then reads the exact Projection GUID with `GetAgentMemory(...,SkipPayload=true)`.
- Candidate `ProcessingFeedback` carries Validator issue lines; Projection `ProcessingFeedback` carries Generator terminal diagnostic context.
- No runtime adapter parses, extracts, validates, repairs or interprets delegated assistant response text for status, route, feedback, issues or correlation.
- `pyPayload`, identity, type, group and case ownership remain immutable; inter-agent state is only `pyStatusValue`, router state and `ProcessingFeedback`.
- Any absent, stale, malformed or correlation-invalid Memory lifecycle state fails closed. Delegated response text can never rescue it.

This bundle does not claim fresh live Pega redeployment/replay of the new Memory-state handoff; static synchronization is separate from runtime evidence.
