# R45 Findings

## H-R45-01 — Validator treated When `valueType` as target-mapped
**Severity:** High — repaired.

Evidence: existing `CM-WHEN-001` says `valueType remains source evidence only and never changes target mode or authorizes recasting`. Generator follows that rule. Validator §4.2 previously grouped `valueType` with facts mapped to exact target fields/wrappers.

Repair: Validator now explicitly marks Rule-Obj-When `valueType` as evidence-only / `NO_FIDELITY_CHECK`; it still validates path/value-presence/value/result/order and fixed target `pyPropertyMode="text"`. No schema, Generator behavior, Projection semantics, or ownership changed.

## M-R45-02 — obsolete `adapter` terminology in Validator action boundary
**Severity:** Medium — repaired.

Evidence: current architecture since R42.1 uses direct existing Knowledge Areas, not a SemanticAdapter layer. Validator still said semantic RUT/dependency “adapters”.

Repair: wording only: `Knowledge Areas` / `semantic Knowledge Areas`. Runtime action set and KnowledgeTool prohibition are unchanged.

## Intentional asymmetries — not findings
- `CM-NAME-001` is Generator-only by schema consumer declaration; Validator checks only schema and `CF-IDENTITY-001`.
- deterministic Property/Param block packing is Generator implementation; Validator intentionally treats schema-valid packing as container-insensitive within the Property/Param family.
- Generator G7 and Validator post-write validation remain separate independent checks.

Final open: Critical=0, High=0, Medium=0, Unresolved=0.
