#!/usr/bin/env python3
import json
from pathlib import Path
from jsonschema import Draft202012Validator

ROOT=Path(__file__).resolve().parents[2]
BASE=Path("/mnt/data/current_r45/RuleIQ_R45_GENERATOR_VALIDATOR_SYNCHRONIZED")
SA=ROOT/"01_PROMPTS/ScenarioAuthor_SystemPrompt.txt"
GEN=ROOT/"01_PROMPTS/UnitTestGenerator_SystemPrompt.txt"
STD=ROOT/"03_TARGET_CONTRACTS/Rule-Test-Unit-Case_JsonSchema.txt"
WHEN=ROOT/"03_TARGET_CONTRACTS/Rule-Test-Unit-Case_MultInpComb-JsonSchema.txt"
STD_EX=ROOT/"03_TARGET_CONTRACTS/Rule-Test-Unit-Case_JsonExample.txt"
WHEN_EX=ROOT/"03_TARGET_CONTRACTS/Rule-Test-Unit-Case_MultInpComb-JsonExample.txt"
REG=ROOT/"docs/r45/R46_SETUP_CARRIER_REGRESSION_SIMULATION_RESULTS.json"

checks=[]
def check(name, cond, detail):
    checks.append({"name":name,"pass":bool(cond),"detail":detail})
    if not cond:
        raise AssertionError(f"{name}: {detail}")

sa=SA.read_text(encoding="utf-8")
gen=GEN.read_text(encoding="utf-8")
std_text=STD.read_text(encoding="utf-8")
when_text=WHEN.read_text(encoding="utf-8")

# Author contract.
check("Carrier rule unique",sa.count("Each frozen execution fact has exactly one carrier.")==1,"one authoritative closed carrier rule")
check("Formal root rule unique",sa.count("optional root `parameters` is the ordered scenario-active subset")==1,"one root-parameter source contract")
check("Primary alias rule",sa.count("Primary.&lt;relativePath&gt;` binds to `ROOT.page")==1,"Primary maps to effective primary")
check("Nested When context rule",sa.count("The resolved provider runtime page owns the When's relative property operands.")==1,"provider page owns operands")
check("Setup materialization rule",sa.count("each fact is materialized at its relative data path under its exact owning page")==1,"page/path materialization")
check("Carrier reconciliation rule",sa.count("**Execution carriers:**")==1,"one pre-persistence reconstruction gate")
check("Producer carrier gate",sa.count("the §6.4.6 execution-carrier census is exact")==1,"canonical check references reconciliation")
check("Legacy generic root-parameter wording absent","optional `parameters` is a nonempty source-parameter array" not in sa,"root parameters no longer generic")
check("UI inputs use carrier census","runtime-page pre-state from the frozen carrier census" in sa,"narrative follows physical carriers")

# Positive/current-state wording in newly added authoritative rules.
new_rule_lines=[
    line for line in sa.splitlines()
    if any(k in line for k in [
        "The resolved provider runtime page owns",
        "Keep the resolved provider class/page",
        "Execution carrier is part",
        "optional root `parameters` is the ordered",
        "optional `setupPages` is the grouped frozen",
        "**Execution carriers:**",
        "the §6.4.6 execution-carrier census is exact",
        "runtime-page pre-state from the frozen carrier census"
    ])
]
joined="\n".join(new_rule_lines).lower()
for word in ["old prompt","previous prompt","regression bug","used to","before refactor","historical defect"]:
    check(f"No remediation history phrase: {word}",word not in joined,"runtime rules describe current target state")

# Generator interface and target mappings.
check("Generator formal carrier",gen.count("Author-frozen ordered scenario-active RUT formal-argument census")==1,"one consumer meaning")
check("Generator setup carrier",gen.count("Author-frozen runtime-page pre-state census")==1,"one consumer meaning")
check("Generator simulation carrier",gen.count("Author-frozen dependency-payload census")==1,"one consumer meaning")
check("Generator preserves carriers","Target mapping preserves these frozen carriers unchanged." in gen,"mechanical compiler boundary")

for label,text in [("Standard",std_text),("When",when_text)]:
    check(f"{label} maps RUT parameters","Map source parameters to RuleCode.pyRuleUnderTest.pyParameters" in text,"CM-EXEC mapping")
    check(f"{label} maps setup pages","Source setupPages→RuleCode.pySetupPages" in text,"CM-EXEC mapping")
    check(f"{label} maps simulations","Source simulations→RuleCode.pySimulation" in text,"CM-EXEC mapping")

# Schemas and examples.
for label,sp,ep in [
    ("Standard",STD,STD_EX),
    ("When",WHEN,WHEN_EX)
]:
    schema=json.load(open(sp,encoding="utf-8"))
    Draft202012Validator.check_schema(schema)
    check(f"{label} schema meta-valid",True,"Draft 2020-12")
    ex=json.load(open(ep,encoding="utf-8"))
    v=Draft202012Validator(schema)
    for i,obj in enumerate(ex["Examples"],1):
        errs=list(v.iter_errors(obj))
        check(f"{label} Example {i} schema-valid",not errs,"; ".join(e.message for e in errs[:3]) or "valid")

# Regression simulation.
reg=json.load(open(REG,encoding="utf-8"))
check("Regression simulation overall",reg["overall"]=="PASS",f'{reg["passCount"]}/{reg["checkCount"]}')
check("Regression simulation complete",reg["passCount"]==reg["checkCount"]==36,"36/36")

# Token-growth guard. Character growth is only a prompt-size budget, not semantic comparison evidence.
base_sa=(BASE/"01_PROMPTS/ScenarioAuthor_SystemPrompt.txt").read_text(encoding="utf-8")
base_gen=(BASE/"01_PROMPTS/UnitTestGenerator_SystemPrompt.txt").read_text(encoding="utf-8")
sa_growth=len(sa)-len(base_sa)
gen_growth=len(gen)-len(base_gen)
check("ScenarioAuthor prompt growth bounded",0 < sa_growth < 2500,f"+{sa_growth} chars")
check("Generator prompt growth bounded",0 < gen_growth < 250,f"+{gen_growth} chars")

out={
    "checks":checks,
    "passCount":sum(x["pass"] for x in checks),
    "checkCount":len(checks),
    "overall":"PASS" if all(x["pass"] for x in checks) else "FAIL",
    "promptGrowthChars":{"ScenarioAuthor":sa_growth,"Generator":gen_growth},
    "validationMethod":"semantic/textual contract inspection; no diff/SHA/hash/checksum evidence"
}
print(json.dumps(out,indent=2,ensure_ascii=False))
