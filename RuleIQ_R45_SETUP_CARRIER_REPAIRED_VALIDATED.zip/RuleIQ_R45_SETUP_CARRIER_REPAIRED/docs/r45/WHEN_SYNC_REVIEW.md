# Rule-Obj-When Synchronization Review

PASS after H-R45-01. `CM-WHEN-001` is authoritative for target Decision construction: row/input order, path copies, fixed `pyPropertyType=input`, fixed `pyPropertyMode=text`, expected presence/value, boolean result serialization, and Result-last via `CF-WHEN-ORDER-001`. Source `valueType` has no target coordinate and Validator now explicitly excludes it from fidelity comparison.
