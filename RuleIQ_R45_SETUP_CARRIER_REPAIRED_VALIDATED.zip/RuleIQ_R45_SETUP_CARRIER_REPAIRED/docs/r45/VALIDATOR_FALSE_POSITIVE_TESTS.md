# Validator False-Positive Tests

All six existing target examples (three Standard, three MultInpComb) validate under their existing Draft-2020-12 schemas. Representative Standard and When examples also pass independent checks for existing `CF-IDENTITY-001`, `CF-PRIMARY-001`, `CF-EXPECTED-STRING-001`, and `CF-WHEN-ORDER-001`.

R45 intentionally does not make Validator reject Generator-internal choices that the target contract leaves legal, such as schema-valid Property/Param block packing.
