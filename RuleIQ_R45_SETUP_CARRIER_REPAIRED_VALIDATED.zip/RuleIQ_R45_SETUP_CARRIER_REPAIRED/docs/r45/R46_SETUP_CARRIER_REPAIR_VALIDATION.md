# Setup Carrier Repair — Final Validation

## Result

**PASS**

- Regression simulation: **36/36 PASS**
- Cross-structural validation: **37/37 PASS**
- ScenarioAuthor prompt growth: **+2045 chars**
- Generator prompt growth: **+85 chars**
- Validation method: semantic/textual contract inspection; no diff/SHA/hash/checksum evidence.

## Implemented behavior

ScenarioAuthor now freezes one execution carrier per fact:

- exact active RUT formal argument → root `parameters[]`;
- required Primary/named runtime-page pre-state → `setupPages[]`;
- setup/cleanup action argument → owning action parameters;
- simulated dependency payload → `simulations[]`.

`Primary.<relativePath>` binds to the effective `ROOT.page`. Page/list When operands keep the resolved provider runtime page through WITNESS/FREEZE. Projection self-validation reconstructs the carrier census before persistence.

Generator remains a mechanical compiler and consumes the same carrier meanings. Existing Standard and MultInpComb `CM-EXEC-001` mappings already map:

- `Projection.parameters[]` → `RuleCode.pyRuleUnderTest.pyParameters`;
- `Projection.setupPages[]` → `RuleCode.pySetupPages`;
- `Projection.simulations[]` → `RuleCode.pySimulation`.

## DetermineCondition regression

Observed bad Projection:

- G001 root parameters: `pyLabel`, `pyType`;
- G002 root parameter: `pyLabel`;
- original RUT has no usable nonempty-name formal parameter declaration.

Repaired deterministic replay:

### G001

```json
[
  {
    "name": "RunRecordPrimaryPage",
    "data": {
      "pyLabel": "Glen"
    }
  }
]
```

Root `parameters` is absent.

The frozen `D_CustomerTestRef` simulation retains:

- `CustomerID = test`;
- `Addresses(1).pyPostalCode = 1011AB`;
- `Addresses(1).pyType = Postal`.

No Primary `pyType` is materialized.

### G002

```json
[
  {
    "name": "RunRecordPrimaryPage",
    "data": {
      "pyLabel": "Other"
    }
  }
]
```

Root `parameters` is absent and the frozen Data Page simulation remains unchanged.

`pyTempInteger=0` was not restored from the historical Candidate because this repair uses current execution semantics rather than historical output resemblance.

## Prompt design review

New runtime instructions describe the required target behavior rather than remediation history. Carrier classification is defined once at ScenarioTrace/freeze authority and then referenced by Projection materialization/self-validation. Generator received only a compact consumer-side clarification.

## Existing contract regression

Both target schemas remain Draft 2020-12 valid. All six concrete target examples remain schema-valid:

- Standard: 3/3 PASS
- MultInpComb: 3/3 PASS

## Evidence

- `R46_SETUP_CARRIER_REGRESSION_SIMULATION.py`
- `R46_SETUP_CARRIER_REGRESSION_SIMULATION_RESULTS.json`
- `R46_SETUP_CARRIER_FINAL_STRUCTURAL_VALIDATION.py`
- `R46_SETUP_CARRIER_FINAL_STRUCTURAL_VALIDATION_RESULTS.json`
- `00_START_HERE/R46_SETUP_CARRIER_REPAIR_PROGRESS.md`
