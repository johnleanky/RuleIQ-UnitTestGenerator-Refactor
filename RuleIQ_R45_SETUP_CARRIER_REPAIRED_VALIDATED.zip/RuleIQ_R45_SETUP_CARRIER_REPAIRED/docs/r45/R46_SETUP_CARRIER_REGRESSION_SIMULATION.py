#!/usr/bin/env python3
import json
from pathlib import Path

NEW=Path("/mnt/data/decision_table/PXCONV-185020 GenUT-94005.txt")
OLD=Path("/mnt/data/decision_table/PXCONV-186030 GenUT-94008.txt")
ROOT=Path(__file__).resolve().parents[2]
SA=ROOT/"01_PROMPTS/ScenarioAuthor_SystemPrompt.txt"
GEN=ROOT/"01_PROMPTS/UnitTestGenerator_SystemPrompt.txt"
STD=ROOT/"03_TARGET_CONTRACTS/Rule-Test-Unit-Case_JsonSchema.txt"
WHEN=ROOT/"03_TARGET_CONTRACTS/Rule-Test-Unit-Case_MultInpComb-JsonSchema.txt"

def load(p): return json.load(open(p,encoding="utf-8"))
new=load(NEW); old=load(OLD)

get_case=next(m for m in new["pyMessageHistory"] if m.get("pyRole")=="tool" and m.get("pyName")=="GetCaseData")
case=json.loads(get_case["pyContent"])
rut=json.loads(case["RuleJSON"])
formal={}
for p in rut.get("pyParameters",[]):
    name=p.get("pyParametersParamName")
    typ=p.get("pyParametersParamType")
    if isinstance(name,str) and name:
        formal[name]=typ

bad={}; freeze=None
for m in new["pyMessageHistory"]:
    if m.get("pyRole")!="assistant": continue
    for tc in m.get("pyToolCalls",[]):
        fn=tc.get("pyFunction",{})
        if fn.get("pyName")=="WriteAgentMemory":
            a=json.loads(fn["pyArguments"])
            if a.get("pyType")=="UnitTestProjectionV3":
                bad[a["pyGroup"]]=json.loads(a["pyPayload"])
        elif fn.get("pyName")=="MemoryTemp":
            a=json.loads(fn["pyArguments"])
            if a.get("type")=="ScenarioTrace" and a.get("value","").startswith("PHASE|FREEZE|"):
                freeze=a["value"]
assert freeze and set(bad)=={"G001","G002"}

scenario_given={}
for line in freeze.splitlines():
    if not line.startswith("SCENARIO|"): continue
    parts=line.split("|")
    facts=[]
    for tok in parts[2].split(";"):
        if tok:
            path,val=tok.split("=",1)
            facts.append((path,val))
    scenario_given[parts[1]]=facts

raw=NEW.read_text(encoding="utf-8")
assert "When@Data-Address-Postal@IsValidPostalAddress" in raw
assert "Prop@Data-Address-Postal@pyType" in raw
assert "@IsInPageListWhen" in raw and "D_CustomerTestRef" in raw and "Addresses" in raw

corrected={}
for sid,facts in scenario_given.items():
    has_dp_pytype=any(p.startswith("D_CustomerTestRef.") and p.endswith(".pyType") for p,_ in facts)
    corrected[sid]=[(p,v) for p,v in facts if not (p=="Primary.pyType" and has_dp_pytype)]

def classify(facts):
    params=[]; primary_setup={}; sim=[]
    for path,val in facts:
        if path.startswith("Param."):
            name=path.split(".",1)[1]
            if name in formal:
                params.append({"name":name,"formalType":formal[name],"value":val})
        elif path.startswith("Primary."):
            primary_setup[path.split(".",1)[1]]=val
        elif path.startswith("D_CustomerTestRef"):
            sim.append((path,val))
    return params,primary_setup,sim

sid_for_group={"G001":"S1","G002":"S2"}
fixed={}
for gid,p in bad.items():
    q=json.loads(json.dumps(p))
    q.pop("parameters",None); q.pop("setupPages",None)
    params,setup,_=classify(corrected[sid_for_group[gid]])
    if params: q["parameters"]=params
    if setup: q["setupPages"]=[{"name":"RunRecordPrimaryPage","data":setup}]
    fixed[gid]=q

def compile_carriers(p):
    out={}
    if p.get("parameters"):
        out["pyRuleUnderTest.pyParameters"]=[
            {"pyParametersParamName":x["name"],"pyParametersParamType":x["formalType"],"pyParametersParamValue":x.get("value")}
            for x in p["parameters"]
        ]
    if p.get("setupPages"):
        out["pySetupPages"]=[
            {"pySetupPageName":x["name"],**({"pyPageDetails":x["data"]} if "data" in x else {})}
            for x in p["setupPages"]
        ]
    if p.get("simulations"):
        out["pySimulation"]=[
            {
                "pyClassName":s["runtimeClass"],
                "pyRuleNameToBeMocked":s["rule"],
                "pySimulationMethod":"DefineData",
                "pySetupPages":[
                    {"pySetupPageName":"PrimaryPage","pyPageDetails":{"pxObjClass":sp["class"],**sp["data"]}}
                    for sp in s["setupPages"]
                ]
            } for s in p["simulations"]
        ]
    return out
compiled={g:compile_carriers(p) for g,p in fixed.items()}

old_resp=json.loads(next(m for m in old["pyMessageHistory"] if m.get("pyRole")=="tool" and m.get("pyName")=="GetAIAgentResponseRecord")["pyContent"])
old_candidate=json.loads(old_resp["JsonResponse"])
old_first=old_candidate["UnitTestRules"][0]["RuleCode"]

checks=[]
def check(name,cond,detail):
    checks.append({"name":name,"pass":bool(cond),"detail":detail})
    if not cond: raise AssertionError(f"{name}: {detail}")

sa=SA.read_text(encoding="utf-8"); gen=GEN.read_text(encoding="utf-8")
std=STD.read_text(encoding="utf-8"); when=WHEN.read_text(encoding="utf-8")

check("SA closed carrier rule","Each frozen execution fact has exactly one carrier." in sa,"carrier invariant")
check("SA formal gate","exact nonempty-name original RUT formal declarations" in sa,"formal provenance")
check("SA Primary binding","Primary.&lt;relativePath&gt;` binds to `ROOT.page" in sa,"primary alias")
check("SA helper context","The resolved provider runtime page owns the When's relative property operands." in sa,"nested When context")
check("SA setup mapping","each fact is materialized at its relative data path under its exact owning page" in sa,"setup materialization")
check("SA producer gate","the §6.4.6 execution-carrier census is exact" in sa,"pre-persistence gate")
check("GEN parameters carrier","Author-frozen ordered scenario-active RUT formal-argument census" in gen,"generator input meaning")
check("GEN setup carrier","Author-frozen runtime-page pre-state census" in gen,"generator input meaning")
check("GEN simulation carrier","Author-frozen dependency-payload census" in gen,"generator input meaning")
check("STD target mapping","Source setupPages→RuleCode.pySetupPages" in std and "Map source parameters to RuleCode.pyRuleUnderTest.pyParameters" in std,"CM-EXEC")
check("WHEN target mapping","Source setupPages→RuleCode.pySetupPages" in when and "Map source parameters to RuleCode.pyRuleUnderTest.pyParameters" in when,"CM-EXEC")

check("No usable RUT formal parameters",formal=={},f"formal={formal}")
for gid in ("G001","G002"):
    observed=[x["name"] for x in bad[gid].get("parameters",[])]
    check(f"{gid} regression observed",bool(observed),f"bad params={observed}")
    check(f"{gid} repaired parameters absent","parameters" not in fixed[gid],str(fixed[gid].get("parameters")))
    check(f"{gid} Primary setup page",fixed[gid]["setupPages"][0]["name"]=="RunRecordPrimaryPage",str(fixed[gid]["setupPages"]))
    check(f"{gid} simulation unchanged",fixed[gid]["simulations"]==bad[gid]["simulations"],"frozen simulation preserved")

check("G001 pyLabel setup",fixed["G001"]["setupPages"][0]["data"]=={"pyLabel":"Glen"},str(fixed["G001"]["setupPages"]))
check("G002 pyLabel setup",fixed["G002"]["setupPages"][0]["data"]=={"pyLabel":"Other"},str(fixed["G002"]["setupPages"]))
check("G001 no Primary.pyType","pyType" not in fixed["G001"]["setupPages"][0]["data"],str(fixed["G001"]["setupPages"]))
g1sim=fixed["G001"]["simulations"][0]["setupPages"][0]["data"]
check("G001 simulation pyType",g1sim["Addresses"][0]["pyType"]=="Postal",str(g1sim))
check("G001 simulation postal",g1sim["Addresses"][0]["pyPostalCode"]=="1011AB",str(g1sim))
check("G001 simulation CustomerID",g1sim["CustomerID"]=="test",str(g1sim))
check("No historical pyTempInteger seed","pyTempInteger" not in fixed["G001"]["setupPages"][0]["data"],str(fixed["G001"]["setupPages"]))

for gid in ("G001","G002"):
    check(f"{gid} target params absent","pyRuleUnderTest.pyParameters" not in compiled[gid],str(compiled[gid]))
    check(f"{gid} target setup present",compiled[gid]["pySetupPages"][0]["pySetupPageName"]=="RunRecordPrimaryPage",str(compiled[gid]["pySetupPages"]))
    check(f"{gid} target simulation present",compiled[gid]["pySimulation"][0]["pyRuleNameToBeMocked"]=="D_CustomerTestRef",str(compiled[gid]["pySimulation"]))

check("Old valid pattern pyLabel setup",old_first["pySetupPages"][0]["pyPageDetails"]["pyLabel"]=="Glen","old carrier evidence")
check("Old valid pattern no RUT params",not old_first.get("pyRuleUnderTest",{}).get("pyParameters"),"old carrier evidence")
check("Old valid pattern simulation pyType",old_first["pySimulation"][0]["pySetupPages"][0]["pyPageDetails"]["Addresses"][0]["pyType"]=="Postal","old carrier evidence")

out={
 "formalRUTParameters":formal,
 "observedBadProjectionParameters":{g:[x["name"] for x in p.get("parameters",[])] for g,p in bad.items()},
 "correctedScenarioFacts":{s:[{"path":p,"value":v} for p,v in facts] for s,facts in corrected.items()},
 "correctedProjections":fixed,
 "compiledCarrierFragments":compiled,
 "checks":checks,
 "passCount":sum(x["pass"] for x in checks),
 "checkCount":len(checks),
 "overall":"PASS" if all(x["pass"] for x in checks) else "FAIL"
}
print(json.dumps(out,indent=2,ensure_ascii=False))
