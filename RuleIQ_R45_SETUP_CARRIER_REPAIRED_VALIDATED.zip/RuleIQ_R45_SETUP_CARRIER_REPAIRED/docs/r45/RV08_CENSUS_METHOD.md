# RV-08 Independent Census Method

- `GENERATOR_TARGET_CENSUS.csv` was derived fresh from `UnitTestGenerator_SystemPrompt.txt` plus the selected Standard/When schemas. Validator census/matrix files were not used as source.
- `VALIDATOR_TARGET_CENSUS.csv` was derived separately from `Validator_SystemPrompt.txt` plus the selected Standard/When schemas. Generator census/matrix files were not used as source.
- `GENERATOR_VALIDATOR_SYNC_MATRIX.csv` was created only after both independent censuses were complete, by semantic atom comparison.
- `TARGET_SCHEMA_SYNC.csv` is a fresh structural traversal of both selected schemas, including properties, types, requiredness, enums/consts, array cardinality, refs, items, additionalProperties, compiler mappings and cross-field invariants.
- Correctness validation uses semantic text/schema inspection. `diff`, SHA, checksums, byte equality and file fingerprints are not validation evidence.
