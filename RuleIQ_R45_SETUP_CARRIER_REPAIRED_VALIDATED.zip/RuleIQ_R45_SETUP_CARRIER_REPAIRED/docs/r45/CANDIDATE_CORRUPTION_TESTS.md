# Candidate Corruption Tests

Static target-contract harness starts from schema-valid existing examples and mutates Candidate output only. PASS means each corruption is detected by ordinary Draft-2020-12 schema rules or an existing `CF-*` invariant.

Cases executed: missing `UnitTestRules`; unknown target field; `Name/pyPurpose/pyLabel` identity mismatch; non-string `pyExpectedValue`; primary PagesAndClasses class mismatch; Rule-Obj-When Result cell moved before inputs; Rule-Obj-When non-string expected value. All were detected. No Projection semantic mutation is part of this suite.
