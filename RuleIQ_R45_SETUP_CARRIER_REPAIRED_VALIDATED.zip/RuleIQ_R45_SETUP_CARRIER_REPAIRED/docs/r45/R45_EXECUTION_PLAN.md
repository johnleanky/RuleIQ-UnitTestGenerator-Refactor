# R45 Generator–Validator Synchronization Audit — Execution Plan

Baseline: R44R. No new runtime interface, layer, adapter, registry, schema, agent, or ownership change is permitted.

Execution sequence: independent Generator census; independent Validator census; atomic synchronization matrix; schema/example evidence; minimal correction only for proven bilateral conflicts; Standard/When/DP/DT regressions; Candidate corruption and false-positive checks; historical-residue scan; independent G1–G10; release only at C=H=M=Unresolved=0.

Hard invariant: compare what already exists, prove disagreements from existing target schemas/mappings/examples, and apply the smallest possible correction. Intentional Generator-only and Validator-only rules remain asymmetric.
