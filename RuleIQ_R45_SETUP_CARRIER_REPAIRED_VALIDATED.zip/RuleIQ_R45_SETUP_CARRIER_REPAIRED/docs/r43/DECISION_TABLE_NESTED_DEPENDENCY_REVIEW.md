# Decision Table Nested Dependency Review

Status: VALIDATED

KDT.10 discovers active nested functions, When rules, Decision Tables, Data Pages, properties and executable rules. It emits dependency evidence only. Core/DWL creates/resolves D occurrences and loads the corresponding Knowledge Area. KDT contains no KW/KDP marker calls.

Validated paths:
- DT -> nested DT -> Core/DWL -> KDT
- DT -> When -> Core/DWL -> Rule-Obj-When Knowledge Area
- DT -> Data Page -> Core/DWL -> Rule-Declare-Pages Knowledge Area
- DT -> RUF -> typed dependency -> Core/DWL

Nested DTE/DTA may satisfy/fail an existing OUTCOME but cannot create/split ScenarioCompiler coverage.
