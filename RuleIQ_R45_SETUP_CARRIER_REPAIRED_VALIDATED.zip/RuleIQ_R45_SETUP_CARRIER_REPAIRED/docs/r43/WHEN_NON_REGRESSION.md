# Rule-Obj-When Non-Regression Review

Status: VALIDATED

KW.17-KW.25 remain exactly the loaded When semantic markers. R43 does not change When MAP/WITNESS/FREEZE/grouping/testability/audit semantics. Decision Table dependencies discovered from When remain dependency evidence resolved through Core/DWL.
