# Decision Table Boundary Review

Status: VALIDATED

- KDT.1-KDT.10 own Decision Table domain semantics.
- KDT.11 owns DT-local execution evidence/result-equivalence semantics.
- KDT.12 owns independent DT semantic audit predicates.
- Core owns DTM/DTA/DTE lifecycle, OUTCOME coverage rows, repair, DECIDE policy, Projection and persistence.
- No KDT marker selects a Core repair phase, ASSERT/OMIT comparator policy, Projection action or persistence action.
- R43 removes only duplicate Core domain definitions; KDT production text is unchanged because it was already canonical after R42.1.
