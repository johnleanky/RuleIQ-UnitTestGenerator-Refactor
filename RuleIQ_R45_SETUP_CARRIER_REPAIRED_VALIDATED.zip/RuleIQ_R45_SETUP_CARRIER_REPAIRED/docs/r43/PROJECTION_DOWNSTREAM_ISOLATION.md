# Projection / Generator / Validator Isolation

Status: VALIDATED

Decision Table Knowledge Area produces semantic facts only. Projection remains Core/shared-contract owned. UnitTestGenerator and Validator contain no KDT/DTM/DTA/DTE dependencies and consume only the persisted Projection/target artifact contracts.
