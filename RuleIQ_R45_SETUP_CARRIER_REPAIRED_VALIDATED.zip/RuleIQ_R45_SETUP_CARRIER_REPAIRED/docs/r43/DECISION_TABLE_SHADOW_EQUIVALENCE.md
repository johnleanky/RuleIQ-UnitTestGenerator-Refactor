# R43 Decision Table Shadow Equivalence Review

## Result

KDT.1-KDT.12 already contain the complete Decision Table domain algorithms needed by current ScenarioAuthor. No KDT production rewrite is required before Core thinning.

The Core statements selected for removal are domain-definition repeats only:

- inactive-scalar semantic meaning and scalar-disabled/evaluate-all behavior -> KDT.4/KDT.11;
- direct-DT deterministic property-action output eligibility -> KDT.11;
- nested-DT final-effect evidence rule -> KDT.11;
- direct-DT FINAL result-equivalence tuple `(mode, scalar state/value, ordered final property-effect vector)` -> KDT.11.

Core statements retained are lifecycle/integration boundaries: DTM/DTA/DTE existence and consumption, no re-inference, Core-owned repair, inactive-scalar OMIT mapping, frozen setup gate, PropertyTrace/DECIDE integration, direct-vs-nested coverage ownership, and pre-projection audit gating.

## Hard checks

- KDT.1-KDT.12: exactly one definition each.
- KDT.10 emits dependency evidence only; Core/DWL resolves nested DT/When/DP/RUF dependencies.
- KDT.11 explicitly defines direct-vs-nested candidate/output semantics and direct-DT result equivalence.
- KDT.12 reports PASS/FAIL with evidence/reason only; Core owns repair/Projection.
- No Generator/Validator dependency on KDT markers.

Shadow equivalence verdict: PASS. Destructive Core thinning is permitted only for mapping rows marked REMOVE_DOMAIN_REPEAT.
