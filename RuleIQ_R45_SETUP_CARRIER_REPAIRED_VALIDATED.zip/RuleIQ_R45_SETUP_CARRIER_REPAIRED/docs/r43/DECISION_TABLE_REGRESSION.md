# Decision Table Functional Regression Review

Status: VALIDATED

Confirmed in KDT/Core:
- FIRST_MATCH stored-order evaluation and stop-at-first-match.
- row-aligned pyOrConditions precedence and raw zero-based pyRowNum; -1 is structural no-row sentinel.
- range lower+upper bound semantics.
- EVALUATE_ALL visits every active row and scalar is NONE.
- defaults/no-match actions.
- scalar-disabled property actions remain executable.
- DTA ordered before/operand/after semantics and frozen setup obligations.
- inactive scalar consumers receive exact KDT reasons; Core maps them to OMIT without blank/null/false substitution.
- nested dependency discovery remains Core/DWL mediated.
- KDT.11 direct-RUT result equivalence remains authoritative; Core MAP owns R/E/U coverage rows.
- KDT.12 independently checks selected-row/transcription/setup/property evidence and reports PASS/FAIL only.
