# R43 Decision Table Ownership Cleanup — Execution Plan

Baseline: R42.1 Direct Knowledge Area Semantics.

Execution: census -> conflict/duplication analysis -> KDT marker integrity -> KDT canonicalization -> nested dependency review -> DTM/DTA/DTE boundary -> shadow equivalence -> direct/nested DT coverage -> Core thinning -> KDT.12 audit cleanup -> cross-domain tests -> downstream isolation -> regressions -> token/locality -> fresh-model -> independent G1-G10 -> repair loop until C/H/M=0.

Hard invariants: KDT owns DT domain meaning; Core owns lifecycle/DWL/ScenarioTrace/coverage rows/repair/DECIDE/Projection/persistence; no direct KA-to-KA marker calls; Generator/Validator never consume KDT internals.
