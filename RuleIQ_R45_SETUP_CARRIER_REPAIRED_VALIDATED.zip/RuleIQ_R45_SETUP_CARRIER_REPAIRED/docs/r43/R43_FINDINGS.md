# R43 Findings

Open Critical/High/Medium findings: 0.

Candidate cleanup areas (not findings until shadow review):
- Core §3.7 repeats DT-domain details already owned by KDT.11.
- Core MAP repeats KDT.11 direct-DT FINAL result-equivalence tuple.

## H-R43-01 — CLOSED
Severity: HIGH
Stage: R43D Core thinning
Finding: initial thinning removed explicit DTE→RX/semantic-propagation and DTA→I/O/setup/decision-evidence consumer mapping.
Repair: restored the complete Core integration mapping in one compact bridge sentence; KDT remains domain owner.
Revalidation: PASS — full semantic/adversarial/downstream suites rerun.

## H-R43-02 — CLOSED
Severity: HIGH
Stage: Fresh-model / historical-residue review
Finding: Core §3.7 referenced undefined `DTC/DTRA` records; no current Core/KDT/ScenarioTrace definition exists.
Repair: replaced the undefined historical record names with the actual `KDT.12 audit evidence` checkpoint.
Revalidation: PASS — full semantic/adversarial/downstream suites rerun.

## M-R43-03 — CLOSED
Severity: MEDIUM
Stage: Release metadata consistency
Finding: STATUS.md lost its current-release heading during metadata rewrite although body/current-release field were already R43.
Repair: restored `# CURRENT STATUS — R43 DECISION TABLE OWNERSHIP CLEANUP`.
Revalidation: PASS — metadata 33/33, semantic 104/104, independent G1–G10 64/64.
