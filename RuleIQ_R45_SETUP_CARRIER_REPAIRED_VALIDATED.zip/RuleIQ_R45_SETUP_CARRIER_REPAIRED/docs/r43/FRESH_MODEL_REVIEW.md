# R43 Fresh-Model Review

Status: VALIDATED

Assume no historical context; only current Core plus loaded Knowledge Areas are available.

1. **How is FIRST_MATCH evaluated?** KDT.5; KDT.6/KDT.7 supply cell/action/default semantics.
2. **How is EVALUATE_ALL evaluated?** KDT.9 using KDT.5 cell rules; scalar remains NONE.
3. **How is default behavior evaluated?** KDT.7.
4. **How are nested When/DP/DT/RUF dependencies handled?** KDT.10 emits dependency evidence; Core/DWL resolves it and loads required Knowledge Areas.
5. **What are DTM/DTA/DTE?** KDT.4/KDT.6/KDT.11 define semantic meaning; Core §3.7 owns lifecycle and consumption.
6. **Who owns direct-DT output classes?** KDT.11 defines result-equivalence; Core MAP creates R/E/U coverage rows.
7. **Who selects ASSERT/OMIT/comparator?** Core DECIDE. KDT supplies facts only.
8. **Who repairs KDT failure?** Core §3.7, never KDT.
9. **Can downstream phases reread RuleJSON?** No; only KDT.12 may reread the bounded literal transcription subset for audit.
10. **Can Generator/Validator use KDT markers?** No; downstream consumes Projection/target contracts only.

No answer requires R42.1 or earlier prompts.
