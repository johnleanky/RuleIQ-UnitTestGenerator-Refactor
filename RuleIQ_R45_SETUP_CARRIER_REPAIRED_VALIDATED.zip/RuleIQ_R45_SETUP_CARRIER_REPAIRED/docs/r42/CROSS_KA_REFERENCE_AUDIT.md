# Cross-KA Reference Audit

Status: VALIDATED

No runtime KA contains a foreign adapter-marker reference (`KW.*` inside KDP/KDT, `KDP.*` inside KW/KDT, or `KDT.*` inside KW/KDP). Generator and Validator contain no KW/KDP/KDT marker dependency.

Allowed semantic composition is mediated by Core/DWL:
- DT → nested When/DP/DT/RUF via KDT.10 dependency evidence → D/DWL.
- When → Data Page via Core resolving/finalizing DP evidence consumed by KW witness semantics.
- RUF → typed rule dependencies via D/DWL.

Direct KA → KA invocation = 0.
