# Domain Regression Review

Status: VALIDATED

## Data Page
PASS: evaluated vs notEvaluated distinction; runtime reachability; REQUIRED_SIMS; DP_SIG; equal-signature sharing vs distinct maps; nested pxObjClass; KDP.11 bijection/indexed carrier; KDP.12 seed path/depth.

## Decision Table
PASS: FIRST_MATCH; EVALUATE_ALL; defaults; row-aligned OR precedence; pyRowNum=-1 sentinel; inactive scalar reasons; increment_seed/inverse seed; direct FINAL result classes; KDT.10 nested dependency discovery; D-row closure; KDT.12 FIRST_MATCH/EVALUATE_ALL audit; DT failure/status mapping in Core.

## Rule-Obj-When
PASS: MC/DC coverage, owner/covers, FREEZE irredundant reduction/canonical ordering, independent audit, Data Page evidence composition.

## RUF
PASS: typed Rule-Obj-When/Rule-Declare-Pages/Rule-Declare-DecisionTable dependency discovery; RUF remains a dependency-contract router, not a foreign-domain executor.
