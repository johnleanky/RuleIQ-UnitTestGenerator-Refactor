# Reverse Dependency Audit — KA → Core

Status: VALIDATED

Allowed: adapter boundary declarations and domain facts consumed by Core.
Forbidden: KA selecting phase, BASE, repair route, tool call, Projection/persistence action.

Findings after repair:
- Data Page KA: no lifecycle action remains; top boundary only states Core ownership.
- Decision Table KA: no `OMIT|`, `ASSERT`, comparator selection, `return to WITNESS`, `return to KDT.4`, or Core rebuild command remains. KDT.11/12 emit facts/status/audit results only.
- Rule-Obj-When adapter remains unchanged from R41 and already states Core owns repair.
- RUF states caller owns DWL/tool lifecycle.

Result: illegal lifecycle dependency = 0.
