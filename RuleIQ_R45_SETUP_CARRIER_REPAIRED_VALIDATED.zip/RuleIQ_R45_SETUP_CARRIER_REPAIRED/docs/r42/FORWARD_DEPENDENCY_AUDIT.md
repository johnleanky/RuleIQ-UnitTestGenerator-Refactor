# Forward Dependency Audit — Core → KA

Status: VALIDATED

Core knows only adapter identity/version/required markers, marker-specific semantic results and PASS/FAIL/completeness needed for lifecycle decisions. It does not delegate phase ownership, ScenarioTrace BASE, repair, Projection or persistence to a KA.

- When: exact RuleObjWhenSemanticAdapter v1 / KW.17–KW.25.
- Data Page: exact DataPageSemanticAdapter v1 / KDP.6–KDP.12.
- Decision Table: exact DecisionTableSemanticAdapter v1 / KDT.1–KDT.12.
- Missing/stale/partial/duplicate/ambiguous adapter evidence blocks affected AUTHOR work.

Result: duplicate architectural owner = 0.
