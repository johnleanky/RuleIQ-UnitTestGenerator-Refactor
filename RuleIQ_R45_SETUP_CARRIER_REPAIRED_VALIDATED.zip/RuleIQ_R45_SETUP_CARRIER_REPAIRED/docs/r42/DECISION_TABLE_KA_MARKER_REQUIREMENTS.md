# Decision Table Knowledge Area Marker Requirements

For every original/fetched Decision Table semantic occurrence that may reach AUTHOR, ScenarioAuthor loads `Rule-Declare-DecisionTable_KnowledgeArea` directly and requires exactly one definition of each marker `KDT.1` through `KDT.12`. Missing, partial, duplicate or ambiguous required semantics is a semantic GAP and blocks affected AUTHOR work.

KDT owns domain identity/evaluation/dependency semantics and DT-local semantic evidence/audit predicates. The Knowledge Area returns facts, completeness/status, provenance and failure reason only. Core owns DWL, lifecycle, ScenarioTrace, invalidation/repair, coverage/grouping, assertion policy, Projection and persistence. Cross-domain dependencies found by KDT.10 are emitted as dependency evidence and resolved only through Core/DWL; KDT never invokes KW/KDP/another KDT marker directly.
