# R42 Findings

## R42-H1 — HIGH — CLOSED
**Finding:** Data Page KA contained Core lifecycle/repair policy.

**Repair:** KDP now returns domain facts/status/evidence only. Core §3.5 owns WITNESS/rebuild/GAP/testability response.

## R42-H2 — HIGH — CLOSED
**Finding:** Decision Table KA had no versioned completeness contract.

**Repair:** Added exact `DecisionTableSemanticAdapter v1` header requiring KDT.1–KDT.12 plus Core fail-closed marker census.

## R42-H3 — HIGH — CLOSED
**Finding:** KDT.11/KDT.12 selected invalidation/rebuild actions.

**Repair:** KDT now reports DT-local status/audit PASS|FAIL + affected evidence/reason; Core §3.7 owns invalidation/reconstruction/repair.

## R42-M1 — MEDIUM — CLOSED
**Finding:** KDT selected Core decision policy (`OMIT`, `ASSERT`, comparator legality).

**Repair:** KDT returns UNKNOWN/UNSUPPORTED, inactive-scalar reason, write/existence/blank facts. Core maps these to OMIT/testability/assertion/comparator policy.

## R42-M2 — MEDIUM — CLOSED
**Finding:** Cross-domain composition needed an explicit no-KA→KA execution rule.

**Repair:** Core adapter contract forbids direct KA-marker invocation; KDT.10/nested When/DP/RUF dependencies re-enter Core/DWL. Cross-namespace marker audit is zero.

## R42-M3 — MEDIUM — CLOSED
**Finding:** Initial hardening added ~1.4–2.0% runtime context.

**Repair:** Compressed only new boundary prose; final overhead is ~1.0–1.4% while exact adapter headers/gates remain.

## R42-H4 — HIGH — CLOSED
**Finding:** Core §2 Decision Table acquisition still said KDT.12 itself may invalidate/return to KDT.4, contradicting the new adapter boundary.

**Repair:** KDT.12 now reports PASS/FAIL only; Core explicitly applies §3.7 invalidation/rebuild.

## Open findings
None.
