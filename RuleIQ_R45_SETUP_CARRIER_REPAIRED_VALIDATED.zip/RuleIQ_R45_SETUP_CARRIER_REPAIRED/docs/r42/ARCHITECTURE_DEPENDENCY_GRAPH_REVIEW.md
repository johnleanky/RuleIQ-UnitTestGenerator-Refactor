# Architecture Dependency Graph Review

Status: VALIDATED

Physical invocation graph: `Core -> KA` only.

Semantic composition graph may include DT→When/DP/DT and When→DP, but each edge is materialized as dependency/evidence through Core/DWL. No KA directly invokes or consumes another KA marker namespace.

RUF may identify typed rule dependencies; it does not evaluate the foreign rule semantics. Generator/Validator consume frozen Projection/target artifacts and do not depend on KA internals.
