# R39 Long-Running Conservative Refactoring Plan

## Goal
Optimize `01_PROMPTS/ScenarioAuthor_SystemPrompt.txt` for Claude Opus 4.8 without changing R38 architecture or semantic contracts.

## Status model
Each stage has independent `Implementation` and `Validation` status. A stage is VALIDATED only when its required reviews are complete and Critical=0, High=0, Medium=0.

## Stages
- Stage 0 — Baseline and execution harness.
- Stage A — Language normalization only.
  - A1 Role/authority/tools/phases
  - A2 KnowledgeTool/DWL core
  - A3 Dependency discovery/RuleCrawler
  - A4 Semantic runtime model
  - A5 ScenarioTrace/compiler wording
  - A6 Testability/Projection/handoff/response wording
- Stage B — Deduplicate repeated explanations, never independent validation boundaries.
  - B1 immutability
  - B2 DECIDE authority
  - B3 page/class lineage
  - B4 output universe
  - B5 comparator/ScenarioTrace/testability/tool/response clusters
  - B6 conservative local deduplication only
- Stage C — Structural presentation only.
  - C1 phase table
  - C2 uniform phase templates
  - C3 DWL/RuleCrawler transitions
  - C4 ScenarioTrace grammar
  - C5 static semantic tables
  - C6 all 11 pre-projection gates as predicates
  - C7 compact inline ProjectionV3 grammar
  - C8 preserve local micro-examples
- Final Global Validation — plan compliance, ownership-map coverage, semantic contract comparison, architecture/gate/regression/adversarial/Opus-execution reviews and metrics.

## Non-negotiable rules
- No externalization.
- No architecture changes.
- No SHA/hash/diff based validation. Use textual semantic comparison only.
- Keep independent AUDIT, pre-projection and Projection self-validation boundaries.
- Keep historical regression examples where they disambiguate behavior.
- Any C/H/M finding reopens its owning stage; after repair rerun owning-stage validation and all affected downstream validations.
