# R39 Regression Manifest

| ID | Regression / invariant | Required protection |
|---|---|---|
| RG01 | raw `pxRuleReferences` treated as semantic Property evidence | Property-path closure must create/fetch required Prop dependencies; `pxRuleClassName` is Applies-To/request-class only |
| RG02 | source index reused as target index | RI/PC/LPE/LIC keep source and target coordinates independent; append index only from proven target-list prior count |
| RG03 | unknown target index deletes child effect | preserve child effect; use safe List/InAnyInstance or terminal OMIT, never fabricate index |
| RG04 | `IndexInPageListWhen` not-found ambiguity | keep exact `-1` sentinel semantics from acquired helper contract |
| RG05 | Data Page evaluated false confused with notEvaluated | evaluated false still requires simulation; only terminal notEvaluated excludes it |
| RG06 | missing dependency occurrence hidden by `open=0` | preAuthor property-path census independently discovers missing required Prop occurrence |
| RG07 | non-primary assertion page loses runtime class | OUTPUT freezes basePage/baseClass; ASSERT requires grounded baseClass; Projection.pages copies it |
| RG08 | comparator alias drift | DECIDE chooses canonical comparator; downstream validates exact canonical value, never normalizes alias |
| RG09 | DECIDE loses child output/candidate | complete OUTPUT census and one DECISION per OUTPUT; BUILD/Projection cannot merge/drop distinct claims |
| RG10 | DECIDE re-casts final values | FREEZE/EFFECT/PropertyTrace carries final clipboard lexical value; DECIDE copies, never recasts |
| RG11 | ScenarioTrace compaction loses provenance | MAP/WITNESS/FREEZE/DECIDE/BUILD lineage and HEAD/BASE ownership preserved |
| RG12 | stale/invalid phase patched in place | earliest-owner INVALIDATE + replacement generation; committed rows immutable |
| RG13 | NotTestable incorrectly inferred from zero assertions | enablement + TEST_ORACLE determine testability; unresolved is forbidden terminally |
| RG14 | Projection repairs semantic defects | Projection is mechanical from frozen Author state and validates only compilation |
| RG15 | Generator repairs Author semantics | Generator receives frozen Projection and cannot change Author semantics |
| RG16 | partial persistence followed by early generation | PREPARE_ALL all groups, PERSIST_ALL all groups, then sequential GENERATE_ALL |
| RG17 | recognized negative Generator blocks later groups | recognized SEMANTIC_REJECT/HUMAN marks DONE and continues queue |
| RG18 | Rule-Obj-When forced through Standard DECIDE | When retains dedicated DecisionInput/DecisionResult path and `decide=-` |
