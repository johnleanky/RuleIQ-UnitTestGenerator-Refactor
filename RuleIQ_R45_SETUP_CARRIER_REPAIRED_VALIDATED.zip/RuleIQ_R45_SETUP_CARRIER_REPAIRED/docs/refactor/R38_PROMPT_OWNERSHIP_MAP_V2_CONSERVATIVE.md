# R38 ScenarioAuthor Prompt Ownership Map — V2 Conservative Optimization

## Scope locks

- **Keep all required semantics inside the ScenarioAuthor prompt.** No externalization in this optimization cycle.
- **Do not redesign mechanisms.** Preserve phase order, DWL/RuleCrawler state, ScenarioTrace rows, MAP/WITNESS/FREEZE/DECIDE/BUILD/AUDIT behavior, repair routing, ProjectionV3, Rule-Obj-When behavior, and handoff lifecycle.
- **Optimize expression, not semantics:** use scoped imperatives, compact tables/grammars, local cross-references, and removal of repeated explanations.
- **Do not treat independent gates as duplicate prose.** preAuthor, preCall, SDL/LIC, AUDIT, pre-projection, Projection self-validation, PREPARE/PERSIST/GENERATE correlation gates remain independent.
- **Keep high-signal examples.** Trim them to micro-examples when they disambiguate known failure modes or mode shapes.

## Opus 4.8 writing profile

- Prefer direct imperative rules: `Create`, `Require`, `Reject`, `Return`, `Preserve`, `Do not`.
- State scope explicitly: `For Standard only`, `For original Rule-Obj-When`, `Before each RuleCrawler call`, `For every ASSERT`.
- Use ordered steps where execution order matters; use predicate tables where validation matters.
- Separate **RULE**, **GATE**, and **EXAMPLE** roles. An example never creates authority.
- Replace explanatory rationale with a single canonical rule plus short local guard references.
- Keep literal names (`D`, `RX`, `OUTPUT`, `DECISION`, `HEAD`, `BASE`, etc.) stable; do not introduce synonym vocabularies.

## Example policy

Keep an example inline only when it does at least one of the following:
1. distinguishes two plausible but materially different interpretations;
2. locks a known regression/failure mode;
3. demonstrates an exact serialization/normalization rule that prose is likely to misapply;
4. distinguishes executable modes/shapes.

Under this rule, keep and compress: P21 crawl contrast examples; P22 family-normalization example; P34 `IndexInPageListWhen` sentinel; P45 Data Page evaluated-vs-notEvaluated example; P47/P48 page-context/kind examples; P70 three Projection mode skeletons; P77 exact Generator invocation question. Remove examples that merely restate an unambiguous rule.

## Detailed conservative action map

| ID | Lines | Instruction family | V2 action | Redundancy class | Example policy |
|---|---:|---|---|---|---|
| P01 | 4-6 | Mission + responsibility boundary | **IMPERATIVE_COMPRESS** | SEMANTIC_OR_PROSE | None |
| P02 | 8-14 | Evidence/authority precedence | **KEEP** | SEMANTIC_OR_PROSE | None |
| P03 | 16-26 | Closed external-action allowlist | **TABLE_COMPACT** | SEMANTIC_OR_PROSE | None |
| P04 | 27-30 | Memory write/read success envelopes | **DEFINE_ONCE_REFERENCE_LOCALLY** | SEMANTIC_OR_PROSE | None |
| P05 | 32-44 | End-to-end phase graph | **KEEP_GRAPH_COMPRESS** | SEMANTIC_OR_PROSE | None |
| P06 | 45 | Earliest-owner invalidation / no patch / post-PREPARE lock | **CANONICAL_RULE_PLUS_LOCAL_GUARDS** | SEMANTIC_OR_PROSE | None |
| P07 | 48-50 | KnowledgeTool key/response protocol | **IMPERATIVE_COMPRESS** | SEMANTIC_OR_PROSE | None |
| P08 | 52-59 | KA cache + required-key eligibility | **IMPERATIVE_COMPRESS** | SEMANTIC_OR_PROSE | None |
| P09 | 60-64 | KA acquisition checkpoint + guided extraction | **ORDERED_ALGORITHM** | SEMANTIC_OR_PROSE | None |
| P10 | 65-76 | DWL identity + D row schema + provenance | **KEEP_LIGHT_COMPRESS** | SEMANTIC_OR_PROSE | None |
| P11 | 77-84 | DWLState/DWLPlan/DWLDELTA/STATECHECK renderings | **TABLE_COMPACT** | SEMANTIC_OR_PROSE | None |
| P12 | 85-91 | DWL closure invariants + preAuthor property-path census | **KEEP_GATE** | INTENTIONAL_GATE | None |
| P13 | 93-94 | CRAWL vs AUTHOR modes + READY projection | **IMPERATIVE_COMPRESS** | SEMANTIC_OR_PROSE | None |
| P14 | 96-97,107 | Page/list When helper parsing/context-class algorithm | **KEEP_INLINE_COMPRESS** | SEMANTIC_OR_PROSE | Keep one helper-path example only if needed after rewrite. |
| P15 | 98 | Decision Table invocation discovery/acquisition specifics | **KEEP_INLINE_COMPRESS** | SEMANTIC_OR_PROSE | None |
| P16 | 99-103 | General RuleJSON executable scan + SCAN_HOLDER + pxRuleReferences identity use | **KEEP** | SEMANTIC_OR_PROSE | None |
| P17 | 104 | Property-path closure / Prop dependencies / pxRuleClassName prohibition | **KEEP_EXACT** | SEMANTIC_OR_PROSE | Keep current explicit prohibition; no additional example required. |
| P18 | 105,142-143 | Critical RUF acquisition + result sufficiency | **KEEP_INLINE_DEDUP** | SEMANTIC_OR_PROSE | None |
| P19 | 106 | Data Page D occurrence/acquisition state | **KEEP_INLINE_DEDUP** | SEMANTIC_OR_PROSE | None |
| P20 | 109-117 | RuleCrawler request planner/preCall validation | **KEEP_GATE_ORDERED_STEPS** | INTENTIONAL_GATE | None |
| P21 | 118-120 | Canonical crawl examples | **KEEP_EXAMPLES_TRIM** | EXAMPLE | KEEP: transitive + metadata-lookup contrast. |
| P22 | 121-127 | Synthetic NON_RUF/RUF materializers, family/gates, kind mapping | **TABLE_PLUS_MICRO_EXAMPLE** | EXAMPLE | KEEP: IsValidCity→ISVALIDCITY; one negative IS_VALID_CITY. |
| P23 | 128-136 | RuleCrawler response transitions/fanout/retry | **TRANSITION_TABLE** | SEMANTIC_OR_PROSE | None |
| P24 | 137-141 | Terminal gap policy + numeric crawl caps | **KEEP** | SEMANTIC_OR_PROSE | None |
| P25 | 145 | Reasoning checkpoint ownership registry | **OWNERSHIP_TABLE** | SEMANTIC_OR_PROSE | None |
| P26 | 147-152 | ROOT / named pages / reserved roots | **IMPERATIVE_COMPRESS** | SEMANTIC_OR_PROSE | None |
| P27 | 153 | Parameter resolution/formal typing | **IMPERATIVE_COMPRESS** | SEMANTIC_OR_PROSE | None |
| P28 | 154-166,177 | Pega scalar conversion matrix + policy | **KEEP_INLINE_TABLE** | SEMANTIC_OR_PROSE | Keep only examples that distinguish ambiguous conversions, if any. |
| P29 | 167-175 | CAST row + algorithm | **ORDERED_ALGORITHM** | SEMANTIC_OR_PROSE | None |
| P30 | 176,226 | Runtime-only Param output semantics | **CANONICAL_RULE_LOCAL_REFERENCE** | SEMANTIC_OR_PROSE | None |
| P31 | 178 | RUT_INPUTS/RUT_OUTPUTS/OWNER_COVERAGE_OUTPUTS inventory | **KEEP_CANONICAL** | SEMANTIC_OR_PROSE | None |
| P32 | 179-183 | Seed-direction / FORBIDDEN_SEEDS / SDL | **KEEP_GATE_COMPRESS** | INTENTIONAL_GATE | None |
| P33 | 185-187 | RX row + generic execution/branch truth | **KEEP_CORE_IMPERATIVE** | SEMANTIC_OR_PROSE | Retain sentinel example separately in P34. |
| P34 | 187 | Specific IndexInPageListWhen sentinel regression lock | **KEEP_REGRESSION_EXAMPLE** | EXAMPLE | KEEP: 1-based match / -1 no-match / branch <=0 distinction. |
| P35 | 188 | Rule-Obj-When pyLogic parsing/evaluation | **KEEP_INLINE_COMPRESS** | SEMANTIC_OR_PROSE | Consider one compact OR-clause example only if evals show ambiguity. |
| P36 | 190-193 | RI/PC producer inventory + source/target/index invariant | **KEEP_CORE_REFERENCE** | SEMANTIC_OR_PROSE | Keep one symbolic template example if it materially aids path/index handling. |
| P37 | 194-196 | LPE list mutation census | **KEEP** | SEMANTIC_OR_PROSE | None |
| P38 | 197-199 | APB assertion producer binding | **KEEP_COMPRESS** | SEMANTIC_OR_PROSE | None |
| P39 | 200-202 | LIC list/index/count safety | **KEEP_GATE** | INTENTIONAL_GATE | None |
| P40 | 204-205 | Candidate universe construction | **LOCAL_DELTA_REFERENCE** | SEMANTIC_OR_PROSE | None |
| P41 | 206-207 | PropertyTrace + presence semantics | **IMPERATIVE_COMPRESS** | SEMANTIC_OR_PROSE | None |
| P42 | 208-209 | Assertion ladder + terminal OMIT rules | **KEEP_LADDER_IMPERATIVE** | INTENTIONAL_GATE | None |
| P43 | 210 | RUF chain/string transformation exactness | **KEEP_INLINE_COMPRESS** | SEMANTIC_OR_PROSE | A micro-example is optional only for a proven tricky transformation. |
| P44 | 212-215 | Data Page DP_SIG/REQUIRED_SIMS/DPA/runtime simulation | **KEEP_CORE_IMPERATIVE** | SEMANTIC_OR_PROSE | None |
| P45 | 216-217 | DP example + seed-path lock | **KEEP_EXAMPLE_TRIM** | EXAMPLE | KEEP one-line DP reachability example. |
| P46 | 219-225 | Property modes/types + comparator domains | **KEEP_INLINE_CANONICAL_SETS** | SEMANTIC_OR_PROSE | None |
| P47 | 227 | ASSERT_PAGE_CONTEXT basePage/baseClass lineage | **KEEP_EXACT_MICRO_EXAMPLE** | EXAMPLE | KEEP one nested-page example; keep Primary.X contrast only if concise. |
| P48 | 228-232 | Assertion-kind selection + representation rules + examples | **KEEP_RULES_TRIM_EXAMPLES** | EXAMPLE | KEEP at most 1–2 micro-examples. |
| P49 | 234-236 | Decision Table semantic integration/inactive scalar/DTA/DTE | **KEEP_INLINE_IMPERATIVE** | SEMANTIC_OR_PROSE | None |
| P50 | 239 | Scenario compiler phase order | **ONE_LINE_REFERENCE** | SEMANTIC_OR_PROSE | None |
| P51 | 241-250 | ScenarioTrace generation/HEAD/BASE/immutability protocol | **KEEP_PROTOCOL_COMPACT** | SEMANTIC_OR_PROSE | None |
| P52 | 252-282 | Phase row sets + every row grammar + arity | **KEEP_INLINE_GRAMMAR_TABLE** | SEMANTIC_OR_PROSE | Keep examples only if needed for escaping/encoding ambiguity. |
| P53 | 284-287 | OUTPUT/DECISION field semantics + normalized decision shapes + comparators | **KEEP_SCHEMA_REFERENCE_SEMANTICS** | SEMANTIC_OR_PROSE | None |
| P54 | 289-291 | General row invariants + phase ownership + no silent loss | **OWNERSHIP_TABLE_PLUS_GUARDS** | SEMANTIC_OR_PROSE | None |
| P55 | 293-295 | SCENARIO fact encoding + pre-MemoryTemp roundtrip validation | **KEEP_SERIALIZER_GATE** | SEMANTIC_OR_PROSE | Keep one escape example only if necessary. |
| P56 | 297 | DECIDE sole final authority | **KEEP_AUTHORITY_PLUS_LOCAL_GUARDS** | SEMANTIC_OR_PROSE | None |
| P57 | 299 | Informational scenario invariant | **KEEP_LOCAL_GUARD_REFERENCE** | SEMANTIC_OR_PROSE | None |
| P58 | 300-305 | MAP coverage/outcome/PDEF construction | **KEEP_PHASE_TEMPLATE_STYLE** | SEMANTIC_OR_PROSE | Retain examples only if a MAP rule is otherwise ambiguous. |
| P59 | 306-314 | WITNESS realization/coverage/PATH | **KEEP_PHASE_TEMPLATE_STYLE** | SEMANTIC_OR_PROSE | None |
| P60 | 315-327 | FREEZE final replay/PATH/EFFECT | **KEEP_PHASE_TEMPLATE_STYLE** | SEMANTIC_OR_PROSE | None |
| P61 | 328-334 | Physical grouping | **IMPERATIVE_COMPRESS** | SEMANTIC_OR_PROSE | None |
| P62 | 335-343 | BUILD GROUP/LOCATION mapping | **IMPERATIVE_COMPRESS** | SEMANTIC_OR_PROSE | None |
| P63 | 344-365 | AUDIT lineage checks + REPAIR loop | **KEEP_INDEPENDENT_GATE_PREDICATES** | INTENTIONAL_GATE | No illustrative examples needed inside AUDIT. |
| P64 | 367-376 | Standard DECIDE output census/support/decision construction | **KEEP_PHASE_DEDUP_INPUT_SEMANTICS** | SEMANTIC_OR_PROSE | None |
| P65 | 377-379 | Rule-Obj-When final cell/result decisions | **KEEP_INLINE_COMPRESS** | SEMANTIC_OR_PROSE | None |
| P66 | 380-389 | Feasibility / enablement / TEST_ORACLE / testability | **KEEP_CANONICAL** | SEMANTIC_OR_PROSE | Retain any example only if needed to distinguish NotTestable from unresolved. |
| P67 | 390-401 | UI metadata derivation | **IMPERATIVE_COMPRESS** | SEMANTIC_OR_PROSE | None |
| P68 | 402-415 | Pre-projection 11-gate checklist | **KEEP_ALL_GATES_PREDICATE_COMPRESS** | INTENTIONAL_GATE | None |
| P69 | 417-429 | Projection materialization procedure | **KEEP_COMPILER_IMPERATIVE** | SEMANTIC_OR_PROSE | Examples live in P70. |
| P70 | 430-452 | Projection shape examples | **KEEP_EXAMPLES_COMPRESS** | EXAMPLE | KEEP 3 compact shape examples. |
| P71 | 453-454 | Projection source-boundary reminders | **ONE_SENTENCE_BOUNDARY** | SEMANTIC_OR_PROSE | None |
| P72 | 455-503 | Full UnitTestProjectionV3 closed grammar | **KEEP_FULL_INLINE_SCHEMA_COMPACT** | SEMANTIC_OR_PROSE | P70 supplies mode examples; avoid extra examples here. |
| P73 | 504-512 | Projection self-validation/reconciliation | **KEEP_INDEPENDENT_VALIDATOR_PREDICATES** | INTENTIONAL_GATE | None |
| P74 | 513-523 | Projection-first orchestration definitions/table | **KEEP_TABLE_REFERENCE_GRAPH** | SEMANTIC_OR_PROSE | None |
| P75 | 524-525 | PREPARE_ALL gate | **KEEP_GATE** | INTENTIONAL_GATE | None |
| P76 | 526-532 | PERSIST_ALL write/correlation/failure policy | **KEEP_GATE_REFERENCE_ENVELOPE** | INTENTIONAL_GATE | None |
| P77 | 533-549 | GENERATE_ALL sequential invocation/read/negative handling | **KEEP_GATE_REFERENCE_ENVELOPE** | INTENTIONAL_GATE | Keep exact invocation example/question because it is protocol data, not explanatory example. |
| P78 | 550-551 | Completion counters/status rule | **KEEP_RULE_REFERENCE_RESPONSE** | SEMANTIC_OR_PROSE | None |
| P79 | 552-553 | External two-key response contract | **KEEP_EXACT** | SEMANTIC_OR_PROSE | None |
| P80 | 554-604 | Legacy Concepts/Style/Guardrails tail incl. pyExpectedValue typing | **DELETE_OBSOLETE_CONFLICTING_TAIL** | SEMANTIC_OR_PROSE | None |

## Revised duplication-cluster decisions

| Cluster | Mechanism | V2 decision |
|---|---|---|
| C01 | Immutable state / earliest-owner repair | Keep one full canonical rule. Keep short mutation guards at phase boundaries. Keep AUDIT repair validation independent. |
| C02 | DECIDE authority | Keep one semantic definition; keep downstream consume/verify guards. Delete only explanatory restatement. |
| C03 | basePage/baseClass lineage | Keep §3.6 definition, DECIDE persistence, AUDIT verification, Projection copy, and §6.8 self-validation. These are distinct lifecycle gates. |
| C04 | Observable output universe | Keep inventories/candidate mechanisms unchanged. Make §3 output rules canonical and make DECIDE text consume them rather than re-explain eligibility. |
| C05 | Rule-Obj-When exceptions | Do not redesign into a new adapter architecture. Keep exceptions where lifecycle phases need them; standardize to short scoped delta sentences. |
| C06 | ProjectionV3 grammar | Keep full closed grammar inline in ScenarioAuthor. Compact format only; no external shared contract in this cycle. |
| C07 | Comparator domains | Keep canonical sets once in §3.6. Other sections validate/reference exact values without repeating the lists. |
| C08 | ScenarioTrace ownership | Keep protocol and all phase rows. Use compact ownership/row-set/arity tables; keep phase-specific gates. |
| C09 | Data Page lifecycle | Keep acquisition, runtime simulation, and validation as distinct existing mechanisms. Remove only repeated rationale between them. |
| C10 | Decision Table lifecycle | Keep current trigger and DTM/DTA/DTE bridge inline. Replace prose explanation with explicit imperatives and KDT references. |
| C11 | Testability | Keep §5.3 as semantic authority; keep local guards elsewhere that prevent premature NotTestable classification. |
| C12 | Tool envelopes | Keep envelopes inline once; call sites reference symbolic envelope names and add local correlation checks. |
| C13 | Rule-specific helper semantics | Keep inline for robustness. Compress to deterministic algorithms; retain known regression examples. |
| C14 | Examples | Do not bulk-delete. Keep only high-signal regression/contrast/shape examples and compress them. |
| C15 | External response | Keep authoritative §8 two-key contract. Delete only the obsolete legacy tail after it. |

## Three review passes

### Pass 1 — architecture freeze
- Rejected every `EXTERNALIZE`, `MOVE_OUT`, and architecture-redesign recommendation from V1.
- Preserved all current phase/state/row/gate mechanisms.
- Only P80 remains a true deletion because it is obsolete residue after the authoritative response contract and contains a competing typing instruction.

### Pass 2 — examples versus noise
- Reclassified P21 and P70 from deletion to retention with compression.
- Retained P34 and P45 because they lock non-obvious runtime semantics.
- Retained P47/P48 micro-examples for page-context/representation ambiguity.
- Marked protocol payloads such as P77 Generator question as exact protocol data, not removable examples.

### Pass 3 — defensive redundancy versus duplicate explanation
- Preserved independent validation boundaries: preAuthor, preCall, semantic support gates, AUDIT, pre-projection checklist, producer-side Projection validation, and handoff correlation gates.
- Optimization applies to the **explanation** around a gate, not to the gate predicate or its independent execution.
- For repeated semantic facts, keep one full definition and use short local `Require <canonical invariant>` guards where lifecycle safety benefits from repetition.

## Recommended rewrite grammar

Use these local forms without changing architecture:

```text
RULE — scope
- Do X.
- Preserve Y.
- Do not infer Z.

GATE — boundary
PASS iff: A; B; C.
FAIL: <owner/action>.

EXAMPLE — non-authoritative
<minimal contrast or regression witness>
```

For phase sections, preserve the mechanism but normalize prose to:

```text
INPUT: <existing upstream authorities>
CREATE: <existing rows/state>
REQUIRE: <existing gates>
FAIL: <existing owner/repair>
```

This is a presentation refactor only; it does not change phase ownership or behavior.

## Conservative reduction target

- Do **not** target the previous 80–100k range in this cycle; that depended on externalization/architectural consolidation.
- First target: **~115–125k characters** (roughly 15–22% reduction) while preserving every mechanism and all independent gates.
- Stretch target after regression evaluation: **~105–115k** only if additional prose duplication can be removed without collapsing gates/examples.
- Measure each wave against the existing regression corpus; size is secondary to semantic equivalence.

## Recommended implementation order

1. **Language normalization:** imperative rewrite + explicit scope; no deletion except P80/format residue.
2. **Local prose deduplication:** P05/P50, P06/P54/P56, P31/P40/P64, comparator repetition, tool-envelope repetition.
3. **Schema/table compaction:** P11, P28, P52, P72 without changing any field/arity/constraint.
4. **Gate compaction:** P63, P68, P73 to predicates + existing failure routing; preserve every check.
5. **Example trimming:** keep the high-signal set above, rewrite as micro-examples.
6. Run full static + bad-case + live replay validation before accepting the optimized prompt.
