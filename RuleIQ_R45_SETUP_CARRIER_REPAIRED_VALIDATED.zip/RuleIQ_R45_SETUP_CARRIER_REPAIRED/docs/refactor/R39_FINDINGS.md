# R39 Findings

No findings yet.

## A3 Review findings

- A3-FP1 — LOW/FALSE_POSITIVE: checker expected literal `Unconsumed`; rewritten text preserves the semantic rule as `Ignore unconsumed reference metadata`. CLOSED after textual review.
- A3-FP2 — LOW/FALSE_POSITIVE: checker expected literal `five-key/four-key`; exact field censuses remain present. CLOSED after textual review.

## B1–B4 review findings
- B14-FP1 — LOW/FALSE_POSITIVE: literal checker expected capitalized `Mapped child`; semantic prohibition remains exact as `mapped child is never represented only by parent`. CLOSED after textual review.

## Stage B aggregate review
- B-FP1 — LOW/FALSE_POSITIVE: RG08 checker expected lowercase phrase; canonical comparator rule and pre-projection rejection are present. CLOSED after textual semantic review.


## Stage C findings
- C-H1 — HIGH/CLOSED: duplicated pre-MemoryTemp Standard AUDIT wording omitted active WITNESS although canonical R38 BASE contract requires `MAP,WITNESS,FREEZE,DECIDE,BUILD`. Resolved by making the canonical BASE contract explicit in the compact validation algorithm. Revalidation required for ScenarioTrace, AUDIT, pre-projection and Projection/handoff boundaries.

- C-M1 — MEDIUM/CLOSED: several sensitive consumers used vague `current/existing` references for assertion grammar, structural support, failure owner, Projection grammar, and Decision Table OMIT handling. Replaced with explicit canonical owners (§3.3–§3.4, §3.6, §6.8, §3.7+§5.1, §1.4). Full Stage C revalidation required.

- C-FP2 — LOW/FALSE_POSITIVE: RG15 checker expected a literal phrase; §7.3 explicitly makes `GENERATOR_REPAIR` Candidate-internal/invalid on Projection and forbids Author Candidate repair. CLOSED.
- C-FP3 — LOW/FALSE_POSITIVE: RG16 checker omitted backticks around `WriteMemory`; PREPARE_ALL/PERSIST_ALL/GENERATE_ALL ordering and all-persist-before-generate gate remain explicit. CLOSED.
- C-FP4 — LOW/FALSE_POSITIVE: RG17 checker expected literal `state=DONE`; §7.3 explicitly marks recognized `SEMANTIC_REJECT/HUMAN` rows DONE and continues. CLOSED.
