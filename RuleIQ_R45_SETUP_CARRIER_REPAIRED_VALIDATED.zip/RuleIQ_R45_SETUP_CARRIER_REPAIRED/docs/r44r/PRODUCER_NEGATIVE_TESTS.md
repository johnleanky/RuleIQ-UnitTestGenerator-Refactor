# Producer Negative Tests

These are static contract tests: every semantic-invalid case has an Author-side blocking rule before persistence; Generator is not required to rediscover it.

- **PN-01 — Comparator alias / noncanonical comparator:** Author §3.6 exact comparator domains + §5.5 Standard decision + §6.4 → `BLOCK BEFORE PERSISTENCE`.
- **PN-02 — Comparator requires expected but expected absent:** Author §3.6 representation rule + DECIDE/Projection reconciliation → `BLOCK BEFORE PERSISTENCE`.
- **PN-03 — Page assertion carries expected:** Author §6.4.3 Page grammar → `BLOCK BEFORE PERSISTENCE`.
- **PN-04 — Non-primary assertion page/class not grounded:** Author §5.5 ROOT/context + §6.4.6 → `BLOCK BEFORE PERSISTENCE`.
- **PN-05 — Duplicate semantic Scenario names in physical group:** Author §6.4.1 → `BLOCK BEFORE PERSISTENCE`.
- **PN-06 — When present input value empty or literal <EMPTY>:** Author §6.4.4 → `BLOCK BEFORE PERSISTENCE`.
- **PN-07 — When row census differs across rows:** Author §5.5 When + §6.4.4/6.4.5 → `BLOCK BEFORE PERSISTENCE`.
- **PN-08 — Illegal semantic mode / unresolved testability:** Author §5.5 Testability + §6.4.5 → `BLOCK BEFORE PERSISTENCE`.
- **PN-09 — Simulation census differs from REQUIRED_SIMS:** Author §5.5 Data Page + §6.4.2 + §6.4.7 → `BLOCK BEFORE PERSISTENCE`.
- **PN-10 — Projection differs from frozen DECIDE/OUTPUT or KW authority:** Author §6.4.6/6.4.7 → `BLOCK BEFORE PERSISTENCE`.
