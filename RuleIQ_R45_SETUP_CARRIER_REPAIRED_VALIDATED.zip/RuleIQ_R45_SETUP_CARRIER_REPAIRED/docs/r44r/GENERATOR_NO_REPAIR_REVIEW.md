# Generator No-Repair Review

Status: PASS. Generator never edits/replaces Projection facts, semantic values, scenario membership, expected values, comparator choice, page/class bindings, When results, confidence/testability, or simulations. Candidate repair is permitted only from the same immutable Projection and authoritative target mapping. `GENERATOR_REPAIR` remains Candidate-internal and is never written to Projection. Projection terminal failures are diagnostic target/generation outcomes and do not reopen Author phases in the same run.
