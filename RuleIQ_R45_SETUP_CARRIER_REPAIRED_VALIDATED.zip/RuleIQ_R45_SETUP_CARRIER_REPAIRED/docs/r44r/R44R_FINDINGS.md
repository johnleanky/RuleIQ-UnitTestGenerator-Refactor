# R44R Findings

## Closed findings

- **H-R44R-01 — R44 consumer semantic validation layer:** R44 had added independent Generator checks for Author-owned Projection invariants. Fixed by reset from R43 and trusted-producer interface model.
- **H-R44R-02 — contract knowledge vs validation ownership ambiguity:** resolved by explicit P/T/G classification and Generator statement that complete local contract is interpretation/guarantee, not second producer validator.
- **H-R44R-03 — Validator mode routing could read as semantic mode validation:** replaced with mechanical target/fidelity-path selection; business semantic eligibility remains Author-owned.
- **M-R44R-04 — Generator source grammar lacked exact comparator-domain knowledge relative to Author:** full comparator domains are now locally documented as producer guarantees, without consumer semantic revalidation.
- **M-R44R-05 — Memory pyGroup/physicalGroupKey equality not explicit in R43 Generator:** retained as T-only transport correlation based on existing historical R3 lifecycle identity; explicitly barred from semantic/target naming use.

Final open Critical/High/Medium: 0. Independent G1–G10 and fresh-agent review PASS.
