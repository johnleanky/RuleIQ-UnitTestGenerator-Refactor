# R44R Projection Producer Authority Restoration — Execution Plan

Baseline: R43 validated release. R44 is evidence only, never production source.

Hard invariant: **AUTHOR GUARANTEES. GENERATOR TRUSTS. GENERATOR TRANSLATES. GENERATOR VALIDATES ONLY ITS OWN OUTPUT.**

Execution stages: reset/census; P/T/G ownership classification; Author semantic completeness review; 11 pre-projection gates; producer self-validation; Generator trusted-interface rewrite; transport boundary; comparator/expected/page/When/Standard/NotTestable ownership; no-repair/no-feedback-loop; Generator target validation; Validator boundary; bilateral interface equivalence; semantic-check purge; producer/Generator/cross-domain regressions; handoff preservation; token/locality optimization; fresh-agent and independent G1–G10 review. Release requires C=0/H=0/M=0.
