# Generator Transport/Target Tests

- **GT-01 — Malformed Invocation identity** [T] → INVALID_INPUT / zero tool calls.
- **GT-02 — Projection Memory GUID/case/type mismatch** [T] → SOURCE_INVALID.
- **GT-03 — Projection payload not JSON object** [T] → SOURCE_INVALID.
- **GT-04 — pyGroup != physicalGroupKey** [T] → SOURCE_INVALID transport correlation.
- **GT-05 — Target contract missing/ambiguous** [G] → KNOWLEDGE_FAILED.
- **GT-06 — Frozen source not deterministically representable by target** [G] → SEMANTIC_REJECTED or HUMAN per §3.1; source unchanged.
- **GT-07 — Compiler emits Candidate different from Projection mapping** [G] → PROJECTION_FAILED / rebuild Candidate only.
- **GT-08 — Candidate persistence failure** [G] → CANDIDATE_WRITE_FAILED.
- **GT-09 — Validator requests target-fragment repair** [G] → new Candidate from same frozen Projection.
- **GT-10 — Validator target/fidelity fails nonrepairably** [G] → terminal Projection failure; no Author semantic repair.
