# Cross-Domain Regression

Static semantic regression scope and result: PASS.

- Standard: Author owns DECIDE/OUTPUT/assertions; Generator receives frozen assertions only.
- Standard + Data Page: REQUIRED_SIMS/KDP semantics remain Author-side; Generator sees only frozen `simulations`.
- Rule-Obj-When: KW.20–KW.25 and MC/DC remain Author-side; Generator sees frozen rows only.
- When + Data Page: Author resolves/freeze-composes both domains before Projection.
- Decision Table: KDT remains Author-side through Core/DWL; Generator has no KDT markers.
- DT + DP / DT + When / DT + When + DP: cross-domain dependency composition remains Core/DWL-owned and is absent from Generator.
- Projection schema/target schemas/Knowledge Areas/tool contracts are unchanged from R43.
- `PREPARE_ALL -> PERSIST_ALL -> GENERATE_ALL` remains unchanged; Generator runs only after all Projection payloads are producer-validated and persisted.
