# R42.1 Direct Knowledge Area Semantics — Validation

Status: **PASS**

Checks: 86/86 PASS

Critical=0 High=0 Medium=0.

No semantic adapter runtime layer remains. Required Knowledge Area markers, domain obligations, Core-owned lifecycle/repair, Core/DWL mediation and downstream isolation are preserved.

## Runtime context chars
- Standard: 133342 -> 133049 (-293)
- Standard+DP: 145678 -> 145295 (-383)
- When: 154686 -> 154285 (-401)
- When+DP: 167022 -> 166531 (-491)
- DT: 171692 -> 171272 (-420)
- DT+DP: 184028 -> 183518 (-510)
