# R42.1 Findings

## Closed findings

- **M-01 Documentation residue:** active STATUS/HANDOFF/START initially still identified R42 and used older adapter terminology. Fixed; all active entrypoints identify R42.1 direct Knowledge Area semantics.
- **M-02 Evidence naming:** semantic-adapter contract/review filenames implied a runtime layer that does not exist. Replaced with Knowledge Area marker-requirements review artifacts.
- **FP-01 KDP.12 check:** first semantic validator expected a spacing-specific `actualDepth` phrase; source rule was present unchanged. Checker corrected; full suite rerun.

## Final
Critical=0 High=0 Medium=0.
