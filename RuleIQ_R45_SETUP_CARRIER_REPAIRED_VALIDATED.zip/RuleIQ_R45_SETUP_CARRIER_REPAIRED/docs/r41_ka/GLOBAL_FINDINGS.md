# R41 findings ledger

Final open findings: **0**.

| ID | Severity | Owner | Finding | Disposition |
|---|---|---|---|---|
| H-11-01 | High | Stage 4/11 | DP PKA eligibility could be read too late because generic dependency rule emphasized executable dependencies | Fixed: explicit discovered-DP PKA rule; full downstream revalidation PASS |
| M-16-01 | Medium | Stage 3/16 docs | Adapter contract retained stale executable-only DP trigger | Fixed to Core fail-closed trigger; revalidated |
| M-16-02 | Medium | Stage 3/16 | Older general When-KA markers contain tool/target vocabulary that could look like authority leakage | Fixed with explicit adapter-scope/Core-authority barrier; migrated markers remain pure; revalidated |

Earlier migration findings are documented in stage-specific reviews and are closed.

Critical=0 High=0 Medium=0.
