# Core thinning review — Rule-Obj-When wave
Status: **VALIDATED**

Deleted from Core only after shadow validation: detailed When coverage, witness, FREEZE-reduction, grouping, DecisionInput/DecisionResult, testability and independent-audit algorithms.
Retained in Core: original-RUT workflow firewall; phase/row/BASE ownership; commit gates; repair routing; physical serialization contract; pre-projection gate; target boundary.
No generic Standard algorithm was externalized.

Critical=0 High=0 Medium=0.
