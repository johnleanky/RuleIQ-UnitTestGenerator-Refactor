# R41 Stage 2 — Historical layer / contradiction review

Status: **READY + VALIDATED after repair design**

## Findings reviewed
- **HIGH H2-01:** existing `KW.16.1` mixes valid semantic column-signature/list-size feasibility with obsolete target-facing phrases (`MultInpComb rows`, physical group, RuleCode). Migration must retain the semantic feasibility rule but remove target serialization ownership from the KA. Planned owner split: semantic column feasibility stays KA; Projection/Generator keep physical representation.
- Existing KDP.1–KDP.5 are already canonical domain owners for identity, scope, caller binding and simulated-loader boundary; Core duplicates some of them.
- R40 When restoration is trusted only where source-fidelity W01–W25 mapping proved it; R39D reconstructed D1 wording is not an authority.
- Vague historical phrases are forbidden in new adapter markers.

Repair condition is encoded in Stages 5–8; no production semantics removed yet.

Open C/H/M after design review: 0.
