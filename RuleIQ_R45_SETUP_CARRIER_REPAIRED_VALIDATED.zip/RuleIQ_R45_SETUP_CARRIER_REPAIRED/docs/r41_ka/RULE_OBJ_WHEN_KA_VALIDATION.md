# Rule-Obj-When KA shadow-definition validation

Status: **READY + VALIDATED**

- KW.17–KW.25 adapter markers present and complete.
- W01–W25 ownership map: 25/25 accounted; W01/W11 Core, W23 shared target contract, remaining domain semantics owned by existing Rule-Obj-When KA markers.
- Source-fidelity anchors validated against the R40 restoration mapping: coverage/MC-DC, witness owner/covers, deterministic reduction, canonical given+simulation ordering, simulation grouping, column/cell semantics, exact Boolean Result, mandatory R-covering rows, zero-R-only informational mode, independent audit.
- `KW.16.1` target-facing historical wording was normalized: semantic feasibility remains KA-owned; RuleCode/physical target ownership was removed from that marker.
- During this shadow stage the old Core definitions remained present, so no semantic obligation depended solely on the new KA before equivalence review.

Findings after repair: Critical=0 High=0 Medium=0.
