# R41 KA semantic externalization — executed plan

Program: Stage 0 baseline; 1 atomic census; 2 historical/contradiction review; 3 adapter contract; 4 loader integration; 5 Rule-Obj-When shadow→validated canonical KA→Core thinning; 6 Data Page shadow→validated canonical KA→Core thinning; 8 duplicate-authority cleanup; 9 token/locality optimization; 10 equivalence matrix; 11 fresh-agent; 12 adversarial loading; 13 regression; 14 Standard non-regression; 15 token economics; 16 cross-artifact architecture; 17 independent G1–G10.

Safety rule: definition may move only after shadow equivalence; independent lifecycle checks stay in Core. Every stage is READY+VALIDATED only at C=H=M=0. Any later finding reopens its earliest owner and all affected downstream validation.
