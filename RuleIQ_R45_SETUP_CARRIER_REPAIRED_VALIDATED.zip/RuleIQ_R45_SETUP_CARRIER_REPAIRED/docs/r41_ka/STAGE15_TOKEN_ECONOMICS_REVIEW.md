# Stage 15 — Token economics / locality review
Status: **READY + VALIDATED**

Measured character context (char/4 shown only as a rough token proxy; no claim of tokenizer identity):

| Activation pattern | R40 chars | R41 chars | delta |
|---|---:|---:|---:|
| Standard_no_DP | 143,720 | 131,703 | -8.361% |
| Standard_DP | 152,017 | 143,721 | -5.457% |
| When_no_DP | 158,684 | 153,047 | -3.552% |
| When_DP | 166,981 | 165,065 | -1.147% |

Core: 143,720 → 131,703 chars (-8.361%).

Every sampled activation pattern is smaller, including When+DP. Therefore the refactor does not merely move Core tokens into always-loaded KAs. The original ~115–125k Core number was a soft target, not an acceptance gate; further deletion was rejected where it would remove independent lifecycle validation.

Largest logical paragraphs: Core 9,536; When KA 1,938; DP KA 2,354 chars.

Critical=0 High=0 Medium=0.
