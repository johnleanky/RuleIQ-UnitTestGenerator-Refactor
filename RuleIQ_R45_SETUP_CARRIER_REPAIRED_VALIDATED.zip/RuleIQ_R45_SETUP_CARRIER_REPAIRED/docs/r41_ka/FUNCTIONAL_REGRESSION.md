# Stage 13 — Functional semantic regression
Status: **READY + VALIDATED**

Static semantic regression is evaluated over **Core + loaded KA + shared target contracts**, not by expecting old inline prose to remain. `validate_r41_global.py` final result: **72/72 PASS**.

Coverage includes RG01–RG18 and migrated domain obligations: property-path/embedded-class closure; source/target index separation; `IndexInPageListWhen=-1`; evaluated vs notEvaluated; OUTPUT basePage/baseClass; comparator authority; OUTPUT/DECISION census; immutable ScenarioTrace/repair; NotTestable rules; Projection no-repair; Generator no-repair; PREPARE/PERSIST/GENERATE; When non-DECIDE path; W01–W25; DP01–DP20; When Generator/schema seam.

The migration maps report W01–W25=25/25 PASS and DP01–DP20=20/20 PASS; GAP=0, UNOWNED=0, AMBIGUOUS=0.

Critical=0 High=0 Medium=0.
