# R41 Knowledge Area Marker Requirements

## Boundary
Core owns authority, tool legality, DWL, lifecycle phases, ScenarioTrace row ownership/BASE, commit gates, invalidation/repair, Projection lifecycle and persistence ordering.
A Knowledge Area may define only domain interpretation, algorithms, domain completeness/feasibility and evidence requirements.

## Fail-closed marker completeness
ScenarioAuthor loads the existing Knowledge Area directly through KnowledgeTool. No semantic adapter layer exists.

Required domain semantics are identified by stable markers inside the loaded Knowledge Area. Every required marker MUST occur exactly once. Missing or duplicate required semantics is a semantic GAP; generic/historical fallback is forbidden.

### Rule-Obj-When
Required iff immutable original `RUT_TYPE=Rule-Obj-When`:
`KW.17` through `KW.25`.

### Data Page
Required for every discovered `Rule-Declare-Pages` D occurrence that may reach AUTHOR unless a scenario-independent terminal pre-access proof already excludes that occurrence:
`KDP.6` through `KDP.12`.

The full Knowledge Area Description may contain older/general domain markers. Required ScenarioAuthor markers own migrated domain semantics; other markers cannot override Core architecture. Tool-oriented verbs in general domain markers express semantic dependency requirements only and are realized through Core tool/DWL contracts. Target-artifact examples never authorize ScenarioAuthor target construction.

## Forbidden Knowledge Area authority
A Knowledge Area MUST NOT add/remove/reorder phases, alter row families/BASE, tool legality, repair routing, commit gates, Projection/persistence ordering, or downstream repair policy.
