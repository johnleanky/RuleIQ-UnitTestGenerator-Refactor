# Stage 11 — Fresh-agent review
Status: **READY + VALIDATED**

Review assumption: the model has no old Main Prompt, R39D, or migration history; it sees only current Core plus deterministically loaded current Knowledge Areas.

| Mechanism | Authority | Required load | Semantic algorithm | Receiving Core state | Completeness | Failure / repair |
|---|---|---|---|---|---|---|
| Rule-Obj-When | Core lifecycle + `RuleObjWhenSemanticAdapter` v1 | primary When KA, exact header, exactly-one KW.17–KW.25 | KW.17–KW.25 | MAP OUTCOME; WITNESS/FREEZE SCENARIO; GROUP/LOCATION; AUDIT | marker-specific + Core commit gates | semantic GAP before AUTHOR; later mismatch -> earliest Core owner / AUDIT REPAIR |
| Data Page | Core lifecycle + `DataPageSemanticAdapter` v1 | discovered DP D occurrence unless already terminally excluded by scenario-independent pre-access proof | KDP.2/KDP.4/KDP.6–KDP.12 | WITNESS access/binding; FREEZE SIM; DPA | REQUIRED_SIMS↔SIM bijection + DPA | unresolved -> WITNESS; rebuild/replay; never patch FREEZE |

Findings repaired during this review:
- **H-11-01**: PKA eligibility previously emphasized “actual executable dependency”, while DP semantic guidance is needed before final reachability. Added an explicit Rule-Declare-Pages PKA rule: discovered DP occurrence loads the adapter unless an already-grounded scenario-independent terminal pre-access proof excludes it.

Fresh-agent questions all have one current answer: authority, load trigger, algorithm, state owner, completeness, failure owner. No `existing semantics`, historical fallback, or old prompt knowledge is required.

Critical=0 High=0 Medium=0.
