# Stage 12 — Dynamic loading adversarial validation
Status: **READY + VALIDATED**

The executable contract harness `validate_r41_adapters.py` exercises the adapter header/marker/Area rules. Final result: **14/14 PASS**.

Cases:
- A01 Standard/no-DP: no migrated adapter required.
- A02 Standard+DP: exact DataPage adapter required and accepted.
- A03 When/no-DP: exact When adapter required and accepted.
- A04 When+DP: both adapters required and accepted.
- A05 missing When KA: fail closed.
- A06 missing DP KA: fail closed.
- A07 incomplete When marker set: fail closed.
- A08 incomplete DP marker set: fail closed.
- A09 stale When adapter version/header: fail closed.
- A10 wrong Description under When Area: fail closed.
- A11 duplicate requested Area result: malformed GAP; fail closed.
- A12 KA architecture-authority attempt: Core prohibition remains authoritative; actual migrated markers contain no lifecycle/tool/persistence instructions.
- A13 already-proven scenario-independent terminal DP exclusion: runtime DP adapter path may be skipped.
- A14 duplicate required marker definition: fail closed.

No generic semantic fallback is legal for a missing/partial/wrong adapter.

Critical=0 High=0 Medium=0.
