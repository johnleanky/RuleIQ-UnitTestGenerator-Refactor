# R39D D1 quarantine

R39D D1 is not semantic authority. R40 starts from R39C, so no D1-created normative text is active by inheritance. The following D1 categories are explicitly quarantined and may appear in R40 only if independently re-derived from OLD_MAIN W obligations and current contracts:

- closed Rule-Obj-When phase-row claims not proven from old semantics;
- any D1 definition of `PRODUCER`;
- D1-specific prohibitions on `COV/RESOLVE/PATH/EFFECT`;
- D1 wording that assigns MAP/WITNESS/FREEZE ownership by reconstruction rather than source mapping;
- D1 claims that owner/covers or audit semantics were already self-contained;
- any validation assertion whose only provenance is D1 itself.

R40 decision: old `PRODUCER` has no old-Main provenance and no current consumer outside historical prompt residue; it is therefore not carried into the restored When flow unless an independent current consumer is found during Stage 2/3.
