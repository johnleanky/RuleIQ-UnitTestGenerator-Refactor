# R40 Findings Ledger

All findings below are closed after repair and complete affected-stage revalidation.

| ID | Severity | Finding | Final disposition |
|---|---|---|---|
| M-5B-01 | Medium | Per-iteration witness coalescing omitted | FIXED + REVALIDATED |
| M-5B-02 | Medium | FREEZE irredundancy/fail-none wording incomplete | FIXED + REVALIDATED |
| H-5C-01 | High | Empty input encoded as empty source value instead of absent value | FIXED + REVALIDATED |
| M-5D-01 | Medium | Nested Decision Table guard ambiguous | FIXED + REVALIDATED |
| M-6-01 | Medium | Original-RUT applicability firewall needed explicit restatement | FIXED + REVALIDATED |
| M-6-02 | Medium | Historical/vague wording remained | FIXED + REVALIDATED |
| H-7-01 | High | Generic TEST_ORACLE rule used Standard OUTPUT semantics for When | FIXED + REVALIDATED |
| H-8-01 | High | First H-7-01 repair tightened Standard NotTestable semantics | FIXED + REVALIDATED |
| H-9-01 | High | R-covering frozen Scenario could become zero-row informational | FIXED + REVALIDATED |
| H-9-02 | High | Informational carrier could coexist with executable groups | FIXED + REVALIDATED |
| H-9-03 | High | Shared Standard §5.3 wording drift | FIXED + REVALIDATED |
| H-9-04 | High | Old canonical post-reduction `given+simulation` sort/final-id rule omitted | FIXED + REVALIDATED |

Open Critical: 0  
Open High: 0  
Open Medium: 0
