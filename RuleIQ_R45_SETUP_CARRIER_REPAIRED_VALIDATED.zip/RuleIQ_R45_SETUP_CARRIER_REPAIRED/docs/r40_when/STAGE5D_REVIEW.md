# Stage 5D Review — BUILD + Independent Rule-Obj-When AUDIT

## Scope
Changed §4.6 BUILD and §4.7 AUDIT. Implements old obligations W11, W12, W16 and W24 in current GROUP/LOCATION/AUDIT representation. No new ScenarioTrace row or arity was added.

## Source / structural checks
- PASS: W11 build packaging only
- PASS: W11 semantic mutation upstream
- PASS: W24 build does not carry owner/covers
- PASS: W24 audit ignores frozen proof
- PASS: W12 forward reverse census
- PASS: W12 original sources only
- PASS: W12 RBU E
- PASS: W12 E proof covered R
- PASS: W12 reexecute physical scenarios
- PASS: W12 rebuild owner covers
- PASS: W12 union covers R
- PASS: W12 mcdc constraints
- PASS: W16 bijection
- PASS: W12 irredundancy
- PASS: W12 no removable
- PASS: When audit BASE
- PASS: When repair MAP
- PASS: When new dep crawl
- PASS: No stale PRODUCER
- PASS: Nested DT scope

## Findings / repair loop
1. **M-5D-01** — inherited nested Decision Table guard said `before DECIDE/grouping`, ambiguous because original Rule-Obj-When has no DECIDE phase. **FIXED** to `before DECIDE (Standard) or grouping (Rule-Obj-When)`; setup ownership/failure route remains WITNESS.

Full Stage 5D structural/independence/restart/loss review repeated after repair.

## Independence review
- BUILD stores only GROUP/LOCATION and therefore cannot carry owner/covers as audit proof.
- When AUDIT independently reconstructs original-RUT census/classification and re-executes final physical Scenarios.
- Frozen owner/covers and prior Result are comparison data only, never proof.
- AUDIT validates coverage union, E proofs, MC/DC constraints, Scenario↔row bijection, row shape, simulation grouping and FREEZE irredundancy.
- New dependency returns CRAWL; any other When audit mismatch restarts MAP, matching old A restart semantics.

## Standard non-regression
Standard A–G gates, BASE=`MAP,WITNESS,FREEZE,DECIDE,BUILD`, repair owner priority and codes remain present.

## Result
- Implementation: **READY**
- Validation: **VALIDATED**
- Critical: 0
- High: 0
- Medium: 0

## Revalidation after independent Stage 9 finding H-9-01
When AUDIT now additionally requires every FREEZE Scenario with nonempty R coverage to materialize as an executable row; informational mode is legal only for a separate empty-cover carrier and cannot satisfy coverage. Independent coverage reconstruction, union(covers)=R, row bijection and irredundancy were rerun: **PASS**. Critical=0, High=0, Medium=0.

## Revalidation after independent Stage 9 finding H-9-02
BUILD/AUDIT now reject coexistence of informational and executable When groups. BUILD packages every R-covering frozen Scenario exactly once as an executable row; AUDIT accepts informational mode only for zero-R MAP with no executable coverage group. **VALIDATED: Critical=0, High=0, Medium=0.**

## Revalidation after independent Stage 9 finding H-9-04
AUDIT independently verifies that final executable FREEZE Scenario order/ids follow the canonical `given+simulation` sort after reduction/merge and that stable grouping preserves that order. BUILD still assigns only physical group/local location. **VALIDATED: Critical=0, High=0, Medium=0.**
