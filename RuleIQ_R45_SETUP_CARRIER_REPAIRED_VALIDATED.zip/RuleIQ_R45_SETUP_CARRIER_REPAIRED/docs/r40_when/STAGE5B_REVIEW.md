# Stage 5B Review — Rule-Obj-When WITNESS + FREEZE

## Scope
Only §4.3 WITNESS and §4.4 FREEZE were changed. Standard semantics remain mode-scoped; Rule-Obj-When receives old-Main obligations W07–W10, W22 and W25 mapped to current SCENARIO/FREEZE ownership.

## Structural review
- Rule-Obj-When WITNESS owns `SCENARIO` only with `BASE|MAP`.
- Rule-Obj-When FREEZE owns final `SCENARIO` only with `BASE|MAP,WITNESS`.
- No Standard `RESOLVE/PATH/WHY/EFFECT` is created for original Rule-Obj-When.
- Standard WITNESS/FREEZE retains `RESOLVE+SCENARIO+PATH(+WHY)` and `SCENARIO+PATH+EFFECT`.

## Source-fidelity review
- PASS: W07 deterministic base
- PASS: W07 actual execution owner/covers
- PASS: W07 invalid witness keeps outcome
- PASS: W07 per-iteration coalesce
- PASS: W08 dependency variants no coverage
- PASS: W09 exact removal cost
- PASS: W09 rebuild grouping/signature/result
- PASS: W09 reexecute
- PASS: W09 preserve all R
- PASS: W09 fixed point
- PASS: W09 not global min
- PASS: W09 fail no serializable
- PASS: W10 exact duplicate merge
- PASS: W10 ids after reduction
- PASS: W22 membership immutable
- PASS: W25 rebuild row authority
- PASS: When WITNESS rows only
- PASS: When FREEZE rows only
- PASS: Standard freeze id equality
- PASS: Standard path effect preserved

## Findings / repair loop
1. **M-5B-01** — initial draft omitted old generic WITNESS requirement to coalesce compatible per-iteration witness data into the smallest typed list. **FIXED** by adding it under When WITNESS without changing coverage ownership.
2. **M-5B-02** — initial draft did not explicitly preserve old FREEZE statement that the fixed point is irredundant, not a claimed global minimum, and must fail rather than invent a Scenario when none is serializable. **FIXED**.

Full structural/source-fidelity/contradiction/loss review repeated after both repairs.

## Contradiction / loss review
- MAP remains sole owner of OUTCOME classification; WITNESS cannot delete/reclassify an invalid candidate without returning to MAP.
- Dependency variants remain witness selectors, never coverage owners.
- FREEZE reduction is coverage-preserving by complete re-execution and cannot be changed by confidence/testability/assertion/grouping.
- Exact duplicate merge is gated after accepted reduction and requires equal final execution representation.
- Standard source/target/index and PATH/EFFECT semantics remain present and scoped Standard.

## Result
- Implementation: **READY**
- Validation: **VALIDATED**
- Critical: 0
- High: 0
- Medium: 0

## Revalidation after independent Stage 9 finding H-9-01
Old Main lines 1581-1597 make every FROZEN Rule-Obj-When coverage Scenario a mandatory final combination row and explicitly forbid confidence/testability from suppressing it. The restored flow was repaired so FREEZE reduction operates only on executable R-covering Scenarios; any current informational carrier is a separate empty-cover current-architecture extension with `owner=covers=-` and cannot participate in or replace the coverage set. W07/W09/W10/W22 were rerun: **PASS**. Critical=0, High=0, Medium=0.

## Revalidation after independent Stage 9 finding H-9-02
OLD_MAIN physical cardinality permits only final coverage rows grouped by distinct simulation keys. The current-only informational carrier is therefore legal only when active MAP has zero R OUTCOME and no executable coverage Scenario exists. WITNESS/FREEZE now keep that carrier outside coverage construction/reduction with `owner=covers=-`; it can never coexist with an executable coverage set. **VALIDATED: Critical=0, High=0, Medium=0.**

## Revalidation after independent Stage 9 finding H-9-04
OLD_MAIN line 1528 adds a deterministic ordering obligation that the initial W10 summary omitted: after final reduction/duplicate merge, retained executable Scenarios are sorted by canonical `given+simulation`, then final Scenario ids are assigned and preserved. FREEZE now states this explicitly and rejects preservation of WITNESS ids/order by convenience. W09/W10/W16/W25 rerun: **PASS. Critical=0, High=0, Medium=0.**
