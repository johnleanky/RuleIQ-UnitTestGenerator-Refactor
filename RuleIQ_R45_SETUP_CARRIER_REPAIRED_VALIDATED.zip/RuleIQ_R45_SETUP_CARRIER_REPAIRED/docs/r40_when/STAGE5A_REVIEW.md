# Stage 5A — acquisition / pyLogic / MAP coverage inventory review

Implementation status: READY  
Validation status: VALIDATED

## Source fidelity
- W01 applicability remains keyed only by immutable original RUT_TYPE.
- W03 pyLogic lock and W04 DWL dependency scan were not rewritten; existing current rules already satisfy old source.
- W05/W06 are now explicit in MAP OUTCOME: TRUE/FALSE + MC/DC sides, pair id/side/atom/fixed truth vector, masked E proof, universal pair exclusion, no Cartesian/dependency-owned coverage.

## Structural review
- Standard MAP still creates OUTCOME/COV/PDEF and keeps its exact COV/PDEF gates.
- Rule-Obj-When MAP creates OUTCOME only.
- ScenarioTrace `PRODUCER` grammar/arity was removed because old Main has no such row and current Projection/Generator has no consumer. Remaining historical mention is in §4.7 and is scheduled for Stage 5D removal; it is not a legal row under the new closed phase table/MemoryTemp gate.
- When BASE chain remains MAP=-, WITNESS=MAP, FREEZE=MAP,WITNESS, BUILD=FREEZE, AUDIT=MAP,FREEZE,BUILD.

## Contradiction/loss review
- No Standard row/arity/BASE changed except removal of the unused When-only PRODUCER row from global grammar.
- No old coverage obligation was moved into dependency-owned state.
- No target/RuleCode mechanics were introduced.

## Negative-space checks
Rejected behaviors remain rejected:
- nested When cannot switch original-RUT workflow;
- dependency result cannot create OUTCOME;
- one MC/DC pair side cannot be dropped alone;
- low confidence/one bad witness cannot reclassify OUTCOME;
- COV/PDEF cannot appear in a When MAP commit.

Findings after repair loop: Critical=0, High=0, Medium=0.
