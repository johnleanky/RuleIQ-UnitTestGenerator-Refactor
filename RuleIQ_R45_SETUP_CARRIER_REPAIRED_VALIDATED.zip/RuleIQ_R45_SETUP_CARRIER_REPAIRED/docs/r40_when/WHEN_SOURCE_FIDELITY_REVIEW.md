# Stage 9 — Independent Rule-Obj-When source-fidelity review

## Review basis

This review was performed independently from the implementation notes. Semantic authority is the old `RuleIQ/Main_Agent_Prompt.txt`; current architecture/Projection/Generator contracts are used only to locate each old obligation in the new pipeline. R39D D1 is explicitly non-authoritative.

The old source was re-scanned across all material Rule-Obj-When/MultInpComb regions: applicability/reserved roots, pyLogic/DWL, Scenario Compiler I/W/F/B/A, MultInpComb cardinality and simulation grouping, DecisionResult dependency lock, coverage/row-shape, empty/path semantics, cell-trace/final gates. Repeated target/trace instructions after line 1817 were classified as either (a) repetitions of W13–W25 or (b) old target/trace representation now owned by current Generator/schema; no additional semantic family outside W01–W25 was required.

## W01–W25 census

All 25 obligations have a final current owner in `WHEN_OLD_TO_CURRENT_MAPPING.csv`. `UNMAPPED=0`, `GAP=0`.

- **W01–W04:** PASS — applicability firewall, reserved-root carrier proof, verbatim/all-clause pyLogic and operand DWL closure remain explicit.
- **W05–W06:** PASS — MAP owns final TRUE/FALSE plus both MC/DC sides, pair id/side/atom/fixed vector, E proof and paired exclusion; no Cartesian coverage.
- **W07–W08:** PASS — WITNESS is deterministic/coverage-complete; only complete original-When execution creates owner/covers; dependency variants select witnesses only.
- **W09–W10:** PASS — FREEZE uses the old cost tuple, rebuilds grouping/signature/cells/Result, re-executes affected retained rows, accepts only coverage/constraint-preserving removals, iterates to fixed point, merges exact duplicates only after proof, then sorts retained executable Scenarios by canonical `given+simulation` before assigning final ids.
- **W11:** PASS — BUILD/grouping are packaging-only and cannot change semantic facts.
- **W12/W24:** PASS — AUDIT re-scans original source, re-executes materialized rows and rebuilds owner/covers/Result without trusting FREEZE proof.
- **W13–W16:** PASS — complete current SIM requirement determines executable groups; `NO_SIMULATION`, distinct-key cardinality, stable order and Scenario↔row bijection are explicit.
- **W17–W20:** PASS — common ordered row signature, empty-cell retention/value absence, exact path namespace and simulated-DP exclusion are explicit.
- **W21:** PASS — Result exists only from complete original-When execution after controlling dependency resolution; missing/unknown dependency never guesses truth.
- **W22:** PASS after repair loop — old lines 1581–1597 are treated as a hard override: every R-covering frozen Scenario is a mandatory executable row and confidence/testability cannot suppress it.
- **W23:** PASS — old target wrappers/constants/labels/Result representation map to current `CM-WHEN-001`, `CF-WHEN-ORDER-001`, `CM-EXEC-001` and MultInpComb schema, not ScenarioAuthor prose.
- **W25:** PASS — final retained row authority is rebuilt from final execution after reduction; witness values are never merely rekeyed.

## Findings discovered by this independent review

### H-9-01 — executable coverage could become informational — FIXED
Old lines 1581–1597 require every FROZEN R-covering Scenario to remain a mandatory combination row. An earlier current-extension formulation allowed executable→informational conversion. R40 now makes every nonempty-R Scenario permanently executable-row mode; testability cannot suppress the row.

### H-9-02 — informational carrier could coexist with executable groups — FIXED
Old physical cardinality is determined by final coverage Scenarios and their distinct simulation keys. A separate informational group beside executable coverage would add an extra physical group outside that rule. R40 now permits one current-only informational carrier **only** for terminal zero-R MAP and no executable coverage Scenario/group/row.

### H-9-03 — shared Standard §5.3 wording drift — FIXED
Mode-specific When oracle work had altered shared Standard wording in path feasibility/oracle/observation steps. R40 now restores the R39C Standard formulas explicitly and places When semantics in separate clauses. Full Standard regression review was rerun.


### H-9-04 — final FROZEN order/id rule omitted from W10 summary — FIXED
Old line 1528 requires final retained S rows to be sorted by canonical `given+simulation` after reduction/duplicate merge and before final ids, with that order preserved through packaging/audit. The initial restoration assigned final ids after reduction but did not state the canonical sort. §4.4 and §4.7 now restore and independently verify it; grouping stable-partitions the frozen order.

## Negative-space source checks

The final prompt does **not** permit any of the following:
- nested/fetched When changing original RUT workflow;
- dependency-only original-RUT coverage;
- single bad witness reclassifying an R obligation;
- independent exclusion of one MC/DC pair side;
- Cartesian coverage generation;
- heuristic/confidence/testability FREEZE deletion;
- informational substitution for, or coexistence with, executable R coverage;
- simulated Data Page roots becoming DecisionInput columns;
- guessed DecisionResult under missing controlling dependency;
- BUILD/Projection changing frozen row semantics;
- AUDIT reusing frozen owner/covers as proof;
- ScenarioAuthor recreating target MultInpComb wrappers/constants.

## Source-fidelity result

`W01–W25=PASS`, `UNMAPPED=0`, `GAP=0`, active D1-only authority=0. After H-9-01/H-9-02/H-9-03/H-9-04 repairs and complete affected-stage revalidation, no Critical/High/Medium source-fidelity finding remains open.
