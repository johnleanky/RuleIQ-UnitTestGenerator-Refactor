# Rule-Obj-When old semantic inventory

Primary source: old `RuleIQ/Main_Agent_Prompt.txt`. Storage names are excluded from the obligation unless intrinsically semantic.

| ID | Lines | Minimal obligation |
|---|---|---|
| W01 | 29-30 | MultInpComb applies iff original RUT is Rule-Obj-When; nested When/DT never switches workflow. |
| W02 | 20-24 | Reserved top-level system-page roots cannot be When input/seed carriers; block coverage only after universal carrier proof. |
| W03 | 581-598 | Copy pyLogic verbatim, tokenize every top-level OR clause, evaluate all clauses, no short-circuit omission. |
| W04 | 598-606 | Every executable operand discovered in a When scan enters DWL; When closes only after each has D row or exact closed link. |
| W05 | 1532-1537 | Original-RUT coverage inventory includes final TRUE/FALSE and both MC/DC sides per atom; masked atom needs E proof; no Cartesian expansion. |
| W06 | 1536 | MC/DC pair carries pair id, side, atom, fixed truth vector; one side cannot be excluded alone. |
| W07 | 1539 | Witness base is deterministic and coverage-complete; owner/covers derive only from complete actual original-When execution; invalid witness does not erase requirement. |
| W08 | 1539 | Dependency variants select witnesses; they never create new original-RUT coverage after requirement is covered. |
| W09 | 1541 | FREEZE performs deterministic fixed-point irredundant reduction by re-execution while preserving all R and MC/DC/joint/shape constraints. |
| W10 | 1528;1541 | Exact duplicate executions merge only after coverage proof; after final reduction/merge sort retained executable Scenarios by canonical `given+simulation`, then assign final ids and preserve that order through packaging/audit. |
| W11 | 1543 | Packaging may assign physical location/grouping but cannot alter inputs/setup/cells/simulation/execution/coverage. |
| W12 | 1545 | AUDIT independently repeats source census/classification and re-executes materialized Scenarios; rebuilds owner/covers and checks irredundancy/bijection. |
| W13 | 32-91;1617-1693 | Group final Scenarios by complete runtime-relevant simulation requirement. |
| W14 | 59;1635-1637 | No required simulation uses NO_SIMULATION. |
| W15 | 78-80;92-96;1679-1691 | Group count equals distinct simulation keys; ordinary inputs/results alone do not split groups. |
| W16 | 92-96;1693-1708;1786-1817 | Scenario↔row bijection, stable order/local numbering and synchronization after grouping. |
| W17 | 1732-1736;1786-1817 | Within a group every row has identical ordered input-column signature; inputs precede exactly one Result. |
| W18 | 1738-1751 | Empty input retains initialized carrier/cell; omit only expected value; never infer absent parent. |
| W19 | 1753-1784 | Preserve input namespace, leading dot, indices, keys, spelling and case; class resolution never rewrites seed root/path. |
| W20 | 1626-1633 | Simulated Data Page roots are not writable MultInpComb input columns; runtime value stays in simulation. |
| W21 | 1710-1730 | DecisionResult Boolean is exact only after controlling dependencies are terminal and complete When execution yields known result; missing dependency never guesses truth. |
| W22 | 24;1541;1581-1597 | Confidence/testability never remove/merge/suppress required coverage Scenarios. |
| W23 | 1579-1615;1786-1817 | RuleCode MultInpComb wrappers/cell constants/display fields/result target representation are target mechanics. |
| W24 | 1543-1545 | Audit must not reuse frozen owner/covers as proof; it reconstructs them independently. |
| W25 | 1541;1732-1735 | After accepted reduction rebuild each retained Scenario row/cell/Result authority from final execution; rekeying witness values is forbidden. |
