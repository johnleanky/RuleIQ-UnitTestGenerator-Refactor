# Stage 4 — Rule-Obj-When prompt integration design

Status: READY + VALIDATED FOR IMPLEMENTATION. This document is design authority for Stage 5 edits; old Main W obligations remain semantic provenance.

## A. ScenarioTrace row/BASE contract

**When row ownership**
- MAP: OUTCOME only.
- WITNESS: SCENARIO only.
- FREEZE: SCENARIO only.
- DECIDE: absent.
- BUILD: GROUP + LOCATION, BASE=FREEZE.
- AUDIT: AUDIT (+ one REPAIR on FAIL), BASE=MAP,FREEZE,BUILD.

Standard row ownership is unchanged. COV/PDEF/RESOLVE/PATH/WHY/EFFECT remain Standard-only. Historical When `PRODUCER` is removed: OLD_MAIN has no such row and current Generator/Projection/AUDIT has no consumer.

Coverage source: W05–W12/W24. Failure route: new dependency -> CRAWL; invalid inventory -> MAP; invalid witness -> WITNESS; reduction/final row defect -> FREEZE; packaging mismatch -> BUILD; When AUDIT semantic failure -> MAP per old independent-A semantics.

## B. MAP coverage adapter

SCOPE: original `RUT_TYPE=Rule-Obj-When`.

MUST:
- scan original RUT forward/reverse and classify final TRUE/FALSE plus both MC/DC sides for every atom;
- encode effective pair obligation in OUTCOME.constraint with pair id, side, atom and fixed truth vector; masked atom requires E proof;
- never exclude one pair side alone: the same universal pair proof must justify both sides;
- typed boundary/empty becomes R only when truth changes; no Cartesian expansion;
- dependency variants choose witnesses and never create OUTCOME;
- commit OUTCOME only for When (no Standard COV/PDEF).

GATE: raw source census equal; every source mapped; R/B/U/E proof rules satisfied; no dependency-owned OUTCOME.

## C. WITNESS

SCOPE: Rule-Obj-When.

MUST:
- consume immutable MAP OUTCOME in source order;
- construct deterministic coverage-complete base: one canonical witness per uncovered R plus required MC/DC pair witnesses, coalescing only when one actual complete execution covers all referenced obligations;
- resolve setup/carriers/DP_SIG/REQSIM and execute complete original When;
- derive SCENARIO.owner/covers only from that execution; `covers` contains only actually executed R OUTCOME ids;
- dependency variants may select witness values but never create/split coverage;
- invalid/unknown/unsafe/unresolved witness invalidates the witness, not OUTCOME; find another or return to MAP only with proof-backed B/U/E classification.

CREATE: SCENARIO only; no RESOLVE/PATH/WHY.

## D. FREEZE reduction

SCOPE: Rule-Obj-When.

MUST:
1. Start from complete WITNESS SCENARIO set.
2. Rank removable candidates by `(simulation-entry count, seeded-leaf count, non-default-parameter count, canonical given+simulation)`, highest cost first.
3. For each proposed removal rebuild affected REQSIM/SIMULATION_GROUP_KEY, union WHEN_COLUMN_SIGNATURE/cells and Result; re-execute every affected complete When row.
4. Accept removal only when actual union covers still equals all MAP R OUTCOME ids and every MC/DC/pair/shape constraint remains true.
5. Repeat to fixed point.
6. Merge exact duplicate executions only after the same proof; exact duplicate means identical final given, simulation, source row signature/cells, Result and execution-derived owner/covers.
7. After final reduction/duplicate merge, sort retained executable Scenarios by canonical `given+simulation`; only then assign final SCENARIO ids, and preserve that order through grouping/BUILD/AUDIT.
8. Rebuild each final Scenario's given/simulation/owner/covers and frozen row authority from final execution.
9. Confidence/testability/assertion availability/packaging never changes membership.

Result: deterministic coverage-complete irredundancy, not a global-minimum claim.

## E. Grouping

For executable When:
`SIMULATION_GROUP_KEY = NO_SIMULATION` iff REQSIM empty, otherwise canonicalJSON(ordered SIM_WIRE list).

Stable-partition executable final Scenarios by exact SIMULATION_GROUP_KEY only. Ordinary input values and Result never split a group. Different key never shares a group. Current `EXECUTION_CLASS` remains a separate current-architecture partition only to isolate INFORMATIONAL_NOT_TESTABLE from executable groups; it must not alter executable coverage membership.

Within each executable group:
`WHEN_COLUMN_SIGNATURE = stable ordered union of eligible non-simulated (path,valueType) inputs from final retained executions, preserving frozen first-occurrence order.`
Every row materializes every signature cell in that order; a non-evaluated/irrelevant/empty cell remains present with absent source `value`. Simulated Data Page roots are excluded from the signature and remain in simulation.

## F. §5.2 source row authority

For each executable retained Scenario after final grouping:
- exactly one source row; scenarios[n] == rows[n];
- inputs exactly match WHEN_COLUMN_SIGNATURE in order;
- path preserves namespace/leading dot/index/key/spelling/case;
- present value is exact frozen lexical; absent value retains the cell; actual initialized empty may be diagnosed as `<EMPTY>` but Projection absence is authoritative for target omission;
- Result is exact boolean from complete actual original-When execution;
- Result is legal only after every controlling executable dependency is CLOSED or terminal; a terminal missing dependency never authorizes guessed boolean and returns to WITNESS/MAP/testability handling;
- freeze DecisionInput/DecisionResult authority from final execution; packaging never re-evaluates it.

## G. AUDIT

SCOPE: original Rule-Obj-When.

AUDIT independently, from original RUT + materialized final rows:
- redo forward/reverse raw census and R/B/U/E classification;
- re-execute every materialized Scenario/row;
- rebuild owner/covers without trusting frozen owner/covers as proof;
- require forward census == reverse census == union OUTCOME.source;
- require R/B/U/E partition, every E points to covered canonical R, union actual covers == all R;
- validate MC/DC pair/fixed-vector constraints;
- validate final Scenario ↔ materialized row bijection, row signature/order/Result/absent values and SIMULATION_GROUP_KEY grouping;
- prove no final Scenario is removable under the FREEZE algorithm.

PASS commits AUDIT only. Any semantic FAIL returns to MAP and rebuilds the When chain; new executable dependency returns to CRAWL. AUDIT never patches.

## H. Projection boundary

Projection mechanically copies §5.2 final rows and frozen simulations. `CM-WHEN-001`/schema own target Decision/row/cell wrappers, input labels/mode/type, Result-last constants and boolean stringification. ScenarioAuthor never authors those target mechanics.

## Design review

- W01–W25 coverage: complete.
- New ScenarioTrace row/schema: none.
- Removed unsupported row: historical When PRODUCER only; no current consumer.
- Standard architecture touched: none by design.
- Target-contract change: none.
- GAP: 0.
- Critical/High/Medium findings after source/architecture/token review: 0/0/0.
