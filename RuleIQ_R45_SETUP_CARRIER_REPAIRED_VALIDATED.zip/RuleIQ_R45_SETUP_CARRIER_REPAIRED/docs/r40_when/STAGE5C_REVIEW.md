# Stage 5C Review — Grouping + DecisionInput/DecisionResult + Testability Boundary

## Scope
Changed §4.5, §5.2 and the Rule-Obj-When membership boundary in §5.3. No Generator/schema or ScenarioTrace grammar change. Implements W13–W22 and W25 source-side obligations; W11 packaging is completed in Stage 5D.

## Source / structural checks
- PASS: W13 sim key exact no-sim
- PASS: W13 sim key complete wire
- PASS: W15 executable groups only sim key
- PASS: W15 ordinary input/result no split
- PASS: W16 row-scenario 1to1
- PASS: W17 stable signature
- PASS: W17 all rows same signature
- PASS: W18 empty cell source value absent
- PASS: W18 no parent absence
- PASS: W19 path lock
- PASS: W20 simulated DP excluded
- PASS: W21 result known actual execution
- PASS: W21 no guessed truth
- PASS: W22 testability no membership change
- PASS: W25 final row authority
- PASS: W25 no rekey
- PASS: Target wrappers Generator-owned
- PASS: Current extension isolated

## Findings / repair loop
1. **H-5C-01 — old empty-cell vs current target mapping conflict.** Old Main requires empty input cell to remain while target `pyExpectedValue` is omitted. `CM-WHEN-001` copies a present empty source string as present `pyExpectedValue=""`. **FIX:** restored When semantics encode empty/irrelevant/not-evaluated cell as a present input object with **absent source `value`**. Current source grammar permits this and CM-WHEN-001 then omits target pyExpectedValue. `<EMPTY>` is diagnostic only. Compatibility proof updated. No Generator/schema change.

Full Stage 5C review repeated after repair.

## Contradiction / loss review
- Executable coverage membership is frozen before grouping; current EXECUTION_CLASS only isolates informational NotTestable and cannot alter executable membership.
- Executable group identity is complete ordered simulation requirement only; input/Result differences do not split groups.
- Source signature is `(path,valueType)`; old target wrappers/constants remain CM-WHEN-001/CF-WHEN-ORDER-001 owned.
- Simulated Data Page roots remain in simulation and never become writable When input columns.
- Result is emitted only from known complete actual execution; missing dependency never guesses truth.
- Testability may switch physical executable/informational mode but cannot modify frozen coverage Scenario membership.

## Result
- Implementation: **READY**
- Validation: **VALIDATED**
- Critical: 0
- High: 0
- Medium: 0

## Revalidation after Stage 7 finding H-7-01
**H-7-01** — generic §5.3 defined TEST_ORACLE absence through Standard OUTPUT/candidate census, which is illegal for original Rule-Obj-When. **FIXED** with mode-specific oracle semantics: Standard uses DECIDE/OUTPUT; When uses final §5.2 DecisionResult and terminal enablement evidence. A final blocked When Scenario requires `TEST_ORACLE=ABSENT`; unknown Result remains UNRESOLVED.

Affected Stage 5C/5E checks rerun: **PASS**. Critical=0, High=0, Medium=0.

## Revalidation after Stage 8 collateral finding H-8-01
**H-8-01** — the first H-7-01 repair unintentionally tightened the generic Standard `NotTestable` formula from `BLOCKED OR (ENABLED+ABSENT)` to require `BLOCKED+ABSENT`. **FIXED**: original Standard formula restored exactly; only original Rule-Obj-When adds the terminal `BLOCKED ⇒ TEST_ORACLE=ABSENT` finalization condition. Affected Stage 5C, Stage 6 and all Stage 7 adversarial cases were rerun and remain PASS.

## Revalidation after independent Stage 9 finding H-9-01
**H-9-01** — old Main lines 1581-1597 require every frozen Rule-Obj-When coverage Scenario to remain a mandatory Decision row; the prior current-extension wording allowed an R-covering frozen Scenario to be converted to `INFORMATIONAL_NOT_TESTABLE` with zero rows. **FIXED**. Every Scenario with nonempty R coverage is permanently `EXECUTION_CLASS=EXECUTABLE`, must retain exactly one row, and may only be Fully/PartiallyTestable. `INFORMATIONAL_NOT_TESTABLE` is now restricted to a separate current-architecture carrier with `owner=covers=-` that substitutes for no R OUTCOME. If an R obligation lacks an executable Result-bearing witness, finalization stays open or MAP must prove B/U/E. Grouping/testability/W17/W21/W22 were fully rerun: **PASS**. Critical=0, High=0, Medium=0.

## Revalidation after independent Stage 9 finding H-9-02
Grouping/testability were tightened to preserve OLD_MAIN row/group cardinality: if any R OUTCOME exists, every final When Scenario is executable and no informational group is legal. Exactly one informational current-only group may exist only when MAP has zero R OUTCOME and no executable group; it has zero rows/SIM/ASSERT and `owner=covers=-`. **VALIDATED: Critical=0, High=0, Medium=0.**

## Revalidation after independent Stage 9 finding H-9-03
The independent non-When review found that the shared §5.3 rewrite had changed Standard wording in steps 1/3/4 while introducing When-specific oracle semantics. Even where apparently equivalent, this was unnecessary shared-surface risk. **FIXED**: Standard infeasibility/oracle/observation formulas were restored to the R39C semantics explicitly; Rule-Obj-When now has separate clauses in the same numbered steps. Standard `NotTestable` formula remains exact. **VALIDATED: Critical=0, High=0, Medium=0.**

## Revalidation after independent Stage 9 finding H-9-04
Grouping now consumes the canonical final FREEZE Scenario order produced after the old-Main `given+simulation` sort and stable-partitions it by exact simulation key. Local row order therefore preserves the required final order within each group. **VALIDATED: Critical=0, High=0, Medium=0.**
