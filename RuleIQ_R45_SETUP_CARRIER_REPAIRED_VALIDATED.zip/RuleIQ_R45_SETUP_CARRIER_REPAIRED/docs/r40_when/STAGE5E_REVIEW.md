# Stage 5E Review — Projection / Generator Boundary

## Scope
Hardened §6.1, executable When source row grammar, producer-side reconciliation and §5.5 When/audit gates. Generator and MultInpComb schema were not changed.

## Boundary checks
- PASS: Projection mechanical §5.2
- PASS: No Standard DECIDE for When
- PASS: Target ownership
- PASS: No target recreate
- PASS: Row present values nonempty
- PASS: Empty source absent
- PASS: No EMPTY projected
- PASS: Reconcile scenario row count
- PASS: Reconcile signature
- PASS: Reconcile value presence
- PASS: Reconcile DP exclusion
- PASS: Reconcile result
- PASS: Reconcile sim
- PASS: No reevaluation
- PASS: Gate10 exact
- PASS: Gate11 When audit
- PASS: no target-field leakage (`rowLevelPage`, pyProperty target fields, target mode/constants) into ScenarioAuthor.

## Source-fidelity / architecture review
- Frozen §5.2 is sole source authority for When rows.
- Old empty-cell semantics maps to absent source `value`, which CM-WHEN-001 deterministically maps to omitted target pyExpectedValue while retaining the cell.
- ScenarioAuthor owns only source path/valueType/value presence/result/order/simulations.
- Generator/schema remain sole owner of Decision/row wrappers, target labels/mode/type, Result-last constants and boolean stringification.
- Projection validation is compilation/reconciliation only; it cannot rerun When semantics.
- Pre-projection gate 11 now accepts the dedicated When active chain MAP/FREEZE/BUILD + independent AUDIT/PASS, without importing Standard DECIDE.

## Findings
No new Critical/High/Medium finding after Stage 5C empty-cell repair.

## Result
- Implementation: **READY**
- Validation: **VALIDATED**
- Critical: 0
- High: 0
- Medium: 0

## Revalidation after Stage 7 finding H-7-01
**H-7-01** — generic §5.3 defined TEST_ORACLE absence through Standard OUTPUT/candidate census, which is illegal for original Rule-Obj-When. **FIXED** with mode-specific oracle semantics: Standard uses DECIDE/OUTPUT; When uses final §5.2 DecisionResult and terminal enablement evidence. A final blocked When Scenario requires `TEST_ORACLE=ABSENT`; unknown Result remains UNRESOLVED.

Affected Stage 5C/5E checks rerun: **PASS**. Critical=0, High=0, Medium=0.

## Revalidation after independent Stage 9 finding H-9-01
Projection reconciliation now counts every R-covering FREEZE Scenario exactly once in the executable When Scenario↔row census. Informational carriers are excluded from that row census and are legal only when `owner=covers=-` and no R OUTCOME is substituted. The generic informational source mode remains unchanged for non-When use. Projection/Generator boundary checks rerun: **PASS**. Critical=0, High=0, Medium=0.

## Revalidation after independent Stage 9 finding H-9-02
Projection mode exclusivity was rechecked against OLD_MAIN cardinality. `EXECUTABLE_WHEN` is the only legal mode when any R OUTCOME exists. `INFORMATIONAL_NOT_TESTABLE` for When is legal only for a single zero-R, empty-cover carrier with no executable group/rows. Generator/schema ownership is unchanged. **VALIDATED: Critical=0, High=0, Medium=0.**

## Revalidation after independent Stage 9 finding H-9-04
Projection continues to copy frozen Scenario/row order mechanically; no new ordering rule is introduced downstream. The restored canonical final order is already frozen by §4.4 and checked by §4.7. **VALIDATED: Critical=0, High=0, Medium=0.**
