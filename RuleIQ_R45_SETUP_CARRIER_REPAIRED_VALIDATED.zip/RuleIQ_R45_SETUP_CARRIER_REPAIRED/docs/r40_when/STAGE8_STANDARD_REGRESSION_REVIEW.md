# Stage 8 — Full Non-When Regression / Integration Review

## Scope
Independent semantic review of all shared areas modified during Rule-Obj-When restoration. Validation is textual/semantic; no SHA or textual diff is used as correctness evidence.

## Regression checks
- **PASS** — DWL occurrence state
- **PASS** — Raw refs not semantic closure
- **PASS** — Property path closure
- **PASS** — pxRuleClassName prohibition
- **PASS** — Standard MAP rows
- **PASS** — Standard WITNESS rows
- **PASS** — Standard FREEZE rows
- **PASS** — Standard DECIDE rows
- **PASS** — Standard BUILD base
- **PASS** — Standard AUDIT base
- **PASS** — Standard WITNESS COV census
- **PASS** — Standard FREEZE exact Scenario ids
- **PASS** — Standard PDEF PATH partition
- **PASS** — Standard EFFECT identity
- **PASS** — Source index target separation
- **PASS** — OUTPUT11
- **PASS** — BasePage/BaseClass lineage
- **PASS** — Nonprimary Projection pages
- **PASS** — DECIDE sole authority
- **PASS** — Standard audit A-G
- **PASS** — Standard audit pass base
- **PASS** — KDT invocation bridge
- **PASS** — KDT no scenario ownership
- **PASS** — Data Page required sims
- **PASS** — DPA gate
- **PASS** — Standard Projection mode
- **PASS** — Standard projection consumes DECIDE
- **PASS** — Standard comparator exact
- **PASS** — PREPARE/PERSIST/GENERATE order
- **PASS** — No Generator before persist all
- **PASS** — Standard testability formula

## Finding / repair loop
- **H-8-01** — Stage 7 oracle repair initially tightened generic Standard testability. **FIXED** by restoring R39C Standard `BLOCKED OR (ENABLED+ABSENT)` and scoping the extra blocked-oracle condition to original Rule-Obj-When. Stages 5C/6/7 were rerun before this review.
- Initial Stage-8 checker expected older DWL wording/formulae and flagged four false positives. Current R39C semantic forms (`D|id|...`, preAuthor raw-ref prohibition, compact property closure) were verified directly; checker expectations were corrected, prompt unchanged.

## Integration conclusions
- Standard DWL/property-path closure and R38 basePage/baseClass hardening remain intact.
- Standard ScenarioTrace row sets, BASE chain, DECIDE ownership and A–G AUDIT remain intact.
- Decision Table and Data Page semantics remain owned by their current mechanisms.
- Standard Projection still consumes DECIDE mechanically; When row grammar is mode-exclusive.
- Handoff remains PREPARE_ALL→PERSIST_ALL→GENERATE_ALL with zero early Generator calls.

## Result
- Stage 8 implementation: **READY**
- Stage 8 validation: **VALIDATED**
- Critical: 0
- High: 0
- Medium: 0

## Revalidation after independent Stage 9 finding H-9-01
The repair is Rule-Obj-When-scoped except for rewriting §5.3 into explicit mode-specific clauses. Standard semantics were rechecked: `NotTestable = BLOCKED OR (ENABLED + ABSENT)` remains exact; Standard DECIDE/OUTPUT, MAP/WITNESS/FREEZE, AUDIT A-G, Projection and handoff are unchanged in meaning. **PASS. Critical=0, High=0, Medium=0.**

## Revalidation after independent Stage 9 finding H-9-02
The zero-R/no-coexistence repair is Rule-Obj-When-scoped. Standard `NotTestable = BLOCKED OR (ENABLED + ABSENT)`, Standard grouping, DECIDE/OUTPUT, AUDIT A-G, Projection and handoff remain unchanged in meaning. **PASS. Critical=0, High=0, Medium=0.**

## Revalidation after independent Stage 9 finding H-9-03
The independent review identified unnecessary shared §5.3 wording drift. **FIXED** by restoring the R39C Standard formulas explicitly: existing Standard infeasibility/disproof mechanism; `PRESENT` = at least one supported executable ASSERT; exact exhaustive ABSENT rule; COMPLETE/PARTIAL/NONE based on supported ASSERTs/terminal OMIT. When-specific semantics are separate clauses. The full Stage-8 checklist was rerun conceptually and remains PASS. **Critical=0, High=0, Medium=0.**

## Revalidation after independent Stage 9 finding H-9-04
The canonical final sort/id repair is confined to original Rule-Obj-When FREEZE/AUDIT. Standard FREEZE requires exact WITNESS/FREEZE Scenario-id equality and remains unchanged. Full Standard checklist remains PASS. **Critical=0, High=0, Medium=0.**
