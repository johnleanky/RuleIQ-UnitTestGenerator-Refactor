# Stages 0–3 review

## Stage 0 — baseline / D1 invalidation
Status: READY + VALIDATED. R39C is the production baseline. R39D D1 is quarantined and not imported.

## Stage 1 — old semantic extraction
Status: READY + VALIDATED. W01–W25 each cite old Main ranges; storage/RuleCode mechanics are separated from semantic obligations.

## Stage 2 — obligation→owner mapping
Status: READY + VALIDATED. W01–W25 mapped; UNMAPPED=0. Old target mechanics are TARGET_OWNED. Current `EXECUTION_CLASS` and source `valueType` are recorded separately as current extensions, not legacy semantics.

### Critical row-set decision
The old source requires coverage `T/OUTCOME` and witness/final `S/SCENARIO`; it does not require current Standard-only COV/RESOLVE/PATH/EFFECT/PDEF machinery for original Rule-Obj-When. The restored When flow therefore uses OUTCOME + SCENARIO as its semantic carrier and does not claim Standard producer/path rows. This conclusion is sourced from old T/S semantics and the current source-only row model, not from R39D D1.

### PRODUCER decision
No old-Main When `PRODUCER` row exists and no current downstream consumer requires the R39C legacy PRODUCER row. It is removed from the restored When row set/global grammar rather than redefined. Standard PDEF/PATH/EFFECT remains untouched.

## Stage 3 — cross-contract compatibility
Status: READY + VALIDATED. `CM-WHEN-001`, `CF-WHEN-ORDER-001`, current MultInpComb schema and `CM-EXEC-001` deterministically own target wrappers/constants and simulation serialization. Current source `rows[]` and `SIM_WIRE/REQSIM` can represent all W16–W23 source semantics. GAP=0; no Generator/schema change required.

## Review findings
Critical=0; High=0; Medium=0 after review.
