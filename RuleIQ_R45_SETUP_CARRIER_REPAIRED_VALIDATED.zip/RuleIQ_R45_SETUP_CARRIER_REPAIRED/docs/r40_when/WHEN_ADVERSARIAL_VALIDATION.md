# Stage 7 — End-to-End Rule-Obj-When Adversarial Validation

Lifecycle under test: `CRAWL → MAP → WITNESS → FREEZE → grouping → §5.2 → BUILD → AUDIT → Projection → Generator mapping`.

H-7-01 discovered during the first run: generic TEST_ORACLE absence was Standard-OUTPUT-specific. It was repaired with mode-specific Standard/When oracle semantics; Stages 5C, 5E and 6 were reopened and revalidated before this complete rerun.

| # | Case | Expected behavior | Evidence | Result |
|---:|---|---|---|---|
| 1 | single-atom TRUE/FALSE | MAP owns both truth sides; WITNESS executes; FREEZE/AUDIT cannot collapse a required side. | §4.2 TRUE/FALSE+both MC/DC; §4.3 union covers R; §4.7 independent audit | **PASS** |
| 2 | two-atom MC/DC fixed truth vector | Pair id/side/atom/fixed vector survives MAP→WITNESS→FREEZE→AUDIT. | §4.2 OUTCOME.constraint; §4.3/4.4 preservation; §4.7 audit | **PASS** |
| 3 | masked/non-effective atom | Masked atom cannot disappear; requires E proof to covered canonical R. | §4.2 + §4.7 | **PASS** |
| 4 | one infeasible pair side | One side cannot be excluded independently; same universal pair proof controls both. | §4.2 | **PASS** |
| 5 | dependency variant same original coverage | Dependency variants select witness values only and never create/own coverage. | §4.2/4.3 | **PASS** |
| 6 | invalid witness with alternative carrier | Invalid candidate does not erase/reclassify R; alternate witness first, MAP reclassification only with valid B/U/E proof. | §4.3 | **PASS** |
| 7 | removable redundant witness | FREEZE removes only after rebuild+re-execution and coverage/constraint proof. | §4.4 | **PASS** |
| 8 | removal breaks MC/DC | Removal is rejected unless every pair/fixed-vector obligation remains. | §4.4 | **PASS** |
| 9 | same REQSIM, different inputs/results | Executable rows share one group when simulation key is equal; input/Result differences do not split. | §4.5 | **PASS** |
| 10 | different REQSIM | Different complete simulation keys separate executable groups. | §4.5 | **PASS** |
| 11 | simulated Data Page root | DP root stays in simulation and is excluded from input signature/source row. | §4.5/§5.2/§6 reconciliation | **PASS** |
| 12 | empty scalar on initialized page/list element | Cell retained; source value absent; Generator omits target pyExpectedValue; never parent absence. | §5.2 + source grammar + CM-WHEN-001 | **PASS** |
| 13 | leading-dot nested list path | Namespace/root/path characters preserved through source and Generator mapping. | §5.2 + CM-WHEN-001 | **PASS** |
| 14 | missing critical nested When/RUF dependency | Never guess Result. If an R coverage obligation lacks a complete Result-bearing witness, finalization stays open or MAP must prove B/U/E. Informational mode is legal only for a separate empty-cover non-coverage carrier. | §4.3/§5.2/§5.3 | **PASS** |
| 15 | exact duplicate physical execution | Merge only after accepted reduction proof and exact final representation equality. | §4.4 | **PASS** |
| 16 | packaging mutation | BUILD cannot author semantic fields; any semantic mutation returns earliest owner. | §4.6 | **PASS** |
| 17 | AUDIT tries to reuse frozen coverage | Audit reexecutes and rebuilds owner/covers; frozen owner/covers are explicitly non-proof. | §4.7 | **PASS** |
| 18 | confidence/testability decrease | Every R-covering frozen Scenario remains a mandatory executable Decision row; confidence/testability may lower it only to PartiallyTestable and cannot convert it to informational mode. | OLD_MAIN 1581-1597; §4.4/§5.3 | **PASS** |
| 19 | informational carrier alongside executable coverage | Illegal. If any MAP R OUTCOME exists, no informational When carrier/group may coexist; every final R-covering Scenario is executable. Informational mode is legal only for terminal zero-R MAP with no executable group. | OLD_MAIN 1581-1597 + grouping cardinality; §4.3–§4.7/§5.3/§6 | **PASS** |
| 20 | two retained executable Scenarios survive reduction in noncanonical witness order | After duplicate merge, sort retained executable Scenarios by canonical `given+simulation`, assign final ids only then, stable-partition groups preserving that order, and AUDIT independently verifies it. | OLD_MAIN 1528/1541; §4.4/§4.5/§4.7 | **PASS** |

## Generator/schema boundary

- **PASS** — CM-WHEN mapping exists
- **PASS** — Absent source omits expected
- **PASS** — Result bool stringification target-owned
- **PASS** — Result-last CF owner
- **PASS** — Generator executes selected mapping

## Negative-space conclusions
- No adversarial case can create dependency-owned original-RUT coverage.
- No case can guess a DecisionResult.
- No grouping/build/projection step can change frozen coverage membership.
- No AUDIT can reuse frozen owner/covers as proof.
- Empty input never becomes parent absence and does not produce target pyExpectedValue.
- Target MultInpComb mechanics remain Generator/schema-owned.

## Result
- Stage 7 implementation: **READY**
- Stage 7 validation: **VALIDATED**
- Critical: 0
- High: 0
- Medium: 0

## Revalidation after Stage 8 collateral finding H-8-01
**H-8-01** — the first H-7-01 repair unintentionally tightened the generic Standard `NotTestable` formula from `BLOCKED OR (ENABLED+ABSENT)` to require `BLOCKED+ABSENT`. **FIXED**: original Standard formula restored exactly; only original Rule-Obj-When adds the terminal `BLOCKED ⇒ TEST_ORACLE=ABSENT` finalization condition. Affected Stage 5C, Stage 6 and all Stage 7 adversarial cases were rerun and remain PASS.


## Revalidation after independent Stage 9 finding H-9-01
The first Stage-9 source-fidelity pass exposed a real conflict with OLD_MAIN cardinality lines 1581-1597: an R-covering frozen Scenario could previously be converted to zero-row informational mode. The prompt was repaired so all R-covering Scenarios are permanently executable-row mode; informational mode is separate empty-cover current state only. All 18 adversarial cases were rerun conceptually after the repair and remain PASS. Critical=0, High=0, Medium=0.

## Revalidation after independent Stage 9 finding H-9-02
A second source-fidelity/cardinality pass proved that even a separate informational carrier cannot coexist with executable coverage: it would add a physical group not derived from final coverage simulation keys. Case 19 was added. The repaired rule permits one informational carrier only for terminal zero-R MAP with no executable coverage group. Cases 1–19 were rerun conceptually and all PASS. Critical=0, High=0, Medium=0.

## Revalidation after independent Stage 9 finding H-9-03
The §5.3 repair changed no Rule-Obj-When obligation: its path-feasibility, Result-oracle, observation and mandatory-row clauses remain explicit. Cases 1–19 were rerun after Standard wording restoration and remain PASS. Critical=0, High=0, Medium=0.

## Revalidation after independent Stage 9 finding H-9-04
Case 20 was added for the old final-order invariant. FREEZE now sorts retained executable Scenarios by canonical `given+simulation` after reduction/merge and before final ids; grouping preserves the order and AUDIT checks it independently. Cases 1–20 PASS. Critical=0, High=0, Medium=0.
