# Stage 6 Aggregate Semantic Review — Stages 5A–5E

## W01–W25 source-fidelity census
| Obligation | Status | Current owner/evidence |
|---|---|---|
| W01 | PASS | §1.4/§2.1.1 |
| W02 | PASS | §3.1 ROOT |
| W03 | PASS | §3.2 RX |
| W04 | PASS | §3.2 + DWL |
| W05 | PASS | §4.2 MAP |
| W06 | PASS | §4.2 MAP constraint |
| W07 | PASS | §4.3 WITNESS |
| W08 | PASS | §4.2/§4.3 boundary |
| W09 | PASS | §4.4 FREEZE |
| W10 | PASS | §4.4 FREEZE |
| W11 | PASS | §4.6 BUILD |
| W12 | PASS | §4.7 AUDIT |
| W13 | PASS | §4.5 grouping |
| W14 | PASS | §4.5 grouping |
| W15 | PASS | §4.5 grouping |
| W16 | PASS | §4.5/§4.6/§4.7 |
| W17 | PASS | §4.5/§5.2/§6.8 |
| W18 | PASS | §5.2/§6.8 |
| W19 | PASS | §5.2 |
| W20 | PASS | §5.2 |
| W21 | PASS | §5.2 |
| W22 | PASS | §4.4/§5.3 |
| W23 | PASS | §6.1 + Generator/schema |
| W24 | PASS | §4.6→§4.7 |
| W25 | PASS | §4.4→§5.2→§6.8 |

## Structural/current-architecture review
- PASS: No PRODUCER row
- PASS: When phase row set
- PASS: When BASE chain
- PASS: When call closed set
- PASS: Standard COV/RESOLVE preserved
- PASS: Standard FREEZE PATH/EFFECT
- PASS: Standard AUDIT A-G
- PASS: Standard DECIDE preserved
- PASS: No target leakage
- PASS: Projection no reevaluation

## Negative-space review
PASS: the candidate does not allow dependency-owned coverage, one-sided MC/DC exclusion, Cartesian When coverage, witness-driven deletion of MAP OUTCOME, testability/grouping-driven membership change, guessed Result truth, Projection semantic re-evaluation, frozen owner/covers reuse as AUDIT proof, or ScenarioAuthor target-RuleCode mechanics.

## Fresh-model review / repairs
1. **M-6-01** — W01 was previously distributed across RUT_TYPE adapter selection and Projection mode. Added one literal firewall: When/MultInpComb mode applies iff immutable original RUT_TYPE is Rule-Obj-When; nested/fetched When dependencies never switch workflow/mode. **FIXED**.
2. **M-6-02** — removed historical/vague When-adjacent wording (`retain §5.2`, `existing infeasibility/disproof mechanism`) in favor of direct current owners (§5.2 and MAP/WITNESS terminal proof). **FIXED**.
No unresolved D1 wording (`existing meaning`, `dedicated existing`, `legacy PRODUCER`) remains authoritative.

## Token/locality
- R39C baseline: 126137 chars / 14508 whitespace words / 958 lines.
- Current restored candidate: 142188 chars / 16605 words / 1036 lines.
- Delta: +16051 chars / +2097 words.
The increase is attributable to restored source-backed When semantics. Token optimization remains a final-stage task after adversarial/regression validation; no semantic rule is removed merely to hit a size target.

## Result
- Implementation waves 5A–5E: **READY**
- Aggregate validation: **VALIDATED**
- Critical: 0
- High: 0
- Medium: 0

## Revalidation after H-7-01
Stage 6 was fully reopened after the mode-oracle repair. W01–W25, row/BASE ownership, negative-space rules and Standard non-regression remain PASS. Rule-Obj-When no longer depends on Standard OUTPUT/DECISION for test-oracle resolution. **VALIDATED: C=0/H=0/M=0.**

## Revalidation after Stage 8 collateral finding H-8-01
**H-8-01** — the first H-7-01 repair unintentionally tightened the generic Standard `NotTestable` formula from `BLOCKED OR (ENABLED+ABSENT)` to require `BLOCKED+ABSENT`. **FIXED**: original Standard formula restored exactly; only original Rule-Obj-When adds the terminal `BLOCKED ⇒ TEST_ORACLE=ABSENT` finalization condition. Affected Stage 5C, Stage 6 and all Stage 7 adversarial cases were rerun and remain PASS.

## Revalidation after independent Stage 9 finding H-9-01
OLD_MAIN lines 1581-1597 were reintroduced into the W22/cardinality review: every frozen R-covering When Scenario is a mandatory final combination row and cannot be suppressed by confidence/testability. The prior X01 wording violated that hard override by permitting executable→informational conversion. The repaired model separates a current-only empty-cover informational carrier from the executable coverage set. W07/W09/W11/W16/W21/W22/W25, row/BASE ownership, Projection mode exclusivity and negative-space checks were rerun. **VALIDATED: Critical=0, High=0, Medium=0.**

## Revalidation after independent Stage 9 finding H-9-02
The second Stage-9 source/cardinality review found that a current informational carrier could not legally coexist with executable coverage groups: doing so would add a physical group not determined by the distinct simulation keys of final coverage rows. The prompt was tightened so informational When exists only for terminal zero-R MAP and no executable group; all W01–W25, row/BASE ownership and Standard-flow checks were rerun. **VALIDATED: Critical=0, High=0, Medium=0.**

## Revalidation after independent Stage 9 finding H-9-03
Shared §5.3 was reworked to preserve the R39C Standard formulas explicitly while retaining separate When-specific clauses. The complete W01–W25, Standard non-regression and negative-space reviews were rerun after the repair. **VALIDATED: Critical=0, High=0, Medium=0.**

## Revalidation after independent Stage 9 finding H-9-04
The old grammar paragraph at line 1528 was added to the source-fidelity census: final retained executable Scenarios must be canonical-`given+simulation` sorted before final ids. The prompt, mapping and W10 inventory were repaired; all W01–W25, row/BASE, negative-space and Standard checks were rerun. **VALIDATED: Critical=0, High=0, Medium=0.**
