# Rule-Obj-When Projection → Generator/schema compatibility proof

## Row/cell mapping
Current MultInpComb schema `CM-WHEN-001` deterministically owns the old target mechanics:
- one Decision block;
- one `rowLevelPage` target row per source row;
- source input `path` -> target `pyPropertyName`, `pyPropertyAbsolutePath`, `pyDisplayLabel`;
- target `pyPropertyType="input"`, `pyPropertyMode="text"`;
- absent source value keeps cell and omits `pyExpectedValue`; schema also permits a present empty source string, but restored old-When empty/irrelevant/not-evaluated cell semantics MUST use **absent source `value`** so target `pyExpectedValue` is omitted; `<EMPTY>` is diagnostic only;
- one Result cell last with schema-owned constants; source boolean maps to target string `"true"|"false"`;
- `CF-WHEN-ORDER-001` owns Result-last.
Therefore ScenarioAuthor must retain source-level `(path,valueType,value?)` plus boolean result only; old target fields are TARGET_OWNED (W23). This explicitly resolves old Main lines 1736–1751 without changing Generator/schema: keep the source input object, omit `value` for the old empty-cell semantic, and let CM-WHEN-001 omit target `pyExpectedValue`.

## Simulation-key sufficiency
Current source simulation wire is `SIM_WIRE=canonicalJSON({runtimeClass,rule,setupPages})`; `REQSIM` is the ordered frozen set. Old runtime-relevant key fields map as follows:
- `pyRuleNameToBeMocked` -> `rule`;
- `pyClassName` -> `runtimeClass`;
- `pyMockingSupportedRuleTypes` and `pySimulationMethod` -> fixed by `CM-EXEC-001`;
- `pxReferredFromClass` -> deterministic from `runtimeClass=Code-Pega-List`, otherwise absent;
- page/list shape -> runtimeClass plus setup-page class/data shape;
- concrete DP_SIG parameters and runtime payload -> frozen `setupPages[].data`;
- old setup-page target name -> fixed by `CM-EXEC-001` as `PrimaryPage`;
- list count/order/empty-vs-populated -> represented in opaque ordered `data`;
- excluded old metadata remains excluded because it is absent from source wire and not invented by Generator.
Thus equality of ordered `REQSIM/SIM_WIRE` is the current representation of equality of complete runtime-relevant simulation requirements. No target-contract GAP was found.

## Gap result
`GAP=0` for W23 and simulation grouping. No Generator/schema edit is required by this restoration.
