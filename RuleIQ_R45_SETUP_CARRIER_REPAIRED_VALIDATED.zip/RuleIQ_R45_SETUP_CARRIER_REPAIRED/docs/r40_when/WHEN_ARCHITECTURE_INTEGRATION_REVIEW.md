# Stage 9 — Independent architecture integration review

## Baseline rule

R39C is the current-architecture baseline. OLD_MAIN supplies Rule-Obj-When semantics only; old T/S/I/W/F/B/A storage and RuleCode target structure are not reintroduced.

## ScenarioTrace mapping

Final original-When phase ownership:

| Phase | BASE | Owned rows | Semantic role |
|---|---|---|---|
| MAP | `-` | `OUTCOME` | old I/T coverage inventory |
| WITNESS | `MAP` | `SCENARIO` | old W execution-backed witness base |
| FREEZE | `MAP,WITNESS` | `SCENARIO` | old F deterministic reduced final set |
| DECIDE | absent | none | original When uses §5.2 row authority, not Standard OUTPUT/DECISION |
| BUILD | `FREEZE` | `GROUP,LOCATION` | old B-style packaging/location only |
| AUDIT | `MAP,FREEZE,BUILD` | `AUDIT,[REPAIR]` | old A independent reconstruction |

No new ScenarioTrace row type was introduced.

## `PRODUCER12` special-gate decision

R39C contained a global `PRODUCER12` row definition annotated “legacy Rule-Obj-When”, plus an arity entry and vague “keeps existing meaning” references. Independent search found:
- no R39C CREATE algorithm for that row;
- no Standard owner/consumer;
- no current Generator or Validator consumer;
- no OLD_MAIN Rule-Obj-When ScenarioTrace PRODUCER row.

Under technical-spec §6.1 this is an orphan current residue, not an old semantic obligation. R40 removes it. This is the one intentional global grammar cleanup. All other Standard row definitions are semantically identical to R39C and Standard phase ownership/BASE remains MAP=`OUTCOME/COV/PDEF`, WITNESS=`RESOLVE+SCENARIO/PATH/WHY`, FREEZE=`SCENARIO/PATH/EFFECT`, DECIDE=`OUTPUT/DECISION`, BUILD=`GROUP/LOCATION`, AUDIT=`AUDIT,[REPAIR]`.

## Why Standard-only rows are absent in original When

`COV/PDEF/RESOLVE/PATH/WHY/EFFECT/OUTPUT/DECISION` were reviewed individually rather than prohibited because R39D D1 had prohibited them. The old When semantics are fully represented by OUTCOME→SCENARIO→final SCENARIO plus §5.2 row authority and independent AUDIT; no current downstream When consumer requires those Standard-specific rows. Adding them would duplicate coverage/execution state or import Standard assertion machinery that original When does not use.

## Projection/Generator seam

ScenarioAuthor owns only current source facts:
- frozen Scenario order and simulations;
- `rows[].inputs[{path,valueType,value?}]` with exact path/order/presence/lexical value;
- boolean `rows[].result`;
- mode/testability metadata.

Current target contracts own physical mechanics:
- `CM-WHEN-001`: one Decision block, `rowLevelPage`, input target fields, absent-value omission, Result stringification;
- `CF-WHEN-ORDER-001`: inputs first, exactly one Result last;
- `CM-EXEC-001`: simulation target constants/wrappers;
- MultInpComb JSON Schema: target row/cell const/cardinality constraints.

No Generator/schema change was required. `WHEN_GENERATOR_SCHEMA_COMPATIBILITY.md` records `GAP=0`.

## Current-only extensions

Two current facts are retained separately from old semantics:
1. Projection source `valueType` remains evidence but cannot alter target `pyPropertyMode="text"` or trigger recasting.
2. `INFORMATIONAL_NOT_TESTABLE` may carry current metadata only when terminal MAP has zero R OUTCOME and no executable coverage Scenario/group/row. It has `owner=covers=-`, zero rows/SIM/ASSERT and cannot participate in coverage/cardinality.

## Standard/non-When integration

Independent contract checks confirm:
- all Standard ScenarioTrace row definitions other than removed legacy-only PRODUCER are unchanged;
- OUTPUT11 and R38 basePage/baseClass hardening remain;
- Standard BUILD/AUDIT BASE remain `FREEZE,DECIDE` and `MAP,WITNESS,FREEZE,DECIDE,BUILD`;
- Standard NotTestable/oracle/observation formulas are restored to R39C semantics;
- property-path closure and `pxRuleClassName` prohibition remain;
- PREPARE_ALL→PERSIST_ALL→GENERATE_ALL remains unchanged.

## Architecture result

No unresolved seam or contract GAP remains. The old storage architecture is not reintroduced; the only removed current artifact is the independently proven orphan `PRODUCER12` legacy-When row. Critical=0, High=0, Medium=0.
