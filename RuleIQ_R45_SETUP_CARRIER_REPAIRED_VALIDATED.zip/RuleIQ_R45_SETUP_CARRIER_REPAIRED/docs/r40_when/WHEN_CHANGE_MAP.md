# R40 Rule-Obj-When production change map

Baseline: R39C current architecture. Semantic source: old `RuleIQ/Main_Agent_Prompt.txt`. R39D D1 is quarantined and is not provenance.

| Current area | R40 action | Source obligations / current owner | Structural constraint |
|---|---|---|---|
| §1.4 execution phases | Keep original-RUT applicability firewall and dedicated When decision path. | W01, W22 | Nested/fetched When never switches mode; no Standard DECIDE for original When. |
| §2.4 / §3.2 acquisition + pyLogic | Preserve/strengthen verbatim pyLogic and operand-DWL closure. | W03, W04 + current DWL | No parallel scan ledger; no semantic closure from raw refs. |
| §3.1 ROOT/setup | Preserve reserved-root carrier ban. | W02 | One bad carrier does not block coverage; universal proof required. |
| §4.1 ScenarioTrace contract | Freeze minimal When row set and BASE chain; remove orphan legacy `PRODUCER12`. | current architecture + spec §6.1 decision | No new row type; Standard row definitions unchanged. |
| §4.2 MAP | Restore TRUE/FALSE + MC/DC R/B/U/E coverage inventory. | W05, W06, W08 | When commits OUTCOME only; dependency behavior owns no coverage. |
| §4.3 WITNESS | Restore deterministic coverage-complete witness construction and execution-derived owner/covers. | W07, W08, W21 | Invalid witness does not erase R; zero-R informational extension isolated. |
| §4.4 FREEZE | Restore re-executed highest-cost-first fixed-point irredundant reduction; rebuild final row authority. | W09, W10, W22, W25 | No confidence/testability/packaging membership changes. |
| §4.5 grouping | Restore grouping by complete current simulation requirement, row bijection and common input signature. | W13–W20, W22 | Inputs/results never split equal simulation keys; informational never coexists with executable coverage. |
| §4.6 BUILD | Packaging-only GROUP/LOCATION; exact executable row mapping. | W11, W16, W22 | Semantic mutation returns upstream. |
| §4.7 AUDIT | Restore independent re-census, re-execution, rebuilt owner/covers/Result and irredundancy check. | W12, W24 | FREEZE proof is comparison data only; semantic fail rebuilds MAP. |
| §5.2 When row authority | Restore source-level DecisionInput/DecisionResult authority, exact paths, empty-cell semantics and DP exclusion. | W17–W21, W25 | Target wrappers/constants stay Generator-owned. |
| §5.3 testability | Add mode-specific When oracle without changing Standard formulas; enforce mandatory executable coverage rows. | W21, W22 + current Projection mode | Informational When is current-only and zero-R/no-executable-group only. |
| §5.5 pre-projection gates | Add independent When row/group/result reconciliation. | W16–W22 | Gate only; no re-evaluation or semantic repair. |
| §6.1/§6.4 Projection | Mechanical copy of frozen When source rows/sims; closed mode/cardinality rules. | W16–W23 + current ProjectionV3 | `CM-WHEN-001`/schema own target mechanics. |
| Generator/schema | No production edit. Verified existing CM/CF/schema compatibility. | W23 current target owner | No RuleCode target detail reintroduced into Author. |

## Intentional current extension

`INFORMATIONAL_NOT_TESTABLE` is not an old coverage-row semantic. It is retained only as a current non-coverage carrier when terminal MAP contains **zero R OUTCOME** and no executable When Scenario/group/row exists. It has `owner=covers=-`, zero rows/SIM/ASSERT, never coexists with executable coverage and never substitutes for an old W obligation.

## Planned structural cleanup approved by spec §6.1

R39C exposed a global `PRODUCER12` grammar line marked “legacy Rule-Obj-When” but supplied no creation algorithm, no stable meaning and no current Generator/Validator consumer. OLD_MAIN does not define this row. R40 removes that orphan row and arity entry. Every remaining Standard ScenarioTrace row definition is unchanged in semantic grammar; Standard never owned/consumed this legacy row.
