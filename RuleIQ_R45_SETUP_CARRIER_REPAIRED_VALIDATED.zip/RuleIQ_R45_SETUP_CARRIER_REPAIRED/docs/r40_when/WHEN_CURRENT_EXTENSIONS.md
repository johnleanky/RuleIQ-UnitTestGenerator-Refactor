# Current-architecture extensions retained separately from restored old semantics

## X01 — INFORMATIONAL_NOT_TESTABLE non-coverage carrier
Current ProjectionV3 supports an informational NotTestable mode that did not exist as a Rule-Obj-When coverage row in OLD_MAIN. OLD_MAIN lines 1581-1597 are authoritative for coverage: every frozen R-covering When Scenario is a mandatory combination row and confidence/testability cannot suppress it.

Therefore X01 is strictly non-substitutive:
- every Scenario with nonempty R coverage is `EXECUTION_CLASS=EXECUTABLE` and retains exactly one Decision row;
- testability may lower such a row only to `PartiallyTestable`, never informational mode;
- an informational When carrier is separate current metadata/testability state only and is legal **only** when active MAP contains zero R OUTCOME after terminal proof-backed B/U classification and no executable coverage Scenario/group/row exists; it has `owner=-`, `covers=-`, zero rows/SIM/ASSERT and can never coexist with an executable When group;
- if active MAP contains any R OUTCOME, informational When is illegal and every final R-covering Scenario remains row-mandatory;
- an R obligation without a complete Result-bearing witness remains open or must be reclassified B/U/E under MAP proof; informational mode is never the escape hatch.

This preserves OLD_MAIN W22/cardinality semantics while retaining the current generic Projection informational mode.

## X02 — ProjectionV3 source row type metadata
`rows[].inputs[].valueType` is a current source-contract field used as source evidence. `CM-WHEN-001` fixes target `pyPropertyMode="text"`; valueType never changes target mode or authorizes recasting. This field does not alter old row coverage semantics.
