# R41 — Knowledge-Area Semantic Externalization Specification

## Objective
Reduce always-loaded ScenarioAuthor semantic surface without losing behavior by moving Rule-Obj-When and Data Page **domain definitions** into their existing Knowledge Areas. Core remains the sole owner of lifecycle, phase/row/BASE, tool legality, repair, commit, Projection and persistence.

## Runtime architecture
- `RuleObjWhenSemanticAdapter` v1: exact KW.17–KW.25 marker set in existing Rule-Obj-When KA.
- `DataPageSemanticAdapter` v1: exact KDP.6–KDP.12 marker set in existing Rule-Declare-Pages KA; KDP.1/2/4/5 remain related canonical domain owners.
- Adapter completeness is fail-closed before affected AUTHOR work.
- Duplicate Area results, duplicate required marker definitions, missing markers and wrong versions are semantic GAPs.
- No generic/historical fallback is legal.

## Migration safety
Definitions were externalized only after shadow equivalence. Independent Core validators were retained. W01–W25 and DP01–DP20 have explicit ownership maps and equivalence evidence.

See `../docs/r41_ka/KA_EXTERNALIZATION_PLAN.md`, `SEMANTIC_OWNERSHIP_MAP.csv`, and `GLOBAL_VALIDATION.md`.
