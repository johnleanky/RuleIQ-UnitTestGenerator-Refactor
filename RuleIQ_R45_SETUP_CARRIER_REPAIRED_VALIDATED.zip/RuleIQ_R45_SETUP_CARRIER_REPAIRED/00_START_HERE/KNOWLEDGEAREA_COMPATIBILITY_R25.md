# R25 KnowledgeArea Compatibility Note

R25 adds a verbatim reference copy of `Rule-Utility-Function_KnowledgeArea`. Runtime prompts/contracts remain unchanged from R24/R23. R24 Model/Data Page/Decision Table compatibility findings remain active.

## Rule-Utility-Function compatibility

- **KRUF.0-4 — compatible.** ScenarioAuthor already treats RUF identity/readiness as KnowledgeArea/helper-owned, uses exact selected-holder `pxRuleReferences[]`, emits only `pxObjClass,pxRuleFamilyName,pxRuleObjClass,pyRuleName`, forbids `pxRuleClassName`, and uses alternate-holder retry/gap rather than synthesis.
- **KRUF.5/5a — compatible.** Fetched parameter/usage/description evidence is concrete-contract authority; insufficient documentation remains unknown. The label fallback is narrower than generic name/signature inference and does not conflict with the prompt.
- **KRUF.6-8 — compatible.** Transitive named-rule dependencies remain ordinary canonical non-RUF dependencies with resolved occurrence-local class; the current prompt already cites KRUF.6-8 for this boundary.
- **KRUF.9-11 — compatible.** Impact tracking, known page/list helpers, and inside-out nested function evaluation align with existing SI/DWL/helper handling.
- **KRUF.12-13 — compatible.** `RUF_RETURN_UNKNOWN:<FunctionName>` and blocked exact claims match ScenarioAuthor §2.9 and preAuthor closure behavior. `BlockingGaps` is interpreted through the existing terminal GAP/blocking-claim model; it does not create a new Projection field or separate canonical state owner.

## Soft duplication / future drift risk

`KRUF.0` says RUF field names, identity rules, request mapping and response matching come from the KnowledgeArea, while ScenarioAuthor also restates the exact KRUF.1/KRUF.4 request projection and source gate. The duplicated rules currently agree exactly, so there is no behavioral conflict, but future edits must keep one authority or update both atomically. R25 does not change the prompt.

## Inherited R24 conflicts

- Model KT.29 uses target `pySetupPages/pyParameters/pyPagesAndClasses` wording across the Author/Generator boundary.
- Decision Table KDT.6/KDT.11/KDT.12 contain final `RuleCode` inspection/repair requirements that conflict with ScenarioAuthor's explicit prohibition on Candidate/RuleCode access.

No semantic prompt change is made in R25.
