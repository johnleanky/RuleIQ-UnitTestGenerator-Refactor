# R38 — Property Path / Page Class Lineage Hardening Validation

**Validation date:** 2026-09-19  
**Result:** PASS — Critical 0 / High 0 / Medium 0  
**Live modified-prompt replay:** pending external Pega/model evidence.

## Regression basis

The supplied live `PXCONV-184077(1).txt` (`GENUT-93002`) shows all `PageValue1..8` Property references already present in the RUT `pxRuleReferences[]`, but its only RuleCrawler wave requested four Rule-Obj-When rules and no Rule-Obj-Property definitions. G001 later failed because `PageValue1` had no class binding; G003 failed for the eight-level page path. R38 closes that gap before AUTHOR/Projection.

## Stage reviews

| Stage | Scope | Review result | Remediation performed |
|---|---|---|---|
| 0 | Baseline / change surface | C0/H0/M0 | None |
| 1 | Property-path dependency discovery | C0/H0/M0 after loop | Preserved synthetic NON_RUF materialization; prevented terminal-gap refetch |
| 2 | OUTPUT page-class lineage | C0/H0/M0 after loop | Allowed `baseClass=-` only for terminal OMIT candidates so OUTPUT census remains complete; ASSERT still requires grounded class |
| 3 | AUDIT / Projection mechanics | C0/H0/M0 after loop | Removed competing assertion-page class authority from ROOT projection wording; assertions now use frozen OUTPUT.baseClass only |
| 4 | Full regression / consistency | C0/H0/M0 | No further runtime fixes required |
| Global | Final bundle revalidation | C0/H0/M0 after loop | Corrected R38 continuation metadata/size wording; no runtime-contract changes |

## Final checks

- Property-path completeness is rechecked before `preAuthor=PASS`.
- Every non-final navigation segment creates a Prop dependency before property mode/class is known.
- `pxRuleReferences[].pxRuleClassName` is explicitly forbidden as embedded runtime page class evidence.
- Existing NON_RUF synthetic request materialization remains available when no matching reference row exists.
- Standard ScenarioTrace uses `OUTPUT11` with `baseClass`; no `OUTPUT10` remains in the active prompt.
- Candidate identity remains `OUTPUT_KEY=(scenarioId,fullTarget,intent,selector)`; class is context lineage, not identity.
- Terminal class gaps remain representable as OUTPUT + OMIT; they cannot ASSERT.
- AUDIT checks class lineage and uses existing `PLAN_RESOLUTION_GAP` / `PAGE_MISMATCH` repair vocabulary.
- Projection v3 external assertion grammar is unchanged; no `baseClass` field is projected.
- Non-primary ASSERT class binding is mechanically materialized from OUTPUT and self-validated before persistence.
- Generator, Validator, target contracts, and tool contracts are direct-content unchanged from R37.
- Rule-Obj-When §5.2 is direct-content unchanged.
- ScenarioAuthor line count remains 604; active runtime change surface is 15 existing lines.
- ScenarioAuthor size changed from 145,193 to 146,779 bytes; Unicode text delta is 1,583 characters (~396 tokens using chars/4), within the <=500 target estimate.

## Evidence boundary

This validation is static/contract/regression validation of the supplied bundle and supplied historical conversation. It does not claim that the modified prompt has already been redeployed and replayed in Pega. A fresh live DeepHierarchy replay is the remaining external confirmation step.
