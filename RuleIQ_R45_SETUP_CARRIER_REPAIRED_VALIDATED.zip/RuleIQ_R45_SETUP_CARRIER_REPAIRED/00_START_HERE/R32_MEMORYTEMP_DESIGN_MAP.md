# R32 ScenarioTrace Design Map

## Authority model
The active ScenarioTrace state is the union of immutable rows belonging to the active generations named by the latest valid `HEAD`. Each MemoryTemp call is one incremental phase commit. Later commits reference prior active generations through `BASE` rather than copying their rows.

## Readable control rows
- `PHASE|<MAP/WITNESS/FREEZE/DECIDE/BUILD/AUDIT>|<pyID>|<pzInsKey>|<RUT_TYPE>` — existing phase identity, unchanged.
- `HEAD|epoch=<positive integer>|map=<MAPn>|witness=<WITNESSn or ->|freeze=<FREEZEn or ->|decide=<DECIDEn or ->|build=<BUILDn or ->|audit=<AUDITn or ->` — complete active generation chain after this commit.
- `BASE|<ordered comma-separated prerequisite generation ids or ->` — immutable generations consumed by this commit.
- `COMMIT|<current generation id>` — closes this exact MemoryTemp commit.
- `INVALIDATE|<generation id>|<reason>` — optional; declares an older generation and all downstream generations depending on it inactive before the new generation is committed.

Generation IDs use readable phase names plus positive integers (`MAP1`, `WITNESS1`, `FREEZE1`, `DECIDE1`, `BUILD1`, `AUDIT1`) and are never reused. Semantic row IDs are unique within their owning generation; full identity is `(owning generation, row ID)`. A replacement generation may assign its own canonical local IDs such as `S1..Sn` and `P1..Pn` without mutating the invalidated generation. Do not introduce a separate abbreviation dictionary.

## Existing semantic rows
- MAP owns `OUTCOME` rows. Materialize each canonical OUTCOME once in the active MAP generation.
- WITNESS owns candidate `SCENARIO` rows using W ids. Do not copy OUTCOME rows.
- FREEZE owns final `SCENARIO` rows using stable S ids. Do not copy MAP OUTCOME rows or WITNESS rows.
- DECIDE owns Standard `OUTPUT` and `DECISION` rows. Do not copy OUTCOME/SCENARIO rows.
- BUILD owns `GROUP` and `LOCATION` rows. Do not copy SCENARIO/OUTPUT/DECISION rows.
- AUDIT owns the existing `AUDIT` row. Do not copy upstream semantic rows.

## Producer execution projection
FREEZE additionally owns `PRODUCER` rows:
`PRODUCER|<id>|<scenarioId>|<producerId>|<execution:executes|skipped|unknown>|<operation>|<source-or->|<target-or->|<beforeState-or->|<afterState-or->|<writeIndex:n|unknown|->|<reason-or->`

Rules:
- `<producerId>` is the existing RI/PC producer identity; `<id>` is only the stable ScenarioTrace projection identity (`P1`, `P2`, ...).
- Rows are in deterministic Scenario order then actual producer execution/tree order.
- `source` and `target` remain separate coordinates.
- Preserve one row for every scenario-relevant PC producer whose execution/state can affect final RUT outputs, PropertyTrace/APB/LIC, or the ordered state of a candidate-sensitive mutable list; include skipped/unknown relevant producers when their state matters. Preserve only state already established by existing semantics and needed downstream. For list/index-sensitive mutations use the prompt's readable canonicalJSON state such as `{"count":0}` and `{"count":1}`; preserve concrete `writeIndex` when established.
- A concrete child write uses its resolved target path (for example `CustomerCommunication.Addresses(1).pyCity`) and the minimal relevant before/after state.
- `unknown` must have a compact reason when the uncertainty affects downstream representation, for example `prior_target_count_unknown`.
- This row does not replace or alter RI/PC/LPE/APB/LIC/PropertyTrace semantics.

## BUILD rows
`GROUP|<groupId>|<scenarioIds>|<claimIds-or->`
`LOCATION|<scenarioId>|<groupId>|<name>|<at>`
These rows contain only new physical grouping/location information and references, never copied upstream semantic state. `scenarioIds`, `claimIds`, and LOCATION rows preserve deterministic materialized order.

## Standard active chain
- MAP commit: `PHASE,HEAD,BASE,OUTCOME,COMMIT`
- WITNESS commit: `PHASE,HEAD,BASE,SCENARIO,COMMIT`
- FREEZE commit: `PHASE,HEAD,BASE,SCENARIO,PRODUCER,COMMIT`
- DECIDE commit: `PHASE,HEAD,BASE,OUTPUT,DECISION,COMMIT`
- BUILD commit: `PHASE,HEAD,BASE,GROUP,LOCATION,COMMIT`
- AUDIT commit: `PHASE,HEAD,BASE,AUDIT,COMMIT`

Original Rule-Obj-When keeps its existing dedicated semantic decision path; only the ScenarioTrace transport changes. It uses MAP/WITNESS/FREEZE/BUILD/AUDIT commits with the same control-row contract and without Standard OUTPUT/DECISION.

## Invalidation
A restart creates a new generation; committed row content is never edited in place. The new commit includes `INVALIDATE` for the earliest invalid active generation when one exists, updates `HEAD`, references only still-valid prerequisites in `BASE`, and emits only the new generation's rows.

## Downstream read rule
Consumers resolve semantic state from the latest valid `HEAD` plus the actual prior MemoryTemp commits for the referenced active generations. A missing, invalidated, duplicate, incompatible, or semantically inconsistent generation is blocking. No consumer may infer missing referenced facts from prose or recreate them merely to avoid following the reference.
