# R26 KnowledgeArea semantic-boundary cleanup

R26 treats KnowledgeAreas as rule-semantic supplements, never alternative pipeline owners.

## Changed
- Rule-Obj-Model: removed target parameter/assertion leakage; KT.29 now emits PAGE source/setup obligations only.
- Rule-Declare-DecisionTable: KDT setup and audit operate on caller-frozen semantic inputs before Projection; Candidate/RuleCode inspection/repair removed while DTM/DTA/DTE, OR/range/inverse-seed/inactive-scalar/existence semantics remain.
- Rule-Utility-Function: KRUF.0 ownership split now matches caller orchestration vs RUF contract authority.
- ScenarioAuthor: one wording-only `rebuild/localize` correction.

## Unchanged
Generator, Validator, target schemas/examples, Rule-Declare-Pages KA, Rule-Obj-When KA, Projection grammar and R22 page-provenance architecture.

## Validation
65/65 static architecture/semantic checks PASS; 6/6 target examples schema-valid. Fresh live Pega replay pending.
