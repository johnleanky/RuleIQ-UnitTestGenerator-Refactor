# R42 — Knowledge-Area Boundary Hardening Specification

## Goal
Harden the R41 Knowledge-Area architecture before any further Decision Table thinning. R42 removes lifecycle/repair ownership from Data Page and Decision Table KAs, formalizes a versioned Decision Table semantic adapter, and makes all cross-domain dependencies flow through Core/DWL.

## Runtime changes
- `Rule-Declare-Pages_KnowledgeArea_REFERENCE.txt`: KDP returns domain facts/status/evidence only; Core remains sole lifecycle/repair owner.
- `Rule-Declare-DecisionTable_KnowledgeArea_REFERENCE.txt`: adds exact `DecisionTableSemanticAdapter` v1 requiring KDT.1–KDT.12; KDT.11/12 return DT-local semantic evidence/audit status only; Core owns invalidation/repair/assertion policy/Projection.
- `ScenarioAuthor_SystemPrompt.txt`: exact DT adapter completeness gate, no-KA→KA rule, KDT.10→Core/DWL mediation, Core-owned DT failure/OMIT/assertion mappings.

## Non-goals
No Decision Table algorithm redesign, no Core thinning wave, no phase/ScenarioTrace/Projection/Generator/Validator contract change, no Rule-Obj-When or RUF semantic change.

## Acceptance
Direct KA→KA marker invocation=0; adapters fail closed; KDP/KDT do not choose lifecycle actions; Standard/When/DP/DT/RUF regressions PASS; downstream Generator/Validator do not consume KA internals; Critical/High/Medium=0.
