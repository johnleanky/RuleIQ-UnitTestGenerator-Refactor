# R34 — Naming Authority and Response Contract Specification

## Scope

R34 changes only naming authority, Candidate Scenario-name representation, ScenarioAuthor terminal response closure, and the prompt wording needed to make those boundaries reliable for Claude Opus 4.8. R33 Property `pyPageName`, Memory/`SkipPayload`, Generator aggregation, lifecycle, MemoryTemp, RuleCrawler, KnowledgeAreas, assertions and simulation semantics remain unchanged.

## Required behavior

1. ScenarioAuthor owns semantic names only. `testLabel` and `scenarios[n].name` contain semantic labels and no Pega technical-name construction.
2. Candidate `Scenarios[n].Name` is an exact copy of Projection `scenarios[n].name`.
3. UnitTestGenerator alone executes `CM-NAME-001` to create the technical Pega Unit Test identity `TC_<RUT>_<Scenario>`.
4. That one technical identity is reused exactly in `UnitTestRules[0].Name`, `RuleCode.pyPurpose`, and `RuleCode.pyLabel`.
5. The shared target JsonSchema remains common to Generator and Validator. Every `x-ruleiq-compilerMappings` entry declares `consumers`; `CM-NAME-001` lists only `UnitTestGenerator`, while the existing fidelity mappings retain both Generator and Validator consumers.
6. UnitTestValidator MUST NOT execute `CM-NAME-001`, derive `TARGET_TEST_NAME`, calculate RUT truncation, or reject a Candidate because it would have invented another technical name.
7. Validator still validates ordinary JSON Schema constraints, `CF-IDENTITY-001`, exact semantic Scenario-name pass-through, and all unrelated authorized Projection→Candidate fidelity rules.
8. ScenarioAuthor terminal output is exactly one raw JSON object with exactly two keys: `AIAgentResponseStatus` and `AIAgentErrorResponseMessage`. Status is `Completed|Failed`; message is a string. No aliases, renamed fields, extra fields, or prose outside JSON.
9. Prompt changes must be explicit and token-efficient for Claude Opus 4.8: one literal owner/boundary rule per concern, no duplicated procedural explanation where schema already owns it.

## Validation

After each implementation stage run targeted checks plus full-project regression. Classify findings as Critical/High/Medium/Low and automatically fix/revalidate until Critical=High=Medium=0. After all stages, repeat the entire R34 acceptance suite from scratch.
