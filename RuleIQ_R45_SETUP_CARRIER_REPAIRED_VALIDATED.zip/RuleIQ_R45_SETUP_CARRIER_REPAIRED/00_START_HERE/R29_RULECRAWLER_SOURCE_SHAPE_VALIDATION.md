# R29 RuleCrawler source-holder + reference-shape validation — 2026-09-16

**Scope:** ScenarioAuthor RuleCrawler source provenance, holder selection, physical reference rendering, and matching RUF KnowledgeArea rules. Static textual/semantic validation plus in-memory adversarial examples only; no live R29 Pega/Claude execution is claimed. No stored fixtures or hash/checksum/fingerprint acceptance gates were used.

## Live R28 evidence that triggered R29

The supplied RuleCrawler call contained one RUT holder for all references and RUF objects containing `"pxRuleClassName":""`. The second condition is definitively invalid under the intended RUF contract. A single holder by itself is not proof of error: it is valid only when every emitted dependency was actually discovered from that holder. R28 could not prove that because holder selection was unconstrained before `REQ` freeze.

## Runtime changes

1. `SCAN_HOLDER` is frozen from the exact scanned RuleJSON/tool correlation (`pzInsKey`/resolved key); aliases such as `RUT` and reconstructed identifiers are forbidden.
2. Every D source is structured as `holder=<SCAN_HOLDER>;at=<path/expression>` and keeps that holder through later context resolution.
3. For each READY KEY, `CANDIDATE_HOLDERS` is only the stable unique source-holder projection of its READY occurrences. Selection/retry outside this list is invalid.
4. Existing R28 `REQ=holder::KEY`, OUT/ACT physical holder audit and grouping remain.
5. Physical references are discriminated before rendering/census:
   - non-RUF: exact keys `pxObjClass,pxRuleClassName,pyRuleName,pxRuleObjClass,pxRuleFamilyName`, class nonempty;
   - RUF: exact keys `pxObjClass,pxRuleFamilyName,pxRuleObjClass,pyRuleName`; `pxRuleClassName` absent. Empty/null still means present and invalid.
6. RUF KA KRUF.1/KRUF.4 matches the same four-key/holder-provenance contract.

## Focused validation

PASS:
- SCAN_HOLDER defined before each RuleJSON scan.
- D source holder is explicit and immutable.
- fetched-rule dependencies inherit fetched-rule holder.
- caller-expression rule arguments retain caller holder.
- missing exact holder provenance cannot become READY.
- CANDIDATE_HOLDERS derives only from READY source occurrences.
- holder selection is deterministic first passing provenance candidate.
- no arbitrary `RUT` alias/reconstruction is permitted.
- retry is limited to next untried provenance candidate.
- physical pyItemRuleId remains equal to frozen REQ holder.
- holder outside candidate set forces FIX before call.
- OUT/ACT remain holder+KEY and exact ordered equality is retained.
- non-RUF and RUF use separate closed reference shapes.
- common/shared physical reference template is explicitly forbidden.
- non-RUF exact five-key gate retained.
- RUF exact four-key gate is explicit in ScenarioAuthor.
- RUF exact four-key gate is explicit in KRUF.1/KRUF.4.
- RUF `pxRuleClassName:""` is rejected.
- RUF `pxRuleClassName:null` is rejected.
- RUF nonempty `pxRuleClassName` is rejected.
- extra RUF fields are rejected.
- non-RUF missing/empty `pxRuleClassName` is rejected.
- physical shape validation occurs before ACT materialization.
- conceptual valid ROOT/DEP1/DEP2 source grouping passes.
- conceptual all-under-ROOT collapse fails when C/D/E provenance belongs to DEP1/DEP2.
- wrong-holder and missing-key conceptual calls fail.
- Generator/Validator, Model/When/DataPage/DecisionTable KAs, target schemas/examples and runtime-tool contract are unchanged from R28.
- all 6 Standard/MultiInput examples validate against the unchanged Draft-2020-12 schemas.

## Size

- ScenarioAuthor: 9,283 -> 9,502 words (+219, ~2.4%).
- RUF KnowledgeArea: 874 -> 888 words (+14).

The change is intentionally local: no RuleCrawler external wire wrapper, target schema, Generator/Validator lifecycle, fixtures, or hash-based validation was introduced.

## Required live R29 replay

Replay `PrepareCustomerCommunication` and capture:

```text
D rows with src.holder
CANDIDATE_HOLDERS per READY KEY
_DWLPlan.OUT
_DWLPlan.ACT
final InterestedRules[]
```

Acceptance:
- each physical `pyItemRuleId` belongs to that KEY's source-derived candidate set;
- nested dependencies discovered from fetched rules use those fetched-rule holders;
- every RUF object omits `pxRuleClassName` entirely;
- OUT == ACT exactly;
- no request is emitted when any source/shape gate is FIX.

A single RUT group is acceptable if and only if the captured D provenance shows every emitted KEY was genuinely sourced from the RUT scan.
