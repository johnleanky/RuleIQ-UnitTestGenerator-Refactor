# R42.1 Direct Knowledge Area Semantics — Specification

## Goal
Remove the artificial `SemanticAdapter` abstraction. ScenarioAuthor talks directly to existing Knowledge Areas and requires their stable semantic markers.

## Runtime model
`ScenarioAuthor -> KnowledgeTool -> Knowledge Area Description -> required semantic markers`

No separate adapter id, version, registry, manifest, runtime contract or adapter file exists.

## Required markers
- Original Rule-Obj-When: exactly one definition each of KW.17–KW.25.
- Rule-Declare-Pages occurrence that may reach AUTHOR: exactly one definition each of KDP.6–KDP.12.
- Original/fetched Rule-Declare-DecisionTable occurrence that may reach AUTHOR: exactly one definition each of KDT.1–KDT.12.

Missing/duplicate/incomplete required semantics is a semantic GAP and blocks affected AUTHOR work. Generic/historical fallback is forbidden.

## Scope
No domain algorithm, phase graph, ScenarioTrace ownership/BASE, repair routing, Projection/Generator/Validator semantics or cross-domain dependency route may change.
