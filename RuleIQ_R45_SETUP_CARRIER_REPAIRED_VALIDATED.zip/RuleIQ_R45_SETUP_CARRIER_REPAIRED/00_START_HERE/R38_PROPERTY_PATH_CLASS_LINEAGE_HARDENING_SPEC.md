# R38 — Property Path / Page Class Lineage Hardening

## Goal

Prevent Standard assertions from reaching Projection/Generator with a non-primary runtime page whose class was never semantically acquired. The live regression is `GENUT-93002`: `pxRuleReferences[]` already listed `PageValue1..8`, ScenarioAuthor crawled only four When rules, then persisted assertions whose `page` had no matching `Projection.pages` class binding.

## Design constraints

- Keep the R37 `CRAWL -> MAP -> WITNESS -> FREEZE -> DECIDE -> BUILD -> AUDIT -> Projection` architecture.
- Keep `pxRuleReferences[]` as identity/materialization evidence only; never crawl unused raw references.
- Do not change Generator, Validator, Projection v3 external schema, target contracts, RuleCrawler payload grammar, DWL grammar, or Rule-Obj-When flow.
- Add no ScenarioTrace row type. Carry page-class lineage in existing Standard OUTPUT.

## Changes

### 1. Property-path closure

Every non-final navigation segment creates/reuses a `Prop@ownerClass@segment` dependency before mode or embedded class is known. A matching `pxRuleReferences[]` row can materialize identity but cannot close semantics. Unless the Prop KEY is already CLOSED/terminal, fetch/scan the Property definition, prove navigable structure and embedded page class, then advance owner class. `pxRuleClassName` is Applies-To/request class only and can never substitute for embedded runtime page class.

Before `preAuthor=PASS`, independently re-enumerate required property-path segments. Missing D is discovery work, not evidence of no dependency.

### 2. Frozen class lineage

Standard OUTPUT becomes:

```text
OUTPUT|scenarioId|claimId|fullTarget|basePage|baseClass|relativeTarget|intent|selector|origin|sourceRefs
```

`OUTPUT11` replaces `OUTPUT10`.

For non-Param outputs, `baseClass` is the runtime class of `basePage`. Primary uses `ROOT.class`; non-primary uses grounded named-page/CTX/APB/property-path evidence. `baseClass=-` is allowed only for terminal class unavailability and forces OMIT. A non-Param ASSERT always requires grounded `baseClass`.

### 3. AUDIT / Projection

AUDIT verifies `basePage/baseClass/relativeTarget/fullTarget` lineage. Missing required Property acquisition repairs from CRAWL; other page/class drift repairs from DECIDE unless earlier EFFECT state is wrong.

Projection performs no class inference. Each non-primary ASSERT mechanically contributes:

```text
Projection.pages[OUTPUT.basePage] = OUTPUT.baseClass
```

This is merged with existing grounded setup/action/CTX bindings. Any page-to-class conflict fails preparation.

§6.8 requires primary ASSERT class equality with `Projection.primary.class`, and non-primary ASSERT exact equality with `Projection.pages[OUTPUT.basePage]`, before any WriteMemory.

## Token/runtime policy

The implementation replaces/extends existing rules rather than adding a parallel subsystem. No new tool call type, Projection field, or ScenarioTrace row family is introduced. Required Property requests are deduplicated by existing Prop KEY semantics; unused raw references remain uncrawled.
