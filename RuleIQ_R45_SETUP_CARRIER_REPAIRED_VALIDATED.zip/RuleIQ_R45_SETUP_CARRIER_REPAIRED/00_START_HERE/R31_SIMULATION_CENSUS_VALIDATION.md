# R31 Data Page Simulation Census Validation — 2026-09-16

## Runtime change

R31 closes the intermittent ScenarioAuthor projection defect observed in `PXCONV-163039`: both G001 and G002 stated that `D_CustomerTestRef` was simulated in Scenario metadata, but the persisted `UnitTestProjectionV3` payloads contained no physical `simulations[]` field.

The active simulation chain is now:

`RX evaluation -> REQUIRED_SIMS -> frozen SIM -> Projection.simulations -> simulationsNarrative`.

`REQUIRED_SIMS` is a stable ordered unique DP_SIG census derived from final Scenario RX `dpRefs`:
- `evalState=evaluated|unknown` requires simulation;
- a false guard still requires every Data Page evaluated to obtain the false result;
- `actionState=skipped` does not remove that obligation;
- exclusion is allowed only when every possible Scenario occurrence is `notEvaluated` with terminal control-flow proof.

Each REQUIRED_SIM freezes exactly one internal SIM. The external Projection simulation shape remains unchanged: `{runtimeClass,rule,setupPages}`. No DP_SIG field was added to the wire contract. Producer validation defines `SIM_WIRE`, derives `REQSIM` from frozen SIMs and `ACTSIM` from final physical `Projection.simulations`, and requires exact ordered `REQSIM==ACTSIM`. `simulations` is absent iff REQSIM is empty; otherwise it is required and nonempty. `simulationsNarrative` is derived from physical simulations and is empty iff ACTSIM is empty.

## Scope

Runtime files changed from R30:
- `01_PROMPTS/ScenarioAuthor_SystemPrompt.txt`

Unchanged runtime artifacts:
- UnitTestGenerator prompt
- Validator prompt
- all five semantic/reference KnowledgeAreas
- all four target schemas/examples
- all tool contracts
- RuleCrawler occurrence-driven R30 behavior and external wire contracts

## Validation

Static/textual checks: **28/28 PASS**.

Adversarial simulation cases: **12/12 PASS**:
- evaluated true -> required;
- evaluated false with skipped action -> required;
- terminally proven notEvaluated -> not required;
- unknown evaluation -> required;
- same DP_SIG repeated -> one simulation;
- same Data Page with different concrete params -> distinct simulations;
- required simulation physically absent -> rejected;
- no requirement with extra physical simulation -> rejected;
- exact required/physical match -> accepted;
- narrative-only simulation -> rejected;
- duplicate physical simulation -> rejected;
- wrong physical simulation order -> rejected.

Observed regression replay against `PXCONV-163039`: **2/2 bad Projections identified and rejected by the R31 rules** (`G001 Valid Postal Address Appended`, `G002 Invalid City Sets Exit Code`). This is static replay of the stored payloads, not a live Pega execution.

Target contract regression:
- all four JSON schema/example files parse;
- **6/6** Standard/MultiInput example candidates remain Draft-2020-12 schema-valid;
- runtime-artifact delta under `01_PROMPTS`–`04_TOOLS` is exactly ScenarioAuthor only; README/status/handoff changes are release metadata only.

## Token impact

ScenarioAuthor word proxy: R30 `9,332` -> R31 `9,524` (`+192`, about `+2.1%`). The change replaces the ambiguous optional simulation boundary with one canonical census and two compact behavioral branches; it adds no parallel simulation ledger/state machine.

No fixtures were created/updated. No hash/SHA/checksum/fingerprint acceptance checks were used.

## Not verified

Static validation does not prove live Claude Opus 4.8/Pega behavior. Live replay must verify that `PrepareCustomerCommunication` persists physical `simulations[]` for both scenarios, that a false guard using a Data Page retains its simulation, and that a terminally not-evaluated Data Page does not acquire an unnecessary simulation.
