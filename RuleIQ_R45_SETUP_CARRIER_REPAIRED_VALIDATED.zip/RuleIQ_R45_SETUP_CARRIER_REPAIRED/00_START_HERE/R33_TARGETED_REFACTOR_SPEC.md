# R33 Targeted Refactor Specification

## Scope
Implement only four changes over R32; preserve unrelated semantics.

1. **Unit-test identity** — `UnitTestRules[0].Name = RuleCode.pyPurpose = RuleCode.pyLabel = TC_<RUT>_<Scenario>`. Keep `Scenarios[n].Name` independently `TC_<Scenario>`. Preserve the 53-character limit by deterministically truncating only the RUT component; an unrepresentable Scenario component fails before persistence.
2. **Property page context** — for every regular `PagePropertyAssertion` inside a Property block, `pyPageName` is the containing page of `pyStepPageName + pyPropertyAbsolutePath`. Do not add a Projection field; Generator derives it and Validator independently checks it. Param assertions omit it; List-block leaf reuse is unchanged.
3. **Memory read interface** — use only `GetAgentMemory(pyGUID,SkipPayload=false)`. Full artifact reads use `false`; status-only Author/Generator polls use `true`. `SkipPayload` is transport-only: if payload is still returned on a status read, ignore it. Correlate the returned `CaseID`; do not pass `pxCaseID` to this read tool.
4. **Generator aggregation and response envelope** — recognized negative Generator terminal outcomes mark the queue row DONE and do not block later Projections. If at least one Generator succeeds, Author completes; if all recognized outcomes are negative, Author fails. Tool/correlation/integrity failures remain fatal. Do not change testability or introduce statuses. ScenarioAuthor emits exactly one raw final status JSON object; all user-visible warning/error text is only in `AIAgentErrorResponseMessage`.

## Prompt design
Changed runtime instructions must remain compact and explicit for Claude Opus 4.8: reuse canonical terms, state mandatory scope/tool calls literally, consolidate duplicate rules, and do not introduce abbreviation vocabularies. Correctness takes priority over token reduction.

## Validation
After each stage run targeted and full static/schema checks. Classify findings Critical/High/Medium/Low; automatically fix and revalidate until Critical=High=Medium=0. Finish with a clean diff-scope review against R32 and do not claim live Pega execution unless actually run.
