# R42.1 Direct Knowledge Area Semantics — Validation

Status: **VALIDATED**

- Primary semantic suite: **86/86 PASS**.
- Independent architecture review: **23/23 PASS**.
- Required markers remain exact and unique: KW.17–KW.25, KDP.6–KDP.12, KDT.1–KDT.12.
- `SemanticAdapter`/`ADAPTER|id=...` active runtime layer: **absent**.
- Fail-closed missing/duplicate/incomplete Knowledge Area semantics: **preserved**.
- Core-owned lifecycle/repair and Core/DWL cross-domain mediation: **preserved**.
- Generator/Validator dependence on KW/KDP/KDT internals: **absent**.
- Internal `§x.y` references: **all resolved**.
- Semantic-adapter-specific contract filenames: **absent**.

Runtime context chars versus R42:
- Standard: 133342 -> 133049 (-293)
- Standard+DP: 145678 -> 145295 (-383)
- When: 154686 -> 154285 (-401)
- When+DP: 167022 -> 166531 (-491)
- DT: 171692 -> 171272 (-420)
- DT+DP: 184028 -> 183518 (-510)

Critical=0 High=0 Medium=0.

Fresh live Pega/model replay is not claimed.
