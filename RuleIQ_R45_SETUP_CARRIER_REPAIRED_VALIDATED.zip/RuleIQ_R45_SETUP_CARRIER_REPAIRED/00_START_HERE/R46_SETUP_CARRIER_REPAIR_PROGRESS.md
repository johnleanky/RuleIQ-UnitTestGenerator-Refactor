# Setup Carrier Repair — Execution Progress

Source: `RuleIQ_R45_RV01_RV08_REMEDIATED`
Regression evidence: `decision_table/PXCONV-185020 GenUT-94005.txt`, `decision_table/PXCONV-186030 GenUT-94008.txt`
Validation policy: semantic/textual inspection only; no diff/SHA/hash/checksum evidence.

| Stage | Status | Validation |
|---|---|---|
| 0. Baseline / regression evidence | VALIDATED | New Projection contains undeclared `pyLabel`/`pyType` parameters; old Candidate carries Primary `pyLabel` in setup and dependency `pyType` in simulation. |
| 1. Carrier classification contract | VALIDATED | Closed one-carrier mapping added at ScenarioTrace→Projection boundary and canonical Projection reconciliation. |
| 2. Formal RUT parameter gate | VALIDATED | `parameters[]` now derives only from exact nonempty-name original RUT declarations; GENUT-94005 has no usable formal parameters. |
| 3. Primary/named-page setup materialization | VALIDATED | `Primary.<path>` binds to `ROOT.page`; required pre-state groups into `setupPages.data` by owning page. |
| 4. Runtime page + simulation ownership | VALIDATED | Page/list When operands stay on resolved provider page; regression keeps `Addresses(1).pyType` simulation-owned and removes rebased Primary duplicate. |
| 5. Projection producer self-validation | VALIDATED | §6.4.6 reconstructs exact carrier census; §6.4.7 requires it before persistence. |
| 6. ScenarioAuthor ↔ Generator synchronization | VALIDATED | Generator source interface now names the same three carrier meanings; both Standard/When `CM-EXEC-001` already map parameters/setupPages/simulations deterministically. |
| 7. DetermineCondition regression simulation | VALIDATED | Deterministic replay: 36/36 checks PASS for G001/G002; no bogus RUT params, Primary pyLabel setup present, Data Page payload preserved. |
| 8. Final cross-structural validation | VALIDATED | 37/37 PASS: prompt contracts, bilateral CM-EXEC mappings, two schemas, six concrete examples, regression evidence, prompt-growth budget. |

## Resume point

Complete. All stages VALIDATED.
