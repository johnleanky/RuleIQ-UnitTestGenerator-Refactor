# R35 — PXCONV-184019 bad-case simulation

This is a deterministic static simulation of the R35 contracts using the actual RuleJSON and the three WITNESS rows recorded in `PXCONV-184019.txt`. It is not a live Claude/Pega replay.

## Source facts

The original RUT contains eight output/composite producers relevant to this regression:

- R1 `1.1.1` SET `Param.ExitCode` (invalid-city exit)
- R2 `1.2` SET `Param.AddressIndex`
- R3 `1.3.1` `APPEND_AND_MAP_TO CustomerCommunication.Addresses`
- R4 `1.3.1.1` SET mapped `pyCity`
- R5 `1.3.1.2` SET mapped `pyPostalCode`
- R6 `1.3.1.3` SET mapped `pyStreet`
- R7 `1.3.1.4` SET `Param.StreetName`
- R8 `1.4.1` SET postal-stop `Param.ExitCode`

The simulation verifies all eight step paths and operations directly against the bad conversation RuleJSON before proceeding.

## Coverage result

The three recorded bad-run witnesses cover the atomic outcomes but do not satisfy required joint COV `C7 = addrIndexPositive + postalNoStop`.

Therefore the original three-witness set is rejected at WITNESS commit.

A fourth feasible witness is constructed from values already present in the bad conversation corpus: keep the valid Postal first address from W1 and use non-stop second postal code `1111AA`. The resulting four semantic paths are:

1. invalid-city exit;
2. append + postal-no-stop;
3. no-append + no-stop;
4. append + postal-stop.

The full required COV census is then covered.

## EXEC / FREEZE result

4 scenarios x 8 PDEF = 32 explicit EXEC rows.

FREEZE has exact set equality between `EXEC=executes` and executing PRODUCER rows. An attempted bad-run collapse in which parent R3 exists but child R4/R5/R6 do not is rejected by this equality.

## Known-index assertion branch

If existing list reasoning proves append index 1, both append scenarios contain three independent named-page Property outputs:

- `CustomerCommunication.Addresses(1).pyCity`
- `CustomerCommunication.Addresses(1).pyPostalCode`
- `CustomerCommunication.Addresses(1).pyStreet`

Each has `basePage=CustomerCommunication`, `page=CustomerCommunication`, and its own child `sourceRefs` id.

## Unknown-index assertion branch

If the append index genuinely remains unknown, the three child outputs still remain independent. They become three List assertions:

- List `page=CustomerCommunication`, `.Addresses`, child `.pyCity`;
- List `page=CustomerCommunication`, `.Addresses`, child `.pyPostalCode`;
- List `page=CustomerCommunication`, `.Addresses`, child `.pyStreet`.

Thus unknown index can no longer collapse three mapped writes to a single arbitrary `.pyCity` assertion and cannot rebase the assertion to `RunRecordPrimaryPage`.

## Explicit rejection of the observed bad shapes

R35 rejects each defect independently:

1. **3 scenarios only** -> missing C7 coverage obligation, WITNESS gate fails.
2. **parent append replaces child producers** -> FREEZE producer set-equality fails.
3. **single `.pyCity` List represents three mapped children** -> R5/R6 missing from OUTPUT.sourceRefs, lineage gate fails.
4. **List page omitted** -> OUTPUT.basePage is `CustomerCommunication` but DECISION effective page becomes primary, page-context gate fails.

## Remaining observation

**Low — EXEC_MATRIX_SCALING.** EXEC is O(number of scenarios × number of PDEF). This regression is only 32 rows. Large RUTs should be monitored for prompt/tool payload pressure. No current tool/prompt contract provides evidence of a hard limit, so no correctness change is justified now.

## Simulation result

PASS. No Critical, High or Medium issue was found by this simulation.
