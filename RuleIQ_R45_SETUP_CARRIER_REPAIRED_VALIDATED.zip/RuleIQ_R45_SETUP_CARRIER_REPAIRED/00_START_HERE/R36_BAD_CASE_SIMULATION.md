# R36 — Bad-case regression simulation

This document applies the R36 transition/lineage rules to the two recorded failure families. It is a deterministic static simulation, not a fresh live Pega run.

## 1. PXCONV-184052 — silent planning/transfer loss

Recorded MAP contains six required outcomes:

```text
O1 cityInvalid
O2 cityValid
O3 idxPositive
O4 idxNonPositive
O5 postalStop
O6 postalNoStop
```

The recorded MAP contains atomic COV only for O2, O3 and O5. R36 requires exactly one atomic COV for every R OUTCOME.

Result:

```text
R_OUTCOME_ATOMIC_COV_MISMATCH
owner=MAP
```

MAP must be rebuilt before WITNESS. The recorded one-scenario downstream state cannot be accepted.

If MAP COV is complete but WITNESS omits any COV instead, the next gate fails:

```text
set(MAP.COV.id) != set(WITNESS.RESOLVE.coverageId)
code=PLAN_RESOLUTION_GAP
owner=WITNESS
```

Thus both failure locations are explicit and no planned obligation can disappear silently.

## 2. PXCONV-184019 — producer/assertion/page loss

R36 preserves the R35 producer-safety intent with a smaller representation:

```text
PDEF -> final PATH -> EFFECT -> OUTPUT -> DECISION -> BUILD
```

The following observed bad shapes remain independently illegal:

1. **Composite parent substitutes child writes**  
   An executing mapped scalar child is in PATH.E and therefore requires its own EFFECT. Parent append cannot satisfy the child obligation.

2. **Only one child assertion represents several mapped writes**  
   Each executed RUT-visible child effect contributes its own candidate lineage. Missing child OUTPUT is caught by AUDIT Gate E.

3. **Named-page List/Property loses `CustomerCommunication`**  
   EFFECT target is fully rooted. OUTPUT freezes `basePage=CustomerCommunication`; DECISION must reconstruct the same full target. Primary-page fallback is a PAGE_MISMATCH.

4. **Source list index used as append target index**  
   Source/target coordinates are independent. Append target index comes only from proven target-list prior count. Unknown remains unknown and cannot be fabricated.

## Result

Static regression design: PASS. No Critical/High/Medium issue remains in the R36 contract for these recorded failure shapes.
