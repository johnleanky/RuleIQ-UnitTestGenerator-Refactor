# R30 Occurrence-Driven RuleCrawler Validation — 2026-09-16

## Runtime change

R30 replaces R29's separate `CANDIDATE_HOLDERS` / `REQ=holder::KEY` planning layer with occurrence-driven request projection:

`scan evidence -> D occurrence(src.holder) -> READY -> pyItemRuleId=that occurrence holder -> grouped InterestedRules`.

`RuleJSON.pxRuleReferences[]` is now stated positively as identity/materialization lookup for already scan-created D occurrences. It does not define the crawl inventory. Two canonical examples anchor transitive holder propagation and metadata-only references.

RUF remains exact four-key materialization from the chosen occurrence holder's matching source row. Non-RUF remains exact five-key materialization. OUT/ACT return to canonical KEY census; preCall separately verifies physical `pyItemRuleId` equals the chosen D occurrence's source holder.

## Scope

Runtime files changed from R29:
- `01_PROMPTS/ScenarioAuthor_SystemPrompt.txt`
- `02_KNOWLEDGE_AREAS/Rule-Utility-Function_KnowledgeArea_REFERENCE.txt` (terminology alignment only)

Unchanged runtime artifacts:
- UnitTestGenerator prompt
- Validator prompt
- Rule-Obj-When, Rule-Obj-Model, Rule-Declare-Pages, Rule-Declare-DecisionTable KnowledgeAreas
- all four target schemas/examples
- all tool contracts

## Static/adversarial checks

25/25 PASS:
- occurrence holder directly drives `pyItemRuleId`;
- raw `pxRuleReferences[]` has lookup/materialization role after scan-created D;
- `CANDIDATE_HOLDERS` and `REQ=holder::KEY` removed;
- OUT/ACT are KEY-based again;
- transitive example groups C under A and D/E under B;
- metadata example requests only scan-discovered A/C even when raw metadata contains A/B/C/D;
- duplicate KEY retry chooses the next occurrence source after prior holder KEYONLY/MISSING;
- valid four-key RUF shape accepted;
- observed RUF shape with extra `pxRuleClassName:""` rejected;
- all four JSON contract/example files parse;
- 6/6 Standard/MultiInput example candidates remain Draft-2020-12 schema-valid.

## Token impact

ScenarioAuthor word proxy: R29 `9502` -> R30 `9332` (`-170`, about `-1.8%`).
RUF KnowledgeArea word proxy: R29 `888` -> R30 `892` (`+4`).

No fixtures, hashes, SHA/checksum/fingerprint gates, new runtime tools, or wire fields were added.

## Not verified

Static prompt/contract validation does not prove Claude Opus 4.8/Pega live behavior. Live replay of `PrepareCustomerCommunication` is still required. Capture scan-created D occurrences, their `src.holder`, `_DWLPlan.OUT/ACT`, and final `InterestedRules[]`; verify raw metadata-only references do not enter READY unless scan evidence creates an occurrence.
