# R24 KnowledgeArea Compatibility Note

R24 adds verbatim reference copies of Rule-Obj-Model, Rule-Declare-Pages and Rule-Declare-DecisionTable KnowledgeAreas. Runtime prompts/contracts are unchanged from R23.

## Compatibility summary
- Rule-Declare-Pages: compatible with current ScenarioAuthor Data Page acquisition/simulation boundary and caller-binding model.
- Rule-Obj-Model: runtime context semantics (current/target/source, UPDATE_PAGE, APPEND_AND_MAP_TO, Primary/Top) align with R22/R23 page-provenance rules. KT.29 leaks target-test JSON terms (pySetupPages/pyParameters/pyPagesAndClasses) across the Author/Generator boundary and must not be interpreted as permission for ScenarioAuthor to construct Candidate/RuleCode.
- Rule-Declare-DecisionTable: semantic DTM/DTA/DTE model broadly matches ScenarioAuthor, but KDT.6/KDT.11/KDT.12 contain final RuleCode/candidate inspection or repair requirements. Current ScenarioAuthor simultaneously forbids reading/constructing Candidate/RuleCode while requiring KDT.4-KDT.12, so this is a real boundary conflict requiring a separate design change before those target-facing clauses can be executed literally.
- Rule-Obj-Model KT.2 lexicographic pyPropertyStepId ordering is not contradicted by the current prompt, therefore it would become effective guidance; it should be runtime-verified because it materially controls execution order.

No semantic prompt change is made in R24. This release only adds the reference sources and records the compatibility findings.
