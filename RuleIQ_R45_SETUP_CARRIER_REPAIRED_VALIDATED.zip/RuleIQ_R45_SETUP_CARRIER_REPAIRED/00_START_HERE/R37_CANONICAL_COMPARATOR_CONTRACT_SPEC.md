# R37 — ScenarioAuthor Canonical Comparator Contract

## Scope

R37 changes only `01_PROMPTS/ScenarioAuthor_SystemPrompt.txt` at runtime. Generator, Validator, Knowledge Areas, target schemas/examples and tool contracts remain unchanged.

## Problem

R36 allowed Standard Projection comparators to be arbitrary nonempty strings. A live successful trace persisted `"Is equal to"`, while the target Pega comparator enum uses the exact label `"Is Equals To"`. This creates downstream representability ambiguity.

## Contract

ScenarioAuthor owns comparator canonicalization.

1. `DECIDE` selects one exact canonical comparator.
2. Committed `DECISION` and `UnitTestProjectionV3` may contain only kind-specific canonical labels.
3. Projection copies the comparator exactly from `DECISION.decision`; no downstream Author normalization occurs.
4. Pre-projection and source-contract validation reject noncanonical comparators and return to DECIDE rather than persisting them.

### Property / Param / List item

`Is Equals To | IS Not Equals TO | Exists | Not exists | Starts With | Ends With | Contains | Is In | Is Not In | Is Empty | Is Not Empty | has errors | has no errors | has error with message | has error message that contains | Is True | Is False`

### Page

`Exists | Not exists`

### ResultCount

`Is Equals To | IS Not Equals TO | Is Less Than | Is Greater Than | Is Less Than Or Equal To | Is Greater Than Or Equal To`

## Required behavior

For equality on `Param.AddressIndex`, the Author must persist:

```json
{"kind":"Param","path":"Param.AddressIndex","comparator":"Is Equals To","expected":"-1"}
```

The following are invalid persisted comparator values:

```text
Is equal
Is equal to
Equals
=
```

No R36 MAP/WITNESS/FREEZE/PATH/EFFECT/AUDIT behavior changes in R37.
