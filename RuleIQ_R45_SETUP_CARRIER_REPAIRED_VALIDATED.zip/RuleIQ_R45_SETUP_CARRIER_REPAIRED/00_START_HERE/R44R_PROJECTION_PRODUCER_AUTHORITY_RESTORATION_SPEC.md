# R44R Projection Producer Authority Restoration — Specification

Baseline: R43. R44 is explicitly non-authoritative evidence only.

Architecture invariant: `AUTHOR GUARANTEES -> authoritative ProjectionV3 -> GENERATOR TRUSTS/TRANSLATES -> GENERATOR VALIDATES TARGET/FIDELITY ONLY`. The complete ProjectionV3 interface remains local in both ScenarioAuthor and Generator, but semantic validation is intentionally one-sided: ScenarioAuthor owns all producer semantic/cross-field correctness before persistence. Generator may check only Invocation/Memory/JSON/readability/correlation needed for consumption plus target representability, target compilation, Candidate fidelity and Validator lifecycle. Validator checks Candidate schema, deterministic Projection→Candidate fidelity and candidate-internal target correctness; never Projection business truth.

No Projection schema, Knowledge Area, target JsonSchema/Example, Memory/tool contract, ScenarioCompiler phase, pre-projection gate, or PREPARE/PERSIST/GENERATE orchestration is changed.
