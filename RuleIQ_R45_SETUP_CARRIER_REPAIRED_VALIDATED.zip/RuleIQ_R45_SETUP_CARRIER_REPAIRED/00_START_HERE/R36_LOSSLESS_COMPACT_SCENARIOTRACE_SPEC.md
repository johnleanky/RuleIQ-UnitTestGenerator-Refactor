# R36 — Lossless Compact ScenarioTrace with End-to-End Audit and Self-Repair

## Objective

R36 is a conservative ScenarioAuthor refactor. It does not redesign the successful MAP/planning logic or downstream Generator/Validator contracts. It fixes the observed loss of semantic state between ScenarioTrace phases and reduces repeated execution-state serialization.

The governing rule is:

> Anything committed by an upstream planning/semantic phase must either be carried forward explicitly or receive an explicit terminal disposition with grounded evidence. Silent disappearance is invalid.

The six phases remain:

```text
MAP -> WITNESS -> FREEZE -> DECIDE -> BUILD -> AUDIT
```

The existing generation control plane remains authoritative: `PHASE`, `HEAD`, `BASE`, `INVALIDATE`, `COMMIT`, epoch and immutable generation ids.

## Runtime scope

Only `01_PROMPTS/ScenarioAuthor_SystemPrompt.txt` changes at runtime.

Unchanged runtime files:

- `01_PROMPTS/UnitTestGenerator_SystemPrompt.txt`
- `01_PROMPTS/Validator_SystemPrompt.txt`
- all retained Knowledge Areas
- all target contracts/examples
- all tool contracts

Original `Rule-Obj-When` keeps its existing dedicated semantic path. Standard `RESOLVE/PATH/EFFECT` is not retrofitted into that path.

## 1. MAP stays the planning authority

Standard MAP continues to own:

- `OUTCOME` — semantic outcomes;
- `COV` — immutable coverage obligations;
- `PDEF` — immutable original-RUT producer census.

WITNESS is not allowed to decide which MAP COV obligations are worth keeping.

A mechanical planning-integrity gate is added before WITNESS commit and repeated in AUDIT:

```text
set(R OUTCOME ids)
==
set(single orderedOutcomeId from atomic COV rows)
```

There must be exactly one atomic COV for every `OUTCOME state=R`, and none for non-R outcomes. This catches the real `PXCONV-184052` failure where six required outcomes existed but only three received atomic COV rows.

## 2. MAP -> WITNESS is explicit through RESOLVE

New Standard WITNESS row:

```text
RESOLVE|<coverageId>|<state:REALIZED|BLOCKED>|<scenarioId-or->|<reasonCode-or->|<proof-or->
```

Every active MAP COV id occurs exactly once.

### REALIZED

`REALIZED` references one concrete same-generation Scenario whose actual RUT execution satisfies the COV.

One Scenario may realize multiple compatible COVs.

### BLOCKED

`BLOCKED` is allowed only for a grounded terminal blocker already represented by the existing canonical semantic/dependency vocabulary.

It requires:

- `scenarioId=-`;
- a canonical terminal reason code;
- shortest factual proof.

Complexity, low confidence, duplicate-looking behavior, convenience minimization, inability to find values, or unresolved/nonterminal work are not blockers.

`BLOCKED` records the fate of the planned COV; it does not suppress existing informational/NotTestable handling where that handling is otherwise required.

### Hard transfer gate

```text
set(MAP.COV.id) == set(WITNESS.RESOLVE.coverageId)
```

No missing, extra or duplicate COV transition is legal.

`SCENARIO.covers` remains the actual executed OUTCOME set. COV-to-Scenario membership is owned only by RESOLVE; no duplicate `coverageIds` field remains in SCENARIO.

## 3. WITNESS EXEC rows become PATH

Standard WITNESS no longer emits one `EXEC` row per Scenario x producer.

It emits one row per Scenario:

```text
PATH|<scenarioId>|E=<ordered producerIds|->|S=<ordered producerIds|->|U=<ordered producerIds|->
```

Where:

- `E` = executes;
- `S` = skipped;
- `U` = unknown.

The three partitions are pairwise disjoint and their union equals the complete active MAP PDEF census exactly. Producer order follows PDEF tree order.

Optional sparse evidence is represented by:

```text
WHY|<scenarioId>|<producerId>|<reasonCode>|<proof>
```

WHY is required only for unknown or exceptional skip/non-effect evidence that cannot be mechanically reconstructed from controlling execution/termination. It never substitutes for PATH completeness.

## 4. WITNESS -> FREEZE preserves Scenario identity

Within one active generation chain:

```text
set(WITNESS.SCENARIO.id) == set(FREEZE.SCENARIO.id)
```

FREEZE may not silently delete, merge, replace or renumber Scenarios.

If final replay proves the witness invalid or discovers a terminal blocker, FREEZE does not hide the Scenario. It invalidates WITNESS and returns the issue to the owning phase, which rebuilds RESOLVE/Scenario state and all downstream generations.

## 5. FREEZE owns a fresh final PATH

FREEZE emits its own PATH from final replay.

WITNESS PATH is historical; it is never copied as final execution authority.

The same complete PDEF partition rules apply.

## 6. Standard PRODUCER rows become EFFECT

MAP PDEF already owns static producer identity, path, operation and symbolic source/target. FREEZE therefore persists only new runtime facts:

```text
EFFECT|<scenarioId>|<producerId>|<resolvedSource-or->|<resolvedTarget-or->|<beforeState-or->|<afterState-or->|<writeIndex:n|unknown|->|<reason-or->
```

Execution state comes only from final FREEZE PATH. Static operation metadata comes only from PDEF.

For every executed effect-bearing PDEF there is exactly one EFFECT, including:

- scalar writes;
- Param writes;
- structural Page/List mutation;
- composite parent mutation;
- every executed modifying child of a composite operation.

A parent never substitutes for child EFFECT rows.

### Page, index and value invariants

- Source and target runtime coordinates are independent.
- Source index never determines target index.
- An append target index is `prior target-list count + 1` only when prior count is proven; otherwise it stays unknown.
- Unknown target index never removes a child EFFECT and never permits a fabricated indexed assertion.
- Every non-Param resolved target remains fully runtime-rooted, preserving named pages such as `CustomerCommunication`.
- Exact scalar/Param `afterState.value` is the already-frozen final Pega clipboard lexical value; DECIDE copies it and never recasts it.

## 7. DECIDE stays the assertion authority

R36 deliberately does not aggressively compress Standard DECIDE.

DECIDE continues to own:

- `OUTPUT` — complete observable candidate census;
- `DECISION` — exactly one `ASSERT` or legal `OMIT` per OUTPUT.

The new input lineage is:

```text
MAP.PDEF + FREEZE.SCENARIO + FREEZE.PATH + FREEZE.EFFECT
    -> OUTPUT -> DECISION
```

Required equality:

```text
set((OUTPUT.scenarioId, OUTPUT.claimId))
==
set((DECISION.scenarioId, DECISION.claimId))
```

Named page, index and value are provenance-locked from EFFECT through OUTPUT into the normalized decision.

## 8. BUILD remains mechanical

BUILD has no semantic decision authority.

Normalized physical assertions must equal exactly the ordered DECIDE decisions with `disposition=ASSERT`; no DECIDE OMIT may materialize.

Scenario membership is unchanged from FREEZE.

## 9. AUDIT becomes an end-to-end lineage audit

Standard AUDIT now references the full active chain:

```text
BASE|MAP,WITNESS,FREEZE,DECIDE,BUILD
```

AUDIT is fail-closed and checks transitions in order:

1. **MAP -> WITNESS** — atomic R-OUTCOME/COV integrity, exact COV/RESOLVE census, REALIZED truth, BLOCKED evidence.
2. **WITNESS -> FREEZE** — Scenario-id equality and continued realization.
3. **PDEF -> PATH** — complete disjoint producer state partition and independent final replay equality.
4. **PATH -> EFFECT** — exact required effect census and source/target/before/after/index/value fidelity.
5. **final state -> OUTPUT** — complete observable candidate census, child lineage and page ownership.
6. **OUTPUT -> DECISION** — exact id census and assertion representation/value/page/index fidelity.
7. **DECISION -> BUILD** — exact normalized physical materialization and unchanged Scenario mapping.

AUDIT additionally preserves existing setup/SIM/DP_SIG/DPA and no-later-mutation checks.

## 10. AUDIT FAIL produces deterministic REPAIR

New row:

```text
REPAIR|<owner:CRAWL|MAP|WITNESS|FREEZE|DECIDE|BUILD>|<code>|<affectedIds>|<action>
```

Standard AUDIT:

- PASS: no REPAIR;
- FAIL: exactly one REPAIR.

AUDIT detects and locates the earliest owner; it never patches state itself.

Owner priority:

```text
CRAWL -> MAP -> WITNESS -> FREEZE -> DECIDE -> BUILD
```

Examples of stable failure codes include:

- `PLAN_RESOLUTION_GAP`
- `INVALID_BLOCKER`
- `SCENARIO_LOST`
- `PATH_STATE_MISMATCH`
- `EFFECT_MISSING`
- `EFFECT_INDEX_MISMATCH`
- `OUTPUT_MISSING`
- `PAGE_MISMATCH`
- `DECISION_MISSING`
- `BUILD_ASSERTION_MISSING`

## 11. Automatic repair loop

Before `PREPARE_ALL`, the same ScenarioAuthor executes the REPAIR directive:

1. invalidate the earliest owning generation, or return to CRAWL;
2. increment epoch;
3. clear the owner and every downstream HEAD field;
4. create a fresh owner generation;
5. rebuild all downstream generations;
6. run AUDIT again.

Failed AUDIT generations remain immutable transcript evidence.

Loop state is not hidden model memory. Repair count and prior signatures are reconstructed only from actual committed current-RUT AUDIT/REPAIR rows.

Maximum repair cycles: 5.

`REPAIR_NO_PROGRESS` is terminal when the same `(owner,code,affectedIds)` recurs after rebuild and the replacement owner generation has the same canonical phase-owned semantic rows as the invalidated owner generation after ledger decoding, excluding control rows/generation ids.

If cycle 5 does not reach PASS: `AUDIT_REPAIR_LIMIT`.

Only the active `AUDIT=PASS` generation may enter `PREPARE_ALL`.

## 12. Closed Standard ScenarioTrace row sets

```text
MAP     : PHASE,HEAD,BASE,OUTCOME,COV,PDEF,COMMIT
WITNESS : PHASE,HEAD,BASE,RESOLVE,SCENARIO,PATH,[WHY],COMMIT
FREEZE  : PHASE,HEAD,BASE,SCENARIO,PATH,EFFECT,COMMIT
DECIDE  : PHASE,HEAD,BASE,OUTPUT,DECISION,COMMIT
BUILD   : PHASE,HEAD,BASE,GROUP,LOCATION,COMMIT
AUDIT   : PHASE,HEAD,BASE,AUDIT,[REPAIR],COMMIT
```

`[WHY]` means zero or more optional rows in the defined position. `[REPAIR]` means exactly one row on Standard AUDIT FAIL and zero on PASS.

## 13. Non-goals

R36 does not:

- redesign the coverage adapter;
- replace OUTCOME/COV with a new planning ontology;
- remove the generation/invalidation control plane;
- introduce fixture/patch compression;
- shorten producer ids;
- compress DECIDE aggressively;
- change Generator/Validator contracts;
- alter target schemas/examples;
- retrofit Standard RESOLVE/PATH/EFFECT into original Rule-Obj-When.

## 14. Expected efficiency

The successful R35 `PXCONV-184033` trace is 17,171 characters across six ScenarioTrace calls.

A deterministic R36 serialization estimate using the same semantic facts is 14,324 characters, a 16.6% reduction. Most savings come from `EXEC -> PATH` and `PRODUCER -> EFFECT`; DECIDE remains intentionally verbose for safety.

This is an estimate from the recorded R35 conversation, not a fresh live Pega execution of the R36 prompt.
