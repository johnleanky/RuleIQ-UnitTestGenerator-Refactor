# R37 Validation — ScenarioAuthor Canonical Comparator Contract

Date: 2026-09-19

## Final result

```text
Critical 0
High     0
Medium   0
```

Validation is static/contract/historical-trace validation. A fresh live Pega/model replay with the R37 prompt has not been executed in this environment.

## Stage validation

### Stage 0 — baseline

Confirmed R36 Standard source grammar allowed `Property/Param/List/ResultCount` comparator as arbitrary nonempty strings. PASS.

### Stage 1 — canonical domains

Added `PROPERTY_COMPARATORS`, `PAGE_COMPARATORS`, and `RESULTCOUNT_COMPARATORS` to ScenarioAuthor. Each set was programmatically compared with the unchanged selected target schema enum and matched exactly. PASS.

### Stage 2 — DECIDE ownership

DECIDE now freezes one canonical comparator after assertion-kind selection. Aliases/synonyms/case variants are illegal in committed DECISION/Projection state. PASS.

### Stage 3 — exact Projection copy

Projection materialization copies comparator exactly from `DECISION.decision` and may not normalize it during packing/materialization. PASS.

### Stage 4 — closed Projection grammar

Property/Param/List use `PROPERTY_COMPARATORS`; Page uses `PAGE_COMPARATORS`; ResultCount uses `RESULTCOUNT_COMPARATORS`. `"Is equal to"` is rejected; `"Is Equals To"` is accepted. PASS.

### Stage 5 — pre-persistence gates

Pre-projection validation rejects any noncanonical DECISION comparator. Projection reconciliation requires exact parsed string equality with DECISION and independent kind-domain membership. PASS.

Independent review found wording ambiguity in `byte-exact after JSON parsing`; corrected to exact string equality. Re-review PASS.

### Stage 6 — stale alias cleanup

No persisted-comparator examples remain using `Is equal`, `Is equal to`, `Equals`, or `=`. General source-contract wording was also tightened so comparator is not described as an arbitrary nonempty string. PASS.

Independent review found prompt growth slightly above the prior 2% hygiene threshold. Wording was compacted without removing invariants. Final growth from R36 is about 1.75%. Re-review PASS.

## Historical regression

Comparator census from recorded traces:

```text
PXCONV-184033 : Is equal to
PXCONV-184019 : Is Equals To
PXCONV-184052 : Is Equals To
```

`PXCONV-184033` therefore reproduces the exact lexical drift R37 is designed to prevent. Its equality assertions must canonicalize to `Is Equals To`; all other Scenario semantics remain unchanged.

## Scope isolation

Direct byte comparison confirmed no runtime changes in:

- `UnitTestGenerator_SystemPrompt.txt`
- `Validator_SystemPrompt.txt`
- Knowledge Areas
- target schemas/examples
- tool contracts

Only `ScenarioAuthor_SystemPrompt.txt` changes at runtime.

## Final acceptance checks

- canonical domains exactly equal selected target enum: PASS
- `Param comparator="Is equal to"`: REJECT
- `Param comparator="Is Equals To"`: ACCEPT
- Page `Is Equals To`: REJECT
- Page `Not exists`: ACCEPT
- ResultCount `Is Greater Than`: ACCEPT
- Property `Is Greater Than`: REJECT
- DECIDE owns comparator: PASS
- Projection exact-copy rule: PASS
- no downstream Author normalization: PASS
- historical trace regression: PASS
- runtime scope isolation: PASS
- prompt integrity/truncation checks: PASS
