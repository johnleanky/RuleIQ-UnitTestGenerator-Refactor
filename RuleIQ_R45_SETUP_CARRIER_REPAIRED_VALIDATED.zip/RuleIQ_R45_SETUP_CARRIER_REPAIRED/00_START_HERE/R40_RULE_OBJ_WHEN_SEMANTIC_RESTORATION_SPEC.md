# Rule-Obj-When Semantic Restoration & Current-Architecture Integration
## Technical Specification for independent review

**Status:** SPECIFICATION ONLY — no runtime changes are authorized by this document.  
**Purpose:** invalidate the unproven Rule-Obj-When reconstruction introduced during R39D D1 and replace it with a source-traceable, token-efficient adaptation of the Rule-Obj-When semantics from the old `Main_Agent_Prompt.txt` into the current ScenarioAuthor / Projection / Generator architecture.

---

## 1. Non-negotiable objective

The next implementation MUST NOT “repair” R39D D1 by further interpretation of the D1 text.

The implementation must instead follow this chain:

```text
OLD MAIN PROMPT Rule-Obj-When semantic obligations
        ↓ extract without storage assumptions
SEMANTIC OBLIGATION INVENTORY
        ↓ map one obligation at a time
CURRENT R39 architecture owners / phases / source contracts
        ↓ only after mapping is proven
TOKEN-OPTIMIZED CURRENT PROMPT TEXT
```

R39D D1 is **not semantic authority**. Any R39D D1 statement may survive only if it is independently re-derived from the old Main Prompt plus the current architecture.

No statement may be retained because it “looks reasonable”, because an earlier assistant wrote it, or because it existed in R39D validation artifacts.

---

## 2. Source authority and provenance

### 2.1 Primary semantic source: old Main Prompt

Use `RuleIQ/Main_Agent_Prompt.txt` from `RuleIQ (2)(1).zip` as the source for the old Rule-Obj-When behavior to be restored/adapted.

Primary source ranges:

| Source range | Semantic subject |
|---|---|
| lines ~20–27 | reserved top-level system-page seed ban |
| lines ~29–96 | MultInpComb applicability, simulation grouping, cardinality, row synchronization |
| lines ~581–598 | `pyLogic` transcription / complete OR-clause evaluation / DWL scan completeness |
| lines ~1532–1545 | Scenario Compiler INVENTORY → WITNESSES → FROZEN → AUDIT BASE → AUDITED |
| lines ~1536–1545 | Rule-Obj-When coverage adapter, actual execution, owner/covers, deterministic reduction, independent audit |
| lines ~1579–1709 | MultInpComb logical/physical structure and simulation grouping |
| lines ~1710–1731 | DecisionResult dependency closure lock |
| lines ~1732–1737 | coverage + row-shape lock |
| lines ~1738–1752 | empty input semantics |
| lines ~1753–1785 | primary-relative path / namespace preservation |
| lines ~1786–1830 | final grouping, row-shape, row-number / trace synchronization validation |

The old prompt’s storage names (`T`, `S`, `I/W/F/B/A`, RuleCode, UnitTestRules) are **not** automatically part of the new design. Extract the semantic obligation first; map storage separately.

### 2.2 Current architecture source

Use the latest current architecture as the representation boundary:

- `ScenarioAuthor_SystemPrompt.txt`
- `UnitTestGenerator_SystemPrompt.txt`
- current `UnitTestProjectionV3` source contract
- current target MultInpComb schema/example
- current Knowledge Areas only for Pega rule interpretation, not for inventing ScenarioTrace semantics.

### 2.3 Explicitly non-authoritative sources

The following are not allowed as semantic provenance for the restoration:

- R39D D1 “self-contained When semantics” text;
- R39D validation statements claiming that D1 is correct;
- inferred meanings of `legacy`, `existing`, `unchanged`, or similar historical references;
- model memory of earlier RuleIQ versions.

They may be used only as search pointers to locate a current-architecture seam that then must be independently justified.

---

## 3. Required baseline strategy

### 3.1 Preferred runtime baseline

Use **R39C as the current-architecture baseline**, because R39D D1 is explicitly invalidated. R39C Rule-Obj-When wording is not automatically semantic authority either; it supplies only the pre-D1 architecture/seams and must still pass the old→current mapping.

Reapply only independently verified non-D1 R39D consistency improvements, such as:

- section/reference cleanup;
- validation-artifact cleanup;
- harmless locality/formatting improvements;
- terminology normalization not coupled to D1.

Do not “subtract D1 from R39D by intuition”. Starting from R39C avoids leaving fragments of the unsupported reconstruction.

### 3.2 If implementation must start from R39D

Before new Rule-Obj-When work:

1. Identify every D1-created or D1-redefined When statement.
2. Mark each `INVALIDATED_PENDING_REDERIVATION`.
3. Restore its pre-D1 R39C semantics or remove its normative effect.
4. Run a semantic review proving that no D1-only rule remains authoritative.
5. Only then begin the old→new adaptation.

---

## 4. Semantic obligation inventory

Every old Rule-Obj-When obligation must receive one terminal mapping status:

- `DIRECT_CURRENT` — current architecture already preserves it faithfully;
- `ADAPT_REQUIRED` — old behavior is required but must be expressed in current representation;
- `TARGET_OWNED` — old rule is target/RuleCode mechanics now owned by Generator/schema, not ScenarioAuthor;
- `CURRENT_EXTENSION` — current architecture adds a behavior not sourced from old Main Prompt; it needs independent justification and must not be presented as restored legacy semantics;
- `GAP` — no safe mapping exists; block implementation or register an architectural finding.

No obligation may remain `UNMAPPED`.

### 4.1 Detailed obligation map

| ID | Old semantic obligation | Old source | Current seam | Initial classification | Required action |
|---|---|---|---|---|---|
| W01 | MultInpComb applies only when original RUT is Rule-Obj-When; nested When does not switch workflow | ~29–31 | §1.4 / §4 grouping / Projection mode | DIRECT_CURRENT | Keep one concise applicability firewall. |
| W02 | Reserved top-level system pages cannot be seeded/input roots; block coverage only if every replayable carrier requires banned root | ~20–27 | current ROOT/setup rules | DIRECT_CURRENT | Preserve current compact rule; validate carrier/blocker semantics. |
| W03 | Copy `pyLogic` verbatim; tokenize all top-level OR clauses; evaluate all; no short-circuit omission | ~581–598 | §3.2 RX | DIRECT_CURRENT | Keep compact imperative form. |
| W04 | Every executable operand discovered during When scan enters DWL before closure | ~598 onward | §2 dependency discovery | DIRECT_CURRENT/PARTIAL | Verify exact DWL completeness; add only missing gate, not a second ledger. |
| W05 | Coverage inventory is original-RUT-owned: final TRUE/FALSE + both MC/DC sides for every atom; masked atom needs E proof; no Cartesian expansion | ~1532–1537 | MAP `OUTCOME` | ADAPT_REQUIRED | Define canonical When OUTCOME adapter from old `T`; do not invent dependency-owned coverage. |
| W06 | One MC/DC pair side cannot be excluded alone; pair exclusion requires proof for the pair; fixed truth vector is part of obligation | ~1536 | OUTCOME.constraint | ADAPT_REQUIRED | Preserve pair id/side/atom/fixed truth vector in current OUTCOME constraint semantics. |
| W07 | Witnesses are deterministic coverage-complete executions; invalid witness does not erase requirement; owner/covers derive only from complete actual original-When execution | ~1539 | WITNESS `SCENARIO` | ADAPT_REQUIRED | Map old `S` to SCENARIO; no desired-coverage inference. |
| W08 | Dependency variants do not create new coverage rows after requirement is already covered | ~1539 | MAP/WITNESS boundary | ADAPT_REQUIRED | Add concise “dependencies select witnesses, never create coverage obligations” rule. |
| W09 | FREEZE performs deterministic irredundant reduction; proposed removals require regroup/rebuild/re-execution; preserve all R + MC/DC/joint/shape constraints; fixed point; confidence/testability cannot change membership | ~1541 | FREEZE | ADAPT_REQUIRED | Restore algorithm explicitly in current terms. This is a major missing/weak area. |
| W10 | Exact duplicate executions may merge only if coverage remains represented; final Scenario identity is assigned only after accepted reduction | ~1541 | FREEZE | ADAPT_REQUIRED | Define merge condition and stable final membership. |
| W11 | Packaging cannot change semantic inputs/setup/cells/simulation/execution/coverage; semantic difference returns upstream | ~1543 | grouping/BUILD | DIRECT_CURRENT/PARTIAL | Preserve strict packaging-only boundary. |
| W12 | AUDIT is independent: redo forward/reverse census/classification and re-execute serialized scenarios; rebuild owner/covers; require coverage completeness, R/B/U/E correctness, MC/DC constraints, bijection and irredundancy | ~1545 | AUDIT | ADAPT_REQUIRED | Strengthen current When AUDIT predicates from old A semantics. |
| W13 | Scenario grouping is by complete runtime-relevant simulation requirement; equal requirements share a group; different requirements never share | ~32–91, ~1609+ | §3.5 SIM + §4.5 grouping | ADAPT_REQUIRED | Define group key using current canonical SIM representation, not legacy target fields. |
| W14 | `NO_SIMULATION` is the key when no simulation is required | old grouping rules | §4.5 | DIRECT_CURRENT | Preserve. |
| W15 | Group count equals distinct simulation-key count for executable When rows; ordinary input/result differences do not split groups | ~92–96, ~1579+ | §4.5 | ADAPT_REQUIRED | Preserve, then compose with any current execution-class rule as a separately justified current extension. |
| W16 | Scenario↔Decision row bijection and stable local row numbering; row trace/ids synchronize after final grouping | ~96, ~1786+ | grouping/BUILD/Projection | ADAPT_REQUIRED | Preserve semantic 1:1 index correlation without restoring legacy RuleCode ledger. |
| W17 | All rows in a group have identical input-column signature/order; input cells precede one Result | ~1732+, ~1786+ | §5.2 + Projection row grammar | ADAPT_REQUIRED | Map legacy DecisionColumnSignature to current ordered `(path,valueType)` source signature. |
| W18 | Empty input means initialized carrier with empty property value, not absent parent; keep cell and omit expected value | ~1738–1752 | §5.2 + Projection + Generator | DIRECT_CURRENT | Keep micro-example / explicit invariant. |
| W19 | Preserve original namespace, leading dot, indices, group keys, casing, root; embedded item class never changes input root | ~1753–1785 | §5.2 | DIRECT_CURRENT/PARTIAL | Keep explicit path lock. |
| W20 | Simulated Data Page roots are not MultInpComb writable input columns; their runtime values live in simulation payload | ~1610+ | §3.5 + §5.2 | ADAPT_REQUIRED | Define exclusion from frozen column set from current frozen SIM/DP identity. |
| W21 | DecisionResult is exact Boolean only after controlling dependency chain is terminal and actual complete When execution produces known result; missing critical dependency cannot be guessed | ~1710–1731 | DWL + WITNESS + §5.2 | ADAPT_REQUIRED | Add explicit Result eligibility gate; terminal blocker leads to omission/informational flow, never guessed boolean. |
| W22 | Confidence/testability never remove, collapse, merge or suppress required coverage scenarios | repeated old MultInpComb/Freeze rules | FREEZE + §5.3 | DIRECT_CURRENT/PARTIAL | State once at FREEZE/testability boundary. |
| W23 | Legacy target details: `pyAllowMultipleInputCombinations`, `rowLevelPage`, Result cell target fields, display labels, target row nesting | ~1579+ | Generator + MultInpComb schema | TARGET_OWNED | Verify Generator/schema mapping; DO NOT copy target mechanics back into ScenarioAuthor. |
| W24 | Legacy `B` phase strips owner/covers before independent audit to prevent reuse | ~1543 | BUILD→AUDIT boundary | ADAPT_REQUIRED | Do not create a new row just to mimic B. Instead require AUDIT to recompute coverage from original RUT + materialized rows and forbid trusting frozen owner/covers as audit proof. |
| W25 | Legacy per-S projection must be rebuilt from final execution after reduction; rekeying witness values alone is forbidden | ~1541 | FREEZE → §5.2 decisions | ADAPT_REQUIRED | Rebuild frozen When columns/cells/result from final retained execution after each accepted reduction. |

---

## 5. Canonical old→current architecture mapping

The implementation must prove the following mapping, not merely assert it.

| Old Main concept | Semantic meaning | Current representation target |
|---|---|---|
| `I` INVENTORY | original-RUT coverage census/classification | MAP |
| `T` | coverage requirement with R/B/U/E state + constraint | `OUTCOME` |
| `W` | coverage-complete witness materialization | WITNESS |
| `S` in W | executable physical witness + given/owner/covers/simulation | `SCENARIO` + current frozen setup/SIM evidence |
| `F` | deterministic reduction to irredundant coverage-complete final witnesses | FREEZE |
| `B` | packaged physical view with no reuse of previous coverage proof | current grouping + BUILD; audit must treat coverage as untrusted |
| `A` | independent reconstruction + re-execution audit | AUDIT |
| `S.given` | typed witness inputs/setup | current SCENARIO.given / frozen setup authority |
| `S.owner/covers` | actual coverage established by complete execution | SCENARIO owner/covers |
| `S.simulation` | complete scenario simulation requirement | REQUIRED_SIMS / frozen SIM census |
| `S.name/at` | physical packaging identity/location | BUILD `LOCATION` |
| legacy DecisionColumnSignature | ordered row input schema | current `WHEN_COLUMN_SIGNATURE := ordered(path,valueType)` |
| legacy MultInpComb row | one When execution row | §5.2 frozen DecisionInput/DecisionResult → Projection `rows[]` |
| legacy RuleCode | target representation | Generator/schema only |

### 5.1 Mapping constraint

Do not create a new ScenarioTrace row merely because the old prompt had a field that has no current row.

A new row/schema change requires a separate architectural decision and is outside this restoration unless the mapping proves that no existing current authority can carry a required old semantic fact.

---

## 6. Mandatory invalidation of R39D D1 constructs

Before implementation, create a D1 quarantine list.

At minimum review every current Rule-Obj-When-specific statement in:

- §4.1 phase delta table;
- §4.1 `PRODUCER` row definition and arity;
- §4.2 MAP When commit rules;
- §4.3 WITNESS When rules;
- §4.4 FREEZE When rules;
- §4.7 When AUDIT rules.

### 6.1 Special decision gate: Rule-Obj-When `PRODUCER`

The old Main Prompt does not define a Rule-Obj-When ScenarioTrace `PRODUCER` row.

Therefore the current R39D semantic definition of that row MUST be treated as **unproven current extension**, not restored old semantics.

Required decision:

1. Determine whether a pre-R39D current-architecture requirement independently needs this row.
2. If no independently evidenced consumer needs it, remove it from the When flow and ScenarioTrace arity/row-set where applicable.
3. If it is required, specify it in a separate “current extension” subsection with exact provenance, consumer and validation; it MUST NOT influence old coverage membership, owner/covers or Result truth.
4. Independent review must approve this decision before release.

### 6.2 Special decision gate: “no COV/RESOLVE/PATH/EFFECT”

Do not keep these prohibitions merely because D1 wrote them.

For each row family ask:

- Is the old semantic fact already fully represented by OUTCOME/SCENARIO/current row decisions?
- Does current architecture have a downstream consumer that needs the row?
- Would adding the row duplicate or conflict with the old Main semantics?

Only then freeze the legal When row set.

The expected minimal mapping is likely OUTCOME → SCENARIO → final SCENARIO → GROUP/LOCATION → AUDIT, but this is a **mapping hypothesis** until Stage 2 proves it.

---

## 7. Token-optimized current design rules

The restoration must be optimized for a literal, high-capability model such as Claude Opus 4.8 without weakening semantics.

### 7.1 Instruction format

Prefer:

```text
SCOPE
MUST
MUST NOT
GATE
FAIL
EX   (only when ambiguity is real)
```

Avoid long historical explanations and words such as `legacy meaning`, `existing semantics`, `as before`, `unchanged` without a named authority.

### 7.2 One canonical owner per old obligation

Examples:

- coverage semantics → MAP;
- witness actual-execution semantics → WITNESS;
- reduction/irredundancy → FREEZE;
- simulation grouping → physical grouping;
- row decision semantics → §5.2;
- independent reconstruction → AUDIT;
- target cell constants → Generator/schema.

Downstream gates verify; they do not redefine.

### 7.3 Do not reintroduce legacy target detail into Author

Do not copy old `pyExpectedResults`, `rowLevelPage`, `pyDisplayLabel`, `pyPropertyType`, or similar RuleCode mechanics into ScenarioAuthor if current Projection/Generator already owns them.

ScenarioAuthor owns source semantics only.

### 7.4 Use current canonical SIM representation for grouping

Instead of reproducing the old long list of simulation-key fields, define the current group key from the already canonical frozen simulation source representation.

Target design:

```text
SIMULATION_GROUP_KEY =
  NO_SIMULATION                              if REQUIRED_SIMS is empty
  canonicalJSON(ordered SIM_WIRE(SIM) list) otherwise
```

where `SIM_WIRE` and REQUIRED_SIMS are the existing current source contracts.

This preserves the old requirement “same complete runtime-relevant simulation requirement” while avoiding a second manually maintained field list.

If current `SIM_WIRE` is proven insufficient to distinguish a runtime-relevant old field, that is a GAP and must be fixed at the canonical SIM owner, not patched only in When grouping.

### 7.5 Use source-level column signature

Define once:

```text
WHEN_COLUMN_SIGNATURE := ordered list of (path,valueType)
```

This matches current Projection/Generator source grammar. Do not duplicate target-only display/property constants in ScenarioAuthor.

### 7.6 Micro-examples to retain

Keep only examples that protect known ambiguity:

1. MC/DC pair: same atom, two sides, fixed other truth vector.
2. Leading-dot input: `.Homes(1).PostalCode` stays primary-relative.
3. Empty input: carrier exists, `value` absent / `<EMPTY>`, never parent “Not exists”.
4. Simulated DP input: DP-root property is excluded from row columns and carried by simulation.
5. Grouping: same REQSIM + different ordinary inputs/results → same executable group.

### 7.7 Token budget

Correctness is the release gate; token size is a review metric.

Target:

- no verbatim migration of old Main Prompt blocks;
- new/restored When semantic core should preferably remain within ~2,500 added model tokens over clean R39C;
- >3,500 added tokens requires explicit independent-review justification showing why the semantics cannot be expressed through current canonical owners.

---

## 8. Execution plan

Every stage has two independent statuses:

```text
IMPLEMENTATION_STATUS = NOT_STARTED | IN_PROGRESS | READY | REPAIRING
VALIDATION_STATUS     = NOT_STARTED | IN_PROGRESS | FAILED | VALIDATED
```

A stage cannot be `VALIDATED` while any Critical/High/Medium finding remains open.

### Stage 0 — Clean baseline and D1 invalidation

**Tasks**

1. Create clean R39C working baseline.
2. Reapply verified non-D1 R39D cleanup only after semantic review.
3. Build D1 quarantine inventory.
4. Confirm no D1 text is used as authority.

**Validation**

- every current When-specific normative statement has provenance `OLD_MAIN`, `CURRENT_ARCH`, or `UNPROVEN`;
- zero `UNPROVEN` statement is active;
- no “existing/legacy meaning” remains as semantic source.

**Exit:** READY + VALIDATED.

### Stage 1 — Old Main semantic extraction

**Tasks**

1. Extract W01–W25 from the old Main Prompt.
2. For each obligation record exact source range and minimal semantic statement.
3. Strip old storage/RuleCode assumptions from the semantic statement.
4. Mark target-specific obligations separately.

**Validation**

- independent reviewer can reconstruct every W item from the cited old source;
- no old RuleCode field is silently promoted to new Author semantics;
- no Rule-Obj-When old obligation is missing.

### Stage 2 — Obligation→current-owner mapping

**Tasks**

For every W item:

1. identify current owner phase/contract;
2. identify current representation;
3. identify consumers/validators;
4. classify DIRECT_CURRENT / ADAPT_REQUIRED / TARGET_OWNED / CURRENT_EXTENSION / GAP;
5. prove no competing owner exists.

**Validation**

- 100% W01–W25 mapped;
- zero UNMAPPED;
- every `CURRENT_EXTENSION` has non-old provenance;
- every GAP blocks implementation until explicit resolution.

### Stage 3 — Cross-contract compatibility review

Review current ScenarioAuthor + Projection + Generator + MultInpComb schema together.

**Mandatory checks**

- current `rows[]` can represent every old logical input/result obligation;
- `WHEN_COLUMN_SIGNATURE=(path,valueType)` is sufficient **because** current Generator mapping `CM-WHEN-001` + selected MultInpComb schema deterministically own the legacy target fields (`pyPropertyType`, property name/path/display label, Result placement); otherwise register GAP;
- empty-value presence/absence survives Projection→Generator;
- leading-dot and namespace survive unchanged;
- source row order/index maps 1:1 to candidate row order;
- Generator/schema own old target constants (`rowLevelPage`, Result cell mechanics, MultInpComb wrappers);
- current canonical SIM representation is sufficient for old simulation grouping: for every legacy runtime-relevant simulation-key field, prove it is either represented by current `SIM_WIRE/REQSIM` or fixed deterministically by Generator/schema; otherwise register GAP.
- current Projection boolean `rows[].result` deterministically maps through `CM-WHEN-001`/schema to the target Result representation required by the old contract; ScenarioAuthor must not stringify the source boolean.

If an old target invariant is missing from Generator/schema, register a **separate target-contract finding**. Do not patch it by leaking target mechanics into ScenarioAuthor.

### Stage 4 — Prompt integration design

Produce proposed replacement text before editing production prompt.

Required blocks:

1. Rule-Obj-When applicability / dependency gate (only missing parts; reuse existing §2/§3 rules).
2. MAP coverage adapter.
3. WITNESS actual-execution witness rule.
4. FREEZE deterministic reduction rule.
5. physical grouping / SIMULATION_GROUP_KEY rule.
6. §5.2 column + DecisionInput/DecisionResult authority.
7. AUDIT independent reconstruction rule.
8. Projection reconciliation pointer.

For each block specify:

- semantic owner;
- W obligations covered;
- current rows consumed/created;
- failure route;
- one optional micro-example.

**Design review:** no production edit until all blocks are approved as source-traceable and seam-free.

### Stage 5 — Implementation waves

Implement in small validated waves.

#### 5A — acquisition / pyLogic / coverage inventory

Targets: §2.4, §3.2, §4.2.

Preserve already-correct rules; add only missing old obligation semantics.

#### 5B — WITNESS + FREEZE

Targets: §4.3–§4.4.

This is the most important semantic wave.

Required FREEZE algorithm in current terms:

```text
- start from complete WITNESS set;
- rank removable candidates by the old deterministic cost tuple expressed with current facts: `(simulation entries, seeded leaves, non-default parameters, canonical given+simulation)`;
- for each proposed removal, rebuild affected row signature + REQUIRED_SIMS/grouping;
- re-execute affected complete When witnesses;
- accept only if every R OUTCOME remains covered and every MC/DC/pair constraint remains true;
- repeat to fixed point;
- merge exact duplicate executions only after the same proof;
- rebuild frozen row/cell/Result authority from final execution;
- confidence/testability never changes membership.
```

Do not claim global minimum; preserve old “deterministic coverage-complete irredundancy” semantics.

#### 5C — grouping + row decisions

Targets: §4.5, §5.2.

Define current canonical simulation key and row signature. Preserve 1:1 Scenario↔row correlation, simulated-DP exclusion, empty-input semantics and path namespace.

#### 5D — BUILD + AUDIT

Targets: §4.6–§4.7.

BUILD remains packaging-only.

AUDIT must independently:

- redo forward/reverse original-When coverage census;
- reclassify OUTCOME R/B/U/E;
- re-execute materialized rows;
- rebuild owner/covers without trusting frozen covers as proof;
- require union covers every R;
- validate E proofs against covered canonical R;
- validate MC/DC pair constraints;
- validate frozen↔materialized bijection;
- validate row signature/order/result/empty inputs/simulation grouping;
- prove no final Scenario is removable under the FREEZE rule;
- restart MAP on failure; never patch.

#### 5E — Projection / Generator boundary

Targets: §6 source reconciliation and Generator mapping only if Stage 3 found a gap.

No new Author target mechanics.

### Stage 6 — Local semantic validation after each wave

Every wave runs:

1. **source fidelity review** — each new sentence points to W item(s);
2. **current-architecture review** — rows/owners/BASE/failure route legal;
3. **negative-space review** — identify newly possible illegal behavior;
4. **token review** — no duplicated legacy explanation;
5. **fresh-model review** — no historical context needed.

Critical/High/Medium findings are fixed automatically and the complete wave review is rerun until zero.

### Stage 7 — End-to-end Rule-Obj-When validation

Run full conceptual lifecycle:

```text
CRAWL
→ MAP
→ WITNESS
→ FREEZE
→ physical grouping
→ §5.2 row decisions
→ BUILD
→ AUDIT
→ Projection
→ Generator fidelity
```

Validate at least these adversarial cases:

1. simple single-atom TRUE/FALSE;
2. two-atom MC/DC with fixed truth vector;
3. masked/non-effective atom requiring E proof;
4. one infeasible pair side — verify pair exclusion rule;
5. dependency variant with same original-RUT coverage — no extra coverage row;
6. invalid witness with alternative carrier — requirement remains R;
7. removable redundant witness — FREEZE removes only after re-execution proof;
8. removal that would break MC/DC — rejected;
9. two scenarios, same REQSIM, different inputs/results — one executable simulation group;
10. different REQSIM — separate groups;
11. simulated Data Page root used in condition — not an input column;
12. empty scalar input on initialized page/list element — cell retained, value absent;
13. leading-dot nested list path — namespace preserved;
14. missing critical nested When/RUF dependency — no guessed DecisionResult;
15. exact duplicate physical execution — merge only when all coverage remains;
16. packaging mutation — rejected/returns upstream;
17. AUDIT attempts to reuse frozen owner/covers rather than recompute — invalid;
18. confidence/testability decrease — coverage membership unchanged.

### Stage 8 — Full regression / integration validation

Re-run all current non-When regression locks to prove no collateral damage:

- DWL and property-path closure;
- Standard MAP/WITNESS/FREEZE/DECIDE/AUDIT;
- basePage/baseClass lineage;
- Decision Table semantics;
- Data Page simulation;
- ProjectionV3 Standard mode;
- handoff ordering.

Rule-Obj-When adaptation MUST NOT alter Standard behavior.

### Stage 9 — Independent review package

Produce review artifacts:

1. `WHEN_OLD_SEMANTIC_INVENTORY.md`
2. `WHEN_OLD_TO_CURRENT_MAPPING.csv`
3. `WHEN_CHANGE_MAP.md`
4. `WHEN_SOURCE_FIDELITY_REVIEW.md`
5. `WHEN_ARCHITECTURE_INTEGRATION_REVIEW.md`
6. `WHEN_GENERATOR_SCHEMA_COMPATIBILITY.md`
7. `WHEN_ADVERSARIAL_VALIDATION.md`
8. `WHEN_TOKEN_METRICS.json`
9. final prompt candidate.

The reviewer must be able to reject any individual mapping without accepting the rest.

---

## 9. Detailed production change map

| Current area | Required treatment | Old obligations | Review focus |
|---|---|---|---|
| §1.4 Execution phases | Keep high-level When branch only; update after canonical mapping is final | W01, W22 | no duplicate algorithm; no historical wording |
| §2.4 dependency discovery | Preserve current DWL; ensure When operand scan completeness | W03, W04, W21 | no parallel dependency ledger |
| §3.1 ROOT/setup | Preserve reserved-root ban | W02 | banned carrier blocks only with universal proof |
| §3.2 RX | Preserve concise pyLogic lock | W03 | all top-level OR clauses evaluated; no short-circuit omission |
| §3.5 SIM | Remain canonical simulation owner | W13, W20 | When grouping derives from SIM owner, does not redefine SIM |
| §4.1 ScenarioTrace contract | Remove D1 authority; rebuild only proven When row-set/BASE mapping | W05–W12, W24 | special review of PRODUCER and row prohibitions |
| §4.2 MAP | Make old T adapter explicit in OUTCOME terms | W05, W06, W08 | final T/F + MC/DC; R/B/U/E; dependencies never own coverage |
| §4.3 WITNESS | Restore deterministic coverage-complete actual execution | W07, W08 | owner/covers actual execution only; invalid witness != invalid requirement |
| §4.4 FREEZE | Restore old deterministic reduction/fixed-point semantics | W09, W10, W22, W25 | re-execute removal; no confidence/testability pruning |
| §4.5 grouping | Define key from current REQSIM/SIM_WIRE; row cardinality | W13–W17 | equal key together; different key apart; current EXECUTION_CLASS explicitly separate |
| §4.6 BUILD | Packaging-only physical mapping | W11, W16, W24 | no semantic changes, no re-authoring |
| §4.7 AUDIT | Map old A independent reconstruction | W12, W16, W24 | forward/reverse census, R/B/U/E, independent owner/covers, irredundancy |
| §5.2 When decisions | Canonical source-level row/Result authority | W17–W21, W25 | signature, empty, path, DP exclusion, Result dependency gate |
| §5.3 testability | Preserve non-interference with coverage | W22 | testability cannot delete required scenario |
| §6.4.4 rows | Keep closed source grammar | W16–W19 | no target-field leakage |
| §6.4.6 reconciliation | Strengthen exact frozen row reconciliation only if needed | W16, W25 | compilation only, no semantic re-evaluation |
| Generator + MultInpComb schema | Verify old target mechanics are already owned here | W23 | source→target row fidelity; Result cell constants; target wrappers |

---

## 10. Acceptance checks

### 10.1 Provenance

- [ ] Every normative When sentence has a source: `OLD_MAIN:<Wxx>` or `CURRENT_ARCH:<owner>`.
- [ ] Zero normative sentence cites R39D D1 as authority.
- [ ] Zero historical phrase (`existing meaning`, `legacy semantics`, etc.) remains unresolved.

### 10.2 Coverage semantics

- [ ] Final TRUE and FALSE obligations represented.
- [ ] Every atom has both MC/DC sides or valid E proof.
- [ ] Pair id / side / atom / fixed truth vector preserved.
- [ ] One pair side is never independently excluded without valid pair proof.
- [ ] Dependency behavior never becomes original-RUT coverage.
- [ ] No Cartesian expansion.

### 10.3 Witness semantics

- [ ] Every required obligation has actual complete execution witness or valid B/U/E classification.
- [ ] Invalid witness does not silently eliminate required OUTCOME.
- [ ] owner/covers come only from complete actual original-When execution.

### 10.4 FREEZE semantics

- [ ] Reduction uses re-execution, not heuristic deletion.
- [ ] Coverage + MC/DC remain complete after every accepted removal.
- [ ] Grouping/signature/simulation effects are rebuilt before accepting removal.
- [ ] Fixed point reached.
- [ ] Exact duplicates merge only after proof.
- [ ] Final row decisions are rebuilt from final retained execution.
- [ ] confidence/testability/assertion availability cannot change final membership.

### 10.5 Grouping / rows

- [ ] Group key represents complete canonical current simulation requirement.
- [ ] Equal executable simulation requirements group together.
- [ ] Different requirements do not group together.
- [ ] Ordinary input and Result differences alone do not split simulation groups.
- [ ] Scenario count == row count within executable group.
- [ ] Ordered `(path,valueType)` signature identical within group.
- [ ] Empty input retains cell and omits value.
- [ ] leading-dot / namespace / indices / keys preserved.
- [ ] simulated DP roots excluded from writable row inputs.
- [ ] row numbers assigned only after final stable group order.

### 10.6 Result semantics

- [ ] Result comes from complete actual When execution.
- [ ] Controlling dependencies closed/terminal before exact Result.
- [ ] Terminal missing dependency never yields guessed TRUE/FALSE.
- [ ] Informational/blocked path does not fabricate Result.

### 10.7 Audit

- [ ] Audit reconstructs raw coverage independently.
- [ ] Audit re-executes materialized rows.
- [ ] Audit does not trust frozen owner/covers as proof.
- [ ] forward census == reverse census == source union.
- [ ] R/B/U/E partition valid.
- [ ] E points to a canonical covered R.
- [ ] union actual covers == all R.
- [ ] MC/DC constraints valid.
- [ ] frozen↔materialized mapping bijective.
- [ ] no final Scenario is removable under FREEZE rules.
- [ ] failure restarts correct earliest phase; never patches.

### 10.8 Architecture boundary

- [ ] ScenarioAuthor does not author RuleCode target structure.
- [ ] Projection contains only current source grammar.
- [ ] Generator/schema own target MultInpComb constants/transforms.
- [ ] Any Generator/schema gap is separately documented, not hidden in Author.

### 10.9 Standard-flow non-regression

- [ ] Standard ScenarioTrace row sets unchanged unless separately approved.
- [ ] Standard DECIDE and assertions unchanged.
- [ ] Property-path/baseClass hardening unchanged.
- [ ] Data Page/Decision Table semantics unchanged except shared canonical references.

---

## 11. Review severity and automatic repair loop

Severity:

- **CRITICAL** — invented/missing coverage behavior, wrong Result, loss of required scenario, audit trusts prior proof, architecture/schema incompatibility, Standard-flow regression.
- **HIGH** — unmapped old obligation, ambiguous owner, incomplete MC/DC semantics, grouping/signature mismatch, D1-only construct still authoritative.
- **MEDIUM** — duplicated semantic definition, vague historical reference, unnecessary target leakage, non-local instruction, avoidable token bloat that risks execution clarity.
- **LOW** — cosmetic/readability only.

Execution rule:

```text
IMPLEMENT STAGE
→ semantic review
→ classify findings
→ auto-fix all Critical/High/Medium
→ rerun complete stage review
→ run downstream affected reviews
→ repeat until C=0 / H=0 / M=0
```

After all stages, run one independent full review from the source documents, not from the implementation notes.

No stage is `VALIDATED` merely because its tests pass; source fidelity and architecture compatibility must both pass.

---

## 12. Independent reviewer checklist

The independent reviewer should answer, with evidence:

1. Can every new When rule be traced either to an old W obligation or a named current-architecture owner?
2. Did any R39D D1 statement survive only because it was already there?
3. Were old storage constructs translated semantically rather than copied structurally?
4. Does current MAP represent the old coverage inventory completely?
5. Does WITNESS derive owner/covers only from complete execution?
6. Does FREEZE actually implement the old deterministic irredundant fixed-point reduction?
7. Is simulation grouping defined from one canonical current SIM representation?
8. Are row semantics source-level and target mechanics Generator-owned?
9. Does AUDIT independently reconstruct rather than reuse frozen coverage proof?
10. Can a fresh Opus 4.8 execute the flow without historical knowledge?
11. Is the When-specific instruction set concise enough that the same invariant is not re-explained across MAP/WITNESS/FREEZE/AUDIT?
12. Do all Standard/non-When regression guarantees remain unchanged?

Any “no” is at least HIGH unless explicitly classified otherwise with evidence.

---

## 12.1 Specification review outcome

Three review passes were applied to this technical specification before release for implementation:

1. **Source-fidelity pass:** W01–W25 were checked against the cited old Main Prompt blocks. The spec distinguishes semantic obligations from old storage/RuleCode representation and does not treat R39D D1 as provenance.
2. **Architecture-seam pass:** target-only MultInpComb mechanics were kept on the Projection→Generator/schema side; `PRODUCER` and When row-set prohibitions remain explicit decision gates rather than assumed truths; a missing mapping is a blocking GAP.
3. **Opus/token pass:** the target design uses canonical current owners, `SIM_WIRE/REQSIM`, source `(path,valueType)` signatures, imperative phase-local rules and micro-examples instead of verbatim old prose.

Corrections made during review:
- Definition of Done now requires `GAP=0`; an unresolved architectural gap blocks this restoration rather than being silently deferred into a supposedly complete release.
- FREEZE reduction now names the exact old cost tuple instead of the vague phrase “current equivalent”.
- Stage 3 now requires explicit proof that `CM-WHEN-001`/MultInpComb schema deterministically own legacy target column/Result fields and boolean target representation.
- SIM grouping review must account for every legacy runtime-relevant simulation-key field as represented or deterministic target constant; otherwise it is a GAP.

At specification level, no unresolved Critical/High/Medium issue remains. This statement validates the **plan**, not any future implementation.

---

## 13. Definition of Done

The adaptation is complete only when all are true:

```text
W01–W25 mapping complete
UNMAPPED = 0
active D1-only authority = 0
GAP = 0
Critical = 0
High = 0
Medium = 0
```

and:

- old Rule-Obj-When coverage/witness/freeze/audit semantics are preserved in current architecture;
- MultInpComb grouping/row semantics are preserved without reintroducing legacy RuleCode ownership into ScenarioAuthor;
- current Projection/Generator boundary remains intact;
- current Standard pipeline remains unchanged;
- token metrics meet the optimization review or have explicit correctness justification;
- independent review can reconstruct every mapping from the old Main Prompt and current contracts.

---

## 14. Spec self-review record

This specification itself must be reviewed before implementation.

### Review Pass 1 — source fidelity

Check W01–W25 against the cited old Main Prompt blocks. Remove any obligation not actually supported by the old source. Add any omitted old semantic obligation.

### Review Pass 2 — current-architecture seams

Check each proposed owner against the current ScenarioAuthor/Projection/Generator contracts. Any mapping that would require a new row, field, or target mechanic becomes a GAP/current-extension decision rather than an implicit change.

### Review Pass 3 — Opus/token execution quality

Check that the implementation strategy uses one owner, imperative rules, local gates and micro-examples; target detail is not duplicated in Author; no historical prose is copied wholesale.

The specification is implementation-ready only after these three reviews report no Critical/High/Medium issue.
