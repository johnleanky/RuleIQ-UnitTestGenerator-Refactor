# R39 Conservative ScenarioAuthor Prompt Optimization — Specification

## Scope

R39 optimizes only `01_PROMPTS/ScenarioAuthor_SystemPrompt.txt`. It does not redesign R38 architecture and does not externalize prompt semantics. Generator, Validator, Knowledge Areas, target contracts and runtime tool contracts remain outside the runtime change surface.

## Execution stages

- **R39A — Language normalization:** prose to imperative/predicate form; explicit scope; shorter regression examples; obsolete legacy §8 tail removed.
- **R39B — Semantic prose deduplication:** canonical definitions retained once while independent AUDIT, pre-projection and producer-side validation boundaries remain separate.
- **R39C — Structural presentation:** canonical phase table; uniform phase sections; compact RuleCrawler transition table; structured ScenarioTrace invariants; all 11 pre-projection gates as predicates; full inline ProjectionV3 contract retained.

## Non-negotiable preserved mechanisms

- occurrence-driven DWL and property-path closure;
- `pxRuleClassName` is Applies-To/request-class evidence only, never embedded runtime page class;
- RI/PC source-target/index separation and LIC;
- MAP/WITNESS/FREEZE/DECIDE/BUILD/AUDIT ownership;
- ScenarioTrace row grammars/arities including `OUTPUT11`;
- immutable generation/invalidation/repair behavior;
- complete OUTPUT→DECISION census and `basePage/baseClass` lineage;
- all 11 pre-projection gates;
- closed inline UnitTestProjectionV3 producer contract and self-validation;
- PREPARE_ALL → PERSIST_ALL → GENERATE_ALL handoff;
- Rule-Obj-When dedicated path;
- Generator/Validator non-authority over frozen Author semantics.

## Validation method

All refactor comparisons use textual semantic comparison of rules, state transitions, row grammars, gates, ownership, failure routes, examples and contracts. SHA/hash/diff comparisons are not used.

Every stage has independent READY and VALIDATED status. Critical/High/Medium findings reopen the owning stage and require full downstream revalidation.
