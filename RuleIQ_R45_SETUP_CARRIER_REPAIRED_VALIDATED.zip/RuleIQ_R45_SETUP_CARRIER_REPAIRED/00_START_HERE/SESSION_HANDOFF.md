# SESSION HANDOFF — R45

Current authoritative release: **R45 Generator–Validator Synchronization**.

Continue from R45, not R44R. Architecture is unchanged: ScenarioAuthor is sole Projection semantic authority; Generator compiles authoritative Projection; Validator independently checks persisted Candidate against Projection + existing target contracts. No new runtime contract layer exists.

R45 runtime changes are limited to Validator: (1) Rule-Obj-When `valueType` is explicitly evidence-only / `NO_FIDELITY_CHECK` per existing `CM-WHEN-001`; (2) obsolete semantic-adapter wording is replaced by direct Knowledge Area terminology. ScenarioAuthor, Generator, all KAs, schemas/examples and tools are unchanged from R44R.

Open validation caveat: fresh live Pega/model replay has not been performed. Static semantic/contract validation is PASS with C/H/M/Unresolved=0.

---

# R44R Session Handoff

## Current release

R44R — Projection producer-authority restoration over R43. R44 is non-authoritative evidence only.

Read first:
1. `STATUS.md`
2. `R44R_PROJECTION_PRODUCER_AUTHORITY_RESTORATION_SPEC.md`
3. `R44R_PROJECTION_PRODUCER_AUTHORITY_RESTORATION_VALIDATION.md`
4. `../docs/r44r/R44R_FINAL_INDEPENDENT_REVIEW.md`
5. `../docs/r44r/PROJECTION_RULE_OWNERSHIP.csv`
6. `01_PROMPTS/ScenarioAuthor_SystemPrompt.txt`
7. `01_PROMPTS/UnitTestGenerator_SystemPrompt.txt`
8. `01_PROMPTS/Validator_SystemPrompt.txt`

## Active architecture

ScenarioAuthor is the sole semantic authority for ProjectionV3. It completes the existing semantic phases, 11 pre-projection gates, Projection materialization, frozen-authority reconciliation and producer self-validation **before persistence**. The complete ProjectionV3 interface is still present in Generator so it can operate independently, but all semantic/cross-field rules there are producer guarantees: Generator does not re-prove them. Generator checks only transport/readability/correlation needed to consume the source, then target representability, deterministic Candidate compilation, Candidate fidelity and Validator lifecycle. Validator verifies target schema/fidelity only and never judges Projection business truth.

The R43 KA/DWL architecture remains unchanged: When/DP/DecisionTable/RUF domain semantics stay in ScenarioAuthor/Core+KAs; Generator/Validator consume no KW/KDP/KDT internals. Handoff remains `PREPARE_ALL -> PERSIST_ALL -> GENERATE_ALL`.

R44R validation: 145/145 boundary, 125/125 regression, 48/48 architecture-preservation, 131/131 G1–G10, 20/20 fresh-agent; C/H/M=0. Fresh live Pega/model replay is not claimed.

## R37 change from R36

Only ScenarioAuthor comparator authoring changed. DECIDE now owns exact canonical comparator labels, UnitTestProjectionV3 accepts only kind-specific canonical comparator sets, and Projection materialization/reconciliation copies comparator exactly without alias normalization. The live `Is equal to` drift is therefore rejected before persistence. MAP/WITNESS/FREEZE/DECIDE dataflow, PATH/EFFECT, AUDIT and repair behavior otherwise remain R36.

## R36 change from R35

Only ScenarioAuthor runtime behavior changed.

### MAP

Keeps existing `OUTCOME/COV/PDEF` planning. Adds a hard integrity requirement: every required OUTCOME must have exactly one atomic COV.

### WITNESS

Every MAP COV gets exactly one:

```text
RESOLVE|COV|REALIZED|Scenario|-|-
```

or a grounded terminal:

```text
RESOLVE|COV|BLOCKED|-|canonical_reason|proof
```

No silent loss. Execution is stored as one complete `PATH(E/S/U)` per Scenario, not individual EXEC rows.

### FREEZE

Scenario ids must equal WITNESS exactly. FREEZE writes a fresh final PATH and compact EFFECT rows containing concrete source/target/before/after/index/value facts. It cannot silently drop or merge a Scenario.

### DECIDE / BUILD

Semantics intentionally remain explicit and largely unchanged. OUTPUT/DECISION are the final assertion authority; BUILD is a mechanical copy/materialization.

### AUDIT

Standard AUDIT BASE now includes WITNESS and audits the whole active lineage. On FAIL it emits one REPAIR directive naming the earliest owner. The same Author invalidates/rebuilds from that owner and retries, max five cycles. Repair counters/signatures come from committed transcript rows, not hidden memory.

## Regression files used

- `PXCONV-184033.txt` — successful R35 reference.
- `PXCONV-184052.txt` — silent-loss failure; R36 rejects its incomplete OUTCOME/COV shape.
- `PXCONV-184019.txt` — historical child producer/assertion/page loss; R36 preserves R35 safeguards with PDEF/PATH/EFFECT lineage.

## Validation result

R38 static/contract/regression review:

```text
Critical 0
High     0
Medium   0
```

All runtime files other than ScenarioAuthor are direct-content unchanged from R37. ScenarioAuthor remains 604 lines; size changed from 145,193 to 146,779 bytes; Unicode text delta is 1,583 characters (~396-token chars/4 estimate). The supplied `GENUT-93002` trace confirms the historical failure shape used by this fix. Fresh live Pega/model replay of R38 is still pending.

## If continuing development

Do not redesign MAP unless new evidence proves a MAP defect. The primary R36 invariant is transition conservation plus end-to-end AUDIT.

Any new optimization must preserve:

- exact COV disposition;
- Scenario identity WITNESS -> FREEZE;
- full PDEF PATH partition;
- child EFFECT completeness;
- source/target index separation;
- named-page rooted target lineage;
- exact Pega lexical expected values;
- OUTPUT/DECISION equality;
- deterministic AUDIT repair ownership.
