# R40 Final Independent Review — Old Main → Current Rule-Obj-When Restoration

## Review posture

This review is independent from implementation notes. Semantic authority is old `RuleIQ/Main_Agent_Prompt.txt`; R39C is the current-architecture baseline; current Generator/schema contracts own target MultInpComb mechanics. R39D D1 is non-authoritative and was not used as provenance. Correctness evidence is textual/semantic; no SHA/hash/textual diff is used.

## Acceptance 10.1 — Provenance — PASS
- W01–W25 mapping contains 25/25 obligations with final owners; `UNMAPPED=0`, `GAP=0`.
- Production When semantics are covered by OLD_MAIN W01–W25 or the explicit current-only extensions X01/X02.
- X01 is non-substitutive and cannot coexist with executable R coverage; X02 is source metadata only.
- No unresolved `existing meaning`, `dedicated existing`, `legacy semantics`, `old meaning` or R39D-D1 authority remains in the production prompt.

## Acceptance 10.2 — Coverage semantics — PASS
- MAP censuses final TRUE/FALSE and both MC/DC sides for every atom.
- Pair id/side/atom/fixed vector and E proof are explicit.
- One pair side cannot be independently excluded; no Cartesian expansion.
- Dependency variants select witness values only and never own original-RUT coverage.

## Acceptance 10.3 — Witness semantics — PASS
- WITNESS starts from the complete MAP R census and builds a deterministic coverage-complete base.
- owner/covers are derived only from complete actual original-When execution.
- An invalid witness invalidates that witness, not the R requirement; coverage remains open until alternate witness or proof-backed B/U/E.

## Acceptance 10.4 — FREEZE semantics — PASS
- Removal uses the old exact cost tuple and re-executes every affected retained Scenario.
- Each accepted removal preserves all R coverage plus MC/DC/joint/shape constraints.
- Reduction iterates to fixed point and claims irredundancy, not global minimum.
- Exact duplicate merge requires equality proof.
- After reduction/merge, retained executable Scenarios are sorted by canonical `given+simulation`; only then are final ids assigned.
- Final given/simulation/owner/covers/REQSIM/row authority are rebuilt from final execution; witness rekeying is forbidden.
- Confidence/testability/assertion availability cannot suppress an R-covering final Scenario.

## Acceptance 10.5 — Grouping / rows — PASS
- Group key is complete current ordered REQSIM/SIM_WIRE, or `NO_SIMULATION` when empty.
- Equal executable simulation requirements group together; different requirements remain separate.
- Ordinary input values and Result do not split groups.
- Each executable FREEZE Scenario maps to exactly one row; stable final Scenario order is preserved within stable simulation partitions.
- `WHEN_COLUMN_SIGNATURE` is identical/order-stable per group; empty/irrelevant/not-evaluated cells remain present with absent source `value`.
- Paths preserve namespace/leading dot/index/key/case/root; simulated Data Page roots are excluded from input columns.
- Row/local numbering occurs only after stable group order.

## Acceptance 10.6 — Result semantics — PASS
- Boolean Result comes only from complete actual original-When execution.
- Controlling dependencies must be CLOSED or terminal before exact Result.
- Missing/unknown critical dependency never guesses TRUE/FALSE.
- Current informational zero-R carrier has no fabricated Result row.

## Acceptance 10.7 — AUDIT — PASS
- AUDIT independently re-scans original source forward/reverse, re-executes materialized rows and rebuilds owner/covers/Result.
- FREEZE owner/covers/Result are not accepted as proof.
- R/B/U/E, E target, source union, coverage union, MC/DC, mapping bijection, canonical final order and irredundancy are independently checked.
- Failure restarts the earliest owner (new dependency → CRAWL; semantic failure → MAP); no patching.

## Acceptance 10.8 — Architecture boundary — PASS
- Old T/S/I/W/F/B/A storage is not reintroduced.
- ScenarioAuthor emits only current source grammar and does not author target RuleCode MultInpComb structure.
- `CM-WHEN-001`, `CF-WHEN-ORDER-001`, `CM-EXEC-001` and MultInpComb schema own wrappers/constants/Result representation.
- `GAP=0` in Generator/schema compatibility review.
- Orphan legacy-only `PRODUCER12` is removed under the spec's explicit §6.1 decision gate; no current producer/consumer existed.

## Acceptance 10.9 — Standard-flow non-regression — PASS
- Standard phase ownership/BASE remain MAP=`OUTCOME/COV/PDEF`, WITNESS=`RESOLVE+SCENARIO/PATH/WHY`, FREEZE=`SCENARIO/PATH/EFFECT`, DECIDE=`OUTPUT/DECISION`, BUILD=`GROUP/LOCATION`, AUDIT=`AUDIT,[REPAIR]`.
- OUTPUT11/basePage/baseClass and R38 property-path closure remain intact.
- Standard testability remains `BLOCKED OR (ENABLED + ABSENT)` for NotTestable.
- Standard DECIDE authority, Data Page/Decision Table ownership and PREPARE_ALL→PERSIST_ALL→GENERATE_ALL are unchanged in meaning.

## Independent reviewer checklist
1. Every new When rule traceable to old W obligation/current owner? **YES.** Mapping W01–W25 + X01/X02.
2. Any R39D D1 statement survives only by inheritance? **NO.** D1 quarantined; historical phrases absent.
3. Old storage copied structurally? **NO.** Semantic mapping only.
4. MAP represents old coverage inventory completely? **YES.** W05/W06.
5. WITNESS owner/covers only from complete execution? **YES.** W07/W08.
6. FREEZE implements deterministic fixed-point irredundant reduction? **YES.** W09/W10/W22/W25, including canonical post-reduction sort/final ids.
7. One canonical current SIM representation drives grouping? **YES.** Ordered REQSIM/SIM_WIRE; compatibility proof maps legacy runtime fields.
8. Row semantics source-level and target mechanics Generator-owned? **YES.** W17–W23.
9. AUDIT independently reconstructs? **YES.** W12/W24.
10. Fresh Opus can execute without historical knowledge? **YES.** Current prompt states phase-local rules; no historical-reference dependency remains.
11. Is When instruction set concise enough to avoid conflicting redefinitions? **YES, with deliberate independent gates only.** MAP/WITNESS/FREEZE/grouping/AUDIT each own one lifecycle responsibility; Projection only reconciles.
12. Standard/non-When guarantees unchanged? **YES.** Stage 8 revalidated after every Stage-9 repair.

## Independent-review findings and repair loop
- H-9-01 — R-covering Scenario could become informational: **FIXED**.
- H-9-02 — informational carrier could coexist with executable coverage: **FIXED**.
- H-9-03 — shared Standard §5.3 wording drift: **FIXED**.
- H-9-04 — canonical final sort before final ids omitted: **FIXED**.
- All affected Stage 5/6/7/8 reviews were rerun after repairs.

## Final result
- W01–W25: **PASS**
- UNMAPPED: **0**
- GAP: **0**
- Active D1-only authority: **0**
- Critical: **0**
- High: **0**
- Medium: **0**
- Stage 9: **READY + VALIDATED**
