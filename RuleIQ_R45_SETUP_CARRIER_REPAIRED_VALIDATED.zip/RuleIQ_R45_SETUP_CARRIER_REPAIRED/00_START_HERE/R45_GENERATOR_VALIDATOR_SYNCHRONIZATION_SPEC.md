# R45 Generator–Validator Synchronization Audit

Baseline: R44R. Scope is consistency audit plus minimal synchronization only. No new interface, runtime layer, adapter, registry, schema, agent, lifecycle, or responsibility change is permitted.

Generator remains target compiler; Validator remains independent Candidate verifier. ScenarioAuthor remains sole Projection semantic authority. Existing JsonSchemas/mappings/invariants are evidence for resolving disagreements. Intentional Generator-only and Validator-only mechanics remain asymmetric.

R45 identified one target-fidelity conflict: Rule-Obj-When `valueType` is evidence-only under existing `CM-WHEN-001`, but Validator wording incorrectly grouped it with target-mapped fields. Validator now explicitly treats `valueType` as `NO_FIDELITY_CHECK` while continuing to check row/input path, expected presence/value, result and order. A second wording-only historical residue replaced obsolete `adapter` terminology with the existing direct Knowledge Area architecture.

All other runtime artifacts are unchanged from R44R.
