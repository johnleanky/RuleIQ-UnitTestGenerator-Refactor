# R32 — MemoryTemp / ScenarioTrace Refactoring Technical Specification

## 1. Execution owner and runtime target
This specification is executed against the current RuleIQ project by the refactoring agent. The resulting `ScenarioAuthor_SystemPrompt.txt` is intended for Claude Opus 4.8 runtime execution. Claude is not the executor of this refactor.

## 2. Strict scope
Change only ScenarioAuthor's `MemoryTemp(type="ScenarioTrace", value=...)` state-management architecture and the ScenarioTrace representations used by MAP, WITNESS, FREEZE, DECIDE, BUILD and AUDIT.

Do **not** redesign or modify GetCaseData, KnowledgeTool, RuleCrawler, DWL/dependency closure, Data Page semantics, Decision Table semantics, ROOT, parameter/CAST rules, RX semantics, RI/PC/LPE/APB/LIC/PropertyTrace semantics, assertion ladder, testability, UnitTestProjectionV3 external schema, WriteMemory, UnitTestGenerator, the Memory read operation (canonically `GetAgentMemory` in R33), Generator orchestration, or Validator. Those systems may be read as existing authorities but are out of scope.

## 3. Agreed architectural decision
Replace repeated complete ScenarioTrace snapshots with an **incremental semantic commit ledger**:

- A semantic fact successfully materialized once remains authoritative under a stable identity.
- Later MemoryTemp commits reference earlier active generations instead of serializing the same fact again.
- Correctness relies on explicit references, not an assumption that the model remembers earlier prose.
- Each commit uses readable `PHASE`, `HEAD`, `BASE`, optional `INVALIDATE`, phase-owned rows, and `COMMIT`.
- Committed facts are immutable. A correction invalidates the earliest affected active generation and creates a new generation; never patch committed content in place.
- The latest valid `HEAD` identifies the active generation chain and prevents mixed old/new state.

## 4. Vocabulary rule
Use existing ScenarioAuthor terminology and readable full field names. Do **not** introduce one-letter/new shorthand such as `e=`, `bc=`, `ac=`, `i=` merely for token savings and do not require a separate abbreviation dictionary.

Stable object IDs may remain compact (`T1`, `S2`, `P3`, `C4`, `G5`) because they are pointers rather than semantic vocabulary. They are unique within their owning generation; full identity is `(owning generation, object ID)`, so a replacement generation may assign its own canonical local IDs without mutating invalidated facts. Phase generation IDs remain globally unique for the run and use readable names such as `MAP1`, `WITNESS1`, `FREEZE1`, `DECIDE1`, `BUILD1`, `AUDIT1`.

## 5. Phase ownership
- MAP owns OUTCOME rows; materialize them once.
- WITNESS owns witness SCENARIO rows; reference MAP instead of copying OUTCOME.
- FREEZE owns final SCENARIO rows and the new compact PRODUCER execution projection; reference MAP/WITNESS instead of copying them.
- DECIDE owns Standard OUTPUT/DECISION rows; reference FREEZE instead of copying SCENARIO/PRODUCER.
- BUILD owns only physical `GROUP`/`LOCATION` mapping; reference FREEZE/DECIDE instead of copying decisions.
- AUDIT owns only the independent AUDIT result; independently verify referenced active state but do not persist copies of upstream rows.
- Original Rule-Obj-When retains its existing dedicated semantic decision model; only ScenarioTrace transport changes.

## 6. Control-state requirements
Each commit must make active state explicit:

- `HEAD` contains epoch plus active map/witness/freeze/decide/build/audit generations.
- `BASE` names the immutable active prerequisite generations consumed by this commit.
- `COMMIT` names exactly the new current phase generation.
- `INVALIDATE` names the earliest invalid active generation when a restart is required.

Normal Standard dependencies are MAP=`-`; WITNESS=`MAP`; FREEZE=`MAP,WITNESS`; DECIDE=`FREEZE`; BUILD=`FREEZE,DECIDE`; AUDIT=`MAP,FREEZE,DECIDE,BUILD`. Rule-Obj-When keeps `decide=-`, with BUILD=`FREEZE` and AUDIT=`MAP,FREEZE,BUILD`.

Missing, invalidated, duplicate, future or incompatible generation references are blocking. A generation ID is never reused for different content.

## 7. Producer execution continuity
Do not redesign producer semantics. Add a compact ScenarioTrace projection of facts already established by the current RI/PC/RX/CTX/list/property reasoning.

FREEZE must materialize one relevant `PRODUCER` row per scenario-local producer whose execution/state can affect final RUT outputs, PropertyTrace/APB/LIC, or the ordered state of a candidate-sensitive mutable list. Preserve skipped/unknown relevant producers where their state matters.

The row must preserve readable fields for:
- stable projection ID;
- frozen Scenario ID;
- existing RI/PC producer identity;
- `execution=executes|skipped|unknown`;
- operation;
- resolved source/read coordinate;
- resolved target/write coordinate;
- minimal before state;
- minimal after state;
- concrete `writeIndex`, `unknown`, or not-applicable;
- compact reason when unresolved state affects downstream representation.

`beforeState`/`afterState` may use compact canonical JSON with readable existing concepts such as `count`, `presence`, and `value`. Do not invent a new semantic ontology.

## 8. Ordered mutable-state rule
Producer execution is an ordered state transition chain. Initialize each candidate-sensitive target from the exact frozen pre-producer state already established by existing setup/context/page-creation semantics. Lack of a prior producer row alone is not proof of emptiness.

When existing semantics prove an initially empty list, preserve `beforeState={"count":0}`. For an executing append with known prior count N, preserve `afterState={"count":N+1}` and `writeIndex=N+1`; later producers consume that after-state. Source and target indexes remain distinct.

Composite operations retain a structural producer and their scalar/Param child producers. If the structural append proves target index 1, child producer targets use the concrete target item, e.g. `CustomerCommunication.Addresses(1).pyCity`.

## 9. DECIDE continuity rule
For producer-derived OUTPUT, store a readable `producerReference` pointing to the active FREEZE `PRODUCER.id`. The PRODUCER row resolves to the existing RI/PC producer identity.

If the active PRODUCER state proves a concrete target/write index, DECIDE must preserve the concrete indexed target through OUTPUT and existing assertion-kind selection. It must not downgrade to `List/InAnyInstance` merely because DECIDE is a later phase.

`List/InAnyInstance` remains legal only when the complete existing producer/list reasoning genuinely leaves the target index unknown, the active PRODUCER row records that unknown index plus its blocker, and the existing LIC semantics permit the fallback.

## 10. BUILD and AUDIT
BUILD materializes only new physical mapping: `GROUP` maps physical group to ordered Scenario/ASSERT claim references and `LOCATION` records Scenario group/name/location. It does not copy SCENARIO, OUTPUT or DECISION payloads.

AUDIT remains independent. It must independently reconstruct coverage/execution/candidate support and additionally verify that the active FREEZE PRODUCER projection matches independent replay, including before/after list state and concrete index or justified unknown. A missing/extra producer projection, wrong concrete index, or unjustified unknown index fails audit. Successful AUDIT materializes only the AUDIT result.

## 11. Restart / invalidation
A correction never mutates committed rows. Invalidate the earliest affected active generation, increment epoch, create a new generation, clear dependent downstream active generations, and reference only still-valid upstream generations.

Examples:
- DECIDE-only correction keeps FREEZE and replaces DECIDE+downstream.
- name-only BUILD repair keeps FREEZE/DECIDE and replaces BUILD+AUDIT.
- execution/index change replaces FREEZE+downstream while keeping valid MAP/WITNESS.
- WITNESS change replaces WITNESS+downstream while keeping MAP.
- MAP restart replaces the whole active ScenarioTrace branch.

## 12. Token optimization policy
Token efficiency is subordinate to semantic correctness and functionality. Do not impose a percentage reduction target.

Optimize primarily by removing cross-phase duplication and referencing stable IDs. Do not remove functional/safety blocks, weaken audit, replace readable terms with cryptic shorthand, or create hidden inference requirements for token savings. Measure prompt and MemoryTemp size before/after as evidence, not as a quota.

## 13. Required regression
Use the fresh `TC Valid Address Appended` conversation as a regression case. The solution must be general, not path-specific.

Source-backed expected chain for that case:
- UPDATE_PAGE creates `CustomerCommunication` as an empty shell under the acquired semantics;
- APPEND_AND_MAP_TO is the first structural write to `CustomerCommunication.Addresses` on the relevant path;
- therefore prior target list size is 0;
- executing append produces `beforeState={"count":0}`, `afterState={"count":1}`, `writeIndex=1`;
- child writes target `CustomerCommunication.Addresses(1).pyCity`, `.pyPostalCode`, `.pyStreet`;
- existing scalar assertion rules then have enough persisted state to retain indexed Property assertions rather than using `List/InAnyInstance` solely because the index was forgotten between phases.

## 14. Staged execution and validation
Perform the refactor in stages:
0. baseline capture and current-run duplication measurements;
1. design map / ownership mapping;
2. incremental commit foundation (`HEAD/BASE/COMMIT/INVALIDATE`);
3. cross-phase deduplication and phase ownership;
4. FREEZE PRODUCER execution projection;
5. DECIDE reference adaptation;
6. BUILD reference-only mapping;
7. independent AUDIT adaptation;
8. restart/invalidation hardening;
9. safe token-optimization pass;
10. Claude Opus 4.8 prompt-quality review of changed MemoryTemp contract;
11. final full validation and review.

After **every stage**, run stage-specific validation and a full ScenarioAuthor compatibility review. Classify findings as Critical/High/Medium/Low. Automatically fix all refactor-related Critical, High and Medium findings, rerun both validations, and repeat until all are zero before proceeding. Unrelated pre-existing issues are recorded only and must not expand this task's scope.

## 15. Full-validation definition
Full validation checks:
- current prompt structure and cross-references;
- no obsolete full-snapshot rules remain;
- active-generation/reference consistency;
- no mixed-generation state;
- producer before/after/index continuity;
- DECIDE/BUILD/AUDIT reference flow;
- independent AUDIT preservation;
- UnitTestProjection handoff still resolves the active DECIDE authority;
- external tool contracts remain unchanged;
- §2 dependency/RuleCrawler and §3 semantic execution blocks remain unchanged;
- no new one-letter shorthand dictionary is introduced.

Static validation must not be misreported as runtime execution. Execute every locally available check; identify any unavailable runtime/E2E test explicitly.

## 16. Acceptance criteria
The refactor is complete only when:
1. repeated full ScenarioTrace snapshots are removed;
2. prior facts are referenced through explicit active generations;
3. committed state is immutable and invalidation is deterministic;
4. FREEZE persists ordered producer continuity state;
5. known list index/count state survives into DECIDE;
6. genuine unknown-index fallback remains supported;
7. BUILD no longer transports complete DECIDE rows;
8. AUDIT no longer transports complete upstream state and remains independent;
9. fresh `TC Valid Address Appended` regression is satisfied by general rules;
10. no out-of-scope tool/subsystem contract changed;
11. all refactor-related Critical/High/Medium findings are resolved;
12. token optimization did not remove functionality or safeguards.
