# R28 — RuleCrawler Holder-Provenance Validation

**Scope:** ScenarioAuthor RuleCrawler request planning/audit only. Static direct textual/structural/semantic validation; no live Pega/Claude replay is claimed. No fixtures or hash/checksum/fingerprint acceptance gates are used.

## Runtime change

R27 audited `OUT/ACT` by canonical dependency KEY only. R28 freezes post-selection `REQ=<holder>::<KEY>`, materializes `InterestedRules[]` only from frozen REQs, and reconstructs ACT independently from physical `pyItemRuleId::KEY(reference)`. Exact ordered `OUT==ACT` is required before RuleCrawler.

The RuleCrawler external wire shape remains:

```json
[
  {
    "pyItemRuleId": "<holder>",
    "pxRuleReferences": [...]
  }
]
```

## Focused checks — 17/17 PASS

1. RuleCrawler wire-contract wording unchanged.
2. REQ explicitly defined as selected holder + canonical KEY.
3. OUT/ACT are REQ lists, not KEY-only lists.
4. ACT physical census includes `pyItemRuleId`.
5. Holder fallback/reselection forbidden after freeze.
6. Physical holder must equal frozen REQ holder.
7. Exact ordered OUT==ACT retained.
8. Ordered KEY projection remains equal to READY_KEYS.
9. Holder mismatch is a hard preCall FIX.
10. Response correlation remains KEY-based after holder validation.
11. Old KEY-only OUT/ACT contract removed.
12. No `RulesToCrawl` requirement introduced.
13. Valid multi-holder grouping passes.
14. Full collapse under RUT fails.
15. One dependency assigned to the wrong holder fails.
16. Missing dependency fails.
17. Extra dependency fails.

## Adversarial identity cases

Planned:

```text
RUT::A
RUT::B
DEP1::C
DEP1::D
DEP2::E
```

Expected PASS:

```text
ACT = RUT::A, RUT::B, DEP1::C, DEP1::D, DEP2::E
```

Expected FIX examples:

```text
RUT::A, RUT::B, RUT::C, RUT::D, RUT::E       # holder collapse
RUT::A, RUT::B, DEP1::C, DEP1::D, DEP1::E     # wrong holder
RUT::A, RUT::B, DEP1::C, DEP1::D               # missing E
```

## Token impact

ScenarioAuthor word-count proxy: **9,212 -> 9,283** (+71; about +0.8%). The fix reuses the existing OUT/ACT preCall gate instead of adding a parallel validation mechanism.

## Unchanged runtime areas

Generator, Validator, KnowledgeAreas, target schemas/examples, Memory/tool contracts, canonical dependency KEY construction, READY/CTX/BLOCKED semantics, and RuleCrawler response correlation semantics are unchanged.

## Remaining evidence

Fresh live Pega/Claude replay is still required to prove deployed runtime behavior. The first replay should use the case that previously collapsed different dependency holders under `pyItemRuleId="RUT"`.
