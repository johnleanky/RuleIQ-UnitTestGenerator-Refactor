# R35 — Deterministic Scenario Compiler Dataflow Refactoring

## Goal

Prevent semantic information from disappearing or being reinterpreted across `MAP -> WITNESS -> FREEZE -> DECIDE -> BUILD -> AUDIT -> UnitTestProjectionV3`.

R35 changes the Standard Scenario Compiler from hidden re-derivation to persisted ID-carrying dataflow:

`discover once -> assign immutable id -> persist -> reference/transform by id -> never silently drop`.

The observed regressions motivating this change were:
- missing independent `append + postal-no-stop` physical scenario;
- composite `APPEND_AND_MAP_TO` child producers (`pyCity`, `pyPostalCode`, `pyStreet`) disappearing between MAP/FREEZE;
- several child output assertions collapsing into one `.pyCity` List assertion;
- List fallback losing `page=CustomerCommunication`, which rebased the assertion to the effective primary page.

## Stage 1 — MAP producer inventory

Standard MAP persists immutable `PDEF` rows projected 1:1 from original-RUT RI/PC producer inventory.

`PDEF|producerId|stepPath|parentProducerId-or-|operation|symbolicTarget|sourceExpression-or-|structuralRole`

Rules:
- every PC producer has exactly one PDEF and vice versa;
- explicit composite parent and every scalar/Param child have separate PDEF ids;
- PDEF is Scenario-independent source identity;
- later phases reference PDEF rather than rediscovering the producer tree.

Gate: `set(PDEF.producerId) == set(PC.producer)` before MAP COMMIT.

## Stage 2 — persisted coverage obligations

Standard MAP persists immutable `COV` rows derived from the selected coverage adapter.

`COV|coverageId|kind|orderedOutcomeIds|requirement`

Rules:
- atomic required outcomes and required joint/pair/shape/adapter obligations each get a stable COV id;
- WITNESS Scenario rows carry `coverageIds` actually satisfied by that exact witness;
- minimization occurs only after all executable COV obligations are covered;
- one Scenario may cover several compatible COVs, but no required COV may disappear through minimization.

Gate: union of executable WITNESS `coverageIds` equals active executable MAP COV census.

## Stage 3 — persisted execution matrix

Standard WITNESS persists one `EXEC` row for every `(Scenario,PDEF)` pair:

`EXEC|scenarioId|producerId|executes|skipped|unknown|proof`

The WITNESS execution matrix is complete: no producer execution state may be implicit or absent.

FREEZE carries the final Scenario execution matrix after any witness reduction/replay.

## Stage 4 — deterministic FREEZE producer materialization

FREEZE does not rediscover which producers exist.

For every final `EXEC=executes`, FREEZE emits exactly one matching PRODUCER resolved from PDEF + replay facts. Parent composite producers never substitute child producers. Unknown target index changes only target-resolution state; executing child producers remain present.

Gate:

`set(PRODUCER.(scenarioId,producerId) where executes) == set(EXEC.(scenarioId,producerId) where executes)`.

## Stage 5 — freeze assertion page ownership before representation

Each Standard OUTPUT carries:

`fullTarget`, `basePage`, `relativeTarget`.

For non-Param output, `basePage + relativeTarget` must reconstruct the frozen runtime target. Assertion-kind conversion (`Property`, `List`, `Page`, `ResultCount`) cannot change `basePage`.

Example:
- known index: `Property(page=CustomerCommunication,path=.Addresses(1).pyCity)`;
- unknown index: `List(page=CustomerCommunication,list=.Addresses,... path=.pyCity)`.

A List fallback may not omit `page` when the frozen base is a non-primary named page.

## Stage 6 — persisted producer-to-output lineage

Each producer-derived OUTPUT carries `sourceRefs`: the ordered active PDEF producer-id chain contributing to that final target.

Rules:
- mapped scalar child OUTPUT must include its exact child producer id;
- a composite parent id cannot substitute the child id;
- distinct child leaves remain distinct candidates when index is unknown;
- each persisted semantic id is copied/referenced, transformed while retaining lineage, or explicitly terminated; it may not disappear silently.

Before DECIDE commit, output-eligible executing PDEF ids must reconcile exactly to OUTPUT `sourceRefs` memberships for their final targets.

## Stage 7 — deterministic AUDIT

AUDIT is primarily a reconciliation phase, not a new authoring pass.

It independently checks the immutable source census once, then verifies:
- MAP OUTCOME/COV/PDEF against original RuleJSON/RI-PC;
- exact FREEZE EXEC cartesian census and replay state;
- exact executing PRODUCER equality;
- child PDEF -> OUTPUT.sourceRefs lineage;
- exact OUTPUT <-> DECISION claim-id census;
- OUTPUT `basePage` against independent replay and DECISION representation;
- exact required COV coverage;
- BUILD grouping bijection;
- expected output-key set against actual OUTPUT set.

Missing mapped child, collapsed child outputs, unjustified unknown index, missing named-page base, extra/unsupported output or coverage loss => AUDIT FAIL and invalidation from the earliest owning phase.

## Stage 8 — mechanical Projection serialization

Standard Projection assertions are serialized only from active ASSERT DECISION rows. Projection materialization cannot choose a new assertion kind/page/path/value, rebase a page, merge distinct child claims, rediscover a target, or rerun assertion semantics.

Before internal ids are dropped, each ASSERT DECISION is joined to its same-id OUTPUT and target/context/source lineage is checked.

## Stage 9 — Claude Opus 4.8 prompt pass

Removed stale wording that allowed later phases to rebuild or rediscover upstream facts. Current concise phase ownership is:

- MAP owns OUTCOME/COV/PDEF;
- WITNESS owns SCENARIO+EXEC;
- FREEZE owns final SCENARIO+EXEC+PRODUCER;
- DECIDE owns OUTPUT+DECISION;
- BUILD owns GROUP+LOCATION;
- AUDIT owns AUDIT only.

Downstream phases reference upstream generations through BASE and never recreate their owned rows.

## Scope

Runtime change is intentionally limited to `01_PROMPTS/ScenarioAuthor_SystemPrompt.txt`.

Byte-identical to R34:
- UnitTestGenerator prompt;
- Validator prompt;
- both target JSON schemas;
- both target example libraries;
- all Knowledge Areas;
- all tool contracts.

R34 naming authority, exact two-field external response, `GetAgentMemory(...,SkipPayload=true)`, property `pyPageName`, simulation census and prior RuleCrawler behavior remain unchanged.

## Validation protocol

Every stage is followed by targeted validation + cumulative prior-stage regression + severity review. Any Critical/High/Medium finding is fixed automatically and the current plus all prior validations are rerun.

After all stages, the complete R35 acceptance suite is rerun from scratch. Final acceptance requires `Critical=0, High=0, Medium=0`.
