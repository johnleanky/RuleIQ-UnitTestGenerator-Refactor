# R35 — Deterministic Scenario Compiler Dataflow Validation

## Validation method

Each implementation stage was validated after the actual prompt change. A stage could advance only after targeted checks, cumulative prior-stage regression and severity review reported no unresolved Critical/High/Medium findings. All such findings found during implementation were remediated before continuing.

## Stage results

| Stage | Scope | Result |
|---|---|---|
| 1 | MAP immutable PDEF census | PASS — C0/H0/M0 |
| 2 | persisted COV obligations and coverage-first minimization | PASS — C0/H0/M0 |
| 3 | complete WITNESS/FREEZE EXEC matrix | PASS — C0/H0/M0 |
| 4 | deterministic FREEZE producer set equality | PASS — C0/H0/M0 |
| 5 | OUTPUT basePage/relativeTarget context lock | PASS — C0/H0/M0 |
| 6 | OUTPUT sourceRefs producer lineage / no silent drop | PASS — C0/H0/M0 |
| 7 | deterministic set-reconciliation AUDIT | PASS — C0/H0/M0 |
| 8 | mechanical Projection serialization | PASS — C0/H0/M0 |
| 9 | stale-instruction cleanup / Claude Opus 4.8 prompt pass | PASS — C0/H0/M0 |

Stage 9 remediation removed stale wording that still described WITNESS/FREEZE or DECIDE as rebuilding upstream state. The complete suite was rerun afterwards.

## Fresh full validation

The fresh full acceptance script validates:

- presence/arity/phase ownership of COV/PDEF/EXEC/OUTPUT lineage rows;
- PDEF == PC producer census requirements;
- WITNESS and FREEZE EXEC cartesian completeness;
- executing PRODUCER == executing EXEC set equality;
- child producer preservation under composite mapping;
- sourceRefs lineage and no parent-for-child substitution;
- `basePage` preservation across assertion-kind conversion;
- named-page List fallback requirement;
- deterministic AUDIT equality gates;
- mechanical Projection serialization;
- R34 exact two-key response contract;
- R34 Generator-only technical naming authority;
- R33 `GetAgentMemory(...,SkipPayload=true)` lifecycle;
- existing property `pyPageName` rules;
- both Draft 2020-12 target schemas;
- all six production examples;
- no runtime change to Generator, Validator, target schemas/examples, Knowledge Areas or tools.

Current fresh result:

`Critical=0 / High=0 / Medium=0 / Low=0` for static contract validation.

ScenarioAuthor size: 143,875 characters versus 135,291 in R34 (+6.34%). The increase is attributable to persisted `COV/PDEF/EXEC/basePage/sourceRefs` continuity and fail-closed reconciliation.

## Bad-case simulation

`R35_BAD_CASE_SIMULATION.json` and `R35_BAD_CASE_SIMULATION.md` execute/check the dataflow against the actual RuleJSON and WITNESS inputs from `PXCONV-184019.txt`.

Simulation result: PASS.

Observed bad shapes are rejected independently at WITNESS coverage, FREEZE producer equality, OUTPUT lineage and page-context gates.

Simulation finding: one Low scalability observation (`EXEC` is O(S×P)); no Critical/High/Medium issue.

## Runtime delta

Only `01_PROMPTS/ScenarioAuthor_SystemPrompt.txt` differs from the R34 runtime/contract directories.

The following are byte-identical to R34:
- `01_PROMPTS/UnitTestGenerator_SystemPrompt.txt`
- `01_PROMPTS/Validator_SystemPrompt.txt`
- `03_TARGET_CONTRACTS/*`
- `02_KNOWLEDGE_AREAS/*`
- `04_TOOLS/*`

## Evidence limitation

This validation is static + deterministic simulation. It does **not** claim a fresh live Pega/Claude Opus 4.8 R35 replay. A live replay of `PrepareCustomerCommunication` remains the final external runtime confirmation.

## Final package verification

The final bundle must pass ZIP integrity, fresh extraction, byte-for-byte extracted-vs-working-tree comparison, schema/example validation, R35 prompt gate checks and bad-case simulation-artifact sanity before release. The release described by this report is accepted only if all of those checks pass.
