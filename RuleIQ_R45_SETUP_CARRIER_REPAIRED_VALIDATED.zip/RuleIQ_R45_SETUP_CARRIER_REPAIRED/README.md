# RuleIQ — Fresh Continuation Bundle

## R45 — Generator–Validator synchronization audit

R45 performs a consistency audit of the existing Generator/Validator target boundary without adding any runtime layer or changing ownership. One real conflict was repaired: Rule-Obj-When `valueType` is evidence-only under `CM-WHEN-001` and now is explicitly excluded from Validator target fidelity. One obsolete `adapter` wording was updated to direct Knowledge Area terminology. ScenarioAuthor, Generator, KAs, schemas/examples and tools are unchanged from R44R.

Validation: 115/115 target-sync checks, 49/49 independent architecture/release checks, 6/6 examples schema-valid, 7/7 Candidate corruptions detected; C/H/M/Unresolved=0. See `00_START_HERE/R45_GENERATOR_VALIDATOR_SYNCHRONIZATION_*` and `docs/r45/`.

## R44R — Projection producer-authority restoration

R44R resets from R43 and makes the Projection handoff boundary explicit: ScenarioAuthor alone proves Projection semantic/cross-field correctness before persistence; Generator keeps the complete interface locally but treats it as trusted producer guarantees and validates only transport/readability/correlation plus its own target compilation/fidelity. Validator remains target/fidelity-only. R44 is non-authoritative evidence only.

All Knowledge Areas, target contracts and tool contracts are unchanged from R43. The 11 pre-projection gates and `PREPARE_ALL -> PERSIST_ALL -> GENERATE_ALL` are unchanged. Validation: 145/145 boundary, 125/125 regression, 48/48 architecture-preservation, 131/131 G1–G10, 20/20 fresh-agent; C/H/M=0.

See `00_START_HERE/R44R_PROJECTION_PRODUCER_AUTHORITY_RESTORATION_*` and `docs/r44r/`.

## R43 — Decision Table ownership cleanup

R43 consolidates Decision Table domain ownership in the existing `Rule-Declare-DecisionTable_KnowledgeArea` while Core retains lifecycle and integration. KDT.11 is canonical for direct-DT result-equivalence; Core MAP owns R/E/U coverage rows. Core §3.7 keeps DTM/DTA/DTE consumers, repair, inactive-scalar disposition mapping and KDT.12 audit handling without restating Decision Table algorithms.

Validation: 104/104 semantic, 25/25 adversarial, 64/64 independent G1–G10; C/H/M=0. See `00_START_HERE/R43_DECISION_TABLE_OWNERSHIP_CLEANUP_*` and `docs/r43/`.

## R42.1 — Direct Knowledge Area semantics

R42.1 removes the artificial `SemanticAdapter` abstraction. ScenarioAuthor loads the existing Knowledge Areas directly and requires stable semantic markers: KW.17–KW.25 for original Rule-Obj-When, KDP.6–KDP.12 for Data Page runtime semantics, and KDT.1–KDT.12 for Decision Table semantics. No adapter id/version/header/registry/manifest/runtime contract exists. Missing or duplicate required marker semantics remains fail-closed. Domain/lifecycle boundaries and Core/DWL cross-domain mediation are unchanged.

See `00_START_HERE/R42_1_DIRECT_KA_SEMANTICS_SPEC.md` and `docs/r421/`.

## Contents

- `00_START_HERE/` — authoritative current status and current/historical specification/validation, session handoff, and historical validation record.
- `01_PROMPTS/` — current Scenario Author, Unit Test Generator, Validator prompts.
- `02_KNOWLEDGE_AREAS/` — retained semantic/reference Knowledge Areas only.
- `03_TARGET_CONTRACTS/` — current Standard/MultiInput schemas and examples.
- `04_TOOLS/` — current Memory/tool contracts and required runtime-tool list.

No superseded prompt versions, validation scripts, hashes/checksums, or offline fixtures are included. `VALIDATION_HISTORY.md` is retained only as explicitly non-authoritative historical context.


## R42 — Knowledge-Area boundary hardening

R42 formalizes Decision Table as direct `Rule-Declare-DecisionTable_KnowledgeArea` semantics (KDT.1–KDT.12), removes lifecycle/repair ownership from Data Page/Decision Table KAs, and requires all cross-domain dependencies to flow through ScenarioAuthor Core/DWL. Rule-Obj-When/RUF semantics, ScenarioTrace architecture, Projection/Generator/Validator contracts and target schemas remain functionally unchanged.

Validation: 117/117 focused semantics, 14/14 adversarial loading, independent G1–G10 119/119; C/H/M=0. See `00_START_HERE/R42_KA_BOUNDARY_HARDENING_*` and `docs/r42/`.

## R41 current delta

R41 moves Rule-Obj-When and Data Page **domain semantics** from always-loaded ScenarioAuthor Core into their existing Knowledge Areas while keeping lifecycle, phase/row/BASE, commit/repair, Projection and persistence in Core. Exact required Knowledge Area markers are fail-closed. The migration used shadow equivalence before deleting Core definitions; W01–W25 and DP01–DP20 remain accounted.

Measured context is smaller than R40 in Standard/no-DP, Standard+DP, When/no-DP and When+DP activation patterns. Final static semantic validation: Critical 0 / High 0 / Medium 0. Fresh live Pega/model replay remains pending.

See `00_START_HERE/R41_KA_SEMANTIC_EXTERNALIZATION_SPEC.md`, `00_START_HERE/R41_KA_SEMANTIC_EXTERNALIZATION_VALIDATION.md`, and `docs/r41_ka/`.

## R40 current delta

R40 restores source-grounded original Rule-Obj-When semantics from the old Main Prompt into the current R39C architecture without reintroducing the legacy storage/RuleCode architecture. W01–W25 cover applicability, coverage/MC/DC, execution-backed witnesses, deterministic FREEZE reduction, canonical final ordering, mandatory-row cardinality, simulation grouping, row/path/empty-value semantics, Result dependency closure and independent audit. Target MultInpComb mechanics remain Generator/schema-owned.

Final independent textual-semantic review: W01–W25 PASS; UNMAPPED=0; GAP=0; Critical 0 / High 0 / Medium 0. R39D D1 is explicitly non-authoritative. Fresh live Pega/Opus replay remains pending.

See `00_START_HERE/R40_RULE_OBJ_WHEN_SEMANTIC_RESTORATION_SPEC.md`, `00_START_HERE/R40_RULE_OBJ_WHEN_SEMANTIC_RESTORATION_VALIDATION.md`, and `docs/r40_when/`.

## R39C current delta

Only `ScenarioAuthor_SystemPrompt.txt` changes at runtime from R38. R39C conservatively optimizes prompt execution for Claude Opus 4.8 without redesigning the stable mechanisms: imperative wording, less repeated explanatory prose, explicit compiler phase structure, compact predicates/tables, retained local regression examples, all 11 pre-projection gates, and the full inline ProjectionV3 contract.

Textual-semantic final validation: Critical 0 / High 0 / Medium 0. ScenarioAuthor is 126,137 characters versus 146,684 in R38 (-14.01%). No SHA/hash/diff comparison was used. Live Pega/model replay remains pending.

See:

- `00_START_HERE/R39_CONSERVATIVE_PROMPT_OPTIMIZATION_SPEC.md`
- `00_START_HERE/R39_CONSERVATIVE_PROMPT_OPTIMIZATION_VALIDATION.md`
- `docs/refactor/R39_FINAL_GLOBAL_VALIDATION.md`

## R38 current delta

Only `ScenarioAuthor_SystemPrompt.txt` changes at runtime from R37. R38 enforces left-to-right Property dependency closure for navigation paths, freezes runtime `baseClass` in Standard OUTPUT, and makes non-primary Projection `pages` a mechanical copy of that frozen class lineage. It does not change Generator, Validator, Projection external schema, target contracts, tools, or Rule-Obj-When flow.

See:

- `00_START_HERE/R38_PROPERTY_PATH_CLASS_LINEAGE_HARDENING_SPEC.md`
- `00_START_HERE/R38_PROPERTY_PATH_CLASS_LINEAGE_HARDENING_VALIDATION.md`

## R37 current delta

Only `ScenarioAuthor_SystemPrompt.txt` changes from R36. R37 canonicalizes Standard comparator labels in DECIDE and requires exact kind-specific comparator domains in UnitTestProjectionV3. Projection then copies comparator exactly. The underlying R36 MAP/WITNESS/FREEZE/DECIDE/BUILD/AUDIT architecture remains active.

R36 previously introduced:

- every MAP COV receives WITNESS `RESOLVE=REALIZED|BLOCKED`;
- WITNESS/FREEZE use complete compact `PATH` producer partitions;
- Standard FREEZE uses runtime `EFFECT` instead of verbose `PRODUCER` rows;
- WITNESS Scenario ids must survive unchanged into FREEZE;
- Standard AUDIT traverses the complete `MAP,WITNESS,FREEZE,DECIDE,BUILD` lineage;
- AUDIT FAIL emits deterministic `REPAIR` and triggers automatic generation invalidation/rebuild from the earliest owner.

See:

- `00_START_HERE/R37_CANONICAL_COMPARATOR_CONTRACT_SPEC.md`
- `00_START_HERE/R37_CANONICAL_COMPARATOR_CONTRACT_VALIDATION.md`
- `00_START_HERE/R36_LOSSLESS_COMPACT_SCENARIOTRACE_SPEC.md`
- `00_START_HERE/R36_LOSSLESS_COMPACT_SCENARIOTRACE_VALIDATION.md`
- `00_START_HERE/R36_BAD_CASE_SIMULATION.md`

Static/contract/regression validation: Critical 0 / High 0 / Medium 0. Fresh live Pega/model R38 replay remains pending.
