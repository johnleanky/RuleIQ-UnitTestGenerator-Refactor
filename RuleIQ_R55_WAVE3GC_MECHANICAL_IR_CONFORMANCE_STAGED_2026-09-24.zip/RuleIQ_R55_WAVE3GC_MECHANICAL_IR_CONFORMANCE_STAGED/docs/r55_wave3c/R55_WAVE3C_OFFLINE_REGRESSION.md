# R55 Wave 3C — Combined Offline Regression

Result: PASS (23/23)

## Static / authority checks
- [x] AUTHOR_READY_single_definition
- [x] MAP_requires_AUTHOR_READY
- [x] CRAWL_reset_invalidates_MAP_downstream
- [x] carrier_single_definition
- [x] runtime_state_excluded_from_carrier
- [x] OUTPUT_single_authority
- [x] unknown_index_does_not_drop_child
- [x] AUDIT_boundary_single
- [x] AUDIT_rejects_post_MAP_acquisition
- [x] AUDIT_rebuilds_MAP_from_closed_evidence
- [x] no_case_specific_terms_added_in_W3C_diff
- [x] only_ScenarioAuthor_changed_in_project

## Live-trace regression fixtures (classification, not fresh execution)
- [x] 199074_has_post_MAP_RuleCrawler
- [x] 199014_has_wrong_Addresses3
- [x] 199047_has_concrete_Addresses1
- [x] 199065_carrier_alias_present
- [x] 199065_unknown_append_index
- [x] 199047_output_count_16
- [x] 199065_output_count_10

## Existing R47 suites
- [x] R47_INDEPENDENT
- [x] R47_SOURCE_GATE
- [x] R47_E2E
- [x] R47_FINAL

## Historical validator availability
- R50_VALIDATION.py: not runnable from this bundle; hard-coded prior /mnt/data/r49_work fixture is absent.
- R52_VALIDATION.py: not runnable from this bundle; hard-coded prior /mnt/data/r52_work fixture is absent.
- R46 setup-carrier scripts: not runnable from this bundle; hard-coded R45/old PXCONV fixtures are absent.
- These are recorded as unavailable, not semantic failures.
