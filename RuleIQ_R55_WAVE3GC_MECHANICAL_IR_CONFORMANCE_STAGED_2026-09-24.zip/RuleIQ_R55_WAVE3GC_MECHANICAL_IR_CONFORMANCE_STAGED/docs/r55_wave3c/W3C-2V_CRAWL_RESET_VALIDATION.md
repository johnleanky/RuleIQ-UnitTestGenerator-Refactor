# W3C-2 CRAWL reset validation

Result: PASS (8/8)

- [x] single_crawl_reset_definition
- [x] late_dependency_invalidates_map
- [x] no_map_means_no_scenario_invalidation
- [x] author_restarts_fresh_map
- [x] section_23_points_to_reset
- [x] audit_points_to_reset
- [x] old_affected_semantic_state_phrase_removed
- [x] normal_owner_invalidation_preserved
