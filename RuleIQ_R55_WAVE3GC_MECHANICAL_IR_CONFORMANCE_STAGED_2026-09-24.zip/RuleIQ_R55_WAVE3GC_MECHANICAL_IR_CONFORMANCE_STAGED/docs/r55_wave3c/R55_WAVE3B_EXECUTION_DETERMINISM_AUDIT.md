# R55 Wave 3B — Execution Determinism & Phase-Barrier Audit

## Status

**AUDIT ONLY — COMPLETED**

No ScenarioAuthor prompt change was made in Wave 3B.

Evidence set:
- `PXCONV-199014.txt` — PrepareCustomerCommunication, pre-Wave-3 bad source/target aliasing run.
- `PXCONV-199047.txt` — PrepareCustomerCommunication, Wave-3 concrete-index run.
- `PXCONV-199065.txt` — PrepareCustomerCommunication, Wave-3 unknown-index/List run.
- `PXCONV-199074.txt` — DetermineChannel, Wave-3 premature AUTHOR / incomplete coverage run.
- `ScenarioAuthor_SystemPrompt_R55_W3.txt` — current staged Wave-3 prompt.

## Executive conclusion

Wave 3 removed several textual ambiguities, but live evidence still shows semantic nondeterminism and phase-order failures.

The remaining problem is not best addressed by adding case-specific assertions such as "Addresses must use index 1". The live traces point to a smaller set of architectural/prompt-control issues:

1. AUTHOR readiness is not part of the canonical MAP commit contract.
2. Return-to-CRAWL does not deterministically define which already-committed ScenarioTrace generation is invalidated.
3. WITNESS pre-state carrier ownership is not mechanically separated from pages/state created during RUT execution.
4. Final output/candidate census is distributed across hidden semantic checkpoints and can be recomputed differently.
5. AUDIT can repeat the same upstream interpretation and produce false PASS.

Wave 4 historical/example cleanup should remain deferred until these issues are resolved.

---

## 3B-F001 — AUTHOR barrier is not canonical MAP entry state

**Severity: CRITICAL**

### Evidence

`PXCONV-199074` commits `MAP1` and `WITNESS1`, then issues a later RuleCrawler wave whose own DWL state still contains two READY executable dependencies:
- nested When `IsValidPostalAddress`
- Data Page `D_CustomerTestRef`

So Scenario phases began before dependency closure.

### Prompt cause

The Wave-3 prompt says at orchestration level to run closure until `STATECHECK.preAuthor=PASS`.

It separately says in §2.2/§2.3 that open/READY/CTX/unscanned work blocks AUTHOR.

However §4.1/§4.2 MAP's actual canonical ScenarioTrace commit contract does not consume a canonical `AUTHOR_READY` fact or require the exact preAuthor predicate at MAP entry/commit. MAP's local INPUT says "closed identities", which is descriptive rather than a mechanically bound transition state.

### Consequence

The model can satisfy the local MAP row grammar while still being semantically in CRAWL.

### Classification

`PHASE_BARRIER_GAP / DISTRIBUTED_TRANSITION_AUTHORITY`

---

## 3B-F002 — Return-to-CRAWL invalidation boundary is underdefined

**Severity: CRITICAL**

### Evidence

In `PXCONV-199074`, after late executable dependencies are fetched, the model invalidates only `WITNESS1` and retains `MAP1`.

But MAP1 had already classified the TRUE outcome as unreachable using incomplete dependency semantics. The late evidence therefore affected MAP coverage classification as well as witness setup.

### Prompt cause

§4.1 has a centralized earliest-owner classification:
- new executable dependency/acquisition -> CRAWL
- coverage/classification -> MAP
- witness/setup/SIM -> WITNESS

But `CRAWL` is not a ScenarioTrace generation. The prompt says return to CRAWL, then for a ScenarioTrace owner invalidate that active generation. It does not define one deterministic "reset anchor" for an already-committed semantic chain when CRAWL discovers new executable evidence.

This leaves a choice:
- return to CRAWL but preserve MAP,
- or invalidate MAP,
- or classify the newly learned fact by its later semantic effect.

`PXCONV-199074` chose the first path and lost required coverage.

### Consequence

Late executable evidence may be incorporated into WITNESS while stale MAP classification remains active.

### Classification

`INVALIDATION_ANCHOR_AMBIGUITY`

---

## 3B-F003 — WITNESS pre-state can absorb operation-created target state

**Severity: HIGH**

### Evidence

Three PrepareCustomerCommunication runs show three interpretations of the same source/target model:

1. `PXCONV-199014`
   - simulated source addresses are represented on `CustomerCommunication`
   - FREEZE infers target prior count 2
   - APPEND target becomes `Addresses(3)`

2. `PXCONV-199047`
   - source remains `D_CustomerTestRef`
   - target prior count is 0
   - target becomes `CustomerCommunication.Addresses(1)`

3. `PXCONV-199065`
   - WITNESS2 includes `CustomerCommunication=D_CustomerTestRef`
   - FREEZE treats target prior count as unknown
   - output falls back to List/InAnyInstance

The Model Knowledge contract used in these runs states:
- UPDATE_PAGE WITH_VALUES_FROM sets target/current and a distinct source,
- UPDATE_PAGE auto-creates the target as an empty shell,
- it does not copy/init child properties/lists/groups.

### Prompt cause

The prompt's `EXECUTION_CARRIER(S)` includes "runtime-page pre-state", but does not define one mechanically closed distinction between:
- external pre-execution state,
- source state,
- and state/pages created by an operation during execution.

That allows an operation-derived relationship such as `CustomerCommunication=D_CustomerTestRef` to enter WITNESS setup/pre-state.

### Consequence

The same RUT can produce:
- wrong concrete index,
- correct concrete index,
- or unknown index,
depending on which state interpretation is chosen.

### Classification

`EXECUTION_CARRIER_OWNERSHIP_AMBIGUITY`

---

## 3B-F004 — Final OUTPUT census is not deterministic across equivalent runs

**Severity: HIGH**

### Evidence

For the same PrepareCustomerCommunication RUT:

`PXCONV-199047` DECIDE produces 16 OUTPUT rows:
- S1: 2
- S2: 6
- S3: 1
- S4: 7

`PXCONV-199065` DECIDE produces 10 OUTPUT rows:
- S1: 1
- S2: 5
- S3: 1
- S4: 3

In the second run:
- unknown index correctly changes S2 child representation to List/InAnyInstance,
- but S4 mapped child outputs are dropped altogether,
- structural/count output also differs.

This contradicts the prompt's intended semantics:
- every executed mapped scalar child remains an independent output claim,
- unknown index changes representation, not claim membership,
- parent collection never substitutes child outputs.

### Prompt cause

The canonical output universe is not a committed ScenarioTrace row family.

`RUT_OUTPUTS`, candidate universe, PropertyTrace/LPE/APB/LIC are internal semantic checkpoints. DECIDE consumes/rebuilds them, and AUDIT later rebuilds expected candidates again from final state.

Therefore the same persisted PDEF/PATH/EFFECT chain can still be interpreted into different output censuses.

### Consequence

Two runs can both pass DECIDE/AUDIT but generate materially different test oracles.

### Classification

`NON_FROZEN_OUTPUT_CENSUS / REINTERPRETATION_BRANCH`

---

## 3B-F005 — AUDIT can produce false PASS for materially incorrect semantics

**Severity: CRITICAL**

### Evidence

AUDIT returns PASS in all of these materially different/error states:

- `PXCONV-199014`: source/target aliasing leads to `.Addresses(3)`.
- `PXCONV-199047`: concrete index 1 and larger output census.
- `PXCONV-199065`: unknown-index List representation and reduced output census.
- `PXCONV-199074`: MAP was committed before dependency closure and one reachable branch was excluded.

### Prompt cause

AUDIT is described as independent, but its inputs still include:
- active MAP/WITNESS/FREEZE/DECIDE/BUILD,
- canonical DWL/internal KDT/KDP state,
- hidden semantic checkpoints such as final RUT_OUTPUTS/replay support.

It does not consume a single frozen "semantic input snapshot" that proves:
- AUTHOR entry occurred after closure,
- MAP was derived from that same closed evidence epoch,
- candidate census was derived mechanically from one immutable final execution state.

As a result, AUDIT can repeat the same interpretation rather than falsify it.

### Consequence

`AUDIT=PASS` is currently not a reliable determinism/correctness gate.

### Classification

`AUDIT_SELF_CONFIRMATION / FALSE_PASS`

---

# Cross-finding causal model

The live failures can be described by one common chain:

```text
distributed readiness / hidden semantic state
        ↓
phase may commit from incomplete or differently interpreted evidence
        ↓
late evidence / replay chooses a local owner
        ↓
upstream semantic state may remain stale
        ↓
non-persisted final semantic checkpoints are rebuilt differently
        ↓
DECIDE candidate census/representation changes
        ↓
AUDIT repeats compatible interpretation
        ↓
PASS
```

The important point is that adding more local MUST statements would not remove this chain.

---

# Recommendation

Do **not** proceed to the old Wave 4 yet.

Run a new implementation wave:

## Wave 3C — Deterministic State-Machine Consolidation

Goals:
1. One canonical CRAWL→AUTHOR readiness predicate.
2. One deterministic reset anchor when new executable evidence appears after ScenarioTrace state exists.
3. One definition of external pre-execution carrier vs operation-created runtime state.
4. One owner/algorithm for final output-census derivation.
5. AUDIT validates these canonical boundaries rather than reinterpreting equivalent prose.

Constraints:
- no RUT-specific fixes;
- no Addresses-specific rule;
- no DetermineChannel-specific rule;
- prefer removing/replacing distributed authority over adding parallel safeguards;
- preserve existing target schemas and Generator/Projection contracts;
- one finding at a time with live regression checkpoints.

## Suggested implementation order

### 3C-1 — AUTHOR_READY consolidation
Make §2 dependency state the sole owner of the CRAWL→AUTHOR transition.
MAP should consume that predicate mechanically; remove competing descriptive transition wording elsewhere.

### 3C-2 — CRAWL reset anchor
When a new executable dependency is discovered after MAP exists, define one deterministic semantic reset behavior.
Recommended conservative policy: new executable dependency after MAP invalidates MAP and every downstream ScenarioTrace generation before AUTHOR can resume.

### 3C-3 — Execution carrier boundary
Canonicalize WITNESS carrier as pre-execution external/setup/simulation state only.
Operation-created pages and child state belong to runtime replay/EFFECT unless independently present before RUT execution.

### 3C-4 — Output census authority consolidation
Centralize the complete observable output-census algorithm in one owner.
Unknown position may change representation only; it cannot change child claim membership.
Remove duplicate candidate-universe descriptions from other sections and make DECIDE/AUDIT consume the one algorithm.

### 3C-5 — AUDIT boundary validation
AUDIT should first validate phase/evidence lineage:
- MAP was created only after canonical AUTHOR_READY,
- no later dependency evidence postdates the MAP evidence basis,
- WITNESS/FREEZE carrier respects pre-state/runtime-state boundary,
then validate semantic lineage and output census.

Only after 3C should historical/example cleanup resume.

---

# Acceptance gates for Wave 3C

Before moving to Wave 4:

1. Run PrepareCustomerCommunication at least 3 times:
   - same MAP coverage membership;
   - same WITNESS carrier ownership;
   - same target prior-state interpretation;
   - same FREEZE child effect census;
   - same OUTPUT_KEY census;
   - same assertion representation whenever index knowledge is identical;
   - AUDIT PASS.

2. Run DetermineChannel at least 2 times:
   - no MAP before final dependency closure;
   - TRUE and FALSE original-RUT branch obligations classified from closed evidence;
   - any late executable dependency resets the correct semantic anchor;
   - AUDIT detects intentionally stale MAP fixture if tested.

3. Then perform the 10x determinism gate after remaining cleanup.
