# R55 Wave 3C — Recommended Cleanup Plan

## Objective

Remove the remaining execution nondeterminism by consolidating state-transition and semantic ownership.

This is not an instruction-strengthening wave. The intended operation is:
- choose one canonical owner,
- move the full rule there,
- delete or shorten competing descriptions,
- make downstream phases consume the canonical result mechanically.

## Planned stages

### W3C-1 — AUTHOR_READY transition authority
- Canonical owner: §2 dependency state.
- One exact CRAWL→AUTHOR predicate.
- MAP entry/commit mechanically depends on it.
- §1.4 becomes orchestration reference only.

### W3C-2 — Return-to-CRAWL reset anchor
- Remove choice about which committed ScenarioTrace state survives new executable evidence.
- Conservative proposed behavior: new executable dependency after MAP invalidates MAP+downstream.
- No semantic correction while stale MAP remains active.

### W3C-3 — Execution-carrier boundary
- Define WITNESS carrier as state existing before RUT execution plus external setup/actions/simulations.
- Operation-created targets are runtime state, not WITNESS pre-state, unless independently seeded before execution.
- Centralize this definition; remove equivalent/looser carrier wording elsewhere.

### W3C-4 — Observable output census authority
- One canonical algorithm for RUT-visible output claim membership.
- Composite child claims never disappear because position is unknown.
- Index knowledge only selects Indexed vs List representation.
- DECIDE consumes the census; AUDIT verifies it.

### W3C-5 — AUDIT evidence-boundary validation
- Validate that active semantic generations were derived from one valid closed evidence basis.
- Reject stale MAP after later executable evidence.
- Validate carrier boundary before effect/decision checks.

## Regression after each stage

Static:
- no duplicate transition authority;
- no duplicate carrier definition;
- no duplicate output-membership algorithm.

Live:
- PrepareCustomerCommunication differential checks.
- DetermineChannel phase-order/coverage checks.

## Exit

Only after Wave 3C passes live sanity should Wave 4 remove regression examples/historical residue.
