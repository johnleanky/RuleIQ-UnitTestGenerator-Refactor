# R55 Wave 3G-C — Live Regression Findings from Wave3GB.zip

Source: user-provided `Wave3GB.zip` containing PXCONV-226073, 226083, 226098, 226101.

## Stable improvement from W3G-B

Producer classification is materially stabilized:

- PrepareCustomerCommunication runs have identical RuleJSON SHA prefix `67063c5acfaf5c0d` and both emit 9 PROD.
- DetermineChannel runs have identical RuleJSON SHA prefix `abafaac922914ac8` and both emit 3 PROD.
- UPDATE_PAGE remains a producer.
- EXIT_MODEL remains non-producer.
- WHEN/OTHERWISE remain non-producer.

This validates the KnowledgeArea semantic-signature direction and is not rolled back.

## Remaining defects localized by the live runs

### 1. Edge cardinality/encoding

Prepare 226073 emits 6 atomic EDGEIR rows, but byte-identical Prepare 226083 emits 3 rows whose branchDomain combines TRUE and FALSE in one row. This violates `ROM.WHEN edges=TRUE,FALSE_CONTINUATION`.

Determine 226098 and 226101 create an independent EDGEIR for OTHERWISE even though `ROM.OTHERWISE edges=NONE` and `control=REUSE_REMAINING_FALSE_CONTINUATION`.

W3G-C response: one signature edge token -> one EDGEIR row; `edges=NONE` -> zero rows; OTHERWISE reuses prior false continuation and never receives a T id.

### 2. DEPIR occurrence identity

Prepare 226073 merges multiple source occurrences into single DEPIR locators such as `step1.1/1.2/1.3.1`; Determine 226101 merges `step2.1/3.1`. Fetches may be deduplicated by KEY, but dependency occurrences may not be merged.

Prepare 226083 also places dependencies discovered in fetched When rules into the caller WHEN XMAP.depRefs.

W3G-C response: one syntactic occurrence -> one D/DEPIR row; source-local XMAP.depRefs include only occurrences emitted while scanning that primary source unit in the original RUT holder. Terminal MISSING/LIMIT occurrences remain in depRefs; fetched-holder transitive rows do not.

### 3. Non-canonical source locators and targets

The same RuleJSON uses locators such as `step1.3.1`, `1.3.1`, and `pyProperties(2)`. Determine 226101 also serializes decorated signature ids such as `SIG:ROM.SET`.

Prepare 226083 persists relative producer targets `.Addresses` and `.Addresses(<APPEND>).pyCity` after the named-page context is already known.

W3G-C response: Rule-Obj-Model source locator is exact raw `pyPropertyStepId`; the literal registry signature id is used with no decoration; PROD/PC targets are canonical `Primary...`, `Param...`, or exact named-page-qualified symbolic targets before IR commit.

### 4. COVREQ instability

Prepare 226073 emits 4 COVREQ while byte-identical 226083 emits 3 different relations. Determine 226098/226101 also differ. Some of this is a direct consequence of malformed EDGEIR; relation identity was also too prose-sensitive.

W3G-C response: COVREQ relation identity is canonical relation class + canonical ordered edge ids, with required control-predecessor closure added mechanically. Duplicate prose cannot create another relation. The established Rule-Obj-Model neutral-relation rule remains, but no relation may be guessed when neutral/modifying roles cannot be mechanically identified.

### 5. Decision Table inverse seed

Determine 226098 fetched ChannelCode and reached a deterministic Text `+=` chain whose requested final value was `TestJuneAugust` and ordered suffix was `JuneAugust`, yet rejected the inverse seed.

W3G-C response: KDT.11 now defines exact lexical slicing: suffix=`June`+`August`; require exact terminal suffix; candidate before is the remaining prefix, therefore `Test`; materialize and replay the complete DT/RUT before accepting.

### 6. Missing executed dependency incorrectly bypassed by setup seed

Determine 226101 terminally missed ChannelCode but still pre-seeded `Primary.pyName` and treated the later WHEN as deterministically reachable. A missing executable table may have unknown property side effects on its invocation page, so a pre-call seed does not prove the post-call guard value.

W3G-C response: unresolved executed side-effect sets create `UNKNOWN_WRITE_BOUNDARY(page,callLocator)`. A later overlapping read is UNKNOWN_ENABLEMENT until preservation/no-write is proved or a deterministic post-call write re-establishes the property. WITNESS cannot mark that branch COV REALIZED through a pre-call seed.

## Acceptance target for the next live run

For identical RuleJSON runs:

1. Rule-Obj-Model XMAP unitLocator is exact raw pyPropertyStepId in every run.
2. Prepare has six atomic source edges: 1.1 TRUE/FALSE_CONTINUATION, 1.3 TRUE/FALSE_CONTINUATION, 1.4 TRUE/FALSE_CONTINUATION.
3. Determine has only the WHEN TRUE/FALSE_CONTINUATION edges; OTHERWISE has no T id.
4. Every syntactic dependency occurrence has a distinct D/DEPIR row; same KEY may repeat with different D ids.
5. XMAP.depRefs are source-local and include terminal occurrences; no fetched-holder transitive dependencies leak into caller XMAP.
6. PROD/PC targets are identically canonical and page-qualified.
7. COVREQ relation census is identical across byte-identical runs.
8. Fetched ChannelCode uses KDT inverse seed `Test` for required final `TestJuneAugust` when the selected += chain is June then August and replay validates it.
9. Missing ChannelCode cannot be bypassed by pre-seeding a downstream page property across its unknown write boundary.
