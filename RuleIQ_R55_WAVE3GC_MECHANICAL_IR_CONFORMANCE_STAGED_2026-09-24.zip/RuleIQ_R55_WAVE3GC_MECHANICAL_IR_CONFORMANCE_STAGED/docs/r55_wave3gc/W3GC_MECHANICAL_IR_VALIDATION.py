from pathlib import Path
import json, re, sys

ROOT=Path(__file__).resolve().parents[2]
PROMPT=(ROOT/'01_PROMPTS'/'ScenarioAuthor_SystemPrompt.txt').read_text(encoding='utf-8')
KA=ROOT/'02_KNOWLEDGE_AREAS'

def parse_sigs(path):
    out={}
    for line in path.read_text(encoding='utf-8').splitlines():
        if not line.startswith('SIG|'): continue
        parts=line.split('|'); sid=parts[1]; attrs={}
        for p in parts[2:]:
            if '=' in p:
                k,v=p.split('=',1); attrs[k]=v
        out[sid]=attrs
    return out

rom=parse_sigs(KA/'Rule-Obj-Model_KnowledgeArea_REFERENCE.txt')
kdt=parse_sigs(KA/'Rule-Declare-DecisionTable_KnowledgeArea_REFERENCE.txt')
rop=parse_sigs(KA/'Rule-Obj-Property_KnowledgeArea_REFERENCE.txt')
kw=parse_sigs(KA/'Rule-Obj-When_KnowledgeArea_REFERENCE.txt')

checks=[]
def ck(name,cond,detail=''):
    checks.append({'name':name,'pass':bool(cond),'detail':str(detail)})

# Canonical source identity
ck('ROM signatures expose exact pyPropertyStepId locator', all(v.get('locator')=='exact_raw_pyPropertyStepId' for v in rom.values()), {k:v.get('locator') for k,v in rom.items()})
ck('KW condition locator is deterministic', kw['ROW.CONDITION'].get('locator')=='pyCondition[zero_based_condition_index]')
ck('KDT row/action locators are deterministic', all('locator' in v and v['locator'] for v in kdt.values()))
ck('Prompt forbids decorated signature ids', 'with no `SIG:` prefix or other decoration' in PROMPT)
ck('Prompt binds locator before IR mapping', 'reuse the resulting string everywhere' in PROMPT)

# Edge conformance
ck('ROM WHEN owns two atomic edges', rom['ROM.WHEN']['edges']=='TRUE,FALSE_CONTINUATION')
ck('ROM OTHERWISE owns no edge', rom['ROM.OTHERWISE']['edges']=='NONE')
ck('Prompt requires one edge token per EDGEIR row', 'one EDGEIR row' in PROMPT and 'never serialize two or more edge tokens/domains into one EDGEIR row' in PROMPT)
ck('Prompt forbids OTHERWISE OUTCOME', '`OTHERWISE` owns no OUTCOME because it owns no EDGEIR' in PROMPT)
ck('Prompt has atomic edge commit gate', 'IR_EDGE_ATOMICITY_PASS' in PROMPT)

# Dependency occurrence identity
ck('Prompt keeps same-KEY occurrences separate', 'two occurrences with the same KEY remain two D rows' in PROMPT)
ck('Prompt forbids merged D source locators', 'slash/comma/plus-separated multiple source locators' in PROMPT)
ck('Prompt includes terminal source-local D in XMAP', 'terminal gaps are still occurrences and may not disappear from XMAP' in PROMPT)
ck('Prompt excludes fetched-holder transitive D from caller XMAP', 'transitive D discovered while scanning a fetched When/DT/Model/RUF' in PROMPT)
ck('Prompt has occurrence commit gate', 'IR_DEP_OCCURRENCE_PASS' in PROMPT)

# Property composition / canonical targets
ck('XMAP excludes property-definition metadata from propertySigRefs', 'ROP.PROPERTY_DEFINITION' in PROMPT and 'MUST NOT appear in XMAP.propertySigRefs' in PROMPT)
ck('Canonical root target rule exists', 'leading-dot target in ROOT context becomes `Primary<relativePath>`' in PROMPT)
ck('Canonical named-page target rule exists', 'active named-page CTX becomes `<exactNamedPage><relativePath>`' in PROMPT)
ck('Prompt has target commit gate', 'IR_TARGET_CANON_PASS' in PROMPT)
ck('Symbolic indexes remain non-producers', all(rop[k]['producer']=='NO' for k in ['ROP.SYMINDEX.APPEND','ROP.SYMINDEX.CURRENT','ROP.SYMINDEX.INSERT','ROP.SYMINDEX.LAST','ROP.SYMINDEX.PREPEND']))

# Coverage constructor stability
ck('COVREQ relation ids use control predecessor closure', 'control-predecessor closure' in PROMPT)
ck('COVREQ dedup ignores prose wording', 'never by prose wording' in PROMPT)
ck('ROM adapter retains neutral relation rule', 'emit exactly one `joint` relation `U+Lneutral`' in PROMPT)
ck('ROM adapter does not invent no-neutral pair', 'emit no relation for that pair rather than guess' in PROMPT)
ck('Prompt has COVREQ constructor gate', 'IR_COVREQ_CONSTRUCTOR_PASS' in PROMPT)

# Decision Table / witness hardening
kdt_text=(KA/'Rule-Declare-DecisionTable_KnowledgeArea_REFERENCE.txt').read_text(encoding='utf-8')
ck('KDT inverse text algorithm is lexical/mechanical', 'final `len(suffix)` characters of `final` to equal `suffix` byte-for-byte/case-sensitively' in kdt_text)
ck('KDT inverse regression example gives Test', 'TestJuneAugust' in kdt_text and 'candidateBefore `Test`' in kdt_text)
ck('Unknown dependency write boundary is explicit', 'UNKNOWN_WRITE_BOUNDARY(page,callLocator)' in PROMPT)
ck('Pre-call seed cannot cross unknown write boundary', 'pre-call CARRIER value on that page does not prove a later guard/property read' in PROMPT)
ck('WITNESS cannot realize branch through unknown boundary', 'do not mark its COV REALIZED' in PROMPT)

# Pure mechanical inverse regression
final='TestJuneAugust'; operands=['June','August']; suffix=''.join(operands)
candidate=final[:-len(suffix)] if len(final)>len(suffix) and final[-len(suffix):]==suffix else None
ck('Mechanical inverse regression computes Test', candidate=='Test', {'final':final,'suffix':suffix,'candidate':candidate})

# Replay malformed W3G-B IR fragments against W3G-C gate rules.
def edge_tokens(sig):
    e=sig.get('edges','NONE')
    return [] if e=='NONE' else e.split(',')

def malformed_edge_case(branch_domain, sig_id):
    tokens=edge_tokens(rom[sig_id])
    return branch_domain not in tokens or ',' in branch_domain

ck('Replay rejects combined TRUE/FALSE EDGEIR', malformed_edge_case('TRUE:cityInvalid,FALSE:cityValidContinuation','ROM.WHEN'))
ck('Replay rejects independent OTHERWISE EDGEIR', len(edge_tokens(rom['ROM.OTHERWISE']))==0)
ck('Replay rejects relative known-CTX PROD target', '.Addresses'.startswith('.'))
ck('Replay rejects decorated signatureRef', 'SIG:ROM.SET' not in rom)
ck('Replay rejects metadata-only propertySigRef', rop['ROP.PROPERTY_DEFINITION'].get('compose')!='PROPERTY_REFERENCE')
ck('Replay rejects merged dependency source locator', '/' in 'step1.1/1.2/1.3.1 D_CustomerTestRef.Addresses')

# Expected canonical shape for the fresh Prepare source edges after hardening.
expected_prepare_edges=[('1.1','TRUE'),('1.1','FALSE_CONTINUATION'),('1.3','TRUE'),('1.3','FALSE_CONTINUATION'),('1.4','TRUE'),('1.4','FALSE_CONTINUATION')]
ck('Prepare canonical edge census has six atomic rows', len(expected_prepare_edges)==6 and all(domain in edge_tokens(rom['ROM.WHEN']) for _,domain in expected_prepare_edges), expected_prepare_edges)
expected_determine_edges=[('2','TRUE'),('2','FALSE_CONTINUATION')]
ck('Determine canonical edge census has no OTHERWISE T id', len(expected_determine_edges)==2 and all(domain in edge_tokens(rom['ROM.WHEN']) for _,domain in expected_determine_edges), expected_determine_edges)

failed=[c for c in checks if not c['pass']]
print(json.dumps({'total':len(checks),'passed':len(checks)-len(failed),'failed':len(failed),'failures':failed},indent=2))
sys.exit(1 if failed else 0)
