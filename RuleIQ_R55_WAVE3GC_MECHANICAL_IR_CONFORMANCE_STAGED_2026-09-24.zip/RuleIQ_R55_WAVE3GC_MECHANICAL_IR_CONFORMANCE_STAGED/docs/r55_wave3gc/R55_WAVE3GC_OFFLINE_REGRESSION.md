# R55 Wave 3G-C — Offline Regression

## Scope

Mechanical IR conformance hardening over W3G-B semantic-signature architecture.

Production files changed:

- `01_PROMPTS/ScenarioAuthor_SystemPrompt.txt`
- all six supported KnowledgeArea reference files only to add/consume canonical `locator` metadata and KDT inverse-seed precision

No changes to UnitTestGenerator, Validator, target schemas/examples, Memory contracts, or Projection batching.

## Validation results

- W3G-B semantic-signature regression: **30/30 PASS**
- W3G-C mechanical IR validation: **39/39 PASS**
- R47 independent validation: **18/18 PASS**
- R47 source-gate fixtures: **6/6 PASS**
- R47 DetermineCondition E2E: **2/2 PASS**
- R47 final structural validation: **17/17 PASS**

## W3G-C targeted gates

Validated:

1. exact Rule-Obj-Model source locator = raw `pyPropertyStepId`;
2. exact un-decorated semantic signature id;
3. one declared edge token -> one EDGEIR row;
4. `ROM.OTHERWISE edges=NONE` -> no T id / no OUTCOME;
5. one syntactic dependency occurrence -> one D/DEPIR row;
6. same KEY may deduplicate physical fetch but never occurrence identity;
7. XMAP.depRefs are original-holder source-local and include terminal occurrences;
8. transitive fetched-holder dependencies do not leak into caller XMAP;
9. `ROP.PROPERTY_DEFINITION` excluded from runtime propertySigRefs;
10. PC/PROD targets canonicalized to `Primary`, `Param`, or exact named page before IR commit;
11. COVREQ relation identity uses canonical control-closed ordered edge ids and semantic relation class, not prose;
12. KDT text += inverse seed is exact lexical suffix subtraction;
13. `TestJuneAugust` with `June`,`August` yields before=`Test`;
14. unresolved executed page side effects establish `UNKNOWN_WRITE_BOUNDARY` and cannot be bypassed by pre-call setup.

## Replay of malformed W3G-B live patterns

The W3G-C validator explicitly rejects the forms observed in `Wave3GB.zip`:

- combined `TRUE:...,FALSE:...` branchDomain in one EDGEIR;
- independent EDGEIR for OTHERWISE;
- relative known-context producer target such as `.Addresses`;
- decorated signatureRef such as `SIG:ROM.SET`;
- metadata-only `ROP.PROPERTY_DEFINITION` in XMAP.propertySigRefs;
- merged dependency locator such as `step1.1/1.2/...`;
- inverse-seed failure for `TestJuneAugust` / `JuneAugust`;
- branch realization through a missing Decision Table by pre-seeding the downstream page value.

## Result

Offline gate: **PASS**.

Next required validation is live repetition on byte-identical RUT RuleJSON, preferably:

- `PrepareCustomerCommunication` x3
- `DetermineChannel` x3

Acceptance criteria are listed in `W3GC_LIVE_REGRESSION_FINDINGS.md`.
