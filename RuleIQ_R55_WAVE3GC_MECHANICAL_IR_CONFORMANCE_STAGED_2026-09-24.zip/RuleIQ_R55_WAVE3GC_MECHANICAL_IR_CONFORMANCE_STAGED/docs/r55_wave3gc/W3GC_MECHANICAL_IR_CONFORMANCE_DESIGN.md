# R55 Wave 3G-C — Mechanical IR Conformance Hardening

## Objective

Keep W3G-B semantic signatures as the semantic authority and remove remaining freedom in their transcription into compiler IR.

The target is:

`same RuleJSON + same KA contracts -> same source locators -> same occurrence census -> same atomic EDGEIR/PROD -> same XMAP -> same COVREQ`

## Changes

### Canonical locator contract

`locator` is added to the semantic-signature schema. Rule-Obj-Model signatures use `exact_raw_pyPropertyStepId`. ScenarioAuthor computes the locator once and reuses it in RI, PC, DEP ownership, EDGEIR, PROD and XMAP. No `step`, `pyProperties(...)`, operation label or prose decoration is legal.

### Occurrence identity

Dependency identity remains occurrence-based, not KEY-based. Identical KEYs at different syntactic locations remain separate D ids. KEY deduplication is allowed only for physical fetch. DEPIR copies one occurrence per row and XMAP maps only original-holder source-local occurrences.

### Atomic edges

The `edges` signature field is an ordered token list. Each token produces exactly one EDGEIR row. `edges=NONE` produces none. Reuse controls do not get new ids. This closes the W3G-B gap where TRUE/FALSE were collapsed into one row or OTHERWISE was assigned its own T id.

### Canonical targets

PC and PROD share one page-qualification rule before commit:

- root relative `.X` -> `Primary.X`
- named-page relative `.X` -> `<NamedPage>.X`
- `Param.X` stays `Param.X`
- symbolic indexes stay symbolic until execution (`<APPEND>`, etc.)

### XMAP conformance

`signatureRef` is the exact registry id. `propertySigRefs` contains only runtime `compose=PROPERTY_REFERENCE` modifiers; metadata-only `ROP.PROPERTY_DEFINITION` is excluded. Source-local depRefs include terminal dependency occurrences and exclude dependencies discovered under fetched holders.

### COVREQ identity

Coverage relation membership remains owned by the selected adapter. W3G-C makes serialization deterministic: participating edges are control-closed, canonicalized in EDGEIR order and deduplicated by semantic relation class + ordered edge ids, never by narrative wording. Existing Rule-Obj-Model neutral-relation semantics are preserved.

### KDT inverse seed

Text `+=` inverse resolution is specified as lexical suffix subtraction rather than prose reasoning. `TestJuneAugust - (June + August) -> Test`, followed by complete Decision Table and RUT replay.

### Unknown write boundary

An executed dependency whose write set on an invocation page is unavailable creates an unknown write boundary. Pre-call setup on that page cannot prove a later property read across the boundary. This prevents a missing Decision Table from being bypassed by seeding the desired final guard value.

## Deliberate non-changes

- Projection batching unchanged.
- UnitTestGenerator unchanged.
- Validator unchanged.
- target schemas/examples unchanged.
- W3G-B producer/signature ownership retained.
- no runtime probes introduced.
