# R55 Wave 3E.2 — Lifecycle + Page Context Hardening

## Scope
Cleanup of existing authorities only. No new ScenarioTrace phase, row family, coverage adapter, scenario-identification algorithm, WITNESS/FREEZE semantics, assertion kind schema, or persistence batching model was introduced. `PERSIST_ALL` was intentionally left unchanged.

## Production changes
Only `01_PROMPTS/ScenarioAuthor_SystemPrompt.txt` changed.

### Existing rules repaired/consolidated
1. **Post-IR acquisition** — §2.1.3 now states KnowledgeTool is legal only in `CRAWL`; if a new need appears after IR, the existing §4.1 CRAWL reset must happen first.
2. **Replacement serialization** — existing invalidation rule now means exactly one earliest-owner INVALIDATE, inside the fresh replacement block, after BASE; downstream generations are cleared by that one invalidation and do not get extra INVALIDATE rows.
3. **AUDIT boundary** — existing boundary reconciliation now checks actual MemoryTemp block grammar as well as tool sequence; post-IR acquisition, pre-PHASE/standalone INVALIDATE and multiple INVALIDATE rows are boundary failures.
4. **Page context** — `baseClass` is explicitly the class of `basePage` itself. A descendant embedded/list-item class may be assertion `applyToClass` but can never replace the named-page class.
5. **ORACLE + Projection reconciliation** — existing ORACLE commit gate, pre-projection ROOT/context gate, materialization procedure and §6.4.6 now all compare the non-primary page class to the frozen binding of the base page itself. Projection cannot silently repair a wrong ORACLE baseClass.

## Targeted static validation
13/13 PASS.

## R47 regression
- Independent: 18/18 PASS
- Source gate: 6/6 PASS
- DetermineCondition E2E: 2/2 PASS, 0 schema errors
- Final structural: 17/17 PASS

## Replay classification of W3E.1 live defects under the new contract
- PXCONV-220012 late KnowledgeTool after IR/MAP -> **FAIL / CRAWL reset required before acquisition**.
- PXCONV-220012 WITNESS2 starting with INVALIDATE before PHASE -> **malformed ScenarioTrace block / AUDIT boundary FAIL**.
- PXCONV-219043 ORACLE replacement with ORACLE1 + DECIDE1 invalidations -> **multiple INVALIDATE / AUDIT boundary FAIL**.
- PXCONV-219043 `CustomerCommunication=Data-Address-Postal` while named-page authority is `Data-Customer` -> **ORACLE PAGE_MISMATCH; Projection persistence blocked**.
- PXCONV-220001 ORACLE `baseClass=Data-Address-Postal` while final Projection uses `CustomerCommunication=Data-Customer` -> **frozen-authority reconciliation FAIL; Projection may not repair ORACLE silently**.

These are contract replays, not new live executions.

## Intentionally unchanged
- scenario discovery / MAP coverage logic
- WITNESS/FREEZE semantic algorithms
- OUTPUT membership algorithm except page-context validation
- Generator/Candidate behavior
- Projection write batching/sequencing
- KnowledgeArea files

## SHA256
- W3E.1 baseline: `c95fd02d850042123efcae8caced37538bae475dacf53f9c1f88aa3f8f5c2648`
- W3E.2 ScenarioAuthor: `bb4786fd17e5e24461faf5d5006befab18c7c84029e5034946bf4eac7f740588`

## Live gate
`W3E.2-L = PENDING_USER_RUNTIME`

Recommended live gate: PrepareCustomerCommunication x2 + DetermineChannel x1. Check that wrong page authority never reaches persistence, late acquisition resets before tool call, and any malformed replacement cannot produce AUDIT PASS.
