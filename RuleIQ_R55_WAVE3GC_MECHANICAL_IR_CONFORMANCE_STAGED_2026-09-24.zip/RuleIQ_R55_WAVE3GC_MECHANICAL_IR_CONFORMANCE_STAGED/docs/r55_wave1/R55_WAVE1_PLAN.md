# R55 — Wave 1 Controlled Conflict Resolution Plan

## Status

Planning status: COMPLETED  
Implementation status: NOT_STARTED

Basis:
- Completed R54 prompt audit artifacts from the current conversation.
- User decisions recorded during Wave 1 planning.
- No production prompt changes are authorized by this planning document.

## Locked decisions

### D1 — Physical test minimization, not semantic scenario minimization
The objective is to minimize the number of physical Pega unit tests only after the complete required semantic scenario/coverage set is established.

Rules:
1. MAP/WITNESS/FREEZE determine and preserve the complete required semantic scenario set.
2. No required scenario, atomic coverage obligation, joint/pair/shape/adapter obligation, or material neutral-vs-modifying distinction may be removed or substituted to reduce test count.
3. Physical grouping is a downstream packaging optimization only.
4. Standard mode preserves one FREEZE Scenario per physical Standard test/group.
5. Rule-Obj-When may package multiple compatible Scenario rows into one physical unit test where the target format supports it.
6. Packaging may combine scenarios only when doing so preserves every scenario's independent semantics and assertions.

### D2 — Earliest-owner invalidation
When a later phase detects an upstream defect, invalidate the earliest affected semantic owner and every downstream generation.

Routing:
- new/missing dependency -> CRAWL
- setup / simulation / execution-carrier defect -> WITNESS
- frozen replay/canonicalization defect with valid witness semantics -> FREEZE
- assertion-selection-only defect -> DECIDE
- DECIDE never patches FREEZE or earlier state in place

### D3 — ScenarioAuthor / Candidate representation boundary
Candidate-specific `pyExpectedValue` typing rules must not be appended to the ScenarioAuthor effective system prompt.

Rules:
1. ScenarioAuthor preserves exact lexical Projection values required by its source contract.
2. Candidate/RuleCode target typing remains owned by Generator/downstream target representation.
3. The platform tail will be changed at the source rather than countermanded by an additional ScenarioAuthor override.

## Implementation discipline

Wave 1 is applied one finding at a time:

1. F-001 patch
2. targeted static + semantic checks
3. mark F-001 implementation stage COMPLETED
4. F-012 patch
5. targeted static + routing checks
6. mark F-012 implementation stage COMPLETED
7. F-018 platform-tail patch
8. targeted boundary/lexical checks
9. mark F-018 implementation stage COMPLETED
10. combined Wave 1 regression
11. mark Wave 1 COMPLETED only if all acceptance gates pass

No later finding is edited before the current finding's stage is recorded as COMPLETED.

## Stage 1 — F-001

### Intended change
Replace any global objective that can be read as minimizing Scenario/ScenarioGroup cardinality with an explicit two-level objective:

- semantic correctness and complete required coverage are authoritative;
- physical test-count reduction is permitted only during packaging and only where the physical unit-test format supports grouping without semantic loss.

### Protected invariants
- MAP coverage completeness
- material neutral-vs-modifying distinctions
- atomic/joint/pair/shape/adapter obligations
- WITNESS realization fidelity
- FREEZE membership preservation
- Standard one Scenario -> one physical test/group
- Rule-Obj-When multi-row grouping only where legal

### Acceptance criteria
- No global instruction encourages reducing semantic Scenario count.
- No grouping operation may change FREEZE membership.
- Standard packaging remains 1:1.
- When packaging may be many Scenario rows -> one physical test only if all rows remain separately represented.
- Existing duplicate physical executions may be avoided only after semantic equivalence and full obligation coverage are proven.

## Stage 2 — F-012

### Intended change
Remove the directive to "invalidate DECIDE" for an upstream defect and replace it with direct earliest-owner invalidation.

### Acceptance criteria
- dependency defect routes to CRAWL
- setup/SIM/execution-carrier defect routes to WITNESS
- frozen replay/canonicalization-only defect routes to FREEZE
- assertion-decision-only defect routes to DECIDE
- invalidation always includes all downstream generations
- no in-place upstream patch by DECIDE
- no redundant DECIDE-first invalidation

## Stage 3 — F-018

### Intended change
Remove/scoped-out Candidate-specific `pyExpectedValue` JSON typing guardrails from the ScenarioAuthor platform-appended system tail.

### Acceptance criteria
- ScenarioAuthor effective prompt contains no Candidate/RuleCode typing obligation
- ScenarioAuthor Projection scalar values remain exact lexical strings
- Generator/downstream contract retains target-type conversion responsibility
- no new ScenarioAuthor override is added merely to counteract the platform tail

## Combined Wave 1 regression gate

Wave 1 does not pass on one successful run.

Required checks:
- static prompt lint for the three conflict classes
- semantic comparison of MAP coverage census
- WITNESS realization/carrier equality
- FREEZE Scenario membership/cardinality equality
- DECIDE decision fidelity
- BUILD packaging legality
- Projection lexical-value fidelity
- targeted invalidation-route tests
- targeted Standard vs Rule-Obj-When packaging tests
- repeated PrepareCustomerCommunication executions
- diversified RUT coverage including Rule-Obj-When / MultInpComb

Non-semantic IDs, GUIDs, timestamps and wording may differ. Required semantic state may not.

## Stop conditions

Wave 1 is NOT complete if any of the following remains:
- semantic Scenario minimization pressure
- Standard multi-Scenario physical grouping
- legal When grouping is prevented without semantic reason
- DECIDE-first invalidation for an earlier-owner defect
- Candidate/RuleCode representation semantics in ScenarioAuthor
- regression mismatch in semantic state caused by a Wave 1 change

## Production-change status

Production prompt modified: NO  
Platform tail modified: NO  
Wave 1 implementation started: NO
