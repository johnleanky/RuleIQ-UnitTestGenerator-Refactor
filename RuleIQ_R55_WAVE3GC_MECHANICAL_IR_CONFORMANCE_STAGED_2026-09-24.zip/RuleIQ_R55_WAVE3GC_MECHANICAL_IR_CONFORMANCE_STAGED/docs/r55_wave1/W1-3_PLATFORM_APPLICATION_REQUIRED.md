# W1-3 — Platform configuration application requirement

Status: **NOT APPLIED TO PRODUCTION PLATFORM CONFIGURATION**

The supplied R54/R53 bundle contains the platform-appended system tail only as observed effective-prompt evidence in live traces. It does not contain the editable platform configuration source that injects this tail.

The staged F-018 change is therefore represented by:

- `PLATFORM_TAIL_R54_EFFECTIVE.txt` — exact 42-line observed tail reconstructed from the supplied live trace.
- `PLATFORM_TAIL_R55_PROPOSED.txt` — same tail with only the five Candidate-specific `pyExpectedValue` typing lines removed.
- `W1-3_F018_PLATFORM_TAIL.patch` — exact diff to apply to the ScenarioAuthor platform tail configuration.

Do not add a countermanding `pyExpectedValue` rule to ScenarioAuthor. Apply the staged removal at the platform-tail source, then capture a fresh effective system prompt and verify that the five removed lines are absent.
