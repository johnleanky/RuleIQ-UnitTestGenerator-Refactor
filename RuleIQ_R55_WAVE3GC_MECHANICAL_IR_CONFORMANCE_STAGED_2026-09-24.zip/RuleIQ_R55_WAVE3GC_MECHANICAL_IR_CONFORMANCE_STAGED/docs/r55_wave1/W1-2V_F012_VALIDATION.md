# W1-2V — F-012 Validation

Result: **PASS**

## Checks

- [x] old_decide_first_route_removed
- [x] direct_earliest_owner_rule_present
- [x] dependency_to_crawl
- [x] setup_sim_carrier_to_witness
- [x] replay_only_to_freeze
- [x] decision_only_to_decide
- [x] no_upstream_patch
- [x] canonical_invalidation_primitive_intact
- [x] kdt_owner_map_consistent
- [x] audit_diagnose_earliest_intact
