# W1-1V — F-001 Validation

Result: **PASS**

## Checks

- [x] old_global_minimization_removed
- [x] new_semantic_first_rule_present
- [x] physical_minimization_scoped_to_grouping
- [x] no_semantic_change_guard_present
- [x] map_cov_census_preserved
- [x] witness_coalesce_guard_preserved
- [x] freeze_no_merge_guard_preserved
- [x] standard_one_group_per_freeze_preserved
- [x] when_kw20_grouping_preserved
- [x] projection_standard_one_scenario_preserved
- [x] projection_when_rows_match_scenarios_preserved

## Scope check

- Line count unchanged: 1017
- Changed aligned line numbers: [4]
- Expected: only line 4 for F-001.
