# W3E-5 Acquisition ledger validation

Result: PASS (8/8)

- [x] acqir_phase_row
- [x] acqir_grammar
- [x] acqir_exact_transcript
- [x] duplicate_ka_invalid
- [x] commit_checks_acq
- [x] audit_checks_acq
- [x] no_post_ir_acq
- [x] arity_acq
