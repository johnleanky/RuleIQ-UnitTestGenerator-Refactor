# R55 — Prompt Cleanup Execution State — W3D Live

## Global status

CURRENT_PHASE: W3D_LIVE_REGRESSION_FAILED
W3D_OFFLINE: COMPLETED
W3D_LIVE: FAILED
NEXT_RECOMMENDED_PHASE: W3E_PERSISTED_COMPILER_IR

## Live bundle

`Troubleshooting W3.zip`

## Stage verdict

| Component | Live status |
|---|---|
| AUTHOR_READY / no post-MAP acquisition | PASS across 6 runs |
| UPDATE_PAGE WITH_VALUES_FROM KT.28 cleanup | PASS observed |
| Addresses target-index regression | PASS observed: no Addresses(3) |
| concrete index -> Property representation | PASS observed in Prepare runs |
| canonical SCAN_EVENT_CENSUS | FAIL |
| canonical RUT_SOURCE_CENSUS / MAP COV | FAIL |
| canonical PDEF/producer census | FAIL |
| EXPECTED_OUTPUTS membership | FAIL |
| KnowledgeTool request-once state | FAIL |
| AUDIT canonical reconciliation | FAIL |
| DetermineChannel final semantics | PASS in one run; repeat required |
| Overall W3D-L | FAIL |

## New findings

- W3D-L-F001 CRITICAL — same RuleJSON yields different DWL census/order/wave partition.
- W3D-L-F002 CRITICAL — same RUT yields COV 6/7/8 and PDEF 10/12/13.
- W3D-L-F003 HIGH — same RUT yields OUTPUT 8/10/13.
- W3D-L-F004 HIGH — duplicate KnowledgeArea request still occurs.
- W3D-L-F005 HIGH — DetermineCondition final oracle stable but compiler/carrier state differs.
- W3D-L-F006 CRITICAL — AUDIT PASS does not detect the above divergences.

## Decision

Do not proceed to historical cleanup Wave 4.

Do not add RUT-specific rules.

Recommended: Wave 3E — replace hidden reconstructed compiler censuses with compact persisted canonical IR that MAP/AUDIT consume mechanically.
