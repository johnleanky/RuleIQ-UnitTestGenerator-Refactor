# W3E-3 Persisted carrier validation

Result: PASS (8/8)

- [x] carrier_row_defined
- [x] witness_owns_carrier_rows
- [x] no_hidden_carrier
- [x] scenario_prose_not_authority
- [x] witness_phase_has_CARRIER
- [x] freeze_exact_rows
- [x] projection_from_rows_only
- [x] arity_carrier
