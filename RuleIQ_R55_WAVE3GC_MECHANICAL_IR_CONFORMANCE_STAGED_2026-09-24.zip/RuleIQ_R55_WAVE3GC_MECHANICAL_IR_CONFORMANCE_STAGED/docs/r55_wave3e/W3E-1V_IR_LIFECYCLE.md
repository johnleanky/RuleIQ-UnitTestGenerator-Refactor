# W3E-1 IR lifecycle and producer authority validation

Result: PASS (10/10)

- [x] IR_phase_table
- [x] MAP_base_IR
- [x] HEAD_has_ir
- [x] base_contract_has_IR
- [x] producer_row_is_PROD
- [x] IR_rows_defined
- [x] repair_owner_IR
- [x] crawl_reset_IR
- [x] orchestration_IR_before_MAP
- [x] arity_updated
