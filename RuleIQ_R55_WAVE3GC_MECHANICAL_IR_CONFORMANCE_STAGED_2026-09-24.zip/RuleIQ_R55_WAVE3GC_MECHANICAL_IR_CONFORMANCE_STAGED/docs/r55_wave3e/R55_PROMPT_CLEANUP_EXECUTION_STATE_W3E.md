# R55 — Prompt Cleanup Execution State — Wave 3E

## Global status

CURRENT_PHASE: W3E_COMPLETED_STAGED_OFFLINE
LIVE_PEGA_CHANGED: NO
W3E_LIVE: PENDING_USER_RUNTIME

## Stage ledger

| Stage | Scope | Status |
|---|---|---|
| W3E-0 | Minimal persisted-IR design | COMPLETED |
| W3E-1 | IR lifecycle + migrate producer authority from PDEF to IR.PROD | COMPLETED — 10/10 PASS |
| W3E-2 | Persist ACQ/dependency/source/coverage requirement authority; MAP consumes IR | COMPLETED — 9/9 PASS |
| W3E-3 | Persist exact WITNESS carrier rows | COMPLETED — 8/8 PASS |
| W3E-4 | Split ORACLE OUTPUT from DECIDE DECISION | COMPLETED — 11/11 PASS |
| W3E-5 | Persist acquisition ledger / duplicate-KA gate | COMPLETED — 8/8 PASS |
| W3E-6 | AUDIT canonical reconciliation cleanup | COMPLETED — 9/9 PASS |
| W3E-R | Combined offline regression | COMPLETED — 25/25 PASS |
| W3E-L | Fresh Pega determinism regression | PENDING_USER_RUNTIME |
| W3E-C | Close implementation | COMPLETED_STAGED_OFFLINE |

## Canonical pipeline

`CRAWL -> IR -> MAP -> WITNESS -> FREEZE -> ORACLE -> DECIDE -> BUILD -> AUDIT`

## New persisted authorities

- IR: `ACQIR, DEPIR, EDGEIR, PROD, COVREQ`.
- WITNESS: exact `CARRIER` rows; SCENARIO prose is not setup authority.
- ORACLE: `OUTPUT` membership/order/context.
- DECIDE: `DECISION` only.

## Removed competing authorities

- `PDEF` removed; IR.PROD is sole producer membership authority.
- hidden authoritative `RUT_SOURCE_CENSUS` removed.
- DECIDE no longer owns OUTPUT membership.
- hidden carrier state prohibited.

## Live acceptance gate

For identical RUT RuleJSON/effective prompt, compare **persisted semantic rows**, not prose or arbitrary fixture lexical values.

### PrepareCustomerCommunication — 3 runs
Require exact semantic equality of:
1. ACQIR key/call census;
2. DEPIR identities/order;
3. EDGEIR/PROD/COVREQ identities/order;
4. MAP OUTCOME state + COV membership/order;
5. CARRIER identity census per Scenario;
6. FREEZE PATH/EFFECT target-before/index semantics;
7. ORACLE OUTPUT_KEY/sourceRefs census;
8. DECIDE representation for equal ORACLE+support state;
9. AUDIT PASS only after all prior equalities.

### DetermineCondition — 2 runs
Require identical ACQIR/DEPIR/EDGEIR/PROD/COVREQ/MAP shape and carrier identity census. Duplicate Knowledge key is immediate FAIL. Final oracle equality alone is insufficient.

### DetermineChannel — 2 runs
Require identical IR/MAP and both TRUE/OTHERWISE obligations. No acquisition after IR. Inverse-seed semantics must remain reproducible.

Runtime determinism is not declared solved until these gates pass.

## Prompt metrics

- W3D: 1040 lines / 157510 chars
- W3E: 1075 lines / 162691 chars
- SHA256: `e1c81db16095679fc56c072c7e18a7ab7c0cd08abd14ac8fc7dac9e2ffaa6e56`
