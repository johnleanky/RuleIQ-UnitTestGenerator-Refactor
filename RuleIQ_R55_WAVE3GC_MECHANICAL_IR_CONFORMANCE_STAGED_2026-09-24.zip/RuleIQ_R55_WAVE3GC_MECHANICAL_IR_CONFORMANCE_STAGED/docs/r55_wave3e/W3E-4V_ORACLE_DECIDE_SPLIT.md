# W3E-4 ORACLE/DECIDE split validation

Result: PASS (11/11)

- [x] oracle_phase
- [x] decide_only_decision
- [x] head_oracle
- [x] base_oracle
- [x] owner_split
- [x] oracle_commit_gate
- [x] decide_no_output
- [x] joined_authority
- [x] audit_oracle
- [x] projection_oracle
- [x] head_arity
