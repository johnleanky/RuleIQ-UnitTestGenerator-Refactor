# R55 Wave 3D — Live Regression Analysis

## Status

**W3D-L: FAILED — DETERMINISM NOT ACHIEVED**

Analyzed live bundle: `Troubleshooting W3.zip`

Conversations:
- PXCONV-208009 — PrepareCustomerCommunication
- PXCONV-209030 — PrepareCustomerCommunication
- PXCONV-209011 — PrepareCustomerCommunication
- PXCONV-208028 — DetermineCondition
- PXCONV-208019 — DetermineCondition
- PXCONV-208018 — DetermineChannel

All six conversations use the same effective system prompt.
The three PrepareCustomerCommunication runs use byte-identical original RuleJSON.
The two DetermineCondition runs use byte-identical original RuleJSON.

## What Wave 3D fixed live

1. No UnitTestGenerator call occurs before MAP in any of the six runs.
2. No KnowledgeTool or RuleCrawler call occurs after MAP in any run.
3. Updated Rule-Obj-Model KT.28 is live:
   - WITH_VALUES_FROM changes active source only.
   - it explicitly does not copy source page state to target.
   - target remains an empty shell except for explicit executed child writes.
4. No PrepareCustomerCommunication run produced CustomerCommunication.Addresses(3).
5. Concrete append executions that were materialized used prior target count 0 and target index 1.
6. Concrete list children were represented as Property assertions rather than List fallback in these runs.
7. DetermineChannel final run covers both true and otherwise behavior, including inverse seed `Test -> TestJuneAugust`.

## Critical remaining failures

### W3D-L-F001 — Canonical scan/DWL is still nondeterministic
Severity: CRITICAL

Same PrepareCustomerCommunication RuleJSON + same effective prompt produced three different W1 dependency censuses:

- PXCONV-208009: READY 8 / CTX 2
- PXCONV-209030: READY 7 / CTX 2
- PXCONV-209011: READY 10 / CTX 2

Dependency ids/order and which properties/RUFs appear in W1 vs W2 differ.

Examples:
- child properties pyCity/pyPostalCode/pyStreet are W1 in 208009 and 209011 but W2 in 209030;
- IsInPageListWhen and IndexInPageListWhen RUFs are omitted from W1 in 208009, present in the other two;
- D ids/order differ.

Therefore `SCAN_EVENT_CENSUS` remains a prose instruction, not a canonical materialized compiler artifact.

### W3D-L-F002 — MAP coverage/producer census remains nondeterministic
Severity: CRITICAL

PrepareCustomerCommunication final MAPs:

| Run | OUTCOME | COV | PDEF | Scenarios | Outputs |
|---|---:|---:|---:|---:|---:|
| 208009 | 6 | 7 | 13 | 3 | 8 |
| 209030 | 6 | 6 | 12 | 4 | 13 |
| 209011 | 6 | 8 | 10 | 4 | 10 |

The current coverage policy requires both no-stop joint obligations:
- T3_addrIndexPositive + T6_postalNoMatch
- T4_addrIndexNonPositive + T6_postalNoMatch

Observed:
- 208009 retains only one joint;
- 209030 retains neither;
- 209011 retains both.

Thus `RUT_SOURCE_CENSUS` / adapter obligation projection is not mechanically authoritative in runtime.

### W3D-L-F003 — EXPECTED_OUTPUTS census still diverges
Severity: HIGH

Even with correct concrete target index 1:
- 209030 emits 13 OUTPUT rows.
- 209011 emits 10 OUTPUT rows.
- 208009 emits 8 OUTPUT rows.

209011, for example, omits some Param.AddressIndex / mapped child output claims even though corresponding final effects exist.

The representation dispatch itself is improved for concrete positions, but membership is still non-deterministic.

### W3D-L-F004 — Closed KnowledgeTool state is violated
Severity: HIGH

PXCONV-208028 requests `Rule-Utility-Function_KnowledgeArea` twice:
- once in the initial KnowledgeTool batch;
- again in a later KnowledgeTool call.

This violates the intended `request each key at most once` state.

AUDIT still returns PASS.

### W3D-L-F005 — DetermineCondition compiler state differs despite same final oracle
Severity: HIGH

Both DetermineCondition runs end with the same effective oracle:
- one scenario gives pyTempInteger=6 and pyValue=First;
- the other gives pyTempInteger=5 and pyValue=Second.

However:
- one run uses 4 RuleCrawler calls / 2 KnowledgeTool calls;
- the other uses 5 RuleCrawler calls / 3 KnowledgeTool calls;
- DWL D ids and wave partition differ;
- one run repeats the RUF KnowledgeArea;
- setup carriers differ: one projects extra Primary.pyType/pyPostalCode seeds, the other does not;
- one projection narrative claims "No RuleCrawler waves occurred" although the trace contains RuleCrawler calls.

So output equality does not mean compiler-state determinism.

### W3D-L-F006 — AUDIT reconciliation remains false-pass capable
Severity: CRITICAL

Every run emits AUDIT PASS, including runs with:
- different dependency census for identical RuleJSON;
- different required joint COV census;
- different PDEF census;
- different output census;
- duplicate KnowledgeTool acquisition;
- differing execution carriers.

Therefore AUDIT still cannot independently verify the intended canonical compiler artifacts, because those artifacts are not externally materialized authoritative state.

## Per-run verdict

### PXCONV-208009 — PrepareCustomerCommunication
- KT.28 behavior: improved.
- append target: index 1, no Addresses(3).
- MAP: incomplete required joint census.
- Scenario count: 3 instead of stable 4.
- OUTPUT count: 8.
- AUDIT: false PASS relative to determinism policy.
- Verdict: **SEMANTIC/DETERMINISM FAIL**.

### PXCONV-209030 — PrepareCustomerCommunication
- KT.28 behavior: correct.
- append target: index 1.
- 4 scenarios and 13 outputs.
- however MAP has zero required joint COV rows.
- one FREEZE generation required correction for S4.
- Verdict: **BEST OUTPUT RUN, BUT COVERAGE-CENSUS FAIL**.

### PXCONV-209011 — PrepareCustomerCommunication
- MAP has both required joint COV rows.
- append target index 1.
- 4 scenarios.
- OUTPUT census only 10, dropping expected claims.
- Verdict: **MAP CLOSER TO POLICY, OUTPUT-CENSUS FAIL**.

### PXCONV-208019 — DetermineCondition
- final oracle coherent.
- 4 RuleCrawler / 2 KnowledgeTool calls.
- carrier/setup differs from peer run.
- dependencyClosureTrace says no RuleCrawler waves despite actual RuleCrawler activity.
- Verdict: **FINAL ORACLE PASS / COMPILER DETERMINISM FAIL**.

### PXCONV-208028 — DetermineCondition
- final oracle coherent and matches 208019.
- 5 RuleCrawler / 3 KnowledgeTool calls.
- duplicate Rule-Utility-Function KnowledgeArea request.
- extra Primary carrier seeds.
- Verdict: **FINAL ORACLE PASS / TOOL-STATE + COMPILER DETERMINISM FAIL**.

### PXCONV-208018 — DetermineChannel
- no post-MAP acquisition.
- final MAP has TRUE and OTHERWISE outcomes.
- inverse seed is recovered: Test + June + August -> TestJuneAugust.
- final pyValue assertions First / Second are coherent.
- Generator 2/2 Passed.
- internal FREEZE and DECIDE self-repair occurred before final AUDIT.
- Verdict: **FINAL SEMANTIC PASS; DETERMINISM REQUIRES REPEAT RUN**.

## Architectural conclusion

Wave 3D successfully cleaned domain semantics and phase/tool timing, but it did not make hidden compiler constructs deterministic.

`SCAN_EVENT_CENSUS`, `RUT_SOURCE_CENSUS`, `OP_SEMANTIC_SIGNATURE`, and `EXPECTED_OUTPUTS` are still instructions for the LLM to reconstruct internally. The model can satisfy the prose while constructing different hidden censuses.

The next change should not add more MUST statements. It should reduce model-owned hidden compilation state.

## Recommended next step — Wave 3E: Persisted Compiler IR

Introduce a compact, canonical, persisted intermediate representation before MAP, with deterministic row grammars for at least:
1. dependency occurrence census;
2. original-RUT edge census;
3. producer census;
4. adapter coverage obligation census.

MAP must become a classifier/projection over these persisted rows, not a phase that reconstructs them.

Then FREEZE/DECIDE should consume persisted producer/effect identities, and AUDIT should compare persisted IR sets rather than independently re-reasoning them.

The goal is to move determinism from prose to data/state.
