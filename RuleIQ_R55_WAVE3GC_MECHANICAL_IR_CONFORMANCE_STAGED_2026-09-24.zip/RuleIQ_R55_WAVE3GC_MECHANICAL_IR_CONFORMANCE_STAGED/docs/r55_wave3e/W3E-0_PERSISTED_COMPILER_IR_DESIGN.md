# R55 Wave 3E — Persisted Compiler IR Design

## Decision

Introduce one pre-MAP `IR` ScenarioTrace phase and one post-FREEZE `ORACLE` phase. The purpose is to move compiler census authority from hidden reasoning into immutable rows, not to add RUT-specific rules.

## IR rows

- `ACQIR` — actual pre-IR KnowledgeTool/RuleCrawler acquisition ledger.
- `DEPIR` — final dependency occurrence census.
- `EDGEIR` — original-RUT edge/result membership and order.
- `PROD` — original-RUT producer tree; replaces MAP-owned PDEF.
- `COVREQ` — non-atomic adapter coverage requirements before MAP classification.

## Other persisted authority

- WITNESS `CARRIER` rows are the complete pre-execution carrier; no hidden setup state.
- ORACLE `OUTPUT` rows own final observable output membership/order/context.
- DECIDE owns only `DECISION` rows.

## Pipeline

`CRAWL -> IR -> MAP -> WITNESS -> FREEZE -> ORACLE -> DECIDE -> BUILD -> AUDIT`

## Reduction of duplicate authority

- Removed `PDEF`; `IR.PROD` is the sole producer membership authority.
- Removed hidden authoritative `RUT_SOURCE_CENSUS`; committed EDGEIR/PROD/COVREQ are the authority.
- DECIDE no longer owns OUTPUT membership.
- SCENARIO narrative no longer owns carrier/setup facts.

## Live requirement

Offline validation proves structural consistency only. Determinism is not claimed until repeated Pega runs produce semantically identical IR/ORACLE authority for identical RUT input.
