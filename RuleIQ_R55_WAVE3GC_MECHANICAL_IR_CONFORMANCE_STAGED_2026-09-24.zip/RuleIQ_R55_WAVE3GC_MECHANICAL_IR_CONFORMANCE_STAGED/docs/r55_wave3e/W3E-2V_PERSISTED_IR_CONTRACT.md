# W3E-2 Persisted IR contract validation

Result: PASS (9/9)

- [x] IR_section_exists
- [x] no_hidden_RUT_SOURCE_CENSUS
- [x] MAP_no_source_rescan
- [x] OUTCOME_reuses_edge_id
- [x] COV_from_COVREQ
- [x] joint_owned_by_IR
- [x] infeasible_joint_blocked_in_WITNESS
- [x] IR_commit_exact_DEPIR
- [x] AUDIT_tests_IR_not_hidden
