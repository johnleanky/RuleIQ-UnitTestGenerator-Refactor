# R55 Wave 3F-A — Offline Regression

## Scope

Shadow instrumentation only. No new ScenarioTrace phase. No change to scenario discovery, MAP classification, WITNESS, FREEZE, ORACLE, DECIDE, BUILD, Projection, Generator, KnowledgeArea semantics, or projection-write strategy.

## Prompt delta

W3E2 lines: 1076
W3FA lines: 1093

Added diagnostic row family:
`XMAP|nodeLocator|operation|prodRefs|edgeRefs|depRefs`

XMAP is optional diagnostic instrumentation and is explicitly excluded from every semantic authority/gate.

## Targeted validation

10/10 PASS before final diagnostic-completeness wording; final wording only adds non-semantic comparison-completeness criteria.

Validated:
- no new phase;
- XMAP created only after semantic IR is already complete;
- no second structural census;
- zero semantic authority;
- excluded from semantic IR commit gate;
- no feedback from XMAP to IR;
- absent from downstream authorities;
- absent from Projection/Generator.

## R47 regression

- Independent validation: 18/18 PASS
- Source gate: 6/6 PASS
- DetermineCondition E2E: 2/2 PASS, 0 schema errors
- Final structural validation: 17/17 PASS

All scripts returned exit code 0.

## W3E2 fixture discrimination

Compared byte-identical PrepareCustomerCommunication runs:

PXCONV-226001:
- PROD cardinality = 9
- includes UPDATE_PAGE WITH_VALUES_FROM
- omits EXIT_MODEL

PXCONV-226013:
- PROD cardinality = 9
- omits UPDATE_PAGE
- includes EXIT_MODEL

Fixture checks: 5/5 PASS.

This demonstrates why row-count comparison is insufficient and why node->IR shadow mapping is useful.

## Production footprint

Only `01_PROMPTS/ScenarioAuthor_SystemPrompt.txt` changed.

## SHA256

W3E2: `bb4786fd17e5e24461faf5d5006befab18c7c84029e5034946bf4eac7f740588`
W3FA: `7dc86e67975966b0d9a7e4946915b3650e870078f57dd584cbb19ff25882ef65`

## Live gate

Recommended:
- PrepareCustomerCommunication x3
- DetermineChannel x2

For identical RuleJSON compare exact ordered XMAP rows:
1. nodeLocator
2. operation
3. prodRefs
4. edgeRefs
5. depRefs

Do not judge 3F-A by whether semantic results improve; XMAP has deliberately zero semantic authority.
