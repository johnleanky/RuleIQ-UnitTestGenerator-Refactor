# Wave 3F-A — Shadow IR Classification Mapping

## Purpose

Diagnose whether nondeterminism originates in the transformation from an already-structured original RUT operation tree into semantic IR classifications.

This wave does **not** build a second structural census and does **not** replace any existing semantic authority.

## Diagnostic row

`XMAP|<nodeLocator>|<operation>|<prodRefs-or->|<edgeRefs-or->|<depRefs-or->`

For each executable original-RUT operation node:

- `nodeLocator` — exact existing hierarchical step/source locator.
- `operation` — exact operation kind.
- `prodRefs` — existing PROD ids mapped to this exact operation node.
- `edgeRefs` — existing EDGEIR ids owned by this node's condition/result field.
- `depRefs` — existing DEPIR ids whose source locator is inside this operation node.

## Isolation

XMAP is constructed only after ordinary semantic IR rows are complete and would independently pass the existing semantic IR commit gate.

XMAP has zero authority over:
- AUTHOR_READY
- IR semantic eligibility
- MAP / coverage
- WITNESS / FREEZE
- ORACLE / DECIDE
- BUILD
- repair ownership
- AUDIT PASS/FAIL
- Projection
- Generator

A missing XMAP row makes the 3F-A diagnostic run inconclusive only. It never blocks semantic execution.

## Experimental question

For byte-identical RuleJSON, do repeated runs produce the exact same ordered XMAP rows?

If yes while semantic IR still differs, the nondeterminism is after structural-node classification.
If XMAP itself differs, the nondeterminism is in operation-node -> semantic-IR classification.

## Known W3E2 fixture

Two byte-identical PrepareCustomerCommunication runs both had `PROD=9`, but the content differed:

- PXCONV-226001: includes top-level UPDATE_PAGE producer, omits EXIT_MODEL producer.
- PXCONV-226013: omits top-level UPDATE_PAGE producer, includes EXIT_MODEL producer.

XMAP should expose this difference directly at the relevant operation nodes without affecting either run's scenario generation.
