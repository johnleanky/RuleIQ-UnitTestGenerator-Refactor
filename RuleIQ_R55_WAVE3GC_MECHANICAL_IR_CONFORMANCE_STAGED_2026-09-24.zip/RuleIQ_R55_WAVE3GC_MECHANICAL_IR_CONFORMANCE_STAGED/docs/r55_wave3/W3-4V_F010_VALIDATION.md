# W3-4V — F-010 Validation

Result: **PASS (9/9)**

- relevance_selector_absent: PASS
- missing_relevant_rx_absent: PASS
- later_relevant_absent: PASS
- census_bound_to_scan: PASS
- dependency_rule_present: PASS
- post_exit_explicit: PASS
- ri_si_bound: PASS
- scan_capture_intact: PASS
- source_target_intact: PASS
