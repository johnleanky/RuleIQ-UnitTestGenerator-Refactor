# W3-6V — F-013 Validation

Result: **PASS (7/7)**

- element_defined: PASS
- collection_defined: PASS
- kdp_owns_identity: PASS
- no_separate_concept: PASS
- empty_collection_predicate: PASS
- dp_scope_rx: PASS
- old_no_required_absent: PASS
