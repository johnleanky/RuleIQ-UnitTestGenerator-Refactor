# 3G-A Conflict Resolution Record

This record closes the semantic conflicts identified during the Pega 26.1 comparison before W3G-B signatures were authored.

Canonical decisions:

1. `UPDATE_PAGE + WITH_VALUES_FROM` — current Rule-Obj-Model KA is correct: target is an empty shell; WITH_VALUES_FROM establishes source context; no implicit source-page copy.
2. WITH_VALUES_FROM child operations — current KA is correct.
3. `APPEND_AND_MAP_TO + EXISTING_PAGE` — current KA is correct.
4. Decision Table `pyOrConditions[].pyRowNum` — current KDT zero-based semantics are correct.
5. Decision Table compound property actions — current KDT semantics are correct.
6. Data Page `pyClassName` — current KDP semantics are retained.
7. Data Page `pyScope` — current KDP semantics are retained.

Vocabulary/modeling correction:

- Real Rule-Obj-Model action names include `APPEND_AND_MAP_TO` and `APPEND_TO`.
- Bare `APPEND`, `CURRENT`, `INSERT`, `LAST`, `PREPEND` are symbolic aggregate-property index/reference semantics, not `pyActionName`.
- Their ownership is Rule-Obj-Property KP.11/KP.12.

No runtime probes were introduced. Conflicts were resolved from the project's confirmed domain knowledge and user-provided runtime clarification.
