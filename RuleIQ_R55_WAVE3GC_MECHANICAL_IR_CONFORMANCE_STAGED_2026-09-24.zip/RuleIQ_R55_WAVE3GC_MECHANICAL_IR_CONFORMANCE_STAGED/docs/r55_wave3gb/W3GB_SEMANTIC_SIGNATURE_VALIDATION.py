from pathlib import Path
import re, sys, hashlib, json

ROOT = Path(__file__).resolve().parents[2]
PROMPT = (ROOT/"01_PROMPTS"/"ScenarioAuthor_SystemPrompt.txt").read_text(encoding="utf-8")
KA = ROOT/"02_KNOWLEDGE_AREAS"

def parse_sigs(path):
    out={}
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.startswith("SIG|"):
            continue
        parts=line.split("|")
        sid=parts[1]
        attrs={}
        for p in parts[2:]:
            if "=" in p:
                k,v=p.split("=",1)
                attrs[k]=v
        out[sid]=attrs
    return out

rom=parse_sigs(KA/"Rule-Obj-Model_KnowledgeArea_REFERENCE.txt")
rop=parse_sigs(KA/"Rule-Obj-Property_KnowledgeArea_REFERENCE.txt")
kdt=parse_sigs(KA/"Rule-Declare-DecisionTable_KnowledgeArea_REFERENCE.txt")
kw=parse_sigs(KA/"Rule-Obj-When_KnowledgeArea_REFERENCE.txt")

checks=[]
def ck(name, cond, detail=""):
    checks.append({"name":name,"pass":bool(cond),"detail":str(detail)})

# W3FA1 live-regression failure modes
ck("UPDATE_PAGE is producer", rom["ROM.UPDATE_PAGE"]["producer"]=="YES", rom["ROM.UPDATE_PAGE"])
ck("EXIT_MODEL is not producer", rom["ROM.EXIT_MODEL"]["producer"]=="NO", rom["ROM.EXIT_MODEL"])
ck("WHEN is not producer", rom["ROM.WHEN"]["producer"]=="NO", rom["ROM.WHEN"])
ck("WHEN declares exact TRUE/FALSE edge set", rom["ROM.WHEN"]["edges"]=="TRUE,FALSE_CONTINUATION", rom["ROM.WHEN"])
ck("OTHERWISE adds no independent edge", rom["ROM.OTHERWISE"]["edges"]=="NONE", rom["ROM.OTHERWISE"])
ck("APPEND_AND_MAP_TO is producer", rom["ROM.APPEND_AND_MAP_TO"]["producer"]=="YES", rom["ROM.APPEND_AND_MAP_TO"])
ck("APPEND_TO is producer", rom["ROM.APPEND_TO"]["producer"]=="YES", rom["ROM.APPEND_TO"])
ck("FOR_EACH_PAGE_IN is not producer", rom["ROM.FOR_EACH_PAGE_IN"]["producer"]=="NO", rom["ROM.FOR_EACH_PAGE_IN"])
ck("COMMENT is not producer", rom["ROM.COMMENT"]["producer"]=="NO", rom["ROM.COMMENT"])

# Ownership correction
for sid in ["ROP.SYMINDEX.APPEND","ROP.SYMINDEX.CURRENT","ROP.SYMINDEX.INSERT","ROP.SYMINDEX.LAST","ROP.SYMINDEX.PREPEND"]:
    ck(f"{sid} never independent producer", rop[sid]["producer"]=="NO", rop[sid])
ck("<APPEND> contributes structural effect", rop["ROP.SYMINDEX.APPEND"]["structural"]=="LIST_APPEND_ON_EXECUTED_WRITE")
ck("<CURRENT> is context only", rop["ROP.SYMINDEX.CURRENT"]["structural"]=="NONE" and rop["ROP.SYMINDEX.CURRENT"]["context"]=="ITERATION")
ck("<LAST> does not materialize", rop["ROP.SYMINDEX.LAST"]["structural"]=="NONE")
ck("<PREPEND> contributes prepend effect", rop["ROP.SYMINDEX.PREPEND"]["structural"]=="LIST_PREPEND_ON_EXECUTED_WRITE")

# Decision Table current KA semantics preserved
kdt_text=(KA/"Rule-Declare-DecisionTable_KnowledgeArea_REFERENCE.txt").read_text(encoding="utf-8")
ck("KDT keeps compound operators", all(x in kdt_text for x in ["+=","-=","*=","/=","%="]))
ck("KDT keeps zero-based row semantics", "zero-based row index" in kdt_text)
ck("KDT property action producer conditional", kdt["KDT.ROW_PROPERTY_ACTION"]["producer"]=="CONDITIONAL")

# When dedicated result path preserved
ck("When result is not Standard PROD", kw["WHEN.BOOLEAN_RESULT"]["producer"]=="NO")
ck("When condition edge signature exists", kw["ROW.CONDITION"]["edges"]=="TRUE,FALSE")

# ScenarioAuthor generic classification
ck("Prompt requires registry", "SEMANTIC_SIGNATURE_REGISTRY" in PROMPT)
ck("Prompt uses XMAP signature gate", "XMAP_SIGNATURE_PASS" in PROMPT and "XMAP8" in PROMPT)
ck("Prompt has no hardcoded UPDATE_PAGE classification", "UPDATE_PAGE" not in PROMPT)
ck("Prompt has no hardcoded APPEND_AND_MAP_TO classification", "APPEND_AND_MAP_TO" not in PROMPT)
ck("Prompt has no hardcoded Rule-Obj-Model WHEN edge rule", "For Rule-Obj-Model `WHEN`" not in PROMPT)
ck("PC producer census derives from signatures", "PC membership is a closed mechanical projection of RI" in PROMPT)
ck("Property signatures cannot add producer", "Property-reference signatures never add a PC row" in PROMPT)

failed=[c for c in checks if not c["pass"]]
print(json.dumps({"total":len(checks),"passed":len(checks)-len(failed),"failed":len(failed),"failures":failed}, indent=2))
sys.exit(1 if failed else 0)
