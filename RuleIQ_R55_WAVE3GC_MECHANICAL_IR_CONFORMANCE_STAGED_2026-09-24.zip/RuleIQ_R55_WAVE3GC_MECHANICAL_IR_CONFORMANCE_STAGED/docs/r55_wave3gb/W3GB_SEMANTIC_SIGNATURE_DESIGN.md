# R55 Wave 3G-B — Semantic Signature Architecture

## Goal

Remove LLM discretion from the transformation:

`structured RuleJSON -> semantic source-unit classification -> DEPIR / EDGEIR / PROD`

without creating a second Pega semantic authority inside ScenarioAuthor.

## Authority model

Each KnowledgeArea owns its domain semantics in its existing canonical markers. A new `SemanticSignatureRegistry` is only a normalized index over those markers. If a signature row conflicts with a cited marker, the marker wins and the registry is invalid/fail-closed.

ScenarioAuthor contains no Data Transform action-to-PROD table. It performs one generic algorithm:

`source unit -> primary KA signature -> optional Rule-Obj-Property signature composition -> mechanical IR rows`

## Ownership correction

`APPEND`, `CURRENT`, `INSERT`, `LAST`, and `PREPEND` are not `Rule-Obj-Model.pyActionName` operations. They are symbolic index qualifiers embedded in aggregate-property references.

Their semantics are now owned by `Rule-Obj-Property`:

- `KP.11 PropertyReferenceSymbolicIndexSemantics`
- `KP.12 SemanticSignatureRegistry`

They never create an independent `PROD`. They modify the structural/index effect of an already executing host producer.

Example:

`SET .Items(<APPEND>).Name = "A"`

Composition is:

`ROM.SET producer` + `ROP.SYMINDEX.APPEND structural modifier`

not:

`SET producer` + a second fictitious `APPEND producer`.

The Pega forum discussion used for vocabulary/placement confirmation is:
`https://forums.pega.com/t/what-are-append-current-insert-and-prepend/7543/2`

## Rule-Obj-Model correction

The Clipboard action vocabulary now contains the real action names including:

`APPEND_AND_MAP_TO`, `APPEND_TO`, `OTHERWISE_WHEN`, `EXIT_FOR_EACH`

and no longer treats bare `APPEND`, `PREPEND`, or `INSERT` as `pyActionName`.

`KT.37` is the normalized operation semantic-signature registry.

## Other registries

- Decision Table: `KDT.13`
- Data Page: `KDP.13`
- Rule-Obj-When: `KW.26`
- Rule-Utility-Function: `KRUF.14`
- Rule-Obj-Property: `KP.12`

The Data Page and RUF registries intentionally do not invent loader/function behavior absent from their existing KA contracts. RUF producer semantics remain dynamic and require the fetched concrete function contract.

## XMAP change

W3F-A.1 XMAP was diagnostic only and exposed the nondeterminism without preventing it.

W3G-B XMAP is now signature-conformance evidence:

`XMAP|unitLocator|unitKind|signatureRef|propertySigRefs|prodRefs|edgeRefs|depRefs`

IR commit requires both:

- `XMAP_CENSUS_PASS`
- `XMAP_SIGNATURE_PASS`

XMAP still has no downstream semantic authority. It only proves that IR transcription/classification matches the already-loaded immutable signatures.

## Confirmed conflict resolutions

The current RuleIQ KnowledgeAreas remain canonical for the previously reviewed runtime conflicts, including:

- `UPDATE_PAGE + WITH_VALUES_FROM`: empty target shell + source-context binding, no implicit page copy.
- `APPEND_AND_MAP_TO + EXISTING_PAGE`: current RuleIQ KA behavior.
- Decision Table `pyOrConditions.pyRowNum`: current zero-based KA behavior.
- Decision Table compound property actions: current KDT behavior.
- Data Page `pyClassName`: current KDP behavior.
- Data Page `pyScope`: current KDP behavior.

No runtime probes are introduced.

## Deliberate fail-closed behavior

Known external authoring vocabulary that still lacks confirmed RuleIQ runtime semantics is not guessed into a producer signature. A raw source unit without a resolved signature blocks deterministic IR classification rather than falling back to model intuition.
