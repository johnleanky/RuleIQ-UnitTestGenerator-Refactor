# R55 Wave 3G-B — Offline Regression

## Result

PASS.

### Focused semantic-signature replay

`W3GB_SEMANTIC_SIGNATURE_VALIDATION.py`

- total: 30
- passed: 30
- failed: 0

The focused replay checks the W3F-A.1 live failure modes directly:

- `UPDATE_PAGE` resolves to one producer signature.
- `EXIT_MODEL` resolves to no producer.
- `WHEN` resolves to no producer and exact declared edge semantics.
- `APPEND_AND_MAP_TO` and `APPEND_TO` are real Rule-Obj-Model producer actions.
- `<APPEND>/<CURRENT>/<INSERT>/<LAST>/<PREPEND>` are Rule-Obj-Property signatures with no independent PROD.
- KDT zero-based OR-row association and compound operators remain present.
- original Rule-Obj-When retains its dedicated Boolean-result path.
- ScenarioAuthor contains no hardcoded `UPDATE_PAGE`, `APPEND_AND_MAP_TO`, or Rule-Obj-Model-WHEN classification.

### Existing R47 regression

- independent validation: 18/18
- source-gate validation: 6/6
- DetermineCondition E2E simulation: 2/2
- final structural validation: 17/17

### Runtime boundary preservation

SHA comparison to W3F-A.1 is identical for:

- UnitTestGenerator prompt
- Validator prompt
- Standard target schema/example
- MultiInput target schema/example
- Memory tool contract
- Memory Pega implementation contract

Projection write batching was not changed.

## Historical-script note

R50/R51/R52 validation scripts inside the continuation bundle are not self-contained: they load absolute historical working directories that are not present in this runtime. Attempting R50 therefore raises `FileNotFoundError` before evaluating W3G-B. This is an environment/history dependency, not a W3G-B regression, and is not counted as PASS or FAIL.

## Live replay still required

Offline validation cannot prove model-run determinism. The next live gate remains:

- `PrepareCustomerCommunication` x3
- `DetermineChannel` x3

The key acceptance condition is identical `signatureRef/propertySigRefs -> DEPIR/EDGEIR/PROD` for byte-identical RuleJSON.
