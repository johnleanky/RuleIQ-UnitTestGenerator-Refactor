# R55 Wave 2 — Authority Deduplication

Status: COMPLETED_STAGED_OFFLINE.

Scope: F-002 through F-006 only. This wave removes competing normative definitions and centralizes ownership; it intentionally does not add a source/target-specific fix for the observed Addresses live variability.

Canonicalization performed:
- ScenarioTrace lifecycle/BASE/control -> §4.1 only.
- Non-AUDIT correction owner/invalidation -> §4.1 only.
- AUDIT repair controller -> §4.7 only.
- Standard final decision authority -> §5.1 DECIDE ownership only.
- DECISION->BUILD copy fidelity -> BUILD + independent AUDIT G + Projection reconciliation, no extra pre-projection gate.
- Pre-projection decision state and AUDIT/PASS-chain legality are separate gates.

Offline status:
- Wave 2 static regression 43/43 PASS.
- R47 suites 18/18, 6/6, 2/2, 17/17 PASS.

Live status:
- prior verified live run PXCONV-199014 failed semantically;
- user reports another run passed, trace unavailable;
- no Wave 2 live stability claim is made.
