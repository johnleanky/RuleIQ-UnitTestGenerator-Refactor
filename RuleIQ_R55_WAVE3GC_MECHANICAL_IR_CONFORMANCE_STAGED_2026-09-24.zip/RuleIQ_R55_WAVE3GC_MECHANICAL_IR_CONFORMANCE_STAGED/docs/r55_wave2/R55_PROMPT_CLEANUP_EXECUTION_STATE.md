# R55 — Prompt Cleanup Execution State

## Global status
CURRENT_PHASE: W2_COMPLETED_STAGED_OFFLINE
PRODUCTION_CHANGES: NONE_APPLIED_TO_LIVE_PEGA; WORKING_COPY_PATCHED

## Stage ledger

| Stage | Scope | Status |
|---|---|---|
| W1-P0 | Resolve design questions and lock Wave 1 semantics | COMPLETED |
| W1-1 | Implement F-001 | COMPLETED |
| W1-1V | Validate F-001 | COMPLETED |
| W1-2 | Implement F-012 | COMPLETED |
| W1-2V | Validate F-012 | COMPLETED |
| W1-3 | Implement F-018 | COMPLETED_STAGED |
| W1-3V | Validate F-018 | COMPLETED_OFFLINE |
| W1-R | Combined Wave 1 regression | PARTIAL_OFFLINE_PASS_LIVE_PENDING |
| W1-R-O | Combined offline/static regression | COMPLETED |
| W1-R-L | Fresh live Pega regression | IN_PROGRESS_FAIL_OBSERVED |
| W1-C | Close Wave 1 | BLOCKED_ON_LIVE_REGRESSION |

## Locked decisions from W1-P0

- Optimize physical unit-test count, never semantic Scenario count.
- Standard: one FREEZE Scenario -> one physical Standard test/group.
- Rule-Obj-When: multiple compatible Scenario rows may share one physical unit test where the target format supports it.
- Earliest affected owner is invalidated directly; all downstream state is rebuilt.
- Candidate-specific `pyExpectedValue` typing is removed/scoped out at the ScenarioAuthor platform-tail source.
- Apply and validate one conflict finding at a time.

## Resume rule

On continuation:
1. Read this file.
2. Find the first stage whose status is not COMPLETED.
3. Execute only that stage.
4. Record findings/results.
5. Set that stage to COMPLETED only after its acceptance criteria pass.
6. Only then proceed to the next stage.

## W1-1 execution log

- Started from an exact copy of the frozen R53 ScenarioAuthor prompt.
- Baseline hash recorded before editing.
- Scope restricted to F-001 global objective wording; no other finding is edited in this stage.

### W1-1 result — COMPLETED
- Replaced the single global `minimum valid physical ScenarioGroups` objective.
- New priority: complete semantic coverage first; physical test-count optimization only after coverage is frozen and only through legal §4.5 grouping.
- Explicitly prohibits physical optimization from changing Scenario identity, coverage membership or material distinctions.
- No MAP/WITNESS/FREEZE/BUILD algorithm was changed.

### W1-1V — IN_PROGRESS
- Validating protected invariants and ensuring the patch is limited to F-001.

### W1-1V result — COMPLETED / PASS
- Static validation passed all protected F-001 invariants.
- Baseline and working prompt retain identical line count.
- Only aligned line 4 differs at this checkpoint.
- Standard 1 Scenario -> 1 group/test rule preserved.
- Rule-Obj-When `KW.20` multi-row grouping authority preserved.

### W1-2 — IN_PROGRESS
- Scope restricted to F-012 earliest-owner invalidation conflict.

### W1-2 result — COMPLETED
- Removed the conflicting DECIDE-first invalidation directive.
- DECIDE-discovered upstream defects now route directly to the earliest affected owner and invalidate all downstream generations.
- Routing made explicit: dependency->CRAWL; setup/SIM/execution-carrier->WITNESS; frozen replay/canonicalization-only->FREEZE; assertion-selection-only->DECIDE.
- DECIDE remains prohibited from patching upstream state.

### W1-2V — IN_PROGRESS
- Validating route consistency against §4.1 and phase-local FAIL semantics.

### W1-2V result — COMPLETED / PASS
- Direct earliest-owner routing is consistent with §4.1 invalidation semantics and KDT/AUDIT owner maps.
- The old DECIDE-first directive is absent.
- Downstream invalidation and no-in-place-patch invariants remain intact.

### W1-3 — IN_PROGRESS
- Locating the exact platform-appended Candidate typing guardrail in supplied effective-live evidence.
- Project ScenarioAuthor prompt will not receive a compensating override.

### W1-3 result — COMPLETED_STAGED
- Reconstructed the exact 42-line platform tail from supplied live-trace evidence.
- Prepared an exact F-018 patch removing only the five Candidate-specific `pyExpectedValue` typing lines.
- No compensating override was added to ScenarioAuthor.
- The editable platform configuration source is absent from the supplied bundle, so production application is explicitly not claimed.
- `W1-3_PLATFORM_APPLICATION_REQUIRED.md` records the remaining deployment action.

### W1-3V — IN_PROGRESS
- Validating the staged tail against ScenarioAuthor lexical-source ownership and downstream target contracts.

### W1-3V result — COMPLETED_OFFLINE / PASS
- Proposed platform tail contains no `pyExpectedValue` instruction.
- Composed staged effective prompt contains no Candidate-specific `pyExpectedValue` rule.
- ScenarioAuthor lexical source contract remains intact.
- Both Standard and MultInpComb target schemas explicitly require emitted `pyExpectedValue` to be JSON string and forbid JSON number/boolean/null.
- F-019 wording was intentionally left untouched because it is outside Wave 1.
- Production verification remains pending until the staged tail patch is applied to the real platform config and a fresh effective prompt is captured.

### W1-R — IN_PROGRESS
- Running all offline/static regressions available from the supplied project and validating combined F-001/F-012/F-018 staged state.

### W1-R-O result — COMPLETED / PASS
- New combined Wave 1 offline regression: 30/30 PASS.
- Existing R47 independent validation: 18/18 PASS.
- Existing R47 source-gate fixture validation: 6/6 PASS.
- Existing R47 DetermineCondition E2E simulation: 2/2 PASS with zero schema errors.
- Existing R47 final structural validation: 17/17 PASS.
- Production-directory diff against frozen R53 baseline: only `01_PROMPTS/ScenarioAuthor_SystemPrompt.txt` differs.

### W1-R-L status — BLOCKED_NO_RUNTIME
- Fresh live Pega runtime is not available in the supplied bundle/environment.
- The editable platform-tail source is also not included in the bundle.
- Required to complete: apply `W1-3_F018_PLATFORM_TAIL.patch` to the real ScenarioAuthor platform-tail configuration, capture the effective prompt, run 10 fresh independent PrepareCustomerCommunication executions, and run diversified Rule-Obj-When/MultInpComb cases.
- Do not mark W1-R or W1-C COMPLETED until those live checks pass.


## W1-R-L live execution log

### Live Run 01 — PXCONV-199014 — FAIL

Source:
- User-supplied live Pega conversation `PXCONV-199014.txt`.
- Effective system prompt contains the R55 Wave-1 F-001 and F-012 edits.
- The prior Candidate-specific `pyExpectedValue` typing block is absent from the effective platform tail.

Observed semantic defect:
1. The simulated dependency `D_CustomerTestRef.Addresses` contains two source list items.
2. The RUT uses `UPDATE_PAGE CustomerCommunication WITH_VALUES_FROM D_CustomerTestRef`.
3. The applicable Model Knowledge contract says UPDATE_PAGE creates the target as an empty shell and does not automatically copy/init child properties/lists; WITH_VALUES_FROM changes the active source for child expressions.
4. WITNESS nevertheless serializes the two simulated source addresses as `CustomerCommunication.Addresses(1..2)`, losing execution-carrier/source identity.
5. FREEZE then records APPEND `before={"count":2}` and target `CustomerCommunication.Addresses(3)`.
6. DECIDE commits Property assertions against `.Addresses(3).*`.
7. G002/G004 projections preserve those erroneous `.Addresses(3).*` assertions.
8. AUDIT returns PASS and fails to detect the source/target aliasing.

Expected semantic result:
- Before the APPEND, `CustomerCommunication` is an auto-created target shell; no prior child operation establishes `CustomerCommunication.Addresses`.
- Therefore target `CustomerCommunication.Addresses` prior size is 0.
- The first APPEND target index should be 1, while source index remains `D_CustomerTestRef.Addresses(Param.AddressIndex)` = source item 1 for these scenarios.
- Source index and target append index are independent coordinates.

Earliest invalid owner:
- WITNESS — execution-carrier/simulation-owner defect.
- Under the R55 F-012 routing rule, WITNESS and all downstream phases must be invalidated/rebuilt if this defect is detected.

Regression consequence:
- Wave 1 live semantic-equality gate is FAILED/PENDING.
- Wave 1 closure remains blocked.
- Do not count this execution as a passing run.
- A second user-reported correct run is not counted until its trace is supplied and compared.

New runtime finding:
- `LIVE-W1-001 — Simulation source/target aliasing causes false target-list prior size and wrong concrete append index`.
- Severity: HIGH (wrong final assertions are persisted).
- Status: OPEN.


## Wave 2 — Authority Deduplication

Scope: remove competing normative definitions only; add no new business/semantic behavior.

| Stage | Scope | Status |
|---|---|---|
| W2-0 | Lock Wave 2 scope and baseline | COMPLETED |
| W2-1 | F-002 ScenarioTrace lifecycle/BASE duplication | COMPLETED |
| W2-1V | Validate F-002 | COMPLETED |
| W2-2 | F-003 repair/invalidation duplication | COMPLETED |
| W2-2V | Validate F-003 | COMPLETED |
| W2-3 | F-004 DECIDE authority duplication | COMPLETED |
| W2-3V | Validate F-004 | COMPLETED |
| W2-4 | F-005 redundant Group-copy gate | COMPLETED |
| W2-4V | Validate F-005 | COMPLETED |
| W2-5 | F-006 duplicated AUDIT/PASS pre-projection gates | COMPLETED |
| W2-5V | Validate F-006 | COMPLETED |
| W2-R | Combined Wave 2 offline/static regression | COMPLETED |
| W2-L | Fresh live Wave 2 sanity/regression | PENDING_USER_RUNTIME |
| W2-C | Close Wave 2 implementation | COMPLETED_STAGED_OFFLINE |

### W2-0 result — COMPLETED
- Baseline prompt: `ScenarioAuthor_SystemPrompt_R55_W1.txt`.
- Live variability is retained as regression evidence; no new source/target rule is introduced in Wave 2.
- One normative owner per fact is the governing cleanup principle.
- F-002 through F-006 are executed one finding at a time with validation before the next finding starts.

### W2-1 result — COMPLETED
- §4.1 is now the sole normative owner for ScenarioTrace phase row ownership, BASE dependencies, control-row order, generation/HEAD/COMMIT mechanics and invalidation serialization.
- §1.4 retains only phase order and semantic orchestration pointers.
- Removed duplicated Standard/When pre-MemoryTemp BASE/row tables and replaced them with one reference to §4.1.
- MAP/WITNESS/FREEZE/DECIDE/BUILD/AUDIT local gates retain semantic pass conditions but no longer redefine control rows/BASE/COMMIT.
- No coverage, witness, assertion, grouping or Projection semantic rule was intentionally changed.

### W2-1V result — COMPLETED / PASS
- 20/20 targeted checks PASS after correcting one validation-pattern typo; the prompt was unchanged between validation attempts.
- §4.1 canonical phase table, real incremental MemoryTemp commits, exact BASE dependencies and invalidation primitive remain intact.
- Targeted local BASE/control/COMMIT restatements are removed.
- MAP/WITNESS/FREEZE/DECIDE/BUILD/AUDIT semantic pass invariants remain present.

### W2-2 result — COMPLETED
- Merged non-AUDIT correction routing into one canonical §4.1 owner-classification + invalidation primitive.
- Removed the detailed routing algorithm from §1.4 and local phase FAIL blocks.
- Local sections now identify only semantic ownership or refer to §4.1; they no longer define independent rebuild algorithms.
- §4.7 remains the sole AUDIT diagnosis/REPAIR controller.
- No new correction category was introduced; the central classification is a consolidation of mappings already present in the R55 Wave-1 prompt.

### W2-2V result — COMPLETED / PASS
- 16/16 targeted checks PASS.
- §4.1 invalidation primitive and centralized correction-owner classification are present.
- Explicit KDT/DPA/DECIDE/local-phase route algorithms no longer compete with the canonical controller.
- §4.7 full AUDIT REPAIR controller, no-in-place-patch rule and post-PREPARE boundary remain intact.

### W2-3 result — COMPLETED
- §5.1 DECIDE ownership is retained as the single full normative definition of final Standard decision authority and downstream immutability.
- §1.2 and §1.4 now reference §5.1 instead of restating the rule.
- The §4.1 area now declares only that active-generation resolution comes from §4.1 and decision authority comes from §5.1.
- Downstream BUILD/AUDIT/Projection verification rules were not removed; they remain consumers/verifiers rather than authoring authorities.

### W2-3V result — COMPLETED / PASS
- 12/12 targeted checks PASS.
- §5.1 retains the only full Standard final-decision authority definition.
- Top-level/§4.1 restatements are now references.
- BUILD, independent AUDIT and Projection reconciliation remain intact as consumers/verifiers.

### W2-4 result — COMPLETED
- Removed the separate §5.5 `Group copy` pre-projection gate and renumbered the remaining gates.
- §5.5 now states explicitly that DECISION→BUILD copy fidelity is owned by BUILD, independently verified by AUDIT gate G, and compilation-reconciled by §6.4.6.
- No physical-copy semantic check was removed from its owning/verifying boundary.

### W2-4V result — COMPLETED / PASS
- 19/19 targeted checks PASS.
- The redundant Group-copy gate is absent.
- BUILD assertion-copy invariant, independent AUDIT G and Projection decision reconciliation/census remain intact.
- §5.5 contains exactly 10 numbered gates after renumbering.

### W2-5 result — COMPLETED
- §5.5 Standard decision-state gate now validates only the active §5.1 DECIDE census/support/comparator state.
- Removed HEAD/BASE/AUDIT-chain recomputation from the decision-state gate.
- The Scenario-audit gate remains the single §5.5 owner of active AUDIT/PASS chain legality.

### W2-5V result — COMPLETED / PASS
- 15/15 targeted checks PASS.
- Gate 2 contains only DECIDE census/support/comparator checks and no HEAD/BASE/AUDIT-chain terms.
- Gate 10 remains the sole §5.5 active AUDIT/PASS-chain legality gate.

### W2-R result — COMPLETED / PASS
- Combined Wave 2 static regression: 43/43 PASS.
- R47 independent validation: 18/18 PASS.
- R47 source-gate fixtures: 6/6 PASS.
- R47 DetermineCondition E2E: 2/2 PASS with zero schema errors.
- R47 final structural validation: 17/17 PASS.
- Prompt reduced from 1017 to 995 lines and from 145579 to 144131 characters.
- F-007/F-008/F-009/F-010/F-011/F-013/F-019 and MOVE_TO_TEST/SAFE_TO_REMOVE findings were intentionally not changed in Wave 2.

### Live evidence carried forward
- Live Run 01 `PXCONV-199014`: verified FAIL; source/target carrier/index divergence persisted despite existing rule.
- Live Run 02: user reports PASS on the same general case; trace not supplied, so recorded as `REPORTED_PASS_NOT_INDEPENDENTLY_VERIFIED`.
- Interpretation for planning only: mixed outcomes support continuing prompt simplification rather than adding a case-specific rule.

### W2-C result — COMPLETED_STAGED_OFFLINE
- F-002 through F-006 are implemented and individually validated in the working prompt.
- No live Pega production application is claimed by this checkpoint.
- Fresh Wave-2 live sanity/regression remains `W2-L=PENDING_USER_RUNTIME`.
- Next cleanup wave, if continued, is ambiguity removal (F-007–F-011, F-013, F-019), still under the rule: reduce choices/owners rather than add case-specific instructions.
