# R55 Wave 3F-A.1 — Mandatory Shadow Classification Trace

## Scope

Diagnostic enforcement only. No semantic authority change.

The previous 3F-A live run produced zero XMAP rows because XMAP was optional. 3F-A.1 removes that ambiguity.

## Changes

- Every executable original-RUT operation node MUST serialize exactly one XMAP row.
- Nodes with no semantic mapping still serialize with `-` refs.
- XMAP rows are in canonical operation-node order.
- `XMAP_CENSUS_PASS` requires exact 1:1 node↔XMAP bijection before the IR MemoryTemp call.
- XMAP is still constructed only after the semantic IR is independently complete.
- XMAP cannot add/remove/reclassify/reorder DEPIR/EDGEIR/PROD/COVREQ.
- XMAP remains excluded from MAP, coverage, WITNESS, FREEZE, ORACLE, DECIDE, BUILD, AUDIT PASS/FAIL, Projection and Generator.

## Targeted static validation

10/10 PASS.

## R47 regression

- Independent: 18/18 PASS
- Source gate: 6/6 PASS
- DetermineCondition E2E: 2/2 PASS, 0 schema errors
- Structural: 17/17 PASS

## Prompt size

W3FA: 1093 lines
W3FA1: 1093 lines

No prompt growth; existing XMAP rules were tightened in place.

## SHA256

W3FA: `7dc86e67975966b0d9a7e4946915b3650e870078f57dd584cbb19ff25882ef65`
W3FA1: `57854cfd36853be6db4a820186b454da10898fdd568393ebf834c7ff06ead23b`

## Live acceptance

Run PrepareCustomerCommunication x3.

For each run require:
1. nonzero XMAP census;
2. exactly one XMAP row per executable original-RUT operation node;
3. identical ordered `nodeLocator,operation` across byte-identical RuleJSON;
4. compare `prodRefs/edgeRefs/depRefs` row-by-row.

Semantic output improvement is NOT an acceptance criterion for 3F-A.1.
