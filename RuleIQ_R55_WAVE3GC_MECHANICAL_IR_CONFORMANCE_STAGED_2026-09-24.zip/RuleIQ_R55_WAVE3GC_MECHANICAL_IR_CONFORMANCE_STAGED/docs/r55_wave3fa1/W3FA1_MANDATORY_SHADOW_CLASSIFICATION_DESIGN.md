# Wave 3F-A.1 — Mandatory Shadow Classification Trace

Purpose: force the diagnostic mapping that 3F-A allowed the model to omit.

Row:
`XMAP|nodeLocator|operation|prodRefs|edgeRefs|depRefs`

Rules:
- exactly one row per executable original-RUT operation node;
- canonical operation-node order;
- no classification -> `-`, never omit the node;
- constructed only after semantic IR is already complete;
- only XMAP serialization may be corrected if the XMAP census is incomplete;
- XMAP cannot change semantic IR or any downstream semantic decision.

This wave diagnoses node->IR classification consistency; it does not fix that classification.
