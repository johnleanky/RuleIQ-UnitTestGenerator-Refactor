# W3D-3 canonical original-RUT source census validation

Result: PASS (7/7)

- [x] single_source_census
- [x] edge_true_false_fixed
- [x] otherwise_not_third_edge
- [x] map_consumes_not_rescans
- [x] classification_cannot_merge
- [x] pdef_reconciles_op_census
- [x] commit_detects_merge
