# W3D-1 Canonical scan/DWL validation

Result: PASS (7/7)

- [x] single_scan_census_owner
- [x] no_discovery_order_projection
- [x] request_uses_canonical_ids
- [x] ids_assigned_after_full_census
- [x] later_context_cannot_reorder
- [x] holder_block_check
- [x] pxrefs_not_discovery_authority
