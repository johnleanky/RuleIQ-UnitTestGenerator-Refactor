# R55 Wave 3E.1 — Lifecycle Consistency Repair

## Scope
Cleanup only. No scenario-identification, MAP semantic, WITNESS, FREEZE, ORACLE membership, DECIDE representation, Projection, Generator, or KnowledgeArea semantic algorithm was redesigned.

## Changes
1. Closed TOOL_STATE MemoryTemp phase list now includes `IR` and `ORACLE`.
2. Execution-phase AUDIT chain now includes `ORACLE`.
3. Pre-projection Scenario-audit chain now requires the complete Standard `IR/MAP/WITNESS/FREEZE/ORACLE/DECIDE/BUILD` chain and complete Rule-Obj-When `IR/MAP/FREEZE/BUILD` chain.
4. Post-PREPARE restart prohibition now names the complete lifecycle including `IR` and `ORACLE`.
5. MemoryTemp commit semantics are explicit:
   - a completed invocation is the commit event even with empty/no-result response;
   - response content is not an ACK;
   - the generation id is consumed after the completed call and cannot be retried;
   - replacement requires invalidation + fresh incremented generation;
   - an invocation that itself fails to execute/return control stops the run Failed rather than reusing the generation.
6. Fixed stale ownership sentence: Standard `COV` belongs to MAP, not IR.

## Static consistency validation
12/12 PASS.

## R47 regression
- Independent: 18/18 PASS
- Source gate: 6/6 PASS
- DetermineCondition E2E: 2/2 PASS, 0 schema errors
- Final structural: 17/17 PASS

The Python environment emitted unrelated spreadsheet-runtime warmup warnings after each successful regression process; each regression returned code 0 and its own validation totals PASS.

## Production footprint
Only `01_PROMPTS/ScenarioAuthor_SystemPrompt.txt` changed.
KnowledgeArea files unchanged.

## SHA256
- W3E baseline ScenarioAuthor: `e1c81db16095679fc56c072c7e18a7ab7c0cd08abd14ac8fc7dac9e2ffaa6e56`
- W3E.1 ScenarioAuthor: `c95fd02d850042123efcae8caced37538bae475dacf53f9c1f88aa3f8f5c2648`

## Live status
`W3E.1-L = PENDING_USER_RUNTIME`

Recommended live smoke gate before Wave 3F-A:
- PrepareCustomerCommunication x2
- DetermineCondition x1

Primary checks:
- IR and ORACLE MemoryTemp calls are legal under the sole TOOL_STATE table.
- no repeated `IR1`/same-generation MemoryTemp call after an empty/no-result tool response.
- AUDIT HEAD/BASE resolves the complete active chain.
