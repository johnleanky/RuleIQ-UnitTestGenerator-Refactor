# R55 Wave 3G-B Status

Status: **STAGED / OFFLINE VALIDATED / LIVE REPLAY PENDING**

Baseline: W3F-A.1.

## Runtime footprint

Changed:
- `01_PROMPTS/ScenarioAuthor_SystemPrompt.txt`
- five existing KnowledgeArea reference files
- added `Rule-Obj-Property_KnowledgeArea_REFERENCE.txt`

Unchanged:
- UnitTestGenerator prompt
- Validator prompt
- target schemas/examples
- Memory/tool contracts
- Projection write batching

## Main delta

Producer/control/dependency source classification is now signature-driven from the loaded KnowledgeAreas. ScenarioAuthor no longer contains hardcoded Data Transform action classification.

Symbolic property indices (`<APPEND>`, `<CURRENT>`, `<INSERT>`, `<LAST>`, `<PREPEND>`) are owned by Rule-Obj-Property and compose with, but never replace or duplicate, the host producer.

## Offline gates

- W3G-B focused structural/signature checks: PASS
- W3G-B semantic signature replay checks: PASS
- R47 independent validation: 18/18
- R47 source gate: 6/6
- R47 DetermineCondition E2E: 2/2
- R47 final structural validation: 17/17

Historical R50/R51/R52 scripts are not self-contained in this continuation bundle because they reference removed absolute historical working directories; they were not counted as W3G-B failures.

## Next live gate

Run:
- PrepareCustomerCommunication x3
- DetermineChannel x3

Acceptance:
- byte-identical RuleJSON -> identical source-unit signatureRef/propertySigRefs and identical DEPIR/EDGEIR/PROD.
- UPDATE_PAGE is consistently a producer because `ROM.UPDATE_PAGE` says so.
- EXIT_MODEL is consistently not a producer.
- WHEN is consistently not a producer and has the signature-declared edge set.
- symbolic `<APPEND>/<...>` never appears as an independent operation/PROD.
- existing page/context assertion lineage remains unchanged.
- DetermineChannel compound Decision Table setup remains governed by KDT, not by a ScenarioAuthor special case.
