# R1 Canonical Single-Record Memory Tool Response Contract

**Status:** CURRENT RUNTIME-EVIDENCED CONTRACT  
**Scope:** success-response framing for `WriteMemory`, `GetMemory`, and `UpdateMemory`; exactly one Memory record per invocation.  
**Evidence basis:** supplied live Pega conversations `PXCONV-144028`, `PXCONV-144029`, and `PXCONV-144030`.

This contract deliberately distinguishes **observed success shapes** from **unverified failure shapes**. Agents MUST NOT translate legacy/idealized aliases into the observed contract.

## 1. General parsing rule

A Memory operation is confirmed successful only when its response matches the applicable success shape below, including wrapper location, field names, value types, and required correlation values.

Do not coerce or alias:
- `IsSuccess` to/from `success`;
- response `RouterKey` to/from `pyRouterKey`;
- string `"true"` to/from boolean `true`;
- missing fields to inferred defaults.

Any exception, uncertainty, missing required field, wrong field type, wrong wrapper, wrong correlation value, or otherwise nonconforming response means the operation is **not confirmed**. The caller follows its own fail-closed tool-error path and MUST NOT retry an uncertain write/update.

No failure response shape is canonicalized by R1 because no sufficiently complete live failure response was supplied. Failure payloads remain `UNVERIFIED_RUNTIME_SHAPE`; callers MUST NOT branch on invented `errorCode`, `errorMessage`, `NOT_FOUND`, `WRITE_FAILED`, or `UPDATE_FAILED` fields.

---

## 2. WriteMemory

### Input semantics

```text
WriteMemory(
  pxCaseID,
  Type,
  pyGroup,
  pyPayload
)
```

Input naming is not redefined by R1; this stage changes response parsing only.

### Canonical observed success response

```json
{
  "MemoryToolResponse": {
    "IsSuccess": "true",
    "pxObjClass": "RuleIQ-Data-AgentMemory",
    "pyGroup": "<exact input pyGroup>",
    "pyGUID": "<new nonempty GUID>",
    "pyType": "<exact persisted artifact type>"
  }
}
```

Observed facts:
- the success object is nested under top-level `MemoryToolResponse`;
- `IsSuccess` is the string `"true"`, not a boolean;
- `pxObjClass` is `RuleIQ-Data-AgentMemory`;
- `pyGroup`, `pyGUID`, and `pyType` are returned;
- no `success`, `errorCode`, or `errorMessage` field was present.

### Caller invariants

- Create-only; never overwrite an existing record.
- One call creates at most one record.
- `pyPayload` becomes immutable after successful create.
- Require exact echoed `pyGroup`, expected `pyType`, and a new nonempty GUID.
- No `RequestsJSON`, `ResultsJSON`, Memory `pxResults[]`, row carrier, partial-success, or batch semantics.
- Any nonconforming response means create is unconfirmed; do not continue downstream and do not retry.

---

## 3. GetMemory

### Input semantics

```text
GetMemory(
  pxCaseID,
  pyGUID
)
```

Input naming is not redefined by R1.

### Canonical observed success response

```json
{
  "IsSuccess": true,
  "pxCaseID": "<stored case id>",
  "pyGroup": "<stored group>",
  "RouterKey": "<stored router key or empty>",
  "pyType": "<stored artifact type>",
  "pyPayload": "<stored immutable payload>",
  "pyStatusValue": "<stored lifecycle status or empty>",
  "pyGUID": "<exact requested GUID>"
}
```

Observed facts:
- `IsSuccess` is top-level boolean `true`;
- router response field is `RouterKey`, not `pyRouterKey`;
- the response includes `pxCaseID`, `pyGroup`, `pyType`, `pyPayload`, `pyStatusValue`, and `pyGUID`;
- no `success`, `errorCode`, or `errorMessage` field was present.

### Caller invariants

- Read-only, exact one-record source read.
- Require exact case/GUID/type correlation and required nonempty group/payload.
- Never substitute another row, infer "latest", or reconstruct a missing record.
- Any nonconforming response means the required read is unconfirmed and the workflow stops through the caller's fail-closed read-error path.

---

## 4. UpdateMemory

### Input semantics

```text
UpdateMemory(
  pxCaseID,
  pyGUID,
  pyStatusValue,
  pyRouterKey
)
```

`pyRouterKey` is the observed **input argument name** in the supplied live update call. R1 does not rename it.

Allowed lifecycle pairs remain:

```text
Passed + OK
Failed + GENERATOR_REPAIR
Failed + SEMANTIC_REJECT
Failed + HUMAN
```

### Canonical observed success response

```json
{
  "MemoryToolResponse": {
    "IsSuccess": "true",
    "pxObjClass": "RuleIQ-Data-AgentMemory",
    "pyGUID": "<exact input GUID>",
    "pyStatusValue": "<exact stored status>",
    "RouterKey": "<exact stored router key>"
  }
}
```

Observed facts:
- response is nested under `MemoryToolResponse`;
- `IsSuccess` is the string `"true"`;
- response router field is `RouterKey`, while the input argument remains `pyRouterKey`;
- no `success`, `errorCode`, or `errorMessage` field was present.

### Caller invariants

- Exact one-record lifecycle update.
- Only lifecycle status/router state may change; payload and record identity remain immutable.
- Require exact GUID, requested status, and requested router echo.
- Any nonconforming response means lifecycle update is unconfirmed; stop routing and do not retry.

---

## 5. Failure-shape boundary

R1 has **no evidence-backed canonical Memory failure object**.

Therefore:
- no agent may infer failure semantics from diagnostic text;
- no agent may require or manufacture `errorCode` / `errorMessage`;
- no agent may treat an alias or "close enough" response as success;
- any response that does not satisfy the applicable observed success parser is handled as an unconfirmed tool operation.

When a real Pega failure trace is captured, update this contract from that evidence before adding branchable failure fields.

---

## 6. Batch boundary

These tools intentionally do not support batch operations.

If batch Memory operations are needed later, create a separate explicitly named tool and contract. Do not extend these three tools with arrays or carrier JSON.

This restriction does **not** apply to other tools such as KnowledgeTool that legitimately return `pxResults[]`.
