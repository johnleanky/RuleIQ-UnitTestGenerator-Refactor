# Runtime Tool Dependencies

## Implemented / specified in this package

- `WriteMemory` — single-record create-only persistence. See `Memory_GenAI_Tools_Contract.md` and `Memory_GenAI_Tools_Pega_Implementation_Spec.md`.
- `GetMemory` — single-record exact read with case/GUID correlation.
- `UpdateMemory` — single-record lifecycle-only update.
- `ValidatorReport_JsonSchema.txt` — machine-readable R6 structural contract for the delegated Validator report. The required non-LLM adapter behavior is specified below; live Pega deployment is not claimed by this package.

The Memory success-response contract is runtime-evidenced and uses the actual observed Pega fields/wrappers. Non-success/failure Memory response shapes remain `UNVERIFIED_RUNTIME_SHAPE` until a live failure trace is captured.

## Existing external tools referenced by the current prompts

The following tools are required by the prompts but their implementations are not redefined in this package:

- `KnowledgeTool` — retrieves KnowledgeArea / JsonSchema / JsonExample content by exact configured key.
- `RuleCrawler` — retrieves RUT/dependency rule information for Author semantic analysis.
- `JsonValidationTool` — validates candidate JSON against the selected target JSON Schema.
- Pega Agent invocation / `question` mechanism — used by Author -> Generator and Generator -> Validator.

## JsonValidationTool — R1 observed response boundary

Supplied live success response:

```json
{
  "message": "JSON_VALID| JSON is valid against the schema",
  "IsValid": true
}
```

Canonical R1 success parser:
- top-level `IsValid` must be boolean `true`;
- top-level `message` must be a string beginning with `JSON_VALID|`;
- no `Success`, `ValidationMessage`, `ErrorCode`, or `ErrorMessage` field is required or inferred.

No supplied trace establishes the exact response for:
- schema-invalid candidate (`IsValid=false` or another shape);
- transport/tool exception;
- any error-code/message envelope.

Those paths are `UNVERIFIED_RUNTIME_SHAPE`. Until live evidence exists, Validator must fail closed to its tool-error/HUMAN path rather than invent an invalid-schema disposition from undocumented fields or message text.

The current prompts remain authoritative for call timing. This file is authoritative for the external JsonValidation response boundary evidenced in R1.

## ValidatorReport structural boundary — R6 required runtime contract

`UnitTestValidator` is a delegated Pega Agent invocation. The supplied live trace shows the delegated tool returning an outer JSON envelope whose `response` field contains the nested model output as a string. R6 does **not** treat that nested string as trusted Generator input.

Authoritative machine-readable report schema: `ValidatorReport_JsonSchema.txt`.

The runtime integration MUST place a deterministic, non-LLM adapter between the delegated Validator response and UnitTestGenerator. This adapter is a deployment requirement; this bundle specifies and validates its contract but does not claim that the live Pega environment has already been redeployed with it.

Required boundary algorithm, in this exact order:

1. Require the delegated-agent envelope to be exactly one JSON object with exactly one field, `response`, whose value is a string. Do not accept extra envelope fields and do not search any other field for report content.
2. Parse the **entire** response string as one JSON value using a parser that rejects duplicate object keys, multiple JSON values, non-finite numbers (`NaN`, `Infinity`), prose/Markdown/code fences, and any non-whitespace prefix/suffix. Ordinary surrounding JSON whitespace is allowed. No substring extraction or "find the last `{...}`" recovery is allowed.
3. Require the parsed value to be exactly one JSON object and validate it against `ValidatorReport_JsonSchema.txt`. `additionalProperties=false` at report and issue level is authoritative.
4. With the exact invocation context, require non-null exact `CaseID`, exact `RUTType`, exact `sourceUUID=UnitTestProjectionUUID`, and exact `UnitTestCandidateUUID=current Candidate GUID`.
5. Validate `groupId` against the frozen source `pyGroup`. A null group is allowed only in the pre-correlation cases already defined by the synchronized Generator/Validator contract; otherwise exact group equality is required.
6. Require `warnings=0` and `blocking == len(issues)`.
7. Require every issue to use one schema-admitted code/action pair. Recompute route from actions with strict precedence `HUMAN_REVIEW > REJECT_SEMANTICS > repair action > zero issues`, and require exact equality with reported `route`.
8. Only after all checks pass may the adapter expose the parsed ValidatorReport object to Generator. On any failure, expose **no nested response text and no issue list** as Generator repair input; signal the boundary failure so Generator terminates the current path as `VALIDATOR_RESPONSE_INVALID`.

The adapter must not repair, normalize, delete fields, coerce values, reorder issues, reinterpret aliases, or convert prose into JSON. Its role is acceptance/rejection only.

### R6 deployment boundary

The schema and adapter contract are part of this bundle and can be statically validated. Actual live Pega deployment of the adapter is external runtime evidence. Until that deployment is verified, a raw delegated `{"response":"..."}` envelope reaching Generator is treated as a noncompliant integration and must fail closed as `VALIDATOR_RESPONSE_INVALID`.

