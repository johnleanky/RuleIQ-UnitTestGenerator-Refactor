# RuleIQ Unit Test Pipeline — Current Status

**Bundle date:** 2026-09-14  
**Authority:** this bundle contains the only current project version. No superseded prompts, historical plans, hashes/checksums, or regression fixtures are included.

## Current architecture

- **Scenario Author** owns RUT semantics, dependency closure, Pega casting/type semantics, scenario construction/grouping, assertions/simulations, and `UnitTestProjectionV3`.
- **Unit Test Generator** is a deterministic `UnitTestProjectionV3 -> Candidate` compiler and persists one Candidate at a time.
- **Validator** independently reads Projection + Candidate and checks schema/fidelity/target invariants without redefining Author semantics.

## Current execution order

```text
Global dependency closure + semantic execution
-> I -> W -> F
-> freeze complete physical group set
-> B -> A, require A=PASS
-> for each frozen physical group in order:
     materialize one Projection
     -> self-validate
     -> WriteMemory
     -> invoke UnitTestGenerator once
     -> require terminal correlated GeneratorRunReport
     -> next group
```

Dependencies are resolved globally before Projection processing. Reused dependencies should therefore reuse already resolved evidence rather than being re-crawled per Projection. Parameterized Data Page invocations may still have distinct normalized invocation semantics even when the rule definition is reused.

After the first successful Projection `WriteMemory`, any need for semantic regrouping/reinterpretation terminates that Author run; already persisted artifacts remain immutable.

## Current contracts

- Memory tools are strictly single-record: `WriteMemory`, `GetMemory`, `UpdateMemory`.
- `pyPayload` is immutable after create.
- Generator/Validator share the Standard and MultiInput Knowledge Areas in this bundle.
- Target examples are the latest coverage-rich canonical examples, including List `InAllInstances` / `InAnyInstance` and the current supported comparator forms.

## Evidence boundary

Static/contract validation has been completed for the current design. Live Pega KnowledgeTool deployment verification (A4) and end-to-end runtime/model/Pega trials (A9) are still external evidence steps and must not be claimed as completed.

---

## Pending Refactoring Plan — 2026-09-14

**Plan status:** `COMPLETE / R0-R8 PASS (STATIC) / LIVE PEGA REVALIDATION PENDING`  
**Execution lock:** no implementation stage may start until explicit user approval.  
**Analysis-mode flag:** `TEXT_SEMANTIC_ONLY=true`  
**Hashing prohibition:** when reading, comparing, validating, or tracing bundle files, do not compute or use SHA/SHA-1/SHA-2/SHA-256/SHA-512, MD5, CRC, checksums, content hashes, hash-derived fingerprints, or hash-based equality/provenance. File validation must be based on direct textual parsing plus semantic/structural comparison of the actual file contents. Filename, size, timestamps, or archive metadata may be used only for navigation and never as proof of semantic equality.  
**Scope rule:** each stage is atomic. The next stage may start only after the current stage's mandatory validation is recorded as `PASS`. A failed validation leaves the stage `BLOCKED`; do not compensate by changing a later stage.

### Refactoring tracker

| Stage | Scope | Status | Mandatory validation |
|---|---|---|---|
| R0 | Freeze observed runtime contracts and change surface | PASS | Evidence matrix complete; no implementation files changed |
| R1 | Synchronize JsonValidation/Memory runtime contracts to observed tool responses | PASS | Contract/prompt field census + response-shape tests PASS |
| R2 | Remove `singlePage` from `UnitTestProjectionV3` | PASS | Projection grammar/mapping/schema cross-check + executable fixtures PASS |
| R3 | Remove `physicalGroupKey` from `CM-NAME-001` only; retain `Gnnn` as correlation/group id | PASS | Naming determinism/length/uniqueness/correlation tests PASS |
| R4 | Correct `_DWLPlan` `OUT`/`ACT` materialization | PASS | Canonical-plan grammar + physical census tests PASS |
| R5 | Lock Validator KnowledgeTool scope; forbid RUT semantic KnowledgeAreas | PASS | Tool-call allowlist/matrix tests PASS |
| R6 | Structurally enforce `ValidatorReport` | PASS | Raw-JSON/schema/parser negative+positive tests PASS |
| R7 | Full cross-bundle consistency and end-to-end readiness validation | PASS | Static cross-contract suite PASS; live Pega trial remains explicit external evidence |
| R8 | Separator-free `TC_` naming for candidate unit-test and Scenario names | PASS | Pascal-token naming/schema/example/collision regression tests PASS |

### R0 — Freeze observed runtime truth and exact change surface

**Goal:** prevent refactoring against remembered or idealized tool shapes.

1. Record the actual successful Memory responses observed in the supplied conversations as runtime facts:
   - Write: wrapper `MemoryToolResponse`, success field `IsSuccess`, plus observed `pxObjClass`, `pyGroup`, `pyGUID`, `pyType`.
   - Get: top-level `IsSuccess`, `pxCaseID`, `pyGroup`, `RouterKey`, `pyType`, `pyPayload`, `pyStatusValue`, `pyGUID`.
   - Update: wrapper `MemoryToolResponse`, `IsSuccess`, `pxObjClass`, `pyGUID`, `pyStatusValue`, `RouterKey`.
2. Record the observed successful JsonValidation response as runtime fact: `IsValid` + `message` (for example `JSON_VALID| ...`).
3. Do **not** invent unobserved failure fields/shapes. Any failure response not evidenced by the supplied traces is marked `UNVERIFIED_RUNTIME_SHAPE` and must be confirmed from Pega before a strict failure parser is finalized.
4. Build a change-surface matrix covering:
   - `01_PROMPTS/ScenarioAuthor_SystemPrompt.txt`
   - `01_PROMPTS/UnitTestGenerator_SystemPrompt.txt`
   - `01_PROMPTS/Validator_SystemPrompt.txt`
   - both target JSON schemas and examples
   - both target Knowledge Areas where mappings/examples reference affected fields
   - `04_TOOLS/Memory_GenAI_Tools_Contract.md`
   - `04_TOOLS/Memory_GenAI_Tools_Pega_Implementation_Spec.md`
   - `04_TOOLS/Required_Runtime_Tools.md`
   - this status/tracker.

**Mandatory validation R0:** evidence-to-file matrix has one owner for every changed concept; observed fields are distinguished from assumptions; implementation-file diff is empty except this planning section. All file comparison/evidence is produced under `TEXT_SEMANTIC_ONLY=true` from parsed text/content structure; no hash/checksum/fingerprint may be generated or used. Record `R0=PASS` before R1.


### R0 execution record — PASS — 2026-09-14

**Execution scope:** evidence freeze and change-surface mapping only. No prompt, schema, KnowledgeArea, example, or runtime-tool implementation file was changed in R0. `TEXT_SEMANTIC_ONLY=true` was used throughout; no hash/checksum/fingerprint was generated or used.

#### Observed runtime facts from the supplied conversations

These are direct observations, not inferred aliases:

| Tool operation | Observed successful response shape | Runtime-fact status |
|---|---|---|
| `WriteMemory` / `WriteAgentMemory` | top-level `MemoryToolResponse`; inside it `IsSuccess` observed as string `"true"`, plus `pxObjClass`, `pyGroup`, `pyGUID`, `pyType` | OBSERVED |
| `GetMemory` / `GetAgentMemory` | top-level `IsSuccess` observed as boolean `true`, plus `pxCaseID`, `pyGroup`, `RouterKey`, `pyType`, `pyPayload`, `pyStatusValue`, `pyGUID` | OBSERVED |
| `UpdateMemory` / `UpdateAgentMemory` | top-level `MemoryToolResponse`; inside it `IsSuccess` observed as string `"true"`, plus `pxObjClass`, `pyGUID`, `pyStatusValue`, `RouterKey` | OBSERVED |
| `JsonValidationTool` | top-level `IsValid` boolean plus `message` string; observed success message begins `JSON_VALID|` | OBSERVED |

Not observed in the supplied successful responses: canonical `success`, `errorCode`, `errorMessage`, `pyRouterKey`, JsonValidation `Success`, `ValidationMessage`, `ErrorCode`, or `ErrorMessage`. Their presence in current bundle contracts is therefore **not runtime evidence**.

**Failure-shape boundary:** no Memory/JsonValidation failure response shape in the supplied traces is sufficient to define a strict canonical failure parser. All such shapes remain `UNVERIFIED_RUNTIME_SHAPE` until confirmed from live Pega evidence. R1 must not invent them.

#### R0 change-surface / ownership matrix

| Changed concept | Runtime/factual authority | Bundle owner for the refactor | Required consumers / mirrors to update in later stage | Stage |
|---|---|---|---|---|
| Memory success response wrappers and field names | observed Pega Memory tool responses | `04_TOOLS/Memory_GenAI_Tools_Contract.md` | `Memory_GenAI_Tools_Pega_Implementation_Spec.md`; ScenarioAuthor/Generator/Validator caller checks; `Required_Runtime_Tools.md` | R1 |
| Memory failure response fields | live Pega failure response, not yet observed | `04_TOOLS/Memory_GenAI_Tools_Contract.md` may document only confirmed fields | implementation spec and caller failure handling only after evidence exists | R1 |
| JsonValidation success response shape | observed `JsonValidationTool` response | `04_TOOLS/Required_Runtime_Tools.md` records external-runtime contract boundary; `Validator_SystemPrompt.txt` owns consumption behavior | Validator schema-gate logic | R1 |
| JsonValidation failure response shape | live Pega failure response, not yet observed | `04_TOOLS/Required_Runtime_Tools.md` marks `UNVERIFIED_RUNTIME_SHAPE` | Validator must fail closed without invented field semantics until confirmed | R1 |
| `UnitTestProjectionV3.rut.singlePage` | no independent runtime fact; current bundle contract only | `01_PROMPTS/ScenarioAuthor_SystemPrompt.txt` owns Projection producer grammar | Generator source grammar/fidelity; Validator fidelity; Standard/MultiInput target mapping/Knowledge/examples where referenced | R2 |
| physical PegaUnit `pyIsSinglePageImplementation` | selected target contract | Standard/MultiInput target JsonSchema mapping/invariant for applicable RUT type | Generator target compilation; Validator target validation; Knowledge/examples as demonstrations only | R2 |
| `CM-NAME-001` deterministic test identity | selected target JsonSchema | `03_TARGET_CONTRACTS/Rule-Test-Unit-Case_JsonSchema.txt` and MultiInput counterpart, each owning its own target schema mapping | Generator and Validator consume mapping; target KnowledgeAreas/examples mirror/demonstrate it | R3 |
| `physicalGroupKey` / `Gnnn` correlation identity | Author physical-group order + Memory `pyGroup` correlation | `ScenarioAuthor_SystemPrompt.txt` for Projection/group creation | Generator/Validator correlation only after R3; target naming must not consume it | R3 |
| `_DWLPlan.OUT` and `_DWLPlan.ACT` semantics | ScenarioAuthor canonical DWL state and physically emitted request | `01_PROMPTS/ScenarioAuthor_SystemPrompt.txt` | every DWL example/request projection in the same prompt | R4 |
| Validator KnowledgeTool acquisition scope | Validator closed tool/acquisition contract | `01_PROMPTS/Validator_SystemPrompt.txt` | Generator target acquisition remains separate; ScenarioAuthor remains sole RUT-semantic KnowledgeArea consumer | R5 |
| `ValidatorReport` logical schema and issue/action catalog | Validator contract + Generator correlation requirements | R6 will introduce one machine-readable structural report contract as the authoritative boundary artifact | Validator output instructions and Generator parser/consumer become consumers of that structural contract | R6 |

#### Textual change-surface census frozen by R0

The current bundle was semantically scanned before implementation changes. The following affected files contain relevant current references and are therefore explicitly in-scope for later stages:

- `01_PROMPTS/ScenarioAuthor_SystemPrompt.txt` — Projection `singlePage`, `physicalGroupKey`, `_DWLPlan`, Memory write checks, semantic KnowledgeArea acquisition.
- `01_PROMPTS/UnitTestGenerator_SystemPrompt.txt` — Memory Get/Write/Update checks, Projection `singlePage`, `physicalGroupKey`, `CM-NAME-001`, `ValidatorReport` consumption.
- `01_PROMPTS/Validator_SystemPrompt.txt` — JsonValidation response expectations, Memory Get checks, target KnowledgeTool scope, `CM-NAME-001`, `ValidatorReport`.
- `02_KNOWLEDGE_AREAS/Rule-Test-Unit-Case_KnowledgeArea.txt` — Standard target mapping/reference material for `singlePage`/naming.
- `02_KNOWLEDGE_AREAS/Rule-Test-Unit-Case_MultInpComb-KnowledgeArea.txt` — MultiInput naming target reference.
- `03_TARGET_CONTRACTS/Rule-Test-Unit-Case_JsonSchema.txt` — Standard `CM-NAME-001` and target physical-field constraints.
- `03_TARGET_CONTRACTS/Rule-Test-Unit-Case_MultInpComb-JsonSchema.txt` — MultiInput `CM-NAME-001` and target physical-field constraints.
- `03_TARGET_CONTRACTS/Rule-Test-Unit-Case_JsonExample.txt` and `Rule-Test-Unit-Case_MultInpComb-JsonExample.txt` — target fixtures to revalidate whenever physical mappings change.
- `04_TOOLS/Memory_GenAI_Tools_Contract.md` — current idealized Memory response contract; canonical refactor owner in R1.
- `04_TOOLS/Memory_GenAI_Tools_Pega_Implementation_Spec.md` — implementation/spec mirror of Memory shapes.
- `04_TOOLS/Required_Runtime_Tools.md` — external `JsonValidationTool` boundary documentation.

#### Mandatory validation R0 result

- Observed successful runtime fields are explicitly separated from unverified/future failure shapes: **PASS**.
- Every planned changed concept has one explicit bundle owner and named downstream consumers/mirrors: **PASS**.
- Direct textual comparison against the input `PLANNED_v2` bundle shows no implementation-file content change in R0; only `00_START_HERE/STATUS.md` changed to record this execution evidence: **PASS**.
- No SHA/MD5/CRC/checksum/content fingerprint/hash-based comparison was used: **PASS**.

**R0 disposition:** `PASS`. Per the execution protocol, R1 is now eligible to start, but remains `NOT STARTED` until the user explicitly requests continuation.

### R1 — Synchronize JsonValidation and Memory response contracts with live runtime

**Goal:** make bundle contracts describe the tools that actually respond in Pega, rather than requiring agents to translate an idealized shape.

1. Rewrite the Memory tool contract/spec and all caller checks to use the **actual observed field names and wrappers as canonical success shapes**, especially `IsSuccess` and `RouterKey` rather than silently treating `success` / `pyRouterKey` as equivalent.
2. Preserve semantic invariants: exact GUID correlation, exact group correlation where the tool returns group, immutable payload, single-record cardinality, and no retry on uncertain writes/updates.
3. Align JsonValidation consumption to the observed success shape (`IsValid`, `message`). Remove requirements for success fields not returned by the actual tool unless Pega runtime is first changed to return them.
4. For failure handling, use only fields actually confirmed from Pega. If failure shape remains unverified, document it as an explicit runtime dependency rather than inventing `Success`, `ValidationMessage`, `ErrorCode`, or `ErrorMessage` fields.
5. Remove permissive alias interpretation from prompts: callers accept exactly the canonical live contract defined by this stage.

**Mandatory validation R1:**
- field-by-field census finds no stale required aliases (`success`, `pyRouterKey`, `Success`, `ValidationMessage`, etc.) unless deliberately documented as actual runtime fields;
- observed Write/Get/Update responses from the supplied conversations validate against the rewritten contracts;
- observed JsonValidation success response validates against its rewritten contract;
- malformed/unknown response samples fail closed instead of being semantically guessed.

### R1 execution record — PASS — 2026-09-14

**Execution scope:** response-contract synchronization only. R1 changed caller parsing and bundle tool-response documentation; it did not change Projection semantics, target schemas/examples, naming, DWL, Validator KnowledgeTool scope, or ValidatorReport structure. `TEXT_SEMANTIC_ONLY=true` remained active; no hash/checksum/fingerprint was generated or used.

#### Canonical Memory success shapes now enforced

- Write: `MemoryToolResponse.IsSuccess` must be the string `"true"`; response must carry observed `pxObjClass="RuleIQ-Data-AgentMemory"`, exact `pyGroup`, nonempty `pyGUID`, and exact `pyType`.
- Get: top-level `IsSuccess` must be boolean `true`; canonical response fields are `pxCaseID,pyGroup,RouterKey,pyType,pyPayload,pyStatusValue,pyGUID`.
- Update: `MemoryToolResponse.IsSuccess` must be the string `"true"`; response must carry `pxObjClass`, exact `pyGUID`, exact `pyStatusValue`, and response `RouterKey` equal to the requested input `pyRouterKey`.
- No alias/coercion is allowed between `success`/`IsSuccess`, response `pyRouterKey`/`RouterKey`, or boolean/string true.
- Memory failure/non-success shape remains `UNVERIFIED_RUNTIME_SHAPE`; no branchable error fields were invented.

The supplied live Pega message names were `WriteAgentMemory`, `GetAgentMemory`, and `UpdateAgentMemory`. The bundle retains the logical operation labels `WriteMemory`, `GetMemory`, and `UpdateMemory`; renaming invocation surfaces was not part of R1.

#### JsonValidation success boundary now enforced

Observed success is exactly based on top-level `IsValid=true` plus `message` beginning `JSON_VALID|`. The previous required `Success`, `ValidationMessage`, `ErrorCode`, and `ErrorMessage` fields were removed from Validator consumption.

The exact schema-invalid/non-success response remains `UNVERIFIED_RUNTIME_SHAPE`. Until live evidence is available, such a response takes `JSON_VALIDATION_TOOL_ERROR/HUMAN_REVIEW`; Validator may not infer `JSON_SCHEMA_INVALID` or `JSON_SCHEMA_MASS_FAILURE` from undocumented fields/message text.

#### Files changed by R1

- `01_PROMPTS/ScenarioAuthor_SystemPrompt.txt`
- `01_PROMPTS/UnitTestGenerator_SystemPrompt.txt`
- `01_PROMPTS/Validator_SystemPrompt.txt`
- `04_TOOLS/Memory_GenAI_Tools_Contract.md`
- `04_TOOLS/Memory_GenAI_Tools_Pega_Implementation_Spec.md`
- `04_TOOLS/Required_Runtime_Tools.md`
- `00_START_HERE/STATUS.md` only for this execution record/tracker update.

No target JsonSchema, JsonExample, KnowledgeArea, README, or start-session file was changed.

#### Mandatory validation R1 result

- Direct parsing of supplied live conversations found and validated: 2 Write success responses, 3 Get success responses, 1 Update success response, and 1 JsonValidation success response: **PASS**.
- Negative response-shape tests rejected old `success` aliases, wrong `IsSuccess` types/wrappers, response `pyRouterKey` aliasing, missing fields, the old five-field JsonValidation shape, undocumented `IsValid=false`, and invalid success-message framing: **PASS**.
- Prompt/tool-contract field census contains no stale **required** response aliases. Remaining `pyRouterKey` occurrences are deliberately input/persistent-field references; remaining old names appear only in explicit prohibition/evidence text, not as accepted response fields: **PASS**.
- Direct textual content comparison against the R0 input confirms that only the six R1 implementation/contract files above plus this `STATUS.md` record changed: **PASS**.
- No SHA/MD5/CRC/checksum/content fingerprint/hash-based comparison was used: **PASS**.

**R1 disposition:** `PASS`. R2 is eligible to start, but remains `NOT STARTED` until the user explicitly requests continuation.

### R2 — Delete `singlePage` from `UnitTestProjectionV3`

**Goal:** remove target-specific PegaUnit representation from Author-owned semantic projection.

1. Change executable Projection RUT shape from `{name,applyToClass,singlePage}` to exactly `{name,applyToClass}`. Do not make `singlePage` optional; remove it completely from the v3 grammar.
2. Remove all Author materialization, self-validation, canonicalization and trace rules that create/check/copy `singlePage`.
3. Remove Generator/Validator source-fidelity checks that expect Projection `singlePage`.
4. Make `pyIsSinglePageImplementation` solely target-owned. Its value must come from the selected target JsonSchema / target mapping for the applicable RUT type, never from Projection semantics.
5. Update Standard and MultiInput schemas/Knowledge mapping/examples wherever they currently describe a Projection-to-target `singlePage` transform.
6. Remove `singlePage` from all Projection examples and source-target conflict examples that depend on it.

**Mandatory validation R2:**
- repository-wide exact search returns no Projection grammar/mapping/reference to `singlePage`;
- `pyIsSinglePageImplementation` remains present only as target/PegaUnit representation where required;
- a `Rule-Obj-Model` Projection with `{name,applyToClass}` compiles deterministically to the schema-owned physical value without semantic conflict;
- Generator G7 and Validator fidelity specifications agree that no source comparison exists for this target-only field.

### R2 execution record — PASS — 2026-09-14

**Execution scope:** deleted the Projection-owned `singlePage` coordinate and moved `pyIsSinglePageImplementation` fully to target ownership. No R3+ naming/group, DWL, KnowledgeTool-scope, or ValidatorReport refactor was started. `TEXT_SEMANTIC_ONLY=true` was used; no hash/checksum/fingerprint was generated or used.

**Files changed in R2:**
- `01_PROMPTS/ScenarioAuthor_SystemPrompt.txt` — executable `rut` is now exactly `{name,applyToClass}` in examples and the closed v3 producer grammar.
- `01_PROMPTS/UnitTestGenerator_SystemPrompt.txt` — source grammar no longer accepts the deleted field; `pyIsSinglePageImplementation` is explicitly target-owned, has no Projection source coordinate, and is emitted only when target authority uniquely determines it.
- `01_PROMPTS/Validator_SystemPrompt.txt` — target field is explicitly excluded from Projection fidelity; Validator checks only selected target authority and uses HUMAN when a required target value is not uniquely determined.
- `02_KNOWLEDGE_AREAS/Rule-Test-Unit-Case_KnowledgeArea.txt` — removed the Projection-to-target transform and replaced it with target-owned selection semantics.
- `03_TARGET_CONTRACTS/Rule-Test-Unit-Case_JsonSchema.txt` — Standard physical field description now declares target ownership; existing Rule-Obj-Model conditional remains the unique owner of value `"false"` for that RUT type.
- `03_TARGET_CONTRACTS/Rule-Test-Unit-Case_MultInpComb-JsonSchema.txt` — existing Rule-Obj-When `const:"false"` is explicitly documented as target-owned with no Projection source coordinate.

**Validation-scope clarification:** this tracker necessarily retains historical/planning references to the deleted source field so the refactor remains auditable. Therefore the R2 exact-term absence gate is applied to every implementation/reference artifact **except this `STATUS.md` history/tracker**. This clarifies the mechanical check without changing the R2 architectural goal.

**Mandatory validation evidence:**
- Direct textual scan of every implementation/reference artifact outside this tracker finds zero occurrences of the deleted Projection field name: **PASS**.
- ScenarioAuthor and Generator closed executable grammars both require exactly `rut={name,applyToClass}`: **PASS**.
- Standard schema, MultiInput schema, and both canonical JsonExamples parse successfully; each example validates against its corresponding Draft-2020-12 schema: **PASS**.
- Standard `Rule-Obj-Model` fixture with Projection RUT keys exactly `{name,applyToClass}` deterministically obtains target `pyIsSinglePageImplementation="false"` from the schema conditional and requires no source comparison: **PASS**.
- MultiInput `Rule-Obj-When` target retains machine-enforced `pyIsSinglePageImplementation="false"`: **PASS**.
- Generator G7 explicitly treats the field as target-owned and Validator fidelity explicitly states that it has no Projection source coordinate: **PASS**.
- For a Standard RUT type where selected target authority leaves multiple required values legal, Generator/Validator fail closed to HUMAN rather than inventing a value or emitting `PF_SOURCE_TARGET_CONFLICT`: **PASS**.
- Direct textual comparison against the R1 input shows changes only in the six R2-owned implementation/reference files above plus this tracker: **PASS**.
- No SHA/MD5/CRC/checksum/content fingerprint/hash-based comparison was used: **PASS**.

**R2 disposition:** `PASS`. R3 is eligible to start, but remains `NOT STARTED` until the user explicitly requests continuation.

### R3 — Remove `physicalGroupKey` from `CM-NAME-001`; keep `Gnnn` correlation-only

**Goal:** produce human-readable test identities without mechanical `G001`, while preserving physical-group correlation.

1. Keep `physicalGroupKey=Gnnn` in `UnitTestProjectionV3` and `pyGroup` as internal physical-group/correlation identity.
2. Remove `physicalGroupKey` / `GROUP` from **both** Standard and MultiInput `CM-NAME-001` inputs and generated test identity.
3. Update Generator and Validator naming rules to compute identity from the revised schema mapping only; neither may append a group suffix independently.
4. Preserve `Scenarios[n].Name` as the exact Author semantic scenario name.
5. Define deterministic collision handling **without** reintroducing `Gnnn` into the user-facing name. Prefer semantic uniqueness enforced by Author/test-label generation; if target-level collision handling is required, it must be a separately specified deterministic rule with an explicit owner.
6. Recalculate length budgeting so the mapping cannot reproduce the observed manual 25-vs-26 character counting failure. Prefer a mapping that avoids LLM arithmetic/counting where possible.

**Mandatory validation R3:**
- no `CM-NAME-001` implementation/reference consumes `physicalGroupKey`;
- generated `Name`, `pyPurpose`, and `pyLabel` remain exactly equal;
- `Gnnn` still correlates Projection/Candidate/Validator lifecycle through Memory `pyGroup` and report `groupId` only;
- boundary tests cover maximum label length, long RUT names, normalization, and two physical groups in one run;
- no generated test name ends in `_Gnnn` solely because of correlation.

### R3 execution record — PASS — 2026-09-14

**Historical R3 identity rule (superseded by R8 formatting only):** both Standard and MultiInput `CM-NAME-001` consumed exactly frozen `UnitTestProjection.testLabel`. At R3 the deterministic target identity was `TC_` plus underscore-preserving label canonicalization. R8 keeps the same ownership/correlation boundary but changes only the physical target-name formatting to separator-free `TC_` + Pascal-token concatenation. `rut.name` and `physicalGroupKey` are explicitly non-inputs. No RUT-name truncation, length allocation, group suffix, counter, ordinal, hash, or collision suffix participates.

**Correlation boundary:** `physicalGroupKey=Gnnn` remains mandatory in UnitTestProjectionV3 and continues to correlate Projection/Memory/Candidate/Validator lifecycle through `pyGroup`/`groupId`; ScenarioAuthor, Generator, and Validator explicitly forbid using it in `Name`, `pyPurpose`, or `pyLabel`.

**Semantic uniqueness rule:** before persistence, ScenarioAuthor must ensure physical-group `testLabel` values remain distinct after the same target-safe label canonicalization. Any collision must be resolved by an evidence-backed semantic Scenario name before B/A; group id, ordinal, counter, hash, or mechanical suffix is forbidden. If no semantic distinction exists, the pre-projection gate fails rather than manufacturing identity.

**Length contract adjustment:** target identity `minLength` is now 4 so the valid source label `A` maps to `TC_A`; `maxLength` remains 53 because source `testLabel` is capped at 50 characters. This removes all prior manual `BASE_ALLOC` / RUT-prefix counting.

**Mandatory validation evidence:**
- Both target schemas parse as Draft-2020-12 schemas and both canonical JsonExamples validate with zero errors: **PASS**.
- R3-time examples used `TC_Happy_Path` / `TC_True_Standard`; this historical formatting is superseded by R8. Current examples are `TC_HappyPath` / `TC_TrueStandard`, with executable `Name == pyPurpose == pyLabel`: **PASS**.
- R3-time boundary fixture used underscore-preserving `TC_City_Not_Valid_Exit`; R8 supersedes only that formatting. One-character/max-length/RUT-independence constraints remain unchanged.
- Two physical groups with the same long RUT but semantic labels `City Not Valid Exit` / `Valid Postal Address` produce distinct names without `_G001/_G002`: **PASS**.
- Collision fixture `A B` versus `A__B` canonicalizes to the same target name and is detected as a pre-persistence semantic-label collision; no mechanical repair is authorized: **PASS**.
- Direct text scan finds no generated target example/name ending in `_Gnnn` and no obsolete `BASE_ALLOC`, `RUT_BASE_FINAL`, `GROUP = physicalGroupKey`, or `rut.name + testLabel + physicalGroupKey` naming logic: **PASS**.
- Direct textual comparison against the R2 input shows changes only in the three prompts, two target KnowledgeAreas, four target schema/example files, plus this tracker: **PASS**.
- `TEXT_SEMANTIC_ONLY=true` was respected; no SHA/MD5/CRC/checksum/content fingerprint/hash-based comparison was used: **PASS**.

**R3 disposition:** `PASS`. R4 is eligible to start, but remains `NOT STARTED` until the user explicitly requests continuation.

### R4 — Correct `_DWLPlan` materialization

**Goal:** make the non-waivable dependency plan self-consistent and machine-auditable.

1. Canonical plan contains exactly one `OUT=<ordered unique KEY list>`.
2. Canonical plan contains exactly one `ACT=<exact ordered KEY list physically emitted>`.
3. Remove count overloads such as `OUT=12`, `ACT=12`. If counts are useful, give them distinct explicitly named fields or derive them; do not overload `OUT`/`ACT`.
4. Require literal ordered equality `OUT == ACT` after holder selection/deduplication and before every RuleCrawler call.
5. Update all examples/instructions that permit or encourage duplicate `OUT` fields or numeric `ACT`.

**Mandatory validation R4:**
- parser/census test rejects `...|OUT=<keys>|OUT=12|...|ACT=12|...`;
- valid fixture has one OUT list and one identical ACT list;
- physical `pxRuleReferences[]` census maps 1:1 to ACT and OUT;
- `STATECHECK.preCall=PASS` is impossible when OUT/ACT differ, duplicate, or contain counts instead of keys.

### R4 execution record — PASS — 2026-09-14

**Implemented DWL plan contract:** `_DWLPlan` now serializes each field exactly once. `OUT` and `ACT` are list-valued canonical KEY sequences only. Numeric/cardinality overloads such as `OUT=12` or `ACT=12`, duplicate `OUT`/`ACT` fields, scalar substitutes, and non-list values are explicitly invalid and force `STATECHECK.preCall=FIX`.

**Materialization order:** `SCAN` preserves READY occurrence ids and internal `READY_KEYS` preserves the stable unique READY KEY projection. Holder selection, source/request-shape gates, deduplication and holder grouping are completed before `OUT` is serialized. `OUT` then records the intended final physical payload's canonical KEYs in deterministic wire order. `ACT` is independently rebuilt by flattening the actual final `InterestedRules[].pxRuleReferences[]` in that exact wire order and mapping each physical reference back to one canonical KEY without guessing. This removes the prior ordering ambiguity when holder grouping changes physical wire order.

**Non-waivable pre-call gate:** `STATECHECK.preCall=PASS` now requires `len(ACT) == len(OUT) == len(READY_KEYS)`, every READY key exactly once, no unmappable/out-of-plan physical reference, one nonempty physical reference set per retained holder, and literal ordered `OUT == ACT`. Any value/order/multiplicity/representation/cardinality mismatch forbids RuleCrawler.

**Mandatory validation evidence:**
- Canonical valid fixture with one list-valued `OUT` and one identical list-valued `ACT`: **PASS**.
- Observed malformed shape `OUT=[keys]|OUT=12|...|ACT=12` rejected because `OUT` occurs more than once and `ACT` is not a KEY list: **PASS**.
- Numeric-only `ACT`, ordered OUT/ACT mismatch, and extra physical reference fixtures are each rejected before a RuleCrawler-eligible state: **PASS**.
- Physical census fixture maps the actual flattened `pxRuleReferences[]` 1:1 to both OUT and ACT: **PASS**.
- Holder-group reordering fixture proves wire-order OUT materialization remains deterministic and allows exact `OUT == ACT` without relying on pre-group READY order: **PASS**.
- Direct textual scan of the active prompt confirms the only `OUT=12` / `ACT=12` mentions are explicit invalid examples; no active grammar or positive instruction permits count-valued OUT/ACT: **PASS**.
- Direct textual comparison against the R3 input shows implementation changes only in `01_PROMPTS/ScenarioAuthor_SystemPrompt.txt`; this tracker is the only additional changed file: **PASS**.
- `TEXT_SEMANTIC_ONLY=true` was respected; no SHA/MD5/CRC/checksum/content fingerprint/hash-based comparison was used: **PASS**.

**R4 disposition:** `PASS`. R5 is eligible to start, but remains `NOT STARTED` until the user explicitly requests continuation.

### R5 — Lock Validator KnowledgeTool scope and forbid RUT semantic KnowledgeAreas

**Goal:** keep Validator independent but target-focused; it must not reacquire Author semantic guidance.

1. Explicitly forbid Validator requests for semantic RUT adapters such as `Rule-Obj-Model_KnowledgeArea`, `Rule-Obj-When_KnowledgeArea`, dependency KnowledgeAreas, property/RUF KnowledgeAreas, etc.
2. Validator may use only the target artifacts explicitly required by its closed validation matrix. Any target `Rule-Test-Unit-Case...` KnowledgeArea usage must be justified solely by target/Pega structural validation, never by RUT semantic reasoning.
3. Re-evaluate whether executable Validator actually needs `Rule-Test-Unit-Case_KnowledgeArea` at all after R2/R3. If all deterministic checks are fully owned by JsonSchema mappings/invariants, reduce Validator acquisition to schema (and only the minimum target artifact still required). Do not retain KnowledgeArea by inertia.
4. Keep ScenarioAuthor as the sole consumer of `RUT_TYPE + "_KnowledgeArea"` semantic adapters.

**Observed-trace note:** in the supplied Validator conversation the visible request is `Rule-Test-Unit-Case_KnowledgeArea,Rule-Test-Unit-Case_JsonSchema,Rule-Test-Unit-Case_JsonExample`, not `Rule-Obj-Model_KnowledgeArea`. The prohibition above is nevertheless made explicit so a Validator can never request the latter.

**Mandatory validation R5:**
- static tool-call matrix proves Validator cannot request `<RUTType>_KnowledgeArea`;
- negative fixture containing `Rule-Obj-Model_KnowledgeArea` is rejected as an invalid Validator acquisition;
- every retained Validator target artifact has at least one named validation responsibility; unused acquisitions are removed;
- ScenarioAuthor semantic acquisition remains unchanged except where separately modified by R2/R4.

#### R5 execution record — 2026-09-14

**Execution scope:** Validator target-acquisition boundary only. No ScenarioAuthor semantic acquisition, Generator target acquisition, target schema/example/KnowledgeArea content, Memory contract, DWL, naming, or ValidatorReport structure was changed in R5. `TEXT_SEMANTIC_ONLY=true` remained active; no SHA/MD5/CRC/checksum/content fingerprint/hash-based comparison was used.

**Implemented:**
- Validator KnowledgeTool acquisition is now a closed four-row matrix selected only from source mode + immutable `RUTType`.
- Any extra/substituted Area is rejected before KnowledgeTool invocation. `<RUTType>_KnowledgeArea` is never appended. `Rule-Obj-Model_KnowledgeArea`, `Rule-Obj-When_KnowledgeArea`, property/RUF/Data Page/dependency semantic KnowledgeAreas are explicitly forbidden.
- ScenarioAuthor remains the sole consumer of RUT/dependency semantic KnowledgeAreas.
- The executable target `Rule-Test-Unit-Case..._KnowledgeArea` remains intentionally retained because the current JsonSchemas do not encode the complete Projection→Candidate serialization mapping (typed/wrapped values, executable context, setup/simulation/assertion or Decision-cell serialization). This target KnowledgeArea is explicitly non-semantic with respect to RUT meaning.
- The executable JsonExample remains retained only for the designated template-owned `RuleCode.pyRuleSet` and `RuleCode.pyRuleSetVersion` values; Validator section 5.2 now gives those fields an explicit validation responsibility.
- JsonSchema remains owner of formal shape, `CM-NAME-001`, `CF-*`, and schema-owned target constants/relationships.

**Mandatory validation R5:**
- Static acquisition matrix has only the four exact permitted target batches and contains no RUT/dependency semantic adapter in any positive row: **PASS**.
- Negative fixture `EXECUTABLE_STANDARD + Rule-Obj-Model_KnowledgeArea` differs from the permitted batch and is rejected before KnowledgeTool call: **PASS**.
- Every retained target artifact has a named responsibility: JsonSchema=formal shape/CM/CF/constants; target KnowledgeArea=remaining deterministic executable serialization; JsonExample=only `pyRuleSet`/`pyRuleSetVersion`: **PASS**.
- Both retained target KnowledgeAreas contain the shared deterministic mapping reference used by section 4, and both retained JsonExamples contain the two designated template fields: **PASS**.
- ScenarioAuthor prompt is textually unchanged from the R4 input, so semantic acquisition behavior was not modified by R5: **PASS**.
- Direct textual comparison against the R4 input shows implementation changes only in `01_PROMPTS/Validator_SystemPrompt.txt`; this tracker is the only additional changed file: **PASS**.
- `TEXT_SEMANTIC_ONLY=true` was respected; no hash/checksum/fingerprint was generated or used: **PASS**.

**R5 disposition:** `PASS`. R6 is eligible to start, but remains `NOT STARTED` until the user explicitly requests continuation.

### R6 — Structurally enforce `ValidatorReport`

**Goal:** make `raw JSON only` a runtime contract, not a prose instruction that the model may ignore.

1. Define a machine-readable `ValidatorReport` schema matching the synchronized issue/action catalog, required identities, route, counters, and closed issue object.
2. Put a structural adapter/parser at the Validator invocation boundary. The nested Validator response must parse as exactly one JSON object and validate against `ValidatorReport` schema **before** Generator can consume it.
3. Reject any response with prefix/suffix prose, Markdown, code fences, multiple JSON values, unknown fields, invalid code/action pairs, wrong counts, or identity/correlation mismatch.
4. Generator must never substring-extract JSON from a prose response and must never use Validator prose as repair input.
5. Keep the Validator prompt's raw-JSON instruction as defense-in-depth, but runtime structural validation is authoritative.

**Mandatory validation R6:**
- the observed bad response (`Now I have all required information...` + Markdown + final JSON) is rejected;
- a valid raw report object passes;
- raw JSON with an extra field fails;
- valid JSON with an unlisted issue/action pair fails;
- valid schema report with wrong `sourceUUID`, Candidate UUID, group correlation, `blocking`, or route precedence fails;
- Generator receives no semantic issue list when structural validation fails.

### R6 execution record — PASS — 2026-09-14

**Execution scope:** introduced one authoritative machine-readable ValidatorReport boundary contract plus deterministic adapter requirements. No Projection semantics, target Candidate schema/mapping, KnowledgeArea acquisition, naming, DWL, or Memory response contract was changed. `TEXT_SEMANTIC_ONLY=true` remained active; no SHA/MD5/CRC/checksum/content-fingerprint comparison was used.

**Files changed in R6:**
- `04_TOOLS/ValidatorReport_JsonSchema.txt` — new authoritative Draft-2020-12 structural report schema with closed root/issue objects, exact issue/action pairs, route-shape constraints and explicit runtime invariants.
- `04_TOOLS/Required_Runtime_Tools.md` — specifies the required non-LLM boundary adapter over the observed delegated `{response:<string>}` envelope; the adapter accepts/rejects only and may not repair/extract/normalize model output.
- `01_PROMPTS/UnitTestGenerator_SystemPrompt.txt` — Generator may consume only an adapter-accepted parsed ValidatorReport; a raw delegated response reaching Generator is noncompliant and fails `VALIDATOR_RESPONSE_INVALID` without substring recovery.
- `01_PROMPTS/Validator_SystemPrompt.txt` — raw-JSON-only remains defense-in-depth and explicitly mirrors the authoritative structural boundary.
- `README.md` — indexes the new ValidatorReport schema artifact.
- `00_START_HERE/STATUS.md` — this execution record/tracker update only.

**Structural boundary now required:**
1. delegated envelope is exactly one object containing exactly one string field `response`;
2. the entire response string is parsed as one finite duplicate-key-free JSON object; prose, Markdown/code fences, multiple JSON values, prefix/suffix text, duplicate keys and non-finite numbers fail closed;
3. the parsed object validates against `ValidatorReport_JsonSchema.txt`;
4. exact invocation identities and group correlation are checked;
5. `blocking == len(issues)` and `warnings == 0`;
6. code/action pairs are closed by schema and route is recomputed with precedence `HUMAN_REVIEW > REJECT_SEMANTICS > repair > OK`;
7. any failure exposes neither raw nested-agent text nor semantic issues to Generator and terminates that validation path as `VALIDATOR_RESPONSE_INVALID`.

**Mandatory validation evidence:**
- The actual supplied `PXCONV-144029` Validator tool response whose nested text begins `Now I have all required information. Let me perform the full analysis.` and contains Markdown before a trailing JSON report is rejected by whole-string JSON parsing before any issue extraction: **PASS**.
- A valid raw `OK` ValidatorReport with exact invocation/correlation values validates and is accepted: **PASS**.
- Extra report field, extra outer-envelope field, code fence, prose prefix, multiple JSON values and duplicate report key are rejected: **PASS**.
- An unlisted `PF_ASSERTION_MISMATCH/FIX_JSON` pair is rejected by the machine-readable schema: **PASS**.
- Wrong `sourceUUID`, wrong `UnitTestCandidateUUID`, wrong `groupId`, wrong `blocking` count and route-precedence contradiction are rejected by schema/runtime invariants: **PASS**.
- A valid `HUMAN` report with `AMBIGUOUS/HUMAN_REVIEW` passes, proving the route gate is not reject-all: **PASS**.
- Machine-readable schema catalog contains exactly the same 14 issue/action pairs as Generator and Validator prompts; exact root report field set is synchronized in all three: **PASS**.
- Direct textual content comparison against the R5 input finds only the five R6 implementation/contract files above plus this tracker changed, with the ValidatorReport schema newly added: **PASS**.
- Structural-failure reference adapter returns no parsed report/issue list to its caller; it fails before semantic consumption: **PASS**.
- Live Pega deployment of this non-LLM adapter has **not** been claimed or tested; it remains external runtime evidence for execution readiness: **PASS boundary statement**.

**R6 disposition:** `PASS`. R7 is eligible to start, but remains `NOT STARTED` until the user explicitly requests continuation.

### R7 — Cross-bundle consistency and execution-readiness validation

**Goal:** prove the six refactors compose without weakening existing non-waivable gates.

1. Run exact-term and semantic cross-checks across all prompts, target schemas/examples, KnowledgeAreas and tool contracts under `TEXT_SEMANTIC_ONLY=true`; do not use hashes/checksums/fingerprints as equality or regression evidence.
2. Verify ownership boundaries:
   - Author owns semantics/dependency closure/scenario formation;
   - Projection contains no `singlePage`;
   - `physicalGroupKey` is correlation-only;
   - Generator owns target serialization;
   - Validator validates target/fidelity but does not reacquire RUT semantics;
   - runtime adapters own tool/report structural response validation.
3. Replay the three supplied conversations as regression evidence at contract level and document which former behaviors must now fail earlier/differently.
4. Confirm no stage accidentally relaxes immutable Memory semantics, commit boundary, G7, source-preservation, Validator issue catalog, or DWL non-waivability.

**Mandatory validation R7:** all static/cross-contract checks PASS and every planned regression has an expected disposition. Live Pega KnowledgeTool/tool deployment and a new end-to-end Pega run remain explicit external validation steps and must not be marked complete until actually executed.


### R7 execution record — PASS (static) — 2026-09-14

**Execution scope:** full cross-bundle semantic/structural regression validation only. No prompt, target schema/example, KnowledgeArea, Memory contract/spec, or runtime-contract implementation text was changed in R7. Only this status/tracker was updated after validation. `TEXT_SEMANTIC_ONLY=true` was used throughout; no SHA/MD5/CRC/checksum/content fingerprint/hash-based equality was generated or used.

#### Static cross-contract suite

The final R7 suite completed **59/59 checks PASS**. The checks covered:

- all three machine-readable JSON Schemas (`Standard`, `MultiInput`, `ValidatorReport`) are valid Draft 2020-12 schemas;
- both canonical Candidate JsonExamples validate against their selected schemas;
- no active implementation/reference file contains the removed Projection source coordinate `singlePage`;
- physical `pyIsSinglePageImplementation` remains target-owned only; Standard `Rule-Obj-Model` selects `"false"` and MultiInput `Rule-Obj-When` selects `"false"` without a Projection source field;
- each target schema contains exactly one `CM-NAME-001`; the mapping input is only `UnitTestProjection.testLabel`; `rut.name`, `physicalGroupKey`, counters/hashes/group suffixes do not participate;
- no active target/example name ends in `_Gnnn`, and the obsolete `BASE_ALLOC` / `RUT_BASE_FINAL` naming arithmetic is absent;
- naming fixtures including one-character and 50-character labels satisfy the target lexical/length contract. R8 supersedes the R7-time underscore format; current mapping is `City Not Valid Exit -> TC_CityNotValidExit` independently of group id;
- `_DWLPlan` has one canonical grammar; `OUT` and `ACT` are list-valued exactly once, numeric overloads are invalid, and `STATECHECK.preCall` requires literal exact ordered `OUT == ACT`;
- Memory caller checks, Memory contract/spec, and JsonValidation success parsing use the observed R1 runtime fields/wrappers without alias coercion;
- Validator has the closed four-row target-artifact KnowledgeTool matrix and explicitly forbids semantic RUT/dependency KnowledgeAreas; ScenarioAuthor remains the semantic KnowledgeArea owner;
- Generator, Validator, and `ValidatorReport_JsonSchema.txt` contain the same exact **14** issue/action pairs;
- positive `OK`, `GENERATOR_REPAIR`, `SEMANTIC_REJECT`, and `HUMAN` ValidatorReport fixtures validate, while route-inconsistent fixtures fail;
- the non-LLM ValidatorReport boundary requires whole-response parsing and forbids substring/Markdown/code-fence recovery;
- Author commit boundary, DWL non-waivability, Generator G7, create-only Candidate persistence, immutable Candidate payload, source preservation, and Validator no-semantic-repair boundaries remain intact.

#### Contract-level replay of supplied conversations

The old conversations are regression evidence, not expected-to-pass current executions. Under the refactored contracts their expected earliest/next dispositions are:

| Supplied trace | Former behavior | Current required disposition |
|---|---|---|
| `PXCONV-144028` ScenarioAuthor | RuleCrawler was called with malformed `_DWLPlan` containing duplicate/count-valued `OUT`/`ACT` | `STATECHECK.preCall=FIX`; **RuleCrawler call is forbidden** until one list-valued OUT and one independently materialized ACT are literally equal in ordered content |
| `PXCONV-144029` Generator | old Projection was accepted and target acquisition continued | the persisted old Projection contains removed `rut.singlePage`, so current closed v3 source grammar yields **`SOURCE_INVALID` before KnowledgeTool** |
| `PXCONV-144029` Generator, after hypothetically replacing only the old Projection with a current R2-compliant Projection | Standard target batch in the supplied live trace returned empty `Rule-Test-Unit-Case_KnowledgeArea.Description` but compilation continued | current Generator requires every requested target Area exactly once and nonempty, therefore **`KNOWLEDGE_FAILED` before Candidate persistence** |
| `PXCONV-144030` Validator | observed JsonValidation success was interpreted using invented legacy fields, then old Projection was analyzed | observed `{IsValid:true,message:"JSON_VALID|..."}` is now a valid R1 success response; however the old Projection still contains removed `singlePage`, so current source-mode gate yields **`AMBIGUOUS/HUMAN_REVIEW` before target KnowledgeTool** |
| `PXCONV-144030` Validator, with a current Projection but the supplied old live target deployment | empty Standard target KnowledgeArea was tolerated | current closed target batch requires nonempty exact results, therefore **`AMBIGUOUS/HUMAN_REVIEW`** |
| old persisted Candidate, if evaluated under current source+target contracts | Name/pyPurpose/pyLabel contained `..._G001`; Validator also treated `singlePage=true` as a source fact | current name after R8 is **`TC_CityNotValidExit`**; the old mechanical name is `PF_RUT_CONTEXT_MISMATCH`. `pyIsSinglePageImplementation="false"` is target-owned for Rule-Obj-Model and **does not create a source semantic conflict** |
| old delegated Validator response | prose/Markdown preceded the final JSON report and Generator still consumed it | R6 boundary rejects the entire nested response; **`VALIDATOR_RESPONSE_INVALID`**, with no issue list exposed to Generator |

The previously identified quote/double-wrapper assertion issue is intentionally **outside this refactoring scope** and is not claimed as fixed by R0-R7.

#### External runtime evidence still required

R7 proves static bundle consistency only. The following remain external before claiming live end-to-end completion:

1. Deploy/verify the current target KnowledgeTool content. The bundle contains a nonempty Standard target KnowledgeArea, but the supplied live Generator/Validator traces returned an empty `Rule-Test-Unit-Case_KnowledgeArea.Description`; no later live deployment evidence was supplied.
2. Deploy the deterministic non-LLM ValidatorReport boundary adapter defined in `Required_Runtime_Tools.md` and verify that raw delegated `{response:<string>}` output never reaches Generator unvalidated.
3. Execute a fresh live Pega Author -> Generator -> Validator run with the current bundle and verify actual persistence/lifecycle behavior and target rule creation.
4. Capture real Memory/JsonValidation non-success responses if strict typed failure parsing beyond the current fail-closed behavior is required; those shapes remain `UNVERIFIED_RUNTIME_SHAPE`.
5. The supplied historical traces also showed platform bootstrap calls such as `application_context` / `data_from_all_sources` outside the prompts' semantic closed-tool allowlists. R0-R7 did not change platform tool exposure. Strict closed-tool compliance therefore still requires live verification/removal or an explicitly documented platform-bootstrap exception.

**R7 disposition:** `PASS (STATIC)`. Refactoring stages R0-R7 are complete. Live Pega deployment/replay is not complete and must not be represented as completed evidence.


### R8 — Separator-free `TC_` physical naming for unit tests and Scenarios

**Goal:** change physical Pega target names from underscore-separated semantic words (for example `TC_City_Not_Valid_Exit`) to separator-free `TC_` + Pascal-token form (`TC_CityNotValidExit`) without changing Projection semantic names, correlation identity, or ownership boundaries.

1. Keep Author/Projection `testLabel` and `scenarios[].name` as semantic human-readable source strings (for example `City Not Valid Exit`).
2. `CM-NAME-001` owns one deterministic `TARGET_NAME(label)` function for both unit-test identity and target Scenario names:
   - split on maximal runs of ASCII spaces or underscores;
   - discard empty edge tokens;
   - uppercase the first character of each token only when it is ASCII `a-z`;
   - preserve every remaining token character exactly;
   - concatenate tokens with no separator;
   - prefix exactly `TC_`.
3. Apply `TARGET_NAME(testLabel)` to `UnitTestRules[0].Name`; for executable candidates `CF-IDENTITY-001` keeps `RuleCode.pyPurpose` and `RuleCode.pyLabel` equal to the same value.
4. Apply `TARGET_NAME(scenarios[n].name)` independently to every candidate `Scenarios[n].Name`.
5. `physicalGroupKey/Gnnn`, RUT name, counters, ordinals, hashes/checksums/fingerprints and collision suffixes remain forbidden naming inputs.
6. Author must prevent two physical groups from producing the same `TARGET_NAME(testLabel)` and must prevent two Scenarios inside one physical group from producing the same `TARGET_NAME(scenario.name)`. Collision disambiguation must remain semantic.

**R8 execution record — PASS — 2026-09-14**

- Standard and MultiInput schemas each contain exactly one `CM-NAME-001` with the same `TARGET_NAME` algorithm: **PASS**.
- Physical unit-test `Name`, `pyPurpose`, `pyLabel`, and target Scenario `Name` patterns are `^TC_[A-Za-z0-9]+$`; underscore is permitted only in the fixed `TC_` prefix: **PASS**.
- Source Projection grammar remains human-readable/non-`TC_`; no semantic source name is rewritten in place: **PASS**.
- Standard canonical example now uses `TC_HappyPath` for both unit-test identity and its single target Scenario: **PASS**.
- MultiInput canonical example uses unit-test identity `TC_TrueStandard` and target Scenario names `TC_TrueStandard`, `TC_HighRisk`, `TC_EmployeeExpress`: **PASS**.
- Mapping fixtures: `City Not Valid Exit -> TC_CityNotValidExit`; `City   Not__Valid Exit -> TC_CityNotValidExit`; `customer ID valid -> TC_CustomerIDValid`; one-character `A -> TC_A`; 50-character alphanumeric label -> target length 53: **PASS**.
- Collision fixture `A B` vs `AB` produces the same `TC_AB` and therefore must be rejected by the Author pre-projection uniqueness gate rather than repaired by suffix: **PASS**.
- Both canonical JsonExamples validate against their corresponding Draft-2020-12 schemas after the change: **PASS**.
- Generator G7 and Validator fidelity independently recompute target Scenario names from source semantic names through `CM-NAME-001`; verbatim source-name equality is no longer required at the target boundary: **PASS**.
- Direct textual comparison against the R7 input shows only R8-owned naming files plus this tracker changed; Memory/DWL/ValidatorReport/runtime-response contracts are unchanged: **PASS**.
- `TEXT_SEMANTIC_ONLY=true` was respected; no SHA/MD5/CRC/checksum/content fingerprint/hash-based comparison was used: **PASS**.

**R8 disposition:** `PASS (STATIC)`. Live Pega redeploy/replay remains external evidence.

### Execution protocol after approval

When implementation is approved for a fresh rebuild, execute strictly `R0 -> R1 -> R2 -> R3 -> R4 -> R5 -> R6 -> R7 -> R8`. After each stage:

1. change only that stage's owned files;
2. run its mandatory validation using direct textual semantic/structural inspection only (`TEXT_SEMANTIC_ONLY=true`);
3. record `PASS`/`BLOCKED` plus concise textual evidence in this tracker;
4. stop immediately on `BLOCKED` and do not start the next stage;
5. do not rewrite earlier stage intent silently; any required scope change must be recorded here before continuing.
