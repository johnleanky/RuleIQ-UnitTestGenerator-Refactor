# RuleIQ — Fresh Continuation Bundle

This is a deliberately clean single-version continuation package.

## Contents

- `00_START_HERE/` — short current status and new-session instruction.
- `01_PROMPTS/` — current Scenario Author, Unit Test Generator, Validator prompts.
- `02_KNOWLEDGE_AREAS/` — current shared target/compiler Knowledge Areas plus Rule-Obj-When reference.
- `03_TARGET_CONTRACTS/` — freshest Standard and MultiInput JSON schemas and coverage-rich examples.
- `04_TOOLS/` — current single-record Memory contract, Pega implementation specification, required runtime-tool list, and authoritative `ValidatorReport_JsonSchema.txt` structural boundary contract.

No historical prompts, old project versions, remediation plans, validation scripts, hashes/checksums, or offline fixtures are included.
