# W3GN Execution Protocol

Status values: PENDING → IMPLEMENTED → VALIDATED PASS. A stage is not closed before its targeted validation passes.

## S00 — Baseline and provenance
- Status: VALIDATED PASS
- Change: Materialized exact W3GM baseline, 7 fresh live traces, current Generator/Validator/Standard schema+example; copied immutable working baseline.
- Validation: File census and SHA-256 baseline captured before edits.
- Evidence: W3GM ScenarioAuthor SHA=5bf38f46...; fresh traces=7; current physical artifacts materialized from Library.

## S01 — Production language / deterministic transform form
- Status: VALIDATED PASS
- Change: No new production policy layer. W3GN uses closed INPUT→TRANSFORM→OUTPUT replacements in later stages.
- Validation: Confirmed no S01-only production text was added; stage is an implementation-language constraint, not runtime semantics.
- Evidence: Protocol created before semantic edits; later stages must remove/replace prose mechanisms rather than stack gates.

## S02 — Static dependency acquisition
- Status: VALIDATED PASS
- Change: Replaced variable pre-scan/general scan with one scenario-independent STATIC_SCAN(holder); property closure now follows only KA-emitted segments with no later relevance decision.
- Validation: 8/8 targeted predicates PASS: pre-scan allocates no D ids; holder scan once; scenario-independent tuple census; D ids after census; no later leaf relevance; KT.39 one-pass contract retained.
- Evidence: Old "semantically required final leaf" branch removed; KT.39 remains source-order/no-relevance and Core now consumes it literally.

## S03 — Source-indexed DTM
- Status: VALIDATED PASS
- Change: Replaced verbose DT execution prose with one closed source-indexed DTM→DT_EXECUTE transform; KDT domain model retained unchanged.
- Validation: 7/7 targeted predicates PASS: direct copy, literal pyRowNum, action-source role, no RuleJSON reread, scenario-independent dependencies, KDT lossless role separation.
- Evidence: Condition cells and pyPropertyValues stay physically disjoint; same RuleJSON/static mode specifies byte-identical DTM.

## S04 — NO_SCALAR_VALUE authority
- Status: VALIDATED PASS
- Change: Made SCALAR(DTM,DTE) a three-branch closed function with mode-specific NO_SCALAR_VALUE reason carried into EFFECT.
- Validation: 4/4 targeted predicates PASS: EVALUATE_ALL reason, FIRST_MATCH-disabled reason, no blank/null substitution, EFFECT stores scalar reason without lexical value.
- Evidence: Param.Run-style outputs can no longer derive an empty lexical value from inactive scalar semantics.

## S05 — Immutable scenario vectors
- Status: VALIDATED PASS
- Change: Replaced repair-oriented Model scenario construction with literal REF copy + one-coordinate ALT mutation + reachability truncation.
- Validation: 4/4 predicates PASS: byte-copy reference, one coordinate replacement, diagonal impossible by construction, carrier cannot mutate vector.
- Evidence: REF T2,T3,T5 mechanically yields T1 / T2,T4,T5 / T2,T3,T6; T2,T4,T6 has no constructor.

## S06 — Seed frontier
- Status: VALIDATED PASS
- Change: Added transient SEED_FRONTIER(VECTOR) producer-backtracking function; only values without a reachable producer before use are seedable.
- Validation: 4/4 predicates PASS including explicit DT→pyName→When case: pyName excluded, DT upstream inputs included.
- Evidence: Removes the causal false-positive mechanism observed in all fresh DetermineChannel runs.

## S07 — Carrier synthesis from vector + frontier
- Status: VALIDATED PASS
- Change: CARRIER now solves frozen vector constraints only over SEED_FRONTIER and materializes only grounded pre-RUT facts.
- Validation: 4/4 predicates PASS: backward substitution, seed-only free variables, deterministic evidence-domain tie-break, produced intermediates absent.
- Evidence: Failed carrier is discarded/re-solved; semantic vector is unchanged.

## S08 — Single-commit WITNESS lifecycle
- Status: VALIDATED PASS
- Change: Collapsed Standard WITNESS construction to local VECTOR→SEED→CARRIER→REPLAY→RESOLVE and one final MemoryTemp commit.
- Validation: 4/4 predicates PASS: one WITNESS call, no draft persistence, no self-error INVALIDATE, old Standard commit-gate retry prose removed.
- Evidence: WITNESS serialization occurs only after all scenario replays succeed.

## S09 — Standard output projection simplification
- Status: VALIDATED PASS
- Change: Removed persisted Standard ORACLE/DECIDE phases and OUTPUT/DECISION rows. Replaced them with pure PROJECT_ASSERTIONS(WITNESS,Scenario); BUILD is grouping-only; removed redundant SDL seed ledger.
- Validation: 9/9 targeted predicates PASS: no ORACLE/DECIDE generations/rows/HEAD fields, pure transform present, BUILD grouping-only, Projection evaluates once, SDL removed.
- Evidence: Standard ScenarioTrace is now IR→MAP→WITNESS→BUILD only; original Rule-Obj-When keeps its dedicated FREEZE branch.

## S10 — Semantic Page to live-Pega physical model
- Status: VALIDATED PASS
- Change: Established the user-supplied manual Pega Page assertion as the golden physical fixture; semantic Page source remains unchanged.
- Validation: 6/6 fixture predicates PASS: parent Page, parent Is Equals To, child Property, child Exists, full absolute path, no step-page dependency.
- Evidence: Canonical live shape stored in REPORTS/LIVE_PEGA_PAGE_ASSERTION_GOLDEN.json with nonsemantic metadata removed.

## S11 — Standard target Page schema
- Status: VALIDATED PASS
- Change: Replaced invented PagePathAssertion target model with canonical PageAssertionBlock→PageExistenceAssertion matching live Pega; updated Standard JsonExample and CM-ASSERT-STD-001.
- Validation: 8/8 schema/example predicates PASS; JSON parses; old PagePathAssertion removed; child has no mode/expected and carries full absolute path.
- Evidence: Page parent now requires pyCardApplyToClass + Is Equals To + nonempty child array; generated Page family disallows pyStepPageName/Class.

## S12 — Generator Page compiler
- Status: VALIDATED PASS
- Change: Replaced Generator Page family with one COMPILE_PAGE transform: BASE_PAGE + relative item path -> full absolute clipboard path; emits live Pega parent/child shape only.
- Validation: 7/7 targeted predicates PASS; PagePathAssertion vocabulary removed from Generator; G7 recomputes exact full path.
- Evidence: Source page=CustomerCommunication + item.path=.Addresses(1) has one legal candidate path CustomerCommunication.Addresses(1).

## S13 — Validator Page reference compiler
- Status: VALIDATED PASS
- Change: Replaced Validator PagePathAssertion interpretation with independent live-Pega Page reference compilation from Projection.
- Validation: 6/6 predicates PASS: exact parent/child shape, BASE_PAGE path, relative path rejected, physical child Property distinguished from semantic source kind.
- Evidence: Candidate .Addresses(1) can no longer compare equal to source CustomerCommunication + .Addresses(1).

## S14 — BASE_PAGE / FULL_PATH function
- Status: VALIDATED PASS
- Change: Unified BASE_PAGE/FULL_PAGE_PATH algorithm across target mapping, Generator and Validator.
- Validation: 6/6 parity predicates PASS across all three physical authorities; schema absolute path excludes leading-dot form.
- Evidence: BASE_PAGE = source.page → primary.page → RunRecordPrimaryPage; FULL_PAGE_PATH = BASE_PAGE + item.path.

## S15 — Self-page structural handling
- Status: VALIDATED PASS
- Change: Kept page-self semantic handling fail-safe pending a direct manual self-page fixture; removed no structure and introduced no surrogate path.
- Validation: 4/4 predicates PASS: self-page terminal OMIT remains, no pxObjClass proxy, no "." physical mapping, generated Page child must be absolute.
- Evidence: Nested Page/PageList existence is now representable correctly; page-self does not invent a physical representation.

## S16 — IR source-unit census preservation
- Status: VALIDATED PASS
- Change: No semantic rewrite required: retained W3GM static IR producer census and no-DEPIR design.
- Validation: 4/4 predicates PASS: UPDATE_PAGE producer=YES, signature producer census 1:1, no DEPIR row family, exact EXPECTED_PROD bijection.
- Evidence: Fresh-run IR stabilization fix remains intact; conditional execution affects PATH, never PROD membership.

## S17 — EFFECT execution semantics preservation
- Status: VALIDATED PASS
- Change: No semantic rewrite required: retained one EFFECT per executed effect-bearing PROD and target-owned structural before/after state.
- Validation: 4/4 predicates PASS: EFFECT bijection, no downstream producer reconstruction, APPEND target-state authority, UPDATE_PAGE empty-shell semantics.
- Evidence: Structural effects remain execution facts consumed by pure assertion projection.

## S18 — Legacy block removal
- Status: VALIDATED PASS
- Change: Removed stale Standard-ORACLE reference from When KA and verified old PagePath/ORACLE/DECIDE/SDL representations are absent across all production artifacts.
- Validation: 8/8 banned historical markers absent; TEST_ORACLE remains explicitly a testability state only.
- Evidence: Cross-production grep covers 3 prompts, 6 KAs, Standard schema and example.

## S19 — Preserved mechanism non-regression
- Status: VALIDATED PASS
- Change: No semantic rewrite of proven-live acquisition/carrier/IR/DT mechanisms.
- Validation: RuleCrawler exact holder/wire grammar retained; typed CARRIER/PageList retained; UPDATE_PAGE remains producer=YES; NO_SCALAR_VALUE retained; Property/Pages/RUF byte-identical W3GJ; DecisionTable/Model byte-identical W3GM; When differs only by stale terminology cleanup.
- Evidence: W3GK `pyItemRuleId,pxRuleReferences` envelope and full W<n>|SCAN|OUT|BLK|ACT|CHK|FIX plan are present.

## S20 — Token/dynamic-state optimization
- Status: VALIDATED PASS
- Change: Optimization is structural removal of redundant persisted phases, not evidence truncation.
- Validation: ScenarioAuthor 156170→~120k chars (~-23%); ScenarioAuthor+6KA ~-14%; actual fresh W3GM ScenarioTrace 105141 chars vs projected W3GN 52155 chars (-50.4%).
- Evidence: Removed persisted ORACLE/DECIDE and discarded/draft WITNESS snapshots; Generator/schema also became smaller.

## S21 — Production footprint
- Status: VALIDATED PASS
- Change: Exactly six production artifacts changed.
- Validation: Changed: ScenarioAuthor, Generator, Validator, When KA stale line, Standard schema, Standard example. DecisionTable/Model/Property/Pages/RUF are byte-identical to their baselines.
- Evidence: `REPORTS/W3GN_PRODUCTION_FOOTPRINT.json`.

## S22 — Determinism acceptance simulation
- Status: VALIDATED PASS
- Change: Executed pure W3GN algorithms on fixtures reconstructed from `2709-1434.zip`.
- Validation: Three independent executions produced identical canonical SHA-256 `c455a6d83f175a349e03aabfe102f7b227af4b6326bc9458051a0fd5eda7089d`.
- Evidence: `REPORTS/W3GN_SIMULATION_RESULTS.json` and `REPORTS/W3GN_SIMULATION_REPORT.md`.

## S23 — DetermineChannel acceptance
- Status: VALIDATED PASS
- Change: Causal seed ownership now follows producer backtracking.
- Validation: `Primary.pyName` absent from seed frontier/CARRIER; 2,7,true→rows0+1→TestJuneAugust→First; 3,7→row1→TestAugust→Second; Param.Run omitted from NO_SCALAR_VALUE; missing DT evidence yields BLOCKED and no exact Projection.
- Evidence: deterministic simulation results.

## S24 — PrepareCustomerCommunication acceptance
- Status: VALIDATED PASS
- Change: Model vector construction is REF-copy plus one-coordinate alternative only; Page physical compiler uses the live Pega shape.
- Validation: Exact vectors `[T2,T3,T5]`, `[T1]`, `[T2,T4,T5]`, `[T2,T3,T6]`; diagonal `[T2,T4,T6]` has no constructor; append Page child absolute path is `CustomerCommunication.Addresses(1)`.
- Evidence: deterministic simulation results and golden live Page fixture.

## S25 — Final success criteria / cross-file proofread
- Status: VALIDATED PASS
- Change: Final proofread removed remaining ScenarioTrace INVALIDATE repair row and converted new-evidence handling to abandon/restart epoch; no extra KA semantic churn introduced.
- Validation: 54/54 final checks PASS: Draft-2020-12 schema; all three Standard JsonExamples; live golden Page shape; adversarial Page rejects; no PagePathAssertion/ORACLE/DECIDE/OUTPUT/DECISION/SDL/INVALIDATE legacy; synchronized FULL_PAGE_PATH in schema/Generator/Validator; section refs; immutable KA hashes; RuleCrawler/UPDATE_PAGE non-regression; deterministic simulation.
- Evidence: `REPORTS/W3GN_FINAL_VALIDATION.json` and `REPORTS/W3GN_FINAL_PROOFREAD.md`.
