# W3GN deterministic simulation — fresh 2709 fixture

Status: **PASS**

Three independent executions produced the same canonical SHA-256:

`c455a6d83f175a349e03aabfe102f7b227af4b6326bc9458051a0fd5eda7089d`

## PrepareCustomerCommunication

Exact vector set on every execution:

```text
[T2,T3,T5]
[T1]
[T2,T4,T5]
[T2,T3,T6]
```

The old diagonal `[T2,T4,T6]` has no constructor.

## DetermineChannel

`pyName` is absent from both seed frontier and carrier. The seed frontier resolves through the DT producer to `pyText`, `pyTempInteger`, and Data Page state.

- `pyText=2,temp=7,validPostal=true` -> rows `[0,1]` -> `TestJuneAugust` -> `pyValue=First`.
- `pyText=3,temp=7` -> row `[1]` only -> `TestAugust` -> `pyValue=Second`.
- `Param.Run` -> `NO_SCALAR_VALUE` -> `OMIT inactive_evaluate_all_scalar`.
- Missing executable DT evidence -> `BLOCKED_EXECUTABLE_DEPENDENCY`; no exact Projection is created.

## Page assertion

Canonical generated physical child path:

`CustomerCommunication.Addresses(1)`

Parent=`Page`, child=`Property`, comparator=`Exists`; no `pyStepPageName`, no relative `.Addresses(1)`.
