# CURRENT STATUS — R50 DT PRE-WITNESS CLOSURE REPAIR

R50 prevents ScenarioAuthor from committing a Decision-Table-dependent witness before the fetched table's DTM-active dependency graph is transitively closed and its scenario-specific DT/Data-Page execution evidence is ready. It preserves the existing architecture and keeps KDT/KDP as domain-semantic authorities.

**Bundle date:** 2026-09-22  
**Current release:** R50  
**Authority:** this bundle is the sole current project version. `STATUS.md` describes active behavior; `VALIDATION_HISTORY.md` is historical/non-authoritative.

## R50 current delta

- Production change: `01_PROMPTS/ScenarioAuthor_SystemPrompt.txt` only.
- Adds `DT_PREWITNESS_READY(DT)` so a fetched reachable DT cannot be considered Author-ready until DTM exists, KDT.10 active-field scanning is complete, and all resulting dependency occurrences are closed/terminal.
- Moves DT producer detection earlier via `POTENTIAL_DT_PRODUCER(DT,P)` from DTM-active `pyPropertyColumns`, preventing a downstream final-value constraint from becoming its own setup seed before row/DTA selection.
- Adds `DP_SIM_READY(S,DP)`: DT-discovered Data Page occurrences classified `evaluated|unknown` require KDP.8/KDP.9/KDP.10 simulation evidence; `NO_SIMULATION` is legal only with no required simulation.
- Retains R49 `DT_CAUSAL_VALID`/FREEZE/AUDIT protections as secondary safety checks.
- KDT, KDP, Generator, Validator, Projection/target schemas, MemoryTemp and ScenarioTrace grammar are unchanged.

Offline validation: 69/69 focused checks PASS; existing target examples 6/6 schema-valid; live `PXCONV-198051` is correctly classified as invalid because it performs only one RuleCrawler wave before WITNESS, directly seeds `Primary.pyName=TestJuneAugust`, and commits `NO_SIMULATION`. Prior `PXCONV-198007` confirms the missing transitive dependency waves. Fresh live Pega/model replay of R50 remains required for acceptance.

See:
- `R50_DT_PREWITNESS_CLOSURE_PROGRESS.md`
- `../docs/r50/R50_VALIDATION_REPORT.md`
- `../docs/r50/R50_VALIDATION_RESULTS.json`
- `../docs/r50/R50_LIVE_TRACE_REGRESSION.json`

## R45 current delta

- Fixed one real target-fidelity skew: existing `CM-WHEN-001` makes source `valueType` evidence-only with no target coordinate; Validator now explicitly applies `NO_FIDELITY_CHECK` to `valueType` instead of treating it as target-mapped.
- Replaced one obsolete Validator reference to semantic “adapters” with the existing direct Knowledge Area terminology; action scope is unchanged.
- Intentional asymmetries remain intentional: `CM-NAME-001` and deterministic Property-block packing stay Generator-owned; Validator does not duplicate Generator implementation when the shared target contract permits multiple legal representations.
- ScenarioAuthor, UnitTestGenerator, all Knowledge Areas, target schemas/examples and tool contracts are unchanged from R44R.

Static validation: target-sync 115/115 PASS; independent architecture/release 49/49 PASS; examples 6/6 schema-valid; Candidate corruption 7/7 detected; architecture preservation PASS; Critical 0 / High 0 / Medium 0 / Unresolved 0. Fresh live Pega/model replay remains pending.

See:
- `R45_GENERATOR_VALIDATOR_SYNCHRONIZATION_SPEC.md`
- `R45_GENERATOR_VALIDATOR_SYNCHRONIZATION_VALIDATION.md`
- `../docs/r45/GENERATOR_VALIDATOR_SYNC_MATRIX.csv`
- `../docs/r45/R45_FINAL_INDEPENDENT_REVIEW.md`

## R44R current delta

- ScenarioAuthor §6.4 explicitly owns all Projection semantic/cross-field validation before persistence.
- Generator §2.1 contains the full local Projection interface as **trusted producer guarantees**, not a second source-semantic validator.
- Generator source checks are limited to Invocation/Memory/JSON/readability and `pyGroup == physicalGroupKey` transport correlation.
- Generator §§3–7 remain the R43 target/compiler/fidelity/lifecycle architecture; G7 is explicitly Candidate compilation fidelity, never Projection semantic review.
- Validator remains `Candidate == Compile(Projection)`, never `Projection == BusinessTruth`; mode selection is mechanical target/fidelity routing only.
- Knowledge Areas, target schemas/examples, tool contracts, ScenarioCompiler phases, 11 pre-projection gates and `PREPARE_ALL -> PERSIST_ALL -> GENERATE_ALL` are unchanged from R43.

Final static validation: boundary 145/145 PASS; regression 125/125 PASS; architecture-preservation 48/48 PASS; independent G1–G10 131/131 PASS; fresh-agent review 20/20 PASS; Critical 0 / High 0 / Medium 0. Fresh live Pega/model replay remains pending.

See:
- `R44R_PROJECTION_PRODUCER_AUTHORITY_RESTORATION_SPEC.md`
- `R44R_PROJECTION_PRODUCER_AUTHORITY_RESTORATION_VALIDATION.md`
- `../docs/r44r/R44R_FINAL_INDEPENDENT_REVIEW.md`
- `../docs/r44r/PROJECTION_RULE_OWNERSHIP.csv`

## R43 current delta

Decision Table domain ownership is consolidated in `Rule-Declare-DecisionTable_KnowledgeArea` (`KDT.1–KDT.12`). Core §3.7 now contains only integration/lifecycle policy: DTM/DTA/DTE bridge and consumers, nested-output restrictions, inactive-scalar disposition mapping, frozen setup requirements, KDT.12 audit handling and Core-owned repair. Direct Decision Table MAP coverage references KDT.11 result-equivalence instead of duplicating the domain tuple.

Two review findings were repaired: H-R43-01 restored explicit DTE→RX/semantic-propagation and DTA→I/O/setup/DECIDE consumer mapping after thinning; H-R43-02 removed undefined inherited `DTC/DTRA` terminology.

Final static validation: semantic suite 104/104 PASS; dynamic/nested adversarial 25/25 PASS; independent G1–G10 64/64 PASS; Critical 0 / High 0 / Medium 0. Fresh live Pega/model replay remains pending.

See:
- `R43_DECISION_TABLE_OWNERSHIP_CLEANUP_SPEC.md`
- `R43_DECISION_TABLE_OWNERSHIP_CLEANUP_VALIDATION.md`
- `../docs/r43/R43_FINAL_INDEPENDENT_REVIEW.md`
- `../docs/r43/DECISION_TABLE_SEMANTIC_OWNERSHIP.csv`

## R42 current delta

R42 hardens Knowledge-Area boundaries without redesigning domain algorithms. Data Page and Decision Table KAs now return domain facts/status/evidence only; ScenarioAuthor Core remains the sole owner of lifecycle, invalidation/repair, assertion policy, Projection and persistence. Decision Table now has fail-closed direct Knowledge Area marker requirements for exactly KDT.1–KDT.12. KDT.10 nested dependencies always re-enter Core/DWL; direct KA→KA marker invocation is forbidden.

Final validation: focused semantics 117/117 PASS; dynamic-loading adversarial 14/14 PASS; independent G1–G10 119/119 PASS; Critical 0 / High 0 / Medium 0. Generator/Validator consume no KW/KDP/KDT internals. Runtime context overhead versus R41 is bounded to ~1.07–1.44% after compression. Fresh live Pega/model replay remains pending.

See:
- `R42_KA_BOUNDARY_HARDENING_SPEC.md`
- `R42_KA_BOUNDARY_HARDENING_VALIDATION.md`
- `../docs/r42/R42_FINAL_INDEPENDENT_REVIEW.md`
- `../docs/r42/KA_DEPENDENCY_MATRIX.csv`


## R41 current delta

R41 externalizes **domain definitions**, not lifecycle, from ScenarioAuthor Core into the existing `Rule-Obj-When_KnowledgeArea` and `Rule-Declare-Pages_KnowledgeArea`. Core remains sole owner of tool legality, DWL, phase/ScenarioTrace ownership and BASE, commit/invalidation/repair, Projection lifecycle and `PREPARE_ALL -> PERSIST_ALL -> GENERATE_ALL`.

Fail-closed Knowledge Area semantics are marker-complete: Rule-Obj-When requires KW.17–KW.25; Rule-Declare-Pages requires KDP.6–KDP.12; Decision Table requires KDT.1–KDT.12. Missing, partial, duplicate or ambiguous required semantics blocks affected AUTHOR work; no generic/historical fallback is legal. Rule-Obj-When W01–W25 and Data Page DP01–DP20 are fully mapped; independent Core boundary checks remain.

Final validation: When thin-Core 44/44 PASS; Data Page 21/21 PASS; cross-artifact regression 72/72 PASS; dynamic loading adversarial suite 14/14 PASS; independent G1–G10 32/32 PASS; Critical 0 / High 0 / Medium 0. Every measured activation context is smaller than R40. Validation is textual/semantic and contract-based; no SHA/hash/textual-diff correctness gate. Fresh live Pega/model replay remains pending.

See:

- `R41_KA_SEMANTIC_EXTERNALIZATION_SPEC.md`
- `R41_KA_SEMANTIC_EXTERNALIZATION_VALIDATION.md`
- `../docs/r41_ka/GLOBAL_VALIDATION.md`
- `../docs/r41_ka/SEMANTIC_OWNERSHIP_MAP.csv`
- `../docs/r41_ka/TOKEN_CONTEXT_METRICS.json`

## R40 current delta

R40 restores original `Rule-Obj-When`/MultInpComb semantics from the old `RuleIQ/Main_Agent_Prompt.txt` into the current R39C architecture. The old T/S/I/W/F/B/A storage and target RuleCode construction are **not** reintroduced. Instead, W01–W25 are mapped into current MAP/WITNESS/FREEZE/BUILD/AUDIT, source Projection rows, and existing Generator/schema mappings.

Key restored guarantees: complete TRUE/FALSE + MC/DC census; execution-derived owner/covers; deterministic fixed-point FREEZE reduction with re-execution; exact duplicate proof; canonical `given+simulation` sort before final Scenario ids; mandatory executable rows for every R-covering frozen Scenario; complete simulation-key grouping; source-level row/path/empty-value fidelity; exact Result dependency closure; independent AUDIT reconstruction.

Current-only informational mode is non-substitutive: it is legal only for terminal zero-R MAP with no executable coverage Scenario/group/row. R39D D1 is non-authoritative and quarantined. Target MultInpComb wrappers/constants/Result representation remain Generator/schema-owned (`CM-WHEN-001`, `CF-WHEN-ORDER-001`, `CM-EXEC-001`).

Validation: W01–W25 PASS; UNMAPPED=0; GAP=0; active D1-only authority=0; Critical 0 / High 0 / Medium 0. Validation is textual/semantic and source/contract based; no SHA/hash/textual-diff correctness gate. Fresh live Pega/Opus replay remains pending.

See:

- `R40_RULE_OBJ_WHEN_SEMANTIC_RESTORATION_SPEC.md`
- `R40_RULE_OBJ_WHEN_SEMANTIC_RESTORATION_VALIDATION.md`
- `../docs/r40_when/R40_EXECUTION_STATE.md`
- `../docs/r40_when/R40_FINAL_INDEPENDENT_REVIEW.md`

## R39C current delta

Only `ScenarioAuthor_SystemPrompt.txt` changes at runtime from R38. R39C is a conservative prompt-structure optimization for Claude Opus 4.8: wording is more imperative, repeated explanations are reduced without removing independent gates, compiler phases are presented explicitly, and the full inline ProjectionV3 contract remains. Existing R38 property-path/page-class hardening, R37 comparator ownership, and R36 ScenarioTrace/AUDIT architecture remain active.

Final textual-semantic validation: `Critical 0 / High 0 / Medium 0`. No SHA/hash/diff comparison was used. Fresh live Pega/model replay of R39C remains pending.

See:

- `R39_CONSERVATIVE_PROMPT_OPTIMIZATION_SPEC.md`
- `R39_CONSERVATIVE_PROMPT_OPTIMIZATION_VALIDATION.md`
- `../docs/refactor/R39_FINAL_GLOBAL_VALIDATION.md`

## R38 current delta

Only `ScenarioAuthor_SystemPrompt.txt` changes from R37 at runtime. R38 closes a property-path/page-class lineage gap exposed by `GENUT-93002`: required navigation Properties are now dependency-closed even when already listed in `pxRuleReferences[]`; Standard OUTPUT carries frozen `baseClass`; AUDIT and Projection self-validation require exact page/class lineage before persistence. Generator, Validator, Projection external schema, target contracts, tools, and Rule-Obj-When behavior remain unchanged.

See:

- `R38_PROPERTY_PATH_CLASS_LINEAGE_HARDENING_SPEC.md`
- `R38_PROPERTY_PATH_CLASS_LINEAGE_HARDENING_VALIDATION.md`

## R37 current delta

Only `ScenarioAuthor_SystemPrompt.txt` changes from R36. Standard assertion comparators are now Author-owned canonical source facts. DECIDE freezes exact comparator labels from kind-specific closed domains matching the selected target schema; Projection copies them exactly and pre-persistence validation rejects aliases such as `Is equal to`. R36 ScenarioTrace, lineage audit and self-repair semantics are unchanged.

See:

- `R37_CANONICAL_COMPARATOR_CONTRACT_SPEC.md`
- `R37_CANONICAL_COMPARATOR_CONTRACT_VALIDATION.md`

## R36 current delta

Only the ScenarioAuthor runtime prompt changes from R35.

R36 fixes silent cross-phase semantic loss and compacts execution state without redesigning successful MAP planning:

- MAP retains `OUTCOME`, `COV`, `PDEF`.
- WITNESS must resolve every MAP COV exactly once with `RESOLVE=REALIZED|BLOCKED`; missing transition is malformed.
- Standard WITNESS and FREEZE use complete `PATH(E/S/U)` producer partitions instead of per-producer `EXEC` rows.
- FREEZE preserves exact WITNESS Scenario ids and uses compact runtime `EFFECT` rows instead of verbose Standard `PRODUCER` rows.
- DECIDE keeps explicit `OUTPUT` and `DECISION` as the assertion safety boundary.
- Standard AUDIT now references the complete active `MAP,WITNESS,FREEZE,DECIDE,BUILD` lineage and verifies every transition.
- `AUDIT=FAIL` emits exactly one deterministic `REPAIR(owner,code,affectedIds,action)`; the same Author invalidates the earliest owning generation and automatically rebuilds downstream before retrying AUDIT.
- Repair state is reconstructed from committed AUDIT/REPAIR rows, capped at five cycles, with deterministic no-progress detection.

The live `PXCONV-184052` failure is specifically blocked by a new planning-integrity gate requiring exactly one atomic COV for every required MAP OUTCOME and then exact MAP-COV/WITNESS-RESOLVE conservation.

See:

- `R36_LOSSLESS_COMPACT_SCENARIOTRACE_SPEC.md`
- `R36_LOSSLESS_COMPACT_SCENARIOTRACE_VALIDATION.md`
- `R36_BAD_CASE_SIMULATION.md`

## Active Standard ScenarioTrace

```text
MAP     : PHASE,HEAD,BASE,OUTCOME,COV,PDEF,COMMIT
WITNESS : PHASE,HEAD,BASE,RESOLVE,SCENARIO,PATH,[WHY],COMMIT
FREEZE  : PHASE,HEAD,BASE,SCENARIO,PATH,EFFECT,COMMIT
DECIDE  : PHASE,HEAD,BASE,OUTPUT,DECISION,COMMIT
BUILD   : PHASE,HEAD,BASE,GROUP,LOCATION,COMMIT
AUDIT   : PHASE,HEAD,BASE,AUDIT,[REPAIR],COMMIT
```

Core conservation rules:

```text
R OUTCOME <-> atomic COV
MAP COV == WITNESS RESOLVE
WITNESS Scenario ids == FREEZE Scenario ids
PATH.E union PATH.S union PATH.U == PDEF ids
executed effect-bearing PDEF -> exactly one EFFECT
OUTPUT ids == DECISION ids
DECISION ASSERT == normalized BUILD assertions
```

## AUDIT and repair

Standard AUDIT checks in order:

```text
MAP -> WITNESS
WITNESS -> FREEZE
PDEF -> PATH
PATH -> EFFECT
final state -> OUTPUT
OUTPUT -> DECISION
DECISION -> BUILD
```

Only active `AUDIT=PASS` may enter `PREPARE_ALL`.

On FAIL, AUDIT is diagnostic/control only. It identifies the earliest owner in:

```text
CRAWL -> MAP -> WITNESS -> FREEZE -> DECIDE -> BUILD
```

The owner is rebuilt through normal generation invalidation; AUDIT never patches committed semantic state directly.

## Downstream architecture

R34/R35 downstream boundaries remain unchanged:

- ScenarioAuthor materializes and self-validates `UnitTestProjectionV3` only after global AUDIT PASS.
- All Projections are prepared before any persistence.
- All prepared Projections are persisted before any Generator invocation.
- Generator owns technical Pega Unit Test naming and Candidate compilation/repair.
- Validator independently validates exact Projection + Candidate and never redefines Author semantics.
- Generator/Validator assistant prose is non-authoritative; exact Memory lifecycle state is authoritative.

## Naming / response contract

Unchanged from R34:

- ScenarioAuthor owns semantic Scenario names only.
- Generator alone applies `CM-NAME-001` and reuses the same target name for UnitTestRules[0].Name / pyPurpose / pyLabel.
- ScenarioAuthor terminal response has exactly `AIAgentResponseStatus` and `AIAgentErrorResponseMessage`.

## Validation boundary

Static/contract/regression validation for R38: **PASS — Critical 0 / High 0 / Medium 0**.

Direct-content comparison confirms every runtime file except `ScenarioAuthor_SystemPrompt.txt` is unchanged from R37. The active ScenarioAuthor prompt remains 604 lines and adds roughly 396 tokens by chars/4 estimate.

The supplied `PXCONV-184077(1).txt` regression was re-analyzed: `PageValue1..8` exist in RUT `pxRuleReferences[]`, while the observed run crawled only four When rules. R38 now forces required navigation Property dependencies and page-class lineage before ASSERT/Projection persistence.

Fresh live Pega/model execution of the modified R38 prompt remains pending external evidence and must not be represented as completed.

## R52 — DT replay + Scenario naming + validation routing

- Offline validation: 84/84 PASS.
- Production changes: ScenarioAuthor, UnitTestGenerator, Validator prompts only.
- No KDT/KDP/schema/tool/phase/ScenarioTrace-family changes.
- Live Pega acceptance pending.
