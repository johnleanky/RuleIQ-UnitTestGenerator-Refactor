# R53 Physical Name Truncation

Status: IMPLEMENTED + OFFLINE VALIDATED
Baseline: R52

Production changes only:
- `01_PROMPTS/UnitTestGenerator_SystemPrompt.txt`
- `03_TARGET_CONTRACTS/Rule-Test-Unit-Case_JsonSchema.txt`
- `03_TARGET_CONTRACTS/Rule-Test-Unit-Case_MultInpComb-JsonSchema.txt`

Change:
- keep existing `CM-NAME-001` name construction;
- after construction, if technical name length exceeds 53, use the first 53 characters;
- bind once as `TARGET_RULE_NAME` and reuse exactly for `UnitTestRules[0].Name`, `RuleCode.pyPurpose`, `RuleCode.pyLabel`;
- `Scenarios[].Name` remains exact Projection copy;
- Validator and ScenarioAuthor unchanged.

Offline validation: 34/34 PASS.
Fresh live Pega execution still required for runtime acceptance.
