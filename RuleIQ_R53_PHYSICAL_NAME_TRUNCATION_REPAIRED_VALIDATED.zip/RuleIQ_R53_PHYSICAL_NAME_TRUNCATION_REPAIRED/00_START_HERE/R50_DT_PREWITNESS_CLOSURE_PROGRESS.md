# R50 DT Pre-Witness Closure Repair Progress

Status: **OFFLINE VALIDATED — LIVE PEGA ACCEPTANCE PENDING**

Production changes:
- `01_PROMPTS/ScenarioAuthor_SystemPrompt.txt` only.

Architecture preserved:
- MAP → WITNESS → FREEZE → DECIDE → BUILD → AUDIT unchanged.
- HEAD / BASE / INVALIDATE / COMMIT unchanged.
- No new ScenarioTrace row family, agent, interface, Projection field or schema.
- KDT and KDP unchanged; their existing KDT.10/KDT.11 and KDP.6–KDP.11 semantics are reused.
- Generator and Validator unchanged.

Repair:
- `DT_PREWITNESS_READY(DT)` forces complete DTM-active KDT.10 dependency materialization/closure before Author readiness.
- DTA/DTE remain scenario-specific and are required before WITNESS commit, not incorrectly treated as preAuthor artifacts.
- `POTENTIAL_DT_PRODUCER(DT,P)` detects DTM-active `pyPropertyColumns` targets before DTA selection; final downstream constraints cannot self-authorize setup.
- `DP_SIM_READY(S,DP)` makes KDP.8 REQUIRED_SIMS/DP_SIG/SIM mandatory for evaluated/unknown DT-discovered DP accesses.
- R49 `DT_CAUSAL_VALID` remains the post-selection causal proof.

Validation:
- Focused architecture/semantic/live-derived checks: 69/69 PASS.
- Prompt growth vs R49: +167 words.
- Existing target examples: 6/6 schema-valid.
- NameMatch fixture: `Test + June + August -> TestJuneAugust -> First`, simulation required.
- R48 else fixture: `Test + August -> TestAugust -> Second`, simulation still required.
- `PXCONV-198051` is rejected by R50 at dependency closure, seed provenance and simulation gates.

Live acceptance required:
1. Run DetermineChannel with R50 ScenarioAuthor.
2. Confirm transitive RuleCrawler closure before WITNESS.
3. Confirm D_CustomerTestRef simulation is materialized when evaluated/unknown.
4. Confirm NameMatch setup uses legal DT before-state rather than final `TestJuneAugust`.
5. Confirm live actual results match frozen assertions.
