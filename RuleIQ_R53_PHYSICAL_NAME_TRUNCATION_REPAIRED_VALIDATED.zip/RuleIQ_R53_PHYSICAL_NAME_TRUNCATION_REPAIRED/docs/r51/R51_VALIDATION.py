from pathlib import Path
import json
from jsonschema import Draft202012Validator

ROOT = Path('/mnt/data/r51_work/RuleIQ_R51_CTX_IDENTITY_REPAIRED')
BASE = Path('/mnt/data/r51_work/RuleIQ_R50_DT_PREWITNESS_CLOSURE_REPAIRED')
PROMPT = ROOT/'01_PROMPTS/ScenarioAuthor_SystemPrompt.txt'
BASE_PROMPT = BASE/'01_PROMPTS/ScenarioAuthor_SystemPrompt.txt'
CUR_PATH = Path('/mnt/data/r51_inputs/PXCONV-197047.txt')
PREP_PATH = Path('/mnt/data/r51_inputs/PXCONV-184019.txt')
DEEP_PATH = Path('/mnt/data/r51_inputs/PXCONV-184077(1).txt')
DETCOND_PATH = Path('/mnt/data/r51_inputs/R46_SETUP_CARRIER_REGRESSION_SIMULATION_RESULTS.json')

new = PROMPT.read_text()
old = BASE_PROMPT.read_text()
CUR = CUR_PATH.read_text(errors='replace')
PREP = PREP_PATH.read_text(errors='replace')
DEEP = DEEP_PATH.read_text(errors='replace')
DETCOND = json.loads(DETCOND_PATH.read_text())
CUR_DOC = json.loads(CUR_PATH.read_text())

CUR_RETURNED=[]
for m in CUR_DOC.get('pyMessageHistory',[]):
    if m.get('pyName')=='RuleCrawler' and m.get('pyRole')=='tool' and isinstance(m.get('pyContent'),str):
        try:
            payload=json.loads(m['pyContent'])
        except Exception:
            continue
        for item in payload.get('InterestedRules',[]):
            for r in item.get('pxRuleReferences',[]):
                row={
                    'requestClass':r.get('pxRuleClassName'),
                    'family':r.get('pxRuleFamilyName'),
                    'objClass':r.get('pxRuleObjClass'),
                }
                if r.get('RuleJSON'):
                    try:
                        row['rule']=json.loads(r['RuleJSON'])
                    except Exception:
                        pass
                CUR_RETURNED.append(row)

checks=[]
def ck(name, cond, evidence=''):
    checks.append({'name':name,'pass':bool(cond),'evidence':evidence})

# 1. Patch shape / ownership
ck('R51 marker CTX_READY defined once', new.count('`CTX_READY(D)` means') == 1)
ck('R51 marker KEY_STABLE defined once', new.count('`KEY_STABLE(D)`') >= 3 and new.count('`KEY_STABLE(D)`:') == 1)
ck('old broad scan rule removed', 'Known request class -> READY. Context-derived class -> CTX until its provider proves the class.' not in new)
ck('context-derived general scan is fail-closed', 'A context-derived executable -> CTX until `CTX_READY(D)` proves its exact runtime/apply-to class from the completed provider chain.' in new)
ck('same-wave barrier excludes dependent from request', 'it cannot appear in SCAN/OUT/ACT/InterestedRules until a later wave' in new)
ck('preCall independently rechecks CTX_READY', 'Before PASS, require every context-derived READY occurrence to satisfy `CTX_READY(D)` and `KEY_STABLE(D)`' in new)
ck('response preserves requested KEY', 'Correlate/close the original requested KEY' in new)
ck('inherited implementation cannot rewrite key', 'including inherited `@baseclass`' in new and 'NEVER rewrites the occurrence/request KEY' in new)

# 2. Preserve R49/R50 safety mechanisms
for marker in ['DT_PREWITNESS_READY(DT)','POTENTIAL_DT_PRODUCER(DT,P)','DT_CAUSAL_VALID(S,P)','DP_SIM_READY(S,DP)']:
    ck(f'preserve {marker}', marker in new)

# 3. Production footprint. Exact file identity here proves footprint only, not semantic correctness.
prod_dirs=['01_PROMPTS','02_KNOWLEDGE_AREAS','03_TARGET_CONTRACTS','04_TOOLS']
changed=[]; missing=[]
for d in prod_dirs:
    for bp in (BASE/d).glob('*'):
        if not bp.is_file():
            continue
        rp=ROOT/d/bp.name
        if not rp.exists():
            missing.append(str(rp.relative_to(ROOT)))
            continue
        if bp.read_bytes()!=rp.read_bytes():
            changed.append(str(rp.relative_to(ROOT)))
ck('production footprint only ScenarioAuthor changed', changed==['01_PROMPTS/ScenarioAuthor_SystemPrompt.txt'], f'changed={changed}')
ck('no production files missing', not missing, f'missing={missing}')

# 4. Prompt growth budget
word_growth=len(new.split())-len(old.split())
char_growth=len(new)-len(old)
ck('prompt growth <= 220 words', 0 < word_growth <= 220, f'words+={word_growth}; chars+={char_growth}')

# 5. Target schema/example regression
schema_pairs=[
 ('Rule-Test-Unit-Case_JsonSchema.txt','Rule-Test-Unit-Case_JsonExample.txt'),
 ('Rule-Test-Unit-Case_MultInpComb-JsonSchema.txt','Rule-Test-Unit-Case_MultInpComb-JsonExample.txt')]
example_total=0; example_pass=0
for sname,ename in schema_pairs:
    schema=json.loads((ROOT/'03_TARGET_CONTRACTS'/sname).read_text())
    Draft202012Validator.check_schema(schema)
    ck(f'schema valid {sname}', True)
    validator=Draft202012Validator(schema)
    exdoc=json.loads((ROOT/'03_TARGET_CONTRACTS'/ename).read_text())
    for i,ex in enumerate(exdoc['Examples'],1):
        example_total += 1
        errs=list(validator.iter_errors(ex))
        if not errs:
            example_pass += 1
        ck(f'{ename} example {i} schema-valid', not errs, '; '.join(e.message for e in errs[:2]))
ck('all six existing target examples valid', example_total==6 and example_pass==6, f'{example_pass}/{example_total}')

# 6. Current DetermineChannel evidence + dry transition
wrong='When@Data-Customer@IsValidPostalAddress'
provider='Prop@Data-Customer@Addresses'
correct='When@Data-Address-Postal@IsValidPostalAddress'
ck('current run reproduces premature wrong When class', wrong in CUR)
ck('current run requests provider in same wave', provider in CUR)
ck('current response proves item runtime class', any(r.get('family')=='ADDRESSES' and r.get('rule',{}).get('pyPageClass')=='Data-Address-Postal' for r in CUR_RETURNED))

r51_w2={
    'READY':[provider,'DP@Data-Customer@D_CustomerTestRef','RUF@@ISINPAGELISTWHEN','Prop@RuleIQ-Data-TestRefLib@pyText','Prop@RuleIQ-Data-TestRefLib@pyTempInteger'],
    'CTX':['When@?@IsValidPostalAddress']
}
r51_w3={'READY':[correct],'CTX':[]}
ck('R51 dry-run removes wrong When from W2 READY', wrong not in r51_w2['READY'])
ck('R51 dry-run keeps When CTX during provider wave', r51_w2['CTX']==['When@?@IsValidPostalAddress'])
ck('R51 dry-run promotes exact When only next wave', r51_w3['READY']==[correct])

# 7. Known-good PageList flow replay
ck('old good trace W1 keeps PageList Whens CTX', 'CTX=[D:3:When@?@IsValidCity,D:4:When@?@IsValidPostalAddress]' in PREP)
ck('old good trace W1 requests Addresses provider', provider in PREP)
ck('old good trace later promotes IsValidCity exact class', 'When@Data-Address-Postal@IsValidCity' in PREP)
ck('old good trace later promotes IsValidPostalAddress exact class', correct in PREP)
ck('R51 dry-run matches known-good PageList sequencing', r51_w2['CTX']==['When@?@IsValidPostalAddress'] and r51_w3['READY']==[correct])

# 8. Direct-class regression
keys=[
 'When@Ruler-RuleBook-Data@RB_When_DeepRouteShallow',
 'When@Ruler-RuleBook-Data@RB_When_DeepRouteMedium',
 'When@Ruler-RuleBook-Data@RB_When_DeepAtLeast8',
 'When@Ruler-RuleBook-Data@RB_When_DeepBooleanEnabled']
ck('deep hierarchy trace has direct exact classes', all(k in DEEP for k in keys))
ck('R51 direct-class case remains READY without provider wave', all(k in DEEP for k in keys) and 'An exact class grounded directly by the occurrence\'s authoritative execution/named-page/context evidence -> READY.' in new)

# 9. Inherited property KEY stability using live returned implementation evidence
for prop in ['pyName','pyValue','pyText','pyTempInteger']:
    request=f'Prop@RuleIQ-Data-TestRefLib@{prop}'
    ck(f'live request has semantic occurrence key {prop}', request in CUR)
ck('live response contains inherited @baseclass Property implementation', any(r.get('objClass')=='Rule-Obj-Property' and r.get('rule',{}).get('pyClassName')=='@baseclass' for r in CUR_RETURNED))
stable_keys={p:f'Prop@RuleIQ-Data-TestRefLib@{p}' for p in ['pyName','pyValue','pyText','pyTempInteger']}
ck('KEY_STABLE dry-run retains semantic request class', all(v.startswith('Prop@RuleIQ-Data-TestRefLib@') for v in stable_keys.values()))
ck('KEY_STABLE dry-run forbids blank-class canonical props', all('Prop@@@' not in v for v in stable_keys.values()))

# 10. DetermineCondition existing regression preservation
ck('DetermineCondition prior simulation baseline passes', DETCOND.get('overall')=='PASS' and DETCOND.get('passCount')==DETCOND.get('checkCount'))
g1=DETCOND['correctedProjections']['G001']
sims=g1.get('simulations',[])
addr=sims[0]['setupPages'][0]['data'].get('Addresses',[]) if sims else []
ck('DetermineCondition nested simulation item class remains Data-Address-Postal', bool(addr) and addr[0].get('pxObjClass')=='Data-Address-Postal')
ck('DetermineCondition DP simulation still present', bool(sims) and sims[0].get('rule')=='D_CustomerTestRef')

# 11. Adversarial synthetic context cases
def classify(direct_exact=False, provider_requested=False, provider_class=None):
    if direct_exact:
        return ('READY','direct-authority')
    if provider_requested:
        return ('CTX','same-wave-provider')
    if provider_class:
        return ('READY',provider_class)
    return ('CTX','unresolved')
ck('named-page/direct exact class remains READY', classify(direct_exact=True)[0]=='READY')
ck('same-wave provider stays CTX', classify(provider_requested=True)[0]=='CTX')
ck('resolved provider promotes in later wave', classify(provider_class='Data-Address-Postal')==('READY','Data-Address-Postal'))
ck('unresolved provider never guesses class', classify()==('CTX','unresolved'))

# 12. R50 Decision Table semantic fixtures remain unchanged
def channel(py_name, py_text, temp, helper_true):
    row0 = (py_text == '2') and helper_true and (temp > 1) and (temp <= 8)
    row1 = (py_text in ('3','2')) and (temp > 5) and (temp <= 10)
    name=py_name
    matched=[]
    if row0:
        matched.append(0); name += 'June'
    if row1:
        matched.append(1); name += 'August'
    value='First' if name=='TestJuneAugust' else 'Second'
    return {'matched':matched,'pyName':name,'pyValue':value,'simulation_required':True}
true_case=channel('Test','2',7,True)
else_case=channel('Test','2',7,False)
ck('R50 NameMatch rows 0+1 preserved', true_case['matched']==[0,1], str(true_case))
ck('R50 NameMatch final pyName preserved', true_case['pyName']=='TestJuneAugust', str(true_case))
ck('R50 NameMatch downstream First preserved', true_case['pyValue']=='First', str(true_case))
ck('R50 NameMatch still requires DP simulation', true_case['simulation_required'] is True)
ck('R48/R50 else row1-only preserved', else_case['matched']==[1], str(else_case))
ck('R48/R50 else final TestAugust preserved', else_case['pyName']=='TestAugust', str(else_case))
ck('R48/R50 else downstream Second preserved', else_case['pyValue']=='Second', str(else_case))
ck('R48/R50 else still requires DP simulation', else_case['simulation_required'] is True)

# 13. Ownership/non-leakage checks
for rel in ['01_PROMPTS/UnitTestGenerator_SystemPrompt.txt','01_PROMPTS/Validator_SystemPrompt.txt']:
    txt=(ROOT/rel).read_text()
    ck(f'no R51 dependency invariant leaked into {Path(rel).name}', all(t not in txt for t in ['CTX_READY','KEY_STABLE']))
ck('no new ScenarioTrace CTX_READY row family', 'CTX_READY|' not in new)
ck('no new ScenarioTrace KEY_STABLE row family', 'KEY_STABLE|' not in new)
kdt=(ROOT/'02_KNOWLEDGE_AREAS/Rule-Declare-DecisionTable_KnowledgeArea_REFERENCE.txt').read_text()
kdp=(ROOT/'02_KNOWLEDGE_AREAS/Rule-Declare-Pages_KnowledgeArea_REFERENCE.txt').read_text()
ck('KDT active dependency semantics still present', 'KDT.10|A|NestedDependencyScan' in kdt)
ck('KDP simulation census semantics still present', 'KDP.8|A/S|RequiredSimulationCensus' in kdp and '`evaluated|unknown`' in kdp)

# 14. Residue / contradiction scan
for bad,label in [
    ('Known request class -> READY','old broad READY rule'),
    ('Prop@@@pyName','blank canonical pyName example'),
    ('Prop@@@pyValue','blank canonical pyValue example')]:
    ck(f'no residue: {label}', bad not in new)
ck('PageList helper retains final pyPageClass authority', 'final PageList/PageGroup `pyPageClass` is the When apply-to class' in new)
ck('property applies-to metadata remains non-runtime evidence', '`pxRuleReferences[].pxRuleClassName` is Property Applies-To/request class ONLY. NEVER use it as embedded runtime page class or closure evidence.' in new)

passed=sum(c['pass'] for c in checks)
result={
    'version':'R51',
    'overall':'PASS' if passed==len(checks) else 'FAIL',
    'passCount':passed,
    'checkCount':len(checks),
    'promptGrowthWords':word_growth,
    'promptGrowthChars':char_growth,
    'productionChangedFiles':changed,
    'checks':checks,
    'simulations':{
        'DetermineChannel':{'W2':r51_w2,'W3':r51_w3},
        'PrepareCustomerCommunication':'known-good CTX -> provider -> exact class sequence preserved',
        'DeepHierarchy':'direct exact When classes remain READY in W1',
        'DetermineCondition':'existing DP simulation preserved; nested Addresses item class remains Data-Address-Postal',
        'ChannelCode_NameMatch':true_case,
        'ChannelCode_Else':else_case
    }
}
(ROOT/'docs/r51/R51_FINAL_VALIDATION_RESULTS.json').write_text(json.dumps(result,indent=2))
print(json.dumps({k:result[k] for k in ['overall','passCount','checkCount','promptGrowthWords','promptGrowthChars','productionChangedFiles']},indent=2))
if result['overall']!='PASS':
    for c in checks:
        if not c['pass']:
            print('FAIL',c)
    raise SystemExit(1)
