# R51 Context Resolution & Canonical Dependency Identity Repair — Validation

## Result

**PASS — 70/70 checks.**

Production delta is limited to:

`01_PROMPTS/ScenarioAuthor_SystemPrompt.txt`

No production changes were made to KDT, KDP, Generator, Validator, target schemas/examples, tools, ProjectionV3, MemoryTemp, or ScenarioTrace grammar.

Prompt growth versus R50: **+182 words / +1469 characters**.

## Confirmed root cause

The live R50 trace formed `When@Data-Customer@IsValidPostalAddress` in the same RuleCrawler wave that requested `Prop@Data-Customer@Addresses`. The returned property then proved `pyPageClass=Data-Address-Postal`. The specialized Page/List rule already required CTX through that wave, but the generic scan rule still allowed a broad "known request class -> READY" interpretation. R51 removes that conflict and makes the barrier independently enforceable at preCall.

A second confirmed issue was canonical-key degradation after inherited property resolution: semantic request keys such as `Prop@RuleIQ-Data-TestRefLib@pyName` must remain occurrence identities even when the returned implementation is `@baseclass`.

## Implemented behavior

R51 adds/strengthens only these dependency-orchestration rules:

- `CTX_READY(D)`: a context-derived executable is READY only after its exact runtime/apply-to class is grounded by authoritative context evidence.
- Page/List helper specialization: final provider `pyPageClass` is required; Data Page payload/root/provider owner class is not a substitute.
- Same-wave barrier: if the required final provider is requested in this wave, the dependent stays CTX and is excluded from SCAN/OUT/ACT/InterestedRules until a later wave.
- `KEY_STABLE(D)`: `? -> exact KEY` is legal once after class proof; an exact occurrence/request KEY is then immutable.
- Returned RuleJSON `pyClassName`/`pzInsKey`, including inherited `@baseclass`, is implementation evidence and cannot rewrite the semantic occurrence KEY.
- RuleCrawler response reconciliation closes the original requested KEY; a newly proven context-derived executable becomes READY only in the subsequent wave.

## Current DetermineChannel simulation

Expected corrected sequence:

```text
W2
READY:
  DP@Data-Customer@D_CustomerTestRef
  RUF@@ISINPAGELISTWHEN
  Prop@RuleIQ-Data-TestRefLib@pyText
  Prop@RuleIQ-Data-TestRefLib@pyTempInteger
  Prop@Data-Customer@Addresses

CTX:
  When@?@IsValidPostalAddress

response:
  Addresses.pyPageClass = Data-Address-Postal

W3
READY:
  When@Data-Address-Postal@IsValidPostalAddress
```

The incorrect `When@Data-Customer@IsValidPostalAddress` is not requestable under R51.

After dependency closure, existing R48/R50 semantics remain:

- NameMatch: `pyName=Test`, `pyText=2`, `pyTempInteger=7`, helper=true → rows 0+1 → `TestJuneAugust` → `pyValue=First`; Data Page simulation required.
- Else: same seed/range with helper=false → row 1 only → `TestAugust` → `pyValue=Second`; Data Page simulation still required because the access is evaluated.

## Regression simulations

### PrepareCustomerCommunication

The earlier known-good trace already uses the intended R51 sequence: W1 fetches `D_CustomerTestRef` and `Addresses` while both page-list When dependencies remain CTX; W2 promotes them to `Data-Address-Postal`. R51 preserves this behavior.

### RLD_DT_DeepHierarchyOperations

The four `When@Ruler-RuleBook-Data@...` dependencies have direct authoritative class evidence. They remain READY in W1. R51 adds no CTX state and no extra provider wave.

### DetermineCondition

The prior 36/36 setup/simulation regression remains compatible. `D_CustomerTestRef` stays simulated and the nested `Addresses(1)` item remains `pxObjClass=Data-Address-Postal`.

### Inherited properties

Requests such as:

`Prop@RuleIQ-Data-TestRefLib@pyName`

remain canonical even when Pega returns a physical implementation with:

`pyClassName=@baseclass`.

Blank/degraded forms such as `Prop@@@pyName` are not valid post-resolution identities.

## Risk review

The repair is intentionally narrow:

- Direct-class and named-page-grounded dependencies remain fast-path READY.
- Only context-derived dependencies waiting on unresolved provider semantics incur an additional wave.
- Unresolvable provider class remains CTX/terminal gap under existing policy; no class is guessed.
- Same rule name on different classes remains distinct by canonical KEY.
- KDT/KDP ownership and R50 pre-WITNESS/causal/simulation gates are unchanged.
- No new persisted row, phase, interface, tool, Projection field, or downstream semantic responsibility is introduced.

## Validation boundary

This is an offline semantic/trace replay and contract validation. It does not claim live Claude/Pega acceptance. Final acceptance requires a fresh Pega ScenarioAuthor run showing the corrected W2 CTX state and later `When@Data-Address-Postal@IsValidPostalAddress` request.
