# R49 Causal Witness & Seed-Direction Integrity Repair — Validation

## Production scope

Only `01_PROMPTS/ScenarioAuthor_SystemPrompt.txt` changed relative to R48 production files.

Unchanged production authorities:
- Decision Table Knowledge Area
- UnitTestGenerator prompt
- Validator prompt
- Standard and MultInpComb target schemas
- MemoryTemp / ScenarioTrace phase and row contract

## Implemented ScenarioAuthor changes

1. §3.1 delegates DT-owned exact downstream constraints to §3.7 before accepting a seed.
2. §3.7 defines `DT_CAUSAL_VALID(S,P)` and keeps inverse/row semantics in KDT.
3. WITNESS requires the causal producer chain before `REALIZED`.
4. FREEZE preserves the causal chain during full replay.
5. AUDIT independently verifies provenance and routes final-value pre-seeding without a producing DTA back to WITNESS.

## Knowledge Area decision

No KDT production change was required. The active KDT already owns:
- `scenario_constraint`;
- `DTA.beforeSource`;
- inverse seed resolution for deterministic `+=` chains;
- `DTA.before` / `DTA.after`;
- complete DTE replay;
- KDT.12 pre-Projection semantic audit.

Keeping KDT unchanged preserves the domain/orchestration boundary.

## Validation results

- Architecture and ownership checks: **40/40 PASS**
- Causal regression fixtures: **13/13 PASS**
- Fresh bad-witness regression: rejected by causal gate in the R49 fixture
- Correct causal NameMatch simulation: `Test -> +June -> +August -> TestJuneAugust -> First`
- Previous R48 regression preserved: `Addresses=[] -> row1 only -> TestAugust -> Second`
- Correct NameMatch full Candidate: **0 Standard schema errors**
- Previous R48 full Candidate: **0 Standard schema errors**
- Existing Standard + MultInpComb executable examples: **6/6 PASS**
- Production prompt footprint: **+1726 characters / +240 whitespace-delimited words**
- KDT changed: **No**
- Generator changed: **No**
- Validator changed: **No**
- MemoryTemp contract changed: **No**

## Runtime acceptance

Offline semantic/schema acceptance is PASS.

Live Pega execution is not available in this environment and remains the final runtime acceptance step. The next live ScenarioAuthor run should specifically verify that the true NameMatch witness no longer uses `pyName=TestJuneAugust` as initial setup merely to force the downstream branch.
