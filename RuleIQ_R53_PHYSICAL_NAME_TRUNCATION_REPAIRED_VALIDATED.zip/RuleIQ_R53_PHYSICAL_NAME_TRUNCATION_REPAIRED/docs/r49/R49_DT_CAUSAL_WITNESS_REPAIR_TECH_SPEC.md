# R49 — Decision Table Causal Witness & Seed-Direction Integrity Repair

## 1. Purpose

Repair the Decision Table witness-construction regression in which ScenarioAuthor can satisfy a downstream branch by placing the required final Decision Table output directly into test setup instead of proving that the Decision Table actually produces that value.

The repair must preserve the current architecture, agent responsibility boundaries, Knowledge Area boundaries, MemoryTemp / ScenarioTrace protocol, Projection contract, Generator and Validator behavior.

This is a **DT-scoped causal-witness repair**, not a general producer-architecture refactor.

## 2. Problem Statement

Observed invalid pattern:

```text
desired downstream branch
    ↓
required property final value
    ↓
required final value copied into setup
    ↓
Decision Table does not produce that value
    ↓
downstream branch still becomes true
    ↓
OUTCOME incorrectly marked REALIZED
```

Concrete regression shape:

```text
required:
  .pyName final = TestJuneAugust

invalid setup:
  .pyName = TestJuneAugust

selected Decision Table execution:
  no relevant DTA writes .pyName

downstream:
  .pyName == TestJuneAugust
  → TRUE
```

Correct causal pattern:

```text
desired downstream branch
    ↓
required .pyName final = TestJuneAugust
    ↓
identify earlier Decision Table producer
    ↓
pass final-value constraint to KDT
    ↓
KDT resolves compatible DTE/DTA execution
    ↓
KDT derives legal DTA.before
    ↓
ScenarioAuthor materializes only that before-state as setup
    ↓
Decision Table executes
    ↓
.pyName becomes TestJuneAugust
    ↓
downstream branch evaluates TRUE
    ↓
OUTCOME may become REALIZED
```

## 3. Architecture Freeze

The following architecture is immutable for this repair:

```text
ScenarioAuthor
    ↓
UnitTestProjectionV3
    ↓
UnitTestGenerator
    ↓
UnitTestCandidate
    ↓
Validator
```

ScenarioTrace phases remain:

```text
MAP
→ WITNESS
→ FREEZE
→ DECIDE
→ BUILD
→ AUDIT
```

Do not add or change:

- agents;
- interfaces;
- MemoryTemp action shape;
- ScenarioTrace phases;
- ScenarioTrace row families;
- `HEAD`;
- `BASE`;
- `INVALIDATE`;
- `COMMIT`;
- phase-generation semantics;
- Projection fields;
- Candidate fields;
- target schemas;
- Generator ownership;
- Validator ownership.

This repair changes only semantic eligibility and validation inside existing ScenarioAuthor phases.

## 4. Responsibility Boundary — Mandatory

### 4.1 ScenarioAuthor owns

ScenarioAuthor owns caller-level orchestration and test semantics:

- original-RUT coverage;
- OUTCOME constraints;
- identification of prior runtime producers;
- routing a downstream property constraint to a Decision Table producer;
- witness construction;
- seed eligibility;
- selection/consumption of KDT-produced DT evidence;
- WITNESS realization;
- FREEZE replay;
- assertion decisions;
- invalidation;
- MemoryTemp / ScenarioTrace lifecycle;
- Projection materialization;
- causal AUDIT.

ScenarioAuthor must **not** implement Decision Table execution algorithms.

### 4.2 Decision Table Knowledge Area owns

`Rule-Declare-DecisionTable_KnowledgeArea` owns only Decision Table domain semantics:

- DTM mode;
- active DT fields;
- row/cell semantics;
- OR-row semantics;
- wildcard semantics;
- range/operator semantics;
- selected-row evaluation;
- property action order;
- DTA construction;
- `DTA.beforeSource`;
- `DTA.before`;
- `DTA.operand`;
- `DTA.after`;
- `scenario_constraint`;
- inverse seed resolution for supported compound actions;
- DTE construction;
- cellProof;
- DT-local semantic consistency.

KDT must not own:

- Scenario membership;
- OUTCOME coverage;
- WITNESS/FREEZE/DECIDE/BUILD/AUDIT phase transitions;
- MemoryTemp;
- INVALIDATE;
- setup serialization;
- Projection;
- Candidate;
- Generator;
- Validator;
- ASSERT/OMIT/testability policy.

### 4.3 Generator and Validator

No semantic Decision Table repair is allowed downstream.

Generator remains a deterministic Projection → Candidate compiler.

Validator remains a Projection/Candidate fidelity and target-correctness validator.

## 5. Core Ownership Invariant

Add one authoritative ScenarioAuthor invariant:

```text
A downstream exact property constraint is a required execution result,
not setup authority.
```

If a downstream branch requires:

```text
P.final = X
```

ScenarioAuthor must first determine whether an earlier reachable Decision Table producer owns `P`.

If yes, `P.final = X` becomes a **producer final-state constraint**, not an initial seed.

Invalid shortcut:

```text
required P.final = X
→ setup P = X
```

Required causal route:

```text
required P.final = X
→ prior DT producer
→ KDT-compatible execution
→ DTA.before
→ setup
→ DT execution
→ DTA.after/final
→ downstream branch
```

## 6. Scope Limitation — DT-Specific Repair

Do not generalize this repair into a new universal producer solver.

Apply the new causal gate only when:

```text
a branch-controlling exact property value
has an earlier reachable Decision Table / DTA producer
```

All non-DT flows continue under their existing semantics.

Examples expected to remain unchanged:

- ordinary Data Transform input branch;
- Model input branch;
- nested When dependency;
- Data Page simulation;
- scalar SET logic;
- list/append producer handling;
- existing generic RI/PC/RX flow.

This minimizes regression risk.

## 7. ScenarioAuthor Changes

Primary production file:

```text
01_PROMPTS/ScenarioAuthor_SystemPrompt.txt
```

### 7.1 §3.1 — Seed-direction integration

Do not rewrite the generic seed-direction model.

Add only a compact DT-specific delegation rule:

```text
If a planned seed is the target of an earlier reachable Decision Table
producer and is also constrained by a downstream exact branch outcome,
apply §3.7 DT causal rules before seed eligibility is accepted.
```

The generic seed system must remain authoritative for non-DT flows.

### 7.2 §3.7 — Decision Table causal constraint routing

Add the main repair here.

Required logic:

```text
For downstream exact property constraint P.final=X:

1. Resolve whether an earlier reachable Decision Table DTA producer owns P.

2. If no such producer exists:
   use existing caller input/setup semantics unchanged.

3. If such producer exists:
   pass P.final=X to KDT as the caller-level final-state constraint.

4. Consume KDT result only:
   DTE
   ordered DTA
   DTA.beforeSource
   DTA.before
   DTA.after

5. Setup may include P only when KDT evidence proves a valid pre-execution
   before-state or existing independent caller-input evidence already owns it.

6. The required final value X is never setup authority by itself.

7. Replay the Decision Table from the chosen before-state and exact DT inputs.

8. The downstream constraint is satisfied only when that replay produces X.
```

ScenarioAuthor must not calculate inverse `+=` values itself.

### 7.3 §4.3 — WITNESS causal realization gate

For a DT-dependent OUTCOME:

```text
REALIZED requires:

- exact downstream constraint;
- earlier DT producer identified;
- compatible FINAL DTE;
- complete ordered FINAL DTA chain;
- legal KDT-proven before-state where required;
- planned setup equal to that before-state;
- exact DT replay from frozen witness inputs;
- produced final value satisfies downstream constraint;
- downstream branch then executes as claimed.
```

Forbidden realization:

```text
required P.final=X
+
setup P=X
+
selected DTE has no DTA writing P
```

Such a witness is invalid and must be rebuilt.

### 7.4 §4.4 — FREEZE causal continuity gate

FREEZE must re-execute the exact retained witness.

For each DT-constrained property preserve:

```text
initial state
→ DTE/DTA producer chain
→ produced final state
→ downstream consumer
```

If the retained witness no longer contains the causal producer chain that justified coverage:

```text
invalidate WITNESS
```

Do not patch FREEZE.

### 7.5 §4.7 — AUDIT causal provenance

Extend existing AUDIT only for DT-dependent property constraints.

Independently reconstruct:

```text
initial property state
→ selected DTE
→ ordered DTA writes
→ property final value
→ downstream branch
→ downstream outputs
→ DECIDE assertions
```

AUDIT must determine where the branch-controlling value originated.

Legal provenance:

```text
independent valid caller input
or
valid before-state + executed Decision Table producer
```

Invalid provenance:

```text
required final value was pre-seeded
and the claimed Decision Table producer did not produce it
```

Result:

```text
AUDIT=FAIL
REPAIR earliestOwner=WITNESS
```

AUDIT never patches the witness.

## 8. Decision Table Knowledge Area Changes

Target:

```text
Rule-Declare-DecisionTable_KnowledgeArea
```

### 8.1 Verify before modifying

First audit the active KDT for existing support of:

- `scenario_constraint`;
- `beforeSource`;
- `scenario_input`;
- `earlier_write`;
- `increment_seed`;
- inverse seed resolution;
- DTA.before;
- DTA.after;
- DTE replay;
- final constraint compatibility.

If the active contract already fully supports these semantics:

```text
KDT_CHANGE = NONE
```

Prefer no KDT modification.

### 8.2 Minimal clarification only if required

If ambiguity exists, add only a domain-semantic invariant:

```text
A downstream exact caller constraint on the final value of a property
written by the selected DT execution constrains the DT final property effect.

For a supported compound action chain, any setup-producing value is DTA.before,
not the required DTA.final/after value.

Return the execution candidate only when replay from that before-state preserves
the selected execution and produces the constrained final value.
```

Do not mention:

- WITNESS phase;
- MemoryTemp;
- INVALIDATE;
- Projection;
- Candidate;
- Generator;
- Validator;
- physical setup serialization.

Those remain ScenarioAuthor responsibilities.

## 9. Example — DetermineChannel

Coverage target:

```text
.pyValue = First
```

Downstream prerequisite:

```text
.pyName = TestJuneAugust
```

Earlier producer:

```text
Decision Table ChannelCode
```

Selected property actions:

```text
.pyName += June
.pyName += August
```

Correct constraint routing:

```text
required final = TestJuneAugust
→ KDT inverse seed resolution
→ before = Test
```

Correct witness setup:

```text
pyName = Test
```

plus the actual evidenced DT condition inputs and required simulation.

Correct execution:

```text
Test
→ TestJune
→ TestJuneAugust
→ downstream WHEN TRUE
→ pyValue = First
```

Invalid witness:

```text
setup pyName = TestJuneAugust
Decision Table writes nothing
downstream WHEN TRUE
```

The invalid witness must not pass WITNESS or AUDIT.

## 10. Regression Matrix

### R1 — Fresh bad witness

Input/setup:

```text
pyName=TestJuneAugust
DT selected execution does not write pyName
```

Expected:

```text
WITNESS rejected for producer-driven NameMatchPath
```

### R2 — Correct NameMatchPath

Expected:

```text
required final TestJuneAugust
→ DTA.before Test
→ DT produces TestJuneAugust
→ pyValue First
```

### R3 — Previous R48 else-path

Exact existing regression:

```text
pyName=Test
pyText=2
pyTempInteger=7
Addresses=[]
```

Expected:

```text
row0=false
row1=true
pyName=TestAugust
pyValue=Second
```

This must remain unchanged.

### R4 — Legitimate direct input

No earlier DT producer:

```text
P=X
```

may remain a legal caller input when existing semantics allow it.

### R5 — Legitimate read-before-write

For executing:

```text
P += operand
```

a proven `DTA.before=P0` remains legal setup.

### R6 — No DTA write

Required:

```text
P.final=X
```

Selected FINAL DTE contains no DTA targeting P.

Expected:

```text
DT producer cannot support constraint
→ witness rebuild/block
```

No final-value seed fallback.

### R7 — Non-DT regression suite

Run stable examples covering:

- Data Transform without DT;
- Model without DT;
- When dependency without DT;
- Data Page simulation without DT;
- setup carrier;
- list/append producer.

Expected:

```text
behavior unchanged
phase architecture unchanged
Projection shape unchanged
```

## 11. MemoryTemp / ScenarioTrace Non-Regression

Verify exact preservation of:

```text
MAP
WITNESS
FREEZE
DECIDE
BUILD
AUDIT
```

and:

```text
HEAD
BASE
INVALIDATE
COMMIT
```

No new rows such as:

```text
CONSTRAINT
DTA
DTE
SEED
CAUSAL
```

may be added to ScenarioTrace.

DTM/DTA/DTE remain internal semantic evidence.

## 12. Cross-Architecture Synchronization Audit

After implementation independently inspect:

```text
ScenarioAuthor
Decision Table Knowledge Area
Generator
Validator
Projection contract
ScenarioTrace contract
```

Required checks:

1. ScenarioAuthor does not contain DT row/operator/inverse algorithms.
2. KDT does not contain Scenario phase or MemoryTemp instructions.
3. Final-value constraint cannot directly authorize setup.
4. DTA.before remains the only DT-derived before-state setup authority.
5. DTA.after/final state remains execution output.
6. Generator performs no DT semantics.
7. Validator performs no DT semantics.
8. No new ScenarioTrace state is introduced.
9. Historical RuleCode/Candidate access does not reappear in KDT.
10. Existing R48 DT evaluation fixes remain intact.

Classify every issue as:

```text
MATCH
INTENTIONAL_ADAPTATION
DEFECT
```

Release requires:

```text
DEFECT=0
```

## 13. Historical Residue Audit

Search active production files for contradictory patterns:

```text
desired output → setup
constraint directly materialized as final-value seed
KDT controls WITNESS/FREEZE/AUDIT
ScenarioAuthor computes inverse += itself
KDT reads Candidate/RuleCode
DECIDE repairs setup
AUDIT trusts desired coverage instead of replay
```

Every hit must be removed or adapted.

## 14. Claude Opus 4.8 Token-Optimization Rules

All production prompt changes must be optimized for Claude Opus 4.8.

### 14.1 One causal model, not many prohibitions

Use:

```text
constraint
→ producer
→ before-state
→ execution
→ final-state
```

instead of long lists of negative rules.

### 14.2 Do not duplicate KDT semantics in ScenarioAuthor

ScenarioAuthor should say:

```text
obtain KDT-compatible execution
consume KDT-proven DTA.before
```

It should not explain:

- suffix subtraction;
- OR semantics;
- range semantics;
- row matching;
- compound operator math.

### 14.3 Reuse one compact invariant

Define conceptually:

```text
DT_CAUSAL_VALID(S,P):
the frozen initial P is independently valid caller input or KDT-proven DTA.before,
and replayed FINAL DTE/DTA produces the P value consumed downstream.
```

Then use compact references:

```text
WITNESS requires DT_CAUSAL_VALID
FREEZE preserves DT_CAUSAL_VALID
AUDIT independently verifies DT_CAUSAL_VALID
```

Do not repeat the full rule in every phase.

### 14.4 Runtime prompt must not contain remediation history

Do not mention:

- R48;
- the observed bug;
- old architecture;
- regression narrative;
- why a rule was added.

Describe only target behavior.

### 14.5 Minimal production footprint

Preferred production delta:

```text
ScenarioAuthor:
  one compact DT causal invariant
  one §3.7 routing rule
  one WITNESS gate
  one FREEZE continuity reference
  one AUDIT provenance reference
```

KDT:

```text
zero changes unless a concrete semantic gap is proven
```

## 15. Acceptance Criteria

Release is allowed only when all are true:

```text
1. OUTCOME/branch constraint is not setup authority.

2. Earlier Decision Table producer is resolved before seeding a constrained value.

3. Producer final constraint is routed through KDT.

4. ScenarioAuthor does not compute Decision Table inverse semantics.

5. KDT owns DTA.before derivation.

6. Setup uses KDT-proven DTA.before, not required DTA.after/final.

7. A FINAL DTE with no DTA write to P cannot claim to have produced P.

8. The fresh bad witness with pyName=TestJuneAugust pre-seeded is rejected.

9. Correct NameMatchPath derives pyName.before=Test.

10. Correct NameMatchPath executes DT to produce TestJuneAugust.

11. Downstream branch then produces pyValue=First.

12. Existing TestAugust/Second regression remains correct.

13. Legitimate direct caller inputs remain valid.

14. Legitimate DT read-before-write setup remains valid.

15. Non-DT regression suite is unchanged.

16. MAP/WITNESS/FREEZE/DECIDE/BUILD/AUDIT remain unchanged.

17. HEAD/BASE/INVALIDATE/COMMIT remain unchanged.

18. No new ScenarioTrace row family exists.

19. Generator remains unchanged.

20. Validator remains unchanged.

21. Projection and target schemas remain unchanged.

22. KDT contains no caller orchestration.

23. ScenarioAuthor contains no duplicated DT engine.

24. Prompt additions are compact and Claude Opus 4.8 optimized.

25. Independent architecture synchronization audit reports zero unexplained defects.

26. Full generated Candidates pass current target schemas.

27. Final live Pega runtime confirms expected == actual.
```

## 16. Expected Final Ownership Model

```text
OUTCOME
    defines behavior to cover

ScenarioAuthor
    routes caller constraints and constructs causal witnesses

Decision Table Knowledge Area
    solves DT-local execution and legal before-state

SETUP
    carries true pre-execution state only

DTE/DTA/RX
    prove actual execution

FREEZE
    freezes actual causal result

DECIDE
    asserts final observable state

AUDIT
    independently verifies causal provenance

Generator
    serializes Projection

Validator
    validates fidelity and target correctness
```

## 17. Recommended Implementation Order

1. Freeze current R48 baseline.
2. Audit active KDT for existing `scenario_constraint / DTA.before / inverse seed` completeness.
3. Modify ScenarioAuthor §3.7 causal constraint routing.
4. Add minimal §3.1 DT delegation.
5. Add WITNESS causal realization gate.
6. Add FREEZE continuity reference.
7. Add AUDIT provenance check.
8. Change KDT only if an objectively missing semantic contract is found.
9. Run architecture synchronization audit.
10. Run bad-witness regression.
11. Run correct NameMatchPath simulation.
12. Re-run TestAugust/Second R48 regression.
13. Run non-DT regression suite.
14. Validate complete generated Candidates against current schemas.
15. Run live Pega acceptance.
