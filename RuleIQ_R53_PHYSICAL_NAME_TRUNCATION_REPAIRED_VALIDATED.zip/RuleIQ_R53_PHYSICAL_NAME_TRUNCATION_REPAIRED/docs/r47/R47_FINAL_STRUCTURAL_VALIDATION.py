import json
from pathlib import Path
from jsonschema import Draft202012Validator
root=Path(__file__).resolve().parents[2]
sa=(root/'01_PROMPTS/ScenarioAuthor_SystemPrompt.txt').read_text()
gen=(root/'01_PROMPTS/UnitTestGenerator_SystemPrompt.txt').read_text()
std=json.loads((root/'03_TARGET_CONTRACTS/Rule-Test-Unit-Case_JsonSchema.txt').read_text())
wh=json.loads((root/'03_TARGET_CONTRACTS/Rule-Test-Unit-Case_MultInpComb-JsonSchema.txt').read_text())
ind=json.loads((root/'docs/r47/R47_INDEPENDENT_VALIDATION_RESULTS.json').read_text())
fix=json.loads((root/'docs/r47/R47_SOURCE_GATE_FIXTURE_VALIDATION_RESULTS.json').read_text())
e2e=json.loads((root/'docs/r47/R47_DETERMINECONDITION_E2E_SIMULATION_RESULTS.json').read_text())
checks=[]
def c(n,v,d): checks.append({'name':n,'pass':bool(v),'detail':d})
c('Independent static audit',ind['passed']==ind['total'],f"{ind['passed']}/{ind['total']}")
c('Independent dynamic source fixtures',fix['passed']==fix['total'],f"{fix['passed']}/{fix['total']}")
c('DetermineCondition E2E',e2e['allPassed'] and e2e['passed']==e2e['total'],f"{e2e['passed']}/{e2e['total']}")
c('All E2E candidates schema-valid',all(not x['schemaErrors'] for x in e2e['cases']),'0 schema errors in each full Candidate')
c('ScenarioAuthor single setup grammar',sa.count('a setup page is exactly `{name,data?}`')==1,'one authoritative physical setup-page definition')
c('ScenarioAuthor Primary physical binding', 'every Primary-owned setup fact materializes with `setupPages.name=ROOT.page`' in sa,'Primary alias resolved before persistence')
c('ScenarioAuthor class binding', 'root `pxObjClass` equals the owning runtime page class' in sa,'setup data carries class')
c('Generator source validation occurs before target',gen.index('Before executable target construction, independently verify the frozen setup-page source contract') < gen.index('#### 2.1.3 Executable Standard assertion interface'),'source gate precedes compilation interface')
c('Generator does not repair source', 'preserve the source unchanged for Author repair' in gen,'reject instead of rewriting')
for label,sch in [('STD',std),('WHEN',wh)]:
    c(label+' schema valid',Draft202012Validator.check_schema(sch) is None,'Draft2020-12')
    c(label+' setup payload requires class','pxObjClass' in sch['$defs']['ClipboardPageSeed']['required'],'ClipboardPageSeed')
    cm=[x['rule'] for x in sch['x-ruleiq-compilerMappings'] if x.get('id')=='CM-EXEC-001'][0]
    c(label+' setup mapping is copy-only','present data→pyPageDetails unchanged' in cm,'Generator consumes schema-ready Projection data')
# Validate all concrete examples independently.
for ef,schema,label in [('Rule-Test-Unit-Case_JsonExample.txt',std,'STD'),('Rule-Test-Unit-Case_MultInpComb-JsonExample.txt',wh,'WHEN')]:
    obj=json.loads((root/'03_TARGET_CONTRACTS'/ef).read_text())
    errs=sum((list(Draft202012Validator(schema).iter_errors(ex)) for ex in obj.get('Examples',[])),[])
    c(label+' all concrete examples valid',not errs,f"examples={len(obj.get('Examples',[]))}, errors={len(errs)}")
res={'total':len(checks),'passed':sum(x['pass'] for x in checks),'failed':[x for x in checks if not x['pass']],'checks':checks}
(root/'docs/r47/R47_FINAL_STRUCTURAL_VALIDATION_RESULTS.json').write_text(json.dumps(res,indent=2))
print(json.dumps({'total':res['total'],'passed':res['passed'],'failed':len(res['failed'])},indent=2))
if res['failed']: raise SystemExit(1)
