import json,re
from pathlib import Path
from jsonschema import Draft202012Validator
root=Path(__file__).resolve().parents[2]
sa=(root/'01_PROMPTS/ScenarioAuthor_SystemPrompt.txt').read_text()
gen=(root/'01_PROMPTS/UnitTestGenerator_SystemPrompt.txt').read_text()
schema=json.loads((root/'03_TARGET_CONTRACTS/Rule-Test-Unit-Case_JsonSchema.txt').read_text())
when_schema=json.loads((root/'03_TARGET_CONTRACTS/Rule-Test-Unit-Case_MultInpComb-JsonSchema.txt').read_text())
checks=[]
def check(name, cond, detail): checks.append({'name':name,'pass':bool(cond),'detail':detail})
# ScenarioAuthor semantics, derived from production text.
check('SA primary default', 'absent `page` means `RunRecordPrimaryPage`' in sa, 'primary.page default')
check('SA Primary resolves to ROOT.page', '`Primary.&lt;relativePath&gt;` binds to `ROOT.page`' in sa, 'semantic alias resolution')
check('SA Primary setup uses ROOT.page', 'every Primary-owned setup fact materializes with `setupPages.name=ROOT.page`' in sa, 'physical setup identity')
check('SA setup page identity contract', '`name` is the resolved runtime page: `ROOT.page` for Primary-owned setup, otherwise an exact key of `pages`' in sa, 'closed source identity')
check('SA setup class contract', 'present `data` is an opaque JSON object whose root `pxObjClass` equals the owning runtime page class' in sa, 'source class ownership')
check('SA producer gate identity/class', 'Primary-owned entries named `ROOT.page` and every present `data.pxObjClass` equal to that page\'s frozen class' in sa, 'pre-persistence self-validation')
# Generator independently recomputes source requirements.
check('GEN primary default', 'absent page = `RunRecordPrimaryPage`' in gen, 'generator source interface')
check('GEN setup source identity/class', 'each `name` equals `P` or an exact key of `pages`; every present `data.pxObjClass` equals `primary.class` when `name=P`, otherwise `pages[name]`' in gen, 'generator independent source interface')
check('GEN explicit source gate', 'Before executable target construction, independently verify the frozen setup-page source contract' in gen, 'pre-target gate')
check('GEN source rejection route', 'A mismatch is `PROJECTION_FAILED` before Candidate construction' in gen, 'malformed projection rejected')
check('GEN fidelity includes setup identity/class', 'setup-page runtime identity/class consistency' in gen, 'G7 target fidelity')
# Target schema / mapping alignment.
check('STD schema valid', Draft202012Validator.check_schema(schema) is None, 'Draft2020-12')
check('WHEN schema valid', Draft202012Validator.check_schema(when_schema) is None, 'Draft2020-12')
check('STD Clipboard requires pxObjClass', 'pxObjClass' in schema['$defs']['ClipboardPageSeed']['required'], 'target setup payload structural class')
check('WHEN Clipboard requires pxObjClass', 'pxObjClass' in when_schema['$defs']['ClipboardPageSeed']['required'], 'target setup payload structural class')
cm=[x['rule'] for x in schema.get('x-ruleiq-compilerMappings',[]) if x.get('id')=='CM-EXEC-001'][0]
check('STD setup mapping copies data', 'present data→pyPageDetails unchanged' in cm, 'Projection data must already be schema-ready')
# Existing examples remain schema-valid.
for fn,sch in [('Rule-Test-Unit-Case_JsonExample.txt',schema),('Rule-Test-Unit-Case_MultInpComb-JsonExample.txt',when_schema)]:
    obj=json.loads((root/'03_TARGET_CONTRACTS'/fn).read_text())
    all_errs=[]
    for i,ex in enumerate(obj.get('Examples',[])):
        errs=list(Draft202012Validator(sch).iter_errors(ex))
        all_errs.extend((i,e) for e in errs)
    check(fn+' concrete examples schema validation', not all_errs, f'examples={len(obj.get("Examples",[]))}, errors={len(all_errs)}')
result={'total':len(checks),'passed':sum(c['pass'] for c in checks),'failed':[c for c in checks if not c['pass']],'checks':checks}
(root/'docs/r47/R47_INDEPENDENT_VALIDATION_RESULTS.json').write_text(json.dumps(result,indent=2))
print(json.dumps({'total':result['total'],'passed':result['passed'],'failed_count':len(result['failed'])},indent=2))
if result['failed']: raise SystemExit(1)
