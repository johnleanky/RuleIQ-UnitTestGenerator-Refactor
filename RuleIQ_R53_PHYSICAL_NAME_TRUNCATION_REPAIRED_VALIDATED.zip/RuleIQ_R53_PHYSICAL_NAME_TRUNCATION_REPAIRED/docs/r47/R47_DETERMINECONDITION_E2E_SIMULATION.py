import json
from pathlib import Path
from jsonschema import Draft202012Validator
root=Path(__file__).resolve().parents[2]
schema=json.loads((root/'03_TARGET_CONTRACTS/Rule-Test-Unit-Case_JsonSchema.txt').read_text())
validator=Draft202012Validator(schema)

def source_gate(p):
    P=p['primary'].get('page','RunRecordPrimaryPage'); pages=p.get('pages',{})
    errs=[]
    for i,sp in enumerate(p.get('setupPages',[])):
        if sp['name']==P: cls=p['primary']['class']
        elif sp['name'] in pages: cls=pages[sp['name']]
        else: errs.append(f'unresolved setup page {sp["name"]}'); continue
        if 'data' in sp and sp['data'].get('pxObjClass') != cls:
            errs.append(f'class mismatch at setupPages[{i}]')
    return errs

def project(case):
    P=case['primary'].get('page','RunRecordPrimaryPage')
    data={'pxObjClass':case['primary']['class'], **case['primarySetup']}
    return {
        'testLabel':case['scenarioName'], 'physicalGroupKey':case['group'],
        'rut':{'name':'DetermineCondition','applyToClass':'RuleIQ-Data-TestRefLib'},
        'primary':case['primary'],
        'setupPages':[{'name':P,'data':data}],
        'simulations':[{'runtimeClass':'Data-Customer','rule':'D_CustomerTestRef','setupPages':[{'class':'Data-Customer','data':case['simulationData']}]}],
        'assertions':[
            {'kind':'Property','path':'.pyTempInteger','comparator':'Is Equals To','expected':str(case['temp']),'mode':'Integer'},
            {'kind':'Property','path':'.pyValue','comparator':'Is Equals To','expected':case['value'],'mode':'Text'}],
        'scenarios':[{'name':case['scenarioName'],'description':case['description'],'type':'Baseline','inputsNarrative':case['inputs'],'assertionsNarrative':f'Assert .pyTempInteger equals {case["temp"]} and .pyValue equals {case["value"]}.','simulationsNarrative':'D_CustomerTestRef is simulated so the DecisionTable evaluates deterministically.','confidence':'High','testability':'FullyTestable','reasoningTrace':case['reasoning'],'dependencyClosureStatus':'Closed','dependencyClosureTrace':'RuleCrawler waves W1-W4 closed all dependencies for ConditionResult and DetermineCondition.'}]
    }

def candidate_from_projection(p, case):
    P=p['primary'].get('page','RunRecordPrimaryPage')
    purpose=case['purpose']
    sim=p['simulations'][0]
    return {'UnitTestRules':[{
        'Name':purpose,
        'Scenarios':[{'Status':'New','Name':case['scenarioName'],'ReasoningConfidence':'High','Testability':'FullyTestable','EvidenceSummary':{'ReasoningTrace':case['reasoning'],'DependencyClosureStatus':'Closed','DependencyClosureTrace':'RuleCrawler waves W1-W4 closed all dependencies for ConditionResult and DetermineCondition.'},'Description':case['description'],'Type':'Baseline','InputsNarrative':case['inputs'],'AssertionsNarrative':f'Assert .pyTempInteger equals {case["temp"]} and .pyValue equals {case["value"]}.','SimulationsNarrative':'D_CustomerTestRef is simulated so the DecisionTable evaluates deterministically.'}],
        'RuleCode':{
            'pyLabel':purpose,'pyRuleSet':'3010067594@','pyRuleSetVersion':'01-01-01','pyClassName':p['primary']['class'],'pyPurpose':purpose,'pyDescription':case['description'],'pyIsInactive':'false','pyCleanUpTestData':'true','pyTypeOfSetupPageSelection':'CUSTOMPAGES',
            'pyRuleUnderTest':{'pyDetails':{'pyRuleUnderTestInsName':'RULEIQ-DATA-TESTREFLIB!DETERMINECONDITION','pyIsSinglePageImplementation':'false','pyRuleUnderTestName':'DetermineCondition','pyRuleUnderTestObjClass':'RuleIQ-Data-TestRefLib','pyRuleUnderTestType':'Rule-Obj-Model'}},
            'pyPagesAndClasses':[{'pyPagesAndClassesPage':P,'pyPagesAndClassesClass':p['primary']['class']}],
            'pySetupPages':[{'pySetupPageName':sp['name'],'pyPageDetails':sp['data']} for sp in p['setupPages']],
            'pySimulation':[{'pyClassName':sim['runtimeClass'],'pyMockingSupportedRuleTypes':'Rule-Declare-Pages','pyRuleNameToBeMocked':sim['rule'],'pySimulationMethod':'DefineData','pySetupPages':[{'pySetupPageName':'PrimaryPage','pyPageDetails':{'pxObjClass':x['class'],**x['data']}} for x in sim['setupPages']]}],
            'pyExpectedResults':[{'pyAssertionType':'Property','pyStepPageClass':p['primary']['class'],'pyStepPageName':P,'pyExpectedResults':[
                {'pyComparator':'Is Equals To','pyPropertyName':'pyTempInteger','pyPropertyAbsolutePath':'.pyTempInteger','pyPropertyMode':'Integer','pyExpectedValue':str(case['temp']),'pyPageName':P},
                {'pyComparator':'Is Equals To','pyPropertyName':'pyValue','pyPropertyAbsolutePath':'.pyValue','pyPropertyMode':'Text','pyExpectedValue':'"'+case['value']+'"','pyPageName':P}
            ]}]
        }
    }]}

cases=[
    {'group':'G002','scenarioName':'DetermineCondition first','purpose':'TC_DetermineCondition_DetermineConditionFirst','primary':{'class':'RuleIQ-Data-TestRefLib'},'primarySetup':{'pyLabel':'Bob'},'simulationData':{},'temp':6,'value':'First','description':'IsNameCorrect false so the Always row matches DecisionTable row1 setting pyTempInteger=6 and the model sets pyValue to First.','inputs':'Primary.pyLabel=Bob; simulated D_CustomerTestRef.','reasoning':'pyLabel=Bob makes IsNameCorrect false; row0 fails, Always row1 matches writing pyTempInteger=6; model step2 (=6) true sets pyValue=First.'},
    {'group':'G001','scenarioName':'DetermineCondition second','purpose':'TC_DetermineCondition_DetermineConditionSecond','primary':{'class':'RuleIQ-Data-TestRefLib'},'primarySetup':{'pyLabel':'Glen'},'simulationData':{'CustomerID':'test','Addresses':[{'pxObjClass':'Data-Address-Postal','pyPostalCode':'1011AB','pyType':'Postal'}]},'temp':5,'value':'Second','description':'IsNameCorrect and the valid postal-address condition make the DecisionTable matching row set pyTempInteger=5 and the model sets pyValue to Second.','inputs':'Primary.pyLabel=Glen; simulated D_CustomerTestRef first address is Postal with postal code 1011AB.','reasoning':'pyLabel=Glen makes IsNameCorrect true and the simulated first Postal address satisfies the row condition; the DecisionTable writes pyTempInteger=5; model step3 (=5) true sets pyValue=Second.'}
]
results=[]
for case in cases:
    p=project(case)
    sg=source_gate(p)
    c=candidate_from_projection(p,case)
    schema_errs=sorted(validator.iter_errors(c),key=lambda e:list(e.path))
    P=p['primary'].get('page','RunRecordPrimaryPage')
    rc=c['UnitTestRules'][0]['RuleCode']
    checks={
        'sourceGate':not sg,
        'projectionPrimarySetupName':p['setupPages'][0]['name']==P,
        'projectionPrimarySetupClass':p['setupPages'][0]['data']['pxObjClass']==p['primary']['class'],
        'candidatePagesAndClassesIdentity':rc['pyPagesAndClasses'][0]['pyPagesAndClassesPage']==P,
        'candidateSetupIdentity':rc['pySetupPages'][0]['pySetupPageName']==P,
        'candidateSetupClass':rc['pySetupPages'][0]['pyPageDetails']['pxObjClass']==p['primary']['class'],
        'identityConvergence':rc['pyPagesAndClasses'][0]['pyPagesAndClassesPage']==rc['pySetupPages'][0]['pySetupPageName']==P,
        'classConvergence':rc['pyPagesAndClasses'][0]['pyPagesAndClassesClass']==rc['pySetupPages'][0]['pyPageDetails']['pxObjClass']==p['primary']['class'],
        'expectedTemp':rc['pyExpectedResults'][0]['pyExpectedResults'][0]['pyExpectedValue']==str(case['temp']),
        'expectedValue':rc['pyExpectedResults'][0]['pyExpectedResults'][1]['pyExpectedValue']=='"'+case['value']+'"',
        'targetSchema':not schema_errs,
    }
    results.append({'case':case['scenarioName'],'projection':p,'candidate':c,'sourceErrors':sg,'schemaErrors':[{'path':'/'+'/'.join(map(str,e.path)),'message':e.message} for e in schema_errs],'checks':checks,'pass':all(checks.values())})
out={'cases':results,'total':len(results),'passed':sum(r['pass'] for r in results),'allPassed':all(r['pass'] for r in results)}
(root/'docs/r47/R47_DETERMINECONDITION_E2E_SIMULATION_RESULTS.json').write_text(json.dumps(out,indent=2))
print(json.dumps({'cases':out['total'],'passed':out['passed'],'allPassed':out['allPassed'],'details':[{r['case']:{'pass':r['pass'],'schemaErrors':len(r['schemaErrors'])}} for r in results]},indent=2))
if not out['allPassed']: raise SystemExit(1)
