import json
from pathlib import Path
root=Path(__file__).resolve().parents[2]

def validate_projection(p):
    primary=p['primary']; P=primary.get('page','RunRecordPrimaryPage'); pages=p.get('pages',{})
    errors=[]
    for i,sp in enumerate(p.get('setupPages',[])):
        name=sp['name']
        if name==P: cls=primary['class']
        elif name in pages: cls=pages[name]
        else:
            errors.append(f'setupPages[{i}].name unresolved: {name}')
            continue
        if 'data' in sp:
            actual=sp['data'].get('pxObjClass')
            if actual != cls: errors.append(f'setupPages[{i}].data.pxObjClass={actual!r}, expected {cls!r}')
    return errors

base={'primary':{'class':'RuleIQ-Data-TestRefLib'}}
fixtures={
'A_default_primary_valid': {**base,'setupPages':[{'name':'RunRecordPrimaryPage','data':{'pxObjClass':'RuleIQ-Data-TestRefLib','pyLabel':'Bob'}}]},
'B_explicit_primary_valid': {'primary':{'class':'My-Work-Case','page':'CasePage'},'setupPages':[{'name':'CasePage','data':{'pxObjClass':'My-Work-Case','X':'1'}}]},
'C_named_page_valid': {'primary':{'class':'My-Work-Case'},'pages':{'TempPage':'Data-Address'},'setupPages':[{'name':'TempPage','data':{'pxObjClass':'Data-Address','City':'Utrecht'}}]},
'D_primary_alias_invalid': {**base,'setupPages':[{'name':'Primary','data':{'pxObjClass':'RuleIQ-Data-TestRefLib','pyLabel':'Bob'}}]},
'E_missing_class_invalid': {**base,'setupPages':[{'name':'RunRecordPrimaryPage','data':{'pyLabel':'Bob'}}]},
'F_wrong_class_invalid': {**base,'setupPages':[{'name':'RunRecordPrimaryPage','data':{'pxObjClass':'Wrong-Class','pyLabel':'Bob'}}]},
}
expected={'A_default_primary_valid':True,'B_explicit_primary_valid':True,'C_named_page_valid':True,'D_primary_alias_invalid':False,'E_missing_class_invalid':False,'F_wrong_class_invalid':False}
checks=[]
for name,p in fixtures.items():
    errs=validate_projection(p); actual=not errs
    checks.append({'name':name,'pass':actual==expected[name],'accepted':actual,'expectedAccepted':expected[name],'errors':errs})
res={'total':len(checks),'passed':sum(x['pass'] for x in checks),'checks':checks}
(root/'docs/r47/R47_SOURCE_GATE_FIXTURE_VALIDATION_RESULTS.json').write_text(json.dumps(res,indent=2))
print(json.dumps({'total':res['total'],'passed':res['passed'],'failed':res['total']-res['passed']},indent=2))
if res['passed']!=res['total']: raise SystemExit(1)
