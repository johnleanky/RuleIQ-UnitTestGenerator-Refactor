# R47 Primary Setup Identity/Class Repair — Validation

## Result

**PASS**

- Independent static cross-agent audit: **18/18 PASS**
- Independent dynamic source-gate fixtures: **6/6 PASS**
- DetermineCondition end-to-end simulations: **2/2 PASS**
- Full newly generated Candidate schema validation: **0 errors for each E2E Candidate**
- Final structural validation: **17/17 PASS**

## Production changes

Updated:

- `01_PROMPTS/ScenarioAuthor_SystemPrompt.txt`
- `01_PROMPTS/UnitTestGenerator_SystemPrompt.txt`

Unchanged target contracts:

- `03_TARGET_CONTRACTS/Rule-Test-Unit-Case_JsonSchema.txt`
- `03_TARGET_CONTRACTS/Rule-Test-Unit-Case_MultInpComb-JsonSchema.txt`

### ScenarioAuthor

Primary-owned pre-execution state now resolves to the effective runtime page before Projection persistence:

`primary.page` when present, otherwise `RunRecordPrimaryPage`.

Every ordinary setup payload with `data` includes root `pxObjClass` equal to the frozen class of its runtime page. Producer self-validation checks both identity and class before `UnitTestProjectionV3` persistence.

### Generator

Before target construction Generator independently validates:

- setup page name is the effective Primary page or an exact frozen named-page key;
- present `data.pxObjClass` equals the corresponding frozen page class.

Inconsistent Projection is rejected as `PROJECTION_FAILED` for Author repair. Generator does not rewrite the source.

The existing target mapping remains copy-only: source `setupPages.name` maps to `pySetupPageName`, and source `data` maps unchanged to `pyPageDetails`.

## Independent validation

Dynamic fixtures verify:

- default Primary (`RunRecordPrimaryPage`) — accepted;
- explicit Primary page — accepted;
- named setup page — accepted;
- literal setup page `Primary` — rejected;
- missing `data.pxObjClass` — rejected;
- wrong `data.pxObjClass` — rejected.

All six concrete target examples across Standard and MultInpComb remain schema-valid.

## DetermineCondition E2E

### Bob branch

Input semantic state:

- `Primary.pyLabel=Bob`;
- simulated `D_CustomerTestRef`.

Expected execution:

- `IsNameCorrect=false`;
- Decision Table falls to Always row;
- `pyTempInteger=6`;
- model condition `=6` sets `pyValue=First`.

Projection setup becomes:

```json
{
  "name": "RunRecordPrimaryPage",
  "data": {
    "pxObjClass": "RuleIQ-Data-TestRefLib",
    "pyLabel": "Bob"
  }
}
```

Candidate contains the same runtime page identity in `pyPagesAndClasses` and `pySetupPages`. Full Candidate validates against `Rule-Test-Unit-Case_JsonSchema.txt` with zero errors.

### Glen companion branch

Input semantic state:

- `Primary.pyLabel=Glen`;
- simulated first postal address with `pyPostalCode=1011AB`, `pyType=Postal`.

Expected execution:

- matching Decision Table row;
- `pyTempInteger=5`;
- model condition `=5` sets `pyValue=Second`.

Primary setup uses `RunRecordPrimaryPage` + `RuleIQ-Data-TestRefLib`; dependency-owned address data remain in simulation. Full Candidate validates with zero target-schema errors.

## Evidence

- `R47_INDEPENDENT_VALIDATION_RESULTS.json`
- `R47_SOURCE_GATE_FIXTURE_VALIDATION_RESULTS.json`
- `R47_DETERMINECONDITION_E2E_SIMULATION_RESULTS.json`
- `R47_FINAL_STRUCTURAL_VALIDATION_RESULTS.json`
- `00_START_HERE/R47_PRIMARY_SETUP_IDENTITY_CLASS_REPAIR_PROGRESS.md`
