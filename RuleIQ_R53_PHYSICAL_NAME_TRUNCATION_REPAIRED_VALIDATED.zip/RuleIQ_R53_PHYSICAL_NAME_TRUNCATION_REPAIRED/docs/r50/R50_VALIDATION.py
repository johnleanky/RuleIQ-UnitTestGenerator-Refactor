from __future__ import annotations
from pathlib import Path
import json, re, hashlib, difflib

ROOT = Path(__file__).resolve().parents[2]
R49 = Path('/mnt/data/r49_work/RuleIQ_R49_DT_CAUSAL_WITNESS_REPAIRED')
LIVE = Path('/mnt/data/PXCONV-198051.txt')
PRIOR = Path('/mnt/data/PXCONV-198007.txt')
OUT = Path(__file__).with_name('R50_VALIDATION_RESULTS.json')

checks = []
def check(name, cond, detail=''):
    checks.append({'name':name,'pass':bool(cond),'detail':detail})
    if not cond:
        print('FAIL', name, detail)

prompt = (ROOT/'01_PROMPTS/ScenarioAuthor_SystemPrompt.txt').read_text()
old_prompt = (R49/'01_PROMPTS/ScenarioAuthor_SystemPrompt.txt').read_text()
kdt = (ROOT/'02_KNOWLEDGE_AREAS/Rule-Declare-DecisionTable_KnowledgeArea_REFERENCE.txt').read_text()
kdp = (ROOT/'02_KNOWLEDGE_AREAS/Rule-Declare-Pages_KnowledgeArea_REFERENCE.txt').read_text()

# Production footprint / ownership
changed=[]
for base in ['01_PROMPTS','02_KNOWLEDGE_AREAS','03_TARGET_CONTRACTS','04_TOOLS']:
    for p in (R49/base).rglob('*'):
        if p.is_file():
            rel=p.relative_to(R49)
            q=ROOT/rel
            if q.exists() and p.read_bytes()!=q.read_bytes(): changed.append(str(rel))
check('production_delta_only_scenarioauthor', changed==['01_PROMPTS/ScenarioAuthor_SystemPrompt.txt'], str(changed))
check('kdt_unchanged', (R49/'02_KNOWLEDGE_AREAS/Rule-Declare-DecisionTable_KnowledgeArea_REFERENCE.txt').read_bytes()==(ROOT/'02_KNOWLEDGE_AREAS/Rule-Declare-DecisionTable_KnowledgeArea_REFERENCE.txt').read_bytes())
check('kdp_unchanged', (R49/'02_KNOWLEDGE_AREAS/Rule-Declare-Pages_KnowledgeArea_REFERENCE.txt').read_bytes()==(ROOT/'02_KNOWLEDGE_AREAS/Rule-Declare-Pages_KnowledgeArea_REFERENCE.txt').read_bytes())
for rel in ['01_PROMPTS/UnitTestGenerator_SystemPrompt.txt','01_PROMPTS/Validator_SystemPrompt.txt','03_TARGET_CONTRACTS/Rule-Test-Unit-Case_JsonSchema.txt','03_TARGET_CONTRACTS/Rule-Test-Unit-Case_MultInpComb-JsonSchema.txt']:
    check('unchanged_'+Path(rel).name, (R49/rel).read_bytes()==(ROOT/rel).read_bytes())

# Prompt gates / token locality
required = [
    'DT_PREWITNESS_READY(DT)',
    'POTENTIAL_DT_PRODUCER(DT,P)',
    'DP_SIM_READY(S,DP)',
    'A fetched DTable cannot be treated CLOSED merely because its first RuleCrawler response was scanned.',
    'WITNESS commit is illegal until the selected execution has the required FINAL DTE/DTA evidence.',
    '`evaluated|unknown` requires simulation',
]
for term in required:
    check('prompt_contains_'+re.sub(r'\W+','_',term)[:60], term in prompt, term)
check('old_late_trigger_removed', 'For every exact downstream property constraint with an earlier reachable DT DTA producer' not in prompt)
check('r49_safety_net_retained', 'DT_CAUSAL_VALID(S,P)' in prompt and 'KDT.12' in prompt)
word_delta=len(prompt.split())-len(old_prompt.split())
check('token_delta_compact', word_delta <= 220, f'word_delta={word_delta}')

# KA already owns required domain semantics
for term in ['KDT.10|A|NestedDependencyScan','pyPropertyColumns targets and values','Before DTE.status=FINAL','inverse seed resolution']:
    check('kdt_has_'+re.sub(r'\W+','_',term), term in kdt, term)
for term in ['KDP.8|A/S|RequiredSimulationCensus','`evaluated|unknown`','KDP.9|A/S|SimulationSignature','KDP.10|A/S|SimulationMaterialization']:
    check('kdp_has_'+re.sub(r'\W+','_',term), term in kdp, term)


# No new ScenarioTrace row families / no downstream semantic leakage.
for marker in ['DT_PREWITNESS_READY|','POTENTIAL_DT_PRODUCER|','DP_SIM_READY|']:
    check('no_new_trace_row_'+marker.rstrip('|'), marker not in prompt, marker)
for rel in ['01_PROMPTS/UnitTestGenerator_SystemPrompt.txt','01_PROMPTS/Validator_SystemPrompt.txt']:
    txt=(ROOT/rel).read_text()
    check('downstream_no_r50_invariant_'+Path(rel).stem, all(t not in txt for t in ['DT_PREWITNESS_READY','POTENTIAL_DT_PRODUCER','DP_SIM_READY']))

# Existing target examples remain schema-valid (contracts are unchanged).
try:
    from jsonschema import Draft202012Validator
    for sn,en in [('Rule-Test-Unit-Case_JsonSchema.txt','Rule-Test-Unit-Case_JsonExample.txt'),('Rule-Test-Unit-Case_MultInpComb-JsonSchema.txt','Rule-Test-Unit-Case_MultInpComb-JsonExample.txt')]:
        schema=json.loads((ROOT/'03_TARGET_CONTRACTS'/sn).read_text())
        Draft202012Validator.check_schema(schema)
        v=Draft202012Validator(schema)
        doc=json.loads((ROOT/'03_TARGET_CONTRACTS'/en).read_text())
        for idx,example in enumerate(doc['Examples'],1):
            errs=list(v.iter_errors({'UnitTestRules':example['UnitTestRules']}))
            check(f'schema_example_{Path(sn).stem}_{idx}', not errs, '; '.join(e.message for e in errs[:3]))
except Exception as e:
    check('target_schema_validation_runtime', False, repr(e))

# Conversation helpers
def convo(path):
    return json.loads(path.read_text())['pyMessageHistory']
def assistant_calls(msgs, name):
    out=[]
    for i,m in enumerate(msgs):
        if m.get('pyRole')!='assistant': continue
        for tc in m.get('pyToolCalls',[]):
            f=tc.get('pyFunction',{})
            if f.get('pyName')==name: out.append((i,f.get('pyArguments','')))
    return out

def first_phase_index(msgs, phase):
    for i,args in assistant_calls(msgs,'MemoryTemp'):
        if f'PHASE|{phase}|' in args: return i,args
    return None,None

live=convo(LIVE)
prior=convo(PRIOR)
live_wit_i,_=first_phase_index(live,'WITNESS')
prior_wit_i,_=first_phase_index(prior,'WITNESS')
live_rc=[x for x in assistant_calls(live,'RuleCrawler') if x[0] < live_wit_i]
prior_rc=[x for x in assistant_calls(prior,'RuleCrawler') if x[0] < prior_wit_i]
check('fresh_live_only_one_crawl_before_witness', len(live_rc)==1, f'count={len(live_rc)}')
check('prior_run_had_transitive_crawl_waves_before_witness', len(prior_rc)>=3, f'count={len(prior_rc)}')
if len(prior_rc)>=2:
    wave2=prior_rc[1][1]
    for term in ['When@Data-Address-Postal@IsValidPostalAddress','DP@Data-Customer@D_CustomerTestRef','Prop@Data-Customer@Addresses','Prop@RuleIQ-Data-TestRefLib@pyText','Prop@RuleIQ-Data-TestRefLib@pyTempInteger']:
        check('prior_wave2_'+term.split('@')[-1], term in wave2, term)

# Extract fetched DT RuleJSON from fresh live first crawler result
crawler_result = next(m for m in live if m.get('pyRole')=='tool' and m.get('pyName')=='RuleCrawler')
outer=json.loads(crawler_result['pyContent'])
dt_rule=None
for item in outer.get('InterestedRules',[]):
    for ref in item.get('pxRuleReferences',[]):
        if ref.get('pxRuleObjClass')=='Rule-Declare-DecisionTable':
            dt_rule=json.loads(ref['RuleJSON'])
assert dt_rule
check('fresh_dt_evaluate_all', str(dt_rule['pyDelegatedRestrictions']['default']['pyEvaluateAllRowsStr']).lower()=='true')
active_text=json.dumps(dt_rule,sort_keys=True)
for term in ['D_CustomerTestRef','IsValidPostalAddress','Addresses','.pyText','.pyTempInteger','.pyName']:
    check('fresh_dt_contains_'+re.sub(r'\W+','_',term), term in active_text, term)
# Fresh live goes to MAP/WITNESS without a second dependency crawler.
check('fresh_trace_pre_author_violation_detected', len(live_rc)==1 and 'D_CustomerTestRef' in active_text and 'IsValidPostalAddress' in active_text)

_,live_wit=first_phase_index(live,'WITNESS')
check('fresh_witness_has_bad_final_seed', 'Primary.pyName=TestJuneAugust' in live_wit)
check('fresh_witness_has_no_simulation', 'NO_SIMULATION' in live_wit)
check('r50_rejects_fresh_witness_by_text_contract', all(x in prompt for x in ['POTENTIAL_DT_PRODUCER(DT,P)','DP_SIM_READY(S,DP)']) and 'Primary.pyName=TestJuneAugust' in live_wit and 'NO_SIMULATION' in live_wit)


# Prior closed-dependency evidence proves this DP is simulation-eligible and the helper has concrete input semantics.
prior_dp=None
prior_when=None
for m in prior:
    if m.get('pyRole')!='tool' or m.get('pyName')!='RuleCrawler':
        continue
    try:
        po=json.loads(m['pyContent'])
    except Exception:
        continue
    for item in po.get('InterestedRules',[]):
        for ref in item.get('pxRuleReferences',[]):
            if not ref.get('RuleJSON'):
                continue
            try:
                rr=json.loads(ref['RuleJSON'])
            except Exception:
                continue
            if ref.get('pxRuleObjClass')=='Rule-Declare-Pages' and rr.get('pyRuleName')=='D_CustomerTestRef': prior_dp=rr
            if ref.get('pxRuleObjClass')=='Rule-Obj-When' and rr.get('pyRuleName')=='IsValidPostalAddress': prior_when=rr
check('prior_dp_rule_fetched', prior_dp is not None)
if prior_dp:
    check('prior_dp_thread_scope', str(prior_dp.get('pyScope')).lower()=='thread', str(prior_dp.get('pyScope')))
    check('prior_dp_customerid_declared', any(x.get('pyParametersParamName')=='CustomerID' for x in prior_dp.get('pyParameters',[])))
check('prior_postal_when_fetched', prior_when is not None)
if prior_when:
    c=' '.join(x.get('pyConditionValue1','') for x in prior_when.get('pyCondition',[]))
    check('postal_when_logic_and', prior_when.get('pyLogic')=='1 AND 2', str(prior_when.get('pyLogic')))
    check('postal_when_requires_postal_code', '.pyPostalCode' in c, c)
    check('postal_when_requires_type_postal', '.pyType' in c and 'Postal' in c, c)

# Deterministic semantic fixtures for ChannelCode.
def channel(py_name, py_text, temp, helper_true):
    # R48-correct semantics: row0 uses aligned pyCondition; row1 uses OR [3,2].
    row0 = (py_text == '2') and helper_true and (temp > 1) and (temp <= 8)
    row1 = (py_text in ('3','2')) and (temp > 5) and (temp <= 10)
    name=py_name
    matched=[]
    if row0:
        matched.append(0); name += 'June'
    if row1:
        matched.append(1); name += 'August'
    value = 'First' if name == 'TestJuneAugust' else 'Second'
    return {'matched':matched,'pyName':name,'pyValue':value,'simulation_required':True}

true_case=channel('Test','2',7,True)
check('name_match_rows_0_1', true_case['matched']==[0,1], str(true_case))
check('name_match_final_name', true_case['pyName']=='TestJuneAugust', str(true_case))
check('name_match_branch_first', true_case['pyValue']=='First', str(true_case))
check('name_match_requires_sim', true_case['simulation_required'] is True)
else_case=channel('Test','2',7,False)
check('r48_else_only_row1', else_case['matched']==[1], str(else_case))
check('r48_else_final_name', else_case['pyName']=='TestAugust', str(else_case))
check('r48_else_second', else_case['pyValue']=='Second', str(else_case))
check('r48_else_still_requires_sim', else_case['simulation_required'] is True)

# Scope guard: new gates are explicitly Decision-Table scoped.
check('non_dt_scope_guard', 'for every fetched reachable Decision Table' in prompt and 'DTM-active `pyPropertyColumns`' in prompt)

results={
    'release':'R50',
    'checks_total':len(checks),
    'checks_passed':sum(c['pass'] for c in checks),
    'checks_failed':sum(not c['pass'] for c in checks),
    'word_delta_vs_r49':word_delta,
    'changed_production_files':changed,
    'live_evidence':{
        'fresh_rulecrawler_calls_before_witness':len(live_rc),
        'prior_rulecrawler_calls_before_witness':len(prior_rc),
        'fresh_witness_bad_final_seed':'Primary.pyName=TestJuneAugust' in live_wit,
        'fresh_witness_no_simulation':'NO_SIMULATION' in live_wit,
    },
    'semantic_fixtures':{'name_match':true_case,'r48_else':else_case},
    'checks':checks,
}
OUT.write_text(json.dumps(results,indent=2))
print(json.dumps({k:results[k] for k in ['checks_total','checks_passed','checks_failed','word_delta_vs_r49','changed_production_files','live_evidence','semantic_fixtures']},indent=2))
raise SystemExit(1 if results['checks_failed'] else 0)
