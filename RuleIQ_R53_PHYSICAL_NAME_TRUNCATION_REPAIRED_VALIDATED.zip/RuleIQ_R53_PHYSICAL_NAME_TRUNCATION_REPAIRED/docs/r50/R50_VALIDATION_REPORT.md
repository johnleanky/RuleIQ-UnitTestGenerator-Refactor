# R50 Validation Report — DT Pre-Witness Closure & Simulation Repair

Status: **OFFLINE VALIDATED — LIVE PEGA ACCEPTANCE PENDING**

## Production footprint

Only `01_PROMPTS/ScenarioAuthor_SystemPrompt.txt` changed from R49. KDT, KDP, Generator, Validator, Projection/target schemas, tools and ScenarioTrace grammar are unchanged.

Prompt growth versus R49: **+167 words**.

## Root cause confirmed from live traces

`PXCONV-198051` fetched `ChannelCode` and the RUT properties, then entered WITNESS after only one RuleCrawler wave. The fetched Decision Table already contained active references to `D_CustomerTestRef`, `IsValidPostalAddress`, `Addresses`, `.pyText`, `.pyTempInteger` and the `.pyName += ...` property action, but those active dependencies were not materialized/closed before WITNESS.

The resulting WITNESS used `Primary.pyName=TestJuneAugust` directly and marked both Scenarios `NO_SIMULATION`, then AUDIT passed. Therefore R49's post-selection causal rule could not trigger because the active dependency graph/DTA producer had never been built.

`PXCONV-198007` provides independent prior execution evidence for the missing closure: before WITNESS it performed two additional RuleCrawler waves, first resolving the When/Data Page/property dependencies and then their RUF/property dependencies.

## R50 repair

1. `DT_PREWITNESS_READY(DT)` makes active KDT.10 dependency-census completeness part of Author readiness. A first fetched DTable response is never sufficient by itself.
2. DTA/DTE are explicitly scenario-specific: they are built during WITNESS from grounded setup/parameters/SIM and are mandatory before WITNESS commit.
3. `POTENTIAL_DT_PRODUCER(DT,P)` is derived before DTA selection from DTM-active `pyPropertyColumns`; a downstream final constraint cannot self-authorize the same initial setup value.
4. `DP_SIM_READY(S,DP)` requires KDP.8/KDP.9/KDP.10 simulation evidence for every `evaluated|unknown` DT-discovered Data Page binding. `NO_SIMULATION` is legal only when no REQUIRED_SIM exists.
5. R49 `DT_CAUSAL_VALID` remains as the selected-execution safety check; FREEZE/AUDIT preserve and independently verify the same causal/simulation lineage.

## Validation results

Focused validation: **69/69 PASS**.

Validated properties include:
- production delta is ScenarioAuthor-only;
- KDT/KDP remain unchanged and already contain required semantics;
- no new ScenarioTrace row family;
- no new Generator/Validator semantic dependency;
- six existing target examples remain schema-valid;
- fresh live regression is rejected by all three new gates;
- prior live trace confirms expected transitive closure waves;
- `D_CustomerTestRef` is Thread-scope with `CustomerID` input;
- `IsValidPostalAddress` requires a nonempty postal code and `pyType=Postal`;
- NameMatch semantic fixture: `Test`, `pyText=2`, `pyTempInteger=7`, helper=true -> rows 0+1 -> `TestJuneAugust` -> `First`; simulation required;
- R48 else fixture: same values with helper=false -> row 1 -> `TestAugust` -> `Second`; simulation still required.

## Acceptance boundary

This validation proves contract consistency and that R50 would classify the observed bad trace as illegal. It does **not** prove Claude/Pega will follow the new prompt in a fresh runtime execution.

Final acceptance requires a new live Pega ScenarioAuthor run showing:
1. transitive DT dependency closure before WITNESS;
2. required Data Page simulation in the witness/Projection;
3. legal `.pyName` before-state rather than final `TestJuneAugust` seed;
4. FINAL DTE/DTA replay producing the downstream branch value;
5. live actual results matching assertions.
