# R52 — Minimal Hardening Plan

## Scope

Baseline: R51 (`RuleIQ_R51_CTX_IDENTITY_REPAIRED_VALIDATED`).

This plan covers two independent fixes:

1. ScenarioAuthor Decision Table witness/freeze integrity for `PXCONV-198061`.
2. UnitTestGenerator Scenario naming + Validator JSON validation routing for `GENUT-97014`.

Primary design goal: fix the observed defects with the smallest possible production footprint, preserve all stable architecture, and keep prompt/MemoryTemp token overhead low for Claude Opus 4.8.

---

## 1. Architecture freeze

Do not redesign or modify unless a new regression proves a concrete defect:

- MAP -> WITNESS -> FREEZE -> DECIDE -> BUILD -> AUDIT
- DWL / RuleCrawler / CTX_READY / KEY_STABLE
- DT_PREWITNESS_READY
- POTENTIAL_DT_PRODUCER
- DP_SIM_READY
- KDT.1-KDT.12
- KDP.1-KDP.12
- existing ScenarioTrace row families and phase ownership
- UnitTestProjectionV3 schema
- Candidate schema
- existing Generator/Validator repair ownership
- existing repair-cycle limits

Do not add:

- new agent;
- new phase;
- new external tool;
- new persisted interface;
- new ScenarioTrace row family;
- new DTM/DTA/DTE/cellProof MemoryTemp rows;
- new Projection field;
- new Candidate field;
- new repair code unless existing codes are insufficient.

---

## 2. Production footprint

### ScenarioAuthor

Preferred change only in:

`01_PROMPTS/ScenarioAuthor_SystemPrompt.txt`

Expected unchanged:

- Decision Table Knowledge Area
- Data Page Knowledge Area
- Property Knowledge Area
- RuleCrawler contracts
- Projection schemas
- Generator/Validator schemas

### Generator

Change only existing Scenario-name materialization/fidelity rules.

### Validator

Change only JsonValidationTool response classification and routing.

---

# 3. Fix A — PXCONV-198061 DT witness/freeze integrity

## 3.1 Root defect

The Scenario was committed as `REALIZED` even though its exact WITNESS inputs could not reproduce the claimed DT execution. FREEZE then introduced an execution-enabling fact (`Primary.pyName=Test`) that was absent from the committed WITNESS and used it to justify the downstream branch/assertion.

The correct ownership is:

`WITNESS = solve the executable scenario`

`FREEZE = replay/canonicalize the already-complete scenario`

`AUDIT = independently verify the replay`

---

## 3.2 Strengthen existing DT_CAUSAL_VALID

Do not create a new proof mechanism.

For a DT-dependent Scenario require:

- exact committed WITNESS execution carrier;
- FINAL DTE;
- complete mode-required KDT.11 cellProof;
- complete ordered referenced DTA;
- KDT.12 PASS;
- deterministic DTA replay from the legal initial state;
- produced final property value consumed by downstream execution.

A desired final property value must never authorize the initial value.

---

## 3.3 Strengthen WITNESS REALIZED gate

Before:

`RESOLVE|<COV>|REALIZED|<Scenario>`

for any reachable DT, require:

1. `DT_PREWITNESS_READY(DT)=PASS`;
2. complete execution-enabling carrier;
3. every required DTA.before already present in `SCENARIO.given`;
4. FINAL DTE for those exact inputs;
5. complete required cellProof;
6. KDT.12 PASS;
7. ordered DTA replay;
8. full RUT replay reaches the requested MAP/COV outcome.

If any condition fails:

- keep the COV unresolved;
- rebuild the witness;
- do not commit REALIZED.

Narrative, desired branch, or desired expected value is never execution proof.

---

## 3.4 Keep full simulation payload in SCENARIO.given

Do not remove or replace the concrete simulation payload with only a symbolic Data Page reference.

`SCENARIO.given` remains the complete compact executable pre-state, including the exact simulation payload required to replay the Scenario.

Example:

`Primary.pyName=Test;Primary.pyText=2;Primary.pyTempInteger=7;D_CustomerTestRef.Addresses(1).pyCity=Amsterdam;D_CustomerTestRef.Addresses(1).pyType=Postal;D_CustomerTestRef.Addresses(1).pyPostalCode=1011AB`

Reason: the simulation payload is execution authority. Removing it risks later reconstruction mistakes in indexes, classes, or leaf values.

Token optimization must come from avoiding duplicate proof structures, not from deleting the frozen simulation carrier.

---

## 3.5 WITNESS owns all DT before-state

If KDT/inverse producer reasoning requires:

`DTA.before = X`

the corresponding setup fact must already be in committed WITNESS `SCENARIO.given`.

Forbidden:

WITNESS: `Primary.pyName` absent

FREEZE: `Primary.pyName=Test`

If FREEZE needs a value that was absent from WITNESS, the witness was incomplete and must be rebuilt.

---

## 3.6 FREEZE replay-only invariant

Define a logical view over existing Scenario state:

`EXECUTION_CARRIER(S) = parameters + primary/non-primary pre-state + simulation payload + execution-determining setup/action inputs`

No new persisted row is required.

Require:

`EXECUTION_CARRIER(FREEZE,S) == EXECUTION_CARRIER(WITNESS,S)`

This is a semantic exact-census comparison, not a hash/checksum comparison.

FREEZE may:

- canonicalize representation;
- rebuild final RX/CTX/CAST;
- derive PATH/EFFECT.

FREEZE may not:

- add execution-enabling setup;
- remove execution-enabling setup;
- change parameters;
- add/change simulation values;
- introduce a new DTA.before seed.

If it needs to, return to WITNESS.

---

## 3.7 MemoryTemp compromise

Default: do not add DTM/DTA/DTE/cellProof rows.

Use existing `SCENARIO.given` as the persisted execution carrier.

Only if live Claude Opus 4.8 still shows phase-memory instability after the hard gates are added, reuse existing WHY with one compact marker, for example:

`WHY|S1|P1|dt_exec|F;A=2;K=P`

where:

- F = DTE FINAL
- A=2 = two referenced ordered DTA
- K=P = KDT.12 PASS

This marker is provenance only, not authority. Omit it if the stronger gates are sufficient.

---

## 3.8 AUDIT strengthening

Reuse existing `DT_EXECUTION_MISMATCH`.

Add checks:

1. WITNESS execution carrier equals FREEZE execution carrier.
2. Every DT-required before-state used in FREEZE existed in WITNESS.
3. KDT.12 replay over the exact frozen carrier yields the same matched rows, DTA sequence, DT effects, downstream RX, and EFFECT.
4. A Scenario whose COV cannot be reproduced from its exact carrier fails AUDIT.

Repair owner remains:

- new/missing executable dependency -> CRAWL;
- incomplete/incorrect witness -> WITNESS;
- valid witness but corrupted final replay -> FREEZE;
- decision-only serialization defect -> DECIDE.

No new repair code.

---

# 4. Fix B — Generator Scenario.Name

## 4.1 Mechanical copy

Require:

`Candidate.UnitTestRules[*].Scenarios[i].Name = Projection.scenarios[i].name`

No Scenario-name transformation.

Forbidden on `Scenarios[].Name`:

- `TC_` prefix;
- Unit Test rule naming normalization;
- physical-group suffix;
- hash suffix;
- ordinal suffix;
- regenerated semantic label.

Keep Pega Unit Test rule naming separate from semantic Scenario naming.

---

## 4.2 Generator self-check

Before Candidate persistence / Validator handoff require:

`Candidate.Scenarios[i].Name == Projection.scenarios[i].name`

This is a mechanical mapping/fidelity check only.

Do not introduce another naming algorithm.

---

# 5. Fix C — Validator JsonValidationTool routing

A result such as:

`{"message":"JSON_VALIDATION_ERROR| ...","IsValid":false}`

means:

- tool invocation succeeded;
- validation ran successfully;
- Candidate is schema-invalid.

Therefore classify as:

`JSON_SCHEMA_INVALID`

not:

`JSON_VALIDATION_TOOL_ERROR`

Required routing:

- `IsValid=true` -> continue fidelity checks;
- `IsValid=false` with usable schema diagnostic -> `JSON_SCHEMA_INVALID` -> existing deterministic Generator repair route when supported;
- exception / unparsable response / missing IsValid / unusable contradictory envelope -> `JSON_VALIDATION_TOOL_ERROR` -> HUMAN.

Validator must not patch Candidate itself. Existing Generator repair ownership remains unchanged.

---

# 6. Claude Opus 4.8 token/latency constraints

Prefer strengthening existing named invariants instead of adding parallel prose.

Target concepts:

1. DT WITNESS REALIZED gate.
2. WITNESS/FREEZE execution-carrier equality.
3. Scenario.Name mechanical copy.
4. `IsValid=false` classification.

MemoryTemp:

- no new row family;
- no persisted DTM/DTA/DTE/cellProof;
- retain full existing simulation payload in `SCENARIO.given`;
- no duplicate simulation payload in new structures;
- optional compact WHY marker only if live evidence requires it.

Prompt editing:

- replace weak/contradictory text rather than append duplicate explanations;
- use positive target behavior;
- do not put bug history into production prompts.

Suggested net prompt deltas:

- ScenarioAuthor: about 180-250 words maximum;
- Generator: about 60-100 words;
- Validator: about 80-130 words.

If more is needed, remove equivalent redundant wording first.

---

# 7. Risk controls

### FREEZE over-constraint

Carrier immutability applies only to execution-enabling facts, not metadata wording, canonical rendering, PATH/EFFECT derivation, or harmless representation reduction.

### WITNESS retry cost

Only DT-dependent scenarios receive the stronger DT replay gate. Do not restart unrelated MAP/dependency work when witness values alone are wrong.

### Simulation payload size

Keep current payload for reliability. Do not duplicate it into DT-specific MemoryTemp rows.

### Non-DT regressions

All new DT replay requirements are conditional on a reachable DT. Non-DT Model/When/Property flows remain unchanged.

### R51 regression

Do not change:

- CTX_READY;
- KEY_STABLE;
- same-wave provider barrier;
- DT_PREWITNESS_READY dependency closure.

### Generator naming regression

Only Candidate Scenario.Name becomes exact-copy. Existing Unit Test rule identifier naming remains untouched.

### Validator over-routing

Only a usable `IsValid=false` validation result becomes schema-invalid. Genuine tool/envelope failures remain HUMAN.

---

# 8. Implementation order

Stage 0 — freeze R51 baseline and source evidence.

Stage 1 — ScenarioAuthor:
- strengthen DT_CAUSAL_VALID;
- strengthen WITNESS REALIZED gate;
- require DTA.before in WITNESS;
- enforce FREEZE carrier immutability;
- strengthen AUDIT.

Stage 2 — Generator:
- exact Scenario.Name copy;
- Candidate/Projection Scenario.Name equality check.

Stage 3 — Validator:
- classify `IsValid=false` as schema-invalid;
- preserve true tool-error HUMAN route.

Stage 4 — static production-footprint/contradiction audit.

Stage 5 — deterministic simulations below.

Stage 6 — complete regression suite.

Stage 7 — fresh live Pega acceptance.

---

# 9. Post-change simulation — PXCONV-198061

## 9.1 Original bad witness

Original problematic form conceptually:

- `Primary.pyText=June`
- `Primary.pyTempInteger=3`
- simulation payload present
- `Primary.pyName` absent

Expected after fix:

`exact DT replay -> requested matched rows/actions cannot be reproduced -> FINAL DTE/cellProof/downstream outcome cannot all hold -> DT_CAUSAL_VALID FAIL -> COV remains unresolved -> REALIZED cannot commit`

Acceptance: original bad S1 cannot reach WITNESS COMMIT as REALIZED.

---

## 9.2 Correct positive witness

Use deterministic carrier:

- `Primary.pyName=Test`
- `Primary.pyText=2`
- `Primary.pyTempInteger=7`
- Data Page simulation makes `IsValidPostalAddress=true`

Expected DT:

- row0 matches -> `pyName += June`
- row1 matches -> `pyName += August`
- final `pyName=TestJuneAugust`
- downstream WHEN true
- `pyValue=First`

Expected phases:

WITNESS:
- full carrier already includes `pyName=Test`;
- FINAL DTE;
- complete cellProof;
- ordered DTA;
- KDT.12 PASS;
- COV REALIZED.

FREEZE:
- carrier identical to WITNESS;
- no new setup/parameter/SIM values;
- same DT effects.

DECIDE:
- `pyValue=First` supported by exact frozen execution.

AUDIT:
- carrier equality PASS;
- KDT.12 replay PASS;
- DT execution lineage PASS.

---

## 9.3 Else regression

Use:

- `Primary.pyName=Test`
- `Primary.pyText=2`
- `Primary.pyTempInteger=7`
- Data Page payload makes `IsValidPostalAddress=false`

Expected:

- row0 false;
- row1 true;
- `pyName=TestAugust`;
- downstream WHEN false;
- `pyValue=Second`.

Simulation remains required because the helper/Data Page access executed even though it returned false.

---

## 9.4 FREEZE-mutation adversarial test

WITNESS omits `Primary.pyName`.

Attempt FREEZE with `Primary.pyName=Test`.

Expected:

`EXECUTION_CARRIER mismatch -> FREEZE invalid -> return WITNESS`

If somehow carried to AUDIT:

`DT_EXECUTION_MISMATCH`.

---

# 10. Post-change simulation — GENUT-97014

## 10.1 Positive G003 replay

Projection source:

- Scenario name: `Valid city non-positive index`
- `Param.AddressIndex` expected `-1`

Expected Generator:

`Candidate.Scenarios[0].Name = "Valid city non-positive index"`

No `TC_`.

Expected JsonValidationTool:

`IsValid=true`

Expected Validator:

continue fidelity checks; PASS if no unrelated candidate defect exists.

Expected queue:

- G001 PASS
- G002 PASS
- G003 PASS
- G004 PASS

Expected overall: 4 of 4 generated.

Do not change the `-1` sentinel.

---

## 10.2 Negative naming-classifier regression

Inject Candidate-only fixture:

`Scenario.Name = "TC_Valid city non-positive index"`

Expected JsonValidationTool:

- `IsValid=false`
- diagnostic path `/UnitTestRules/0/Scenarios/0/Name`

Expected Validator:

`JSON_SCHEMA_INVALID`

Not:

- `JSON_VALIDATION_TOOL_ERROR`
- immediate HUMAN

If deterministic repair is supported:

- route Generator repair;
- restore exact Projection scenario.name;
- revalidate;
- `IsValid=true`.

---

## 10.3 Genuine tool-error regression

Inject malformed/unusable validation-tool response:

- missing `IsValid`, or
- unparsable response, or
- invocation exception.

Expected:

`JSON_VALIDATION_TOOL_ERROR -> HUMAN`

This proves that the fix does not weaken actual tool-failure handling.

---

# 11. Cross-regression run

ScenarioAuthor:

- PXCONV-198061 bad-witness rejection;
- PXCONV-198061 corrected positive witness;
- R48 row1-only else;
- R50 DT_PREWITNESS closure;
- R51 CTX->READY PageList When class resolution;
- R51 KEY_STABLE inherited `@baseclass`;
- PrepareCustomerCommunication PageList helper closure;
- direct-class When dependencies: no extra wave;
- non-DT Model baseline;
- DP evaluated/false-result still requires simulation;
- terminal `notEvaluated` DP may omit simulation.

Generator:

- Scenario.Name exact copy;
- existing Unit Test rule naming unchanged;
- all four PrepareCustomerCommunication groups retained;
- `Param.AddressIndex=-1` preserved;
- unrelated Scenario names unchanged.

Validator:

- `IsValid=true` -> fidelity;
- `IsValid=false` + schema diagnostic -> schema-invalid route;
- malformed/unusable tool response -> tool-error/HUMAN;
- existing SEMANTIC_REJECT route unchanged;
- existing genuine HUMAN route unchanged;
- repair-cycle limit unchanged.

---

# 12. Acceptance criteria

DT / ScenarioAuthor:

1. Original PXCONV-198061 bad witness cannot commit REALIZED.
2. DT-required DTA.before exists in WITNESS.given.
3. Full simulation payload remains in SCENARIO.given.
4. FREEZE cannot add/change execution-enabling facts.
5. WITNESS and FREEZE execution carriers are semantically equal.
6. Correct positive witness reaches `pyValue=First`.
7. Correct else witness reaches `pyValue=Second`.
8. KDT.12 remains KDT-owned.
9. No DTM/DTA/DTE/cellProof ScenarioTrace family is added.
10. Existing `DT_EXECUTION_MISMATCH` is reused.

Generator:

11. Candidate Scenario.Name exactly equals Projection scenario.name.
12. No `TC_`/Unit-Test naming transform touches Scenario.Name.
13. Unit Test rule identifier naming remains unchanged.
14. G003 AddressIndex=-1 remains present/executable.

Validator:

15. `IsValid=false` is schema-invalid, not tool-error.
16. Normal schema-invalid response does not immediately route HUMAN.
17. Real malformed/tool failures still route HUMAN.
18. Existing bounded Generator repair remains the repair owner.

Architecture/performance:

19. R51 CTX_READY/KEY_STABLE unchanged.
20. KDT/KDP unchanged unless independent evidence proves a new defect.
21. Projection/Candidate schemas unchanged.
22. No new phase/agent/interface/persisted row family/repair code.
23. Prompt deltas stay compact and remove redundant wording.
24. No additional repeated simulation payload.
25. Claude Opus 4.8 latency/token footprint stays close to R51 baseline.

---

# 13. Validation artifacts after implementation

Produce:

- `R52_VALIDATION_REPORT.md`
- `R52_FINAL_VALIDATION_RESULTS.json`
- `R52_PXCONV_198061_SIMULATION.json`
- `R52_GENUT_97014_SIMULATION.json`
- `R52_PRODUCTION_FOOTPRINT.json`
- `RuleIQ_R52_DT_REPLAY_AND_VALIDATION_ROUTING_REPAIRED_VALIDATED.zip`

Clearly separate offline deterministic validation from fresh live Pega acceptance.

Offline PASS must never be presented as live proof.

---

# 14. Live acceptance

DT case:

- bad/incomplete DT witness rejected, or corrected witness contains `Primary.pyName=Test` before REALIZED;
- FREEZE adds no new execution facts;
- assertions derive from reproduced frozen execution;
- AUDIT passes only after exact replay.

PrepareCustomerCommunication:

- 4 Scenarios in WITNESS;
- 4 Scenarios in FREEZE;
- 4 groups in BUILD;
- 4 persisted Projections;
- 4 Generator invocations;
- Candidate Scenario.Name copied exactly;
- G003 no Scenario.Name schema failure;
- 4 terminal PASS results when no unrelated defect exists.

---

# 15. Final principle

Do not add more architecture to compensate for a missing gate.

Persist the exact executable witness once and require later phases to replay it without mutation.

Do not regenerate semantic names downstream; copy them from Projection.

Treat schema-invalid output as schema-invalid. Reserve tool-error/HUMAN routing for actual unusable tool responses.
