# R52 Validation Report

## Result

**PASS — 84/84 offline deterministic/structural checks passed.**

This report is offline validation only. Fresh live Pega execution remains the final acceptance step.

## Production changes

Only these production files changed from R51:

- `01_PROMPTS/ScenarioAuthor_SystemPrompt.txt`
- `01_PROMPTS/UnitTestGenerator_SystemPrompt.txt`
- `01_PROMPTS/Validator_SystemPrompt.txt`

KDT, KDP, RuleCrawler/tool contracts, Projection schemas and Candidate schemas are unchanged. No new agent, phase, ScenarioTrace row family, Projection field, Candidate field, or external interface was introduced.

## Claude Opus 4.8 footprint

- ScenarioAuthor: +191 words (budget <= 250)
- Generator: +89 words (budget <= 100)
- Validator: +81 words (budget <= 130)

The full simulation payload remains in `SCENARIO.given`; no duplicate DTM/DTA/DTE/cellProof MemoryTemp representation was added.

## PXCONV-198061

The original WITNESS S1 omitted `Primary.pyName`; FREEZE later added `Primary.pyName=Test`. The new carrier-equality gate makes that transition illegal.

Deterministic DT replay:

- original bad witness (`pyText=June`, `pyTempInteger=3`, no `pyName`) -> no ChannelCode rows match -> cannot produce `TestJuneAugust`;
- corrected positive witness (`pyName=Test`, `pyText=2`, `pyTempInteger=7`, helper=true) -> rows 0+1 -> `TestJuneAugust` -> `pyValue=First`;
- corrected else regression (`pyName=Test`, `pyText=2`, `pyTempInteger=7`, helper=false) -> row 1 only -> `TestAugust` -> `pyValue=Second`; simulation remains required because the DP/helper access is evaluated.

The repair strengthens existing `DT_CAUSAL_VALID`, WITNESS REALIZED, FREEZE replay and AUDIT gates and reuses `DT_EXECUTION_MISMATCH`.

## GENUT-97014

Independent review found that the observed name failure was not primarily a `TC_` rewrite. The persisted semantic source name was `Valid city non-positive index`; the hyphen itself violates the existing Scenario-name regex. This was caught during R52 validation before packaging.

R52 therefore fixes the owner layers as follows:

1. ScenarioAuthor WITNESS must author every committed Scenario name directly in the source grammar; punctuation separators such as hyphen are expressed as spaces (`Valid city non positive index`).
2. Generator remains copy-only: Candidate `Scenarios[n].Name` must equal Projection `scenarios[n].name` character-for-character; `CM-NAME-001` is explicitly technical-test-name-only.
3. Validator now recognizes `IsValid=false` + `JSON_VALIDATION_ERROR|...` as `JSON_SCHEMA_INVALID`, not `JSON_VALIDATION_TOOL_ERROR`. It routes to `GENERATOR_REPAIR` when the target fragment is deterministically rebuildable.
4. If the frozen Projection source name itself is invalid, Generator refuses to sanitize it downstream and terminates semantic source rejection instead of looping.
5. Genuine malformed/unusable JsonValidationTool responses still route `JSON_VALIDATION_TOOL_ERROR/HUMAN`.

## Regression protection

The validation rechecked:

- R51 `CTX_READY` and `KEY_STABLE`;
- same-wave provider barrier;
- R50 `DT_PREWITNESS_READY` / `DP_SIM_READY`;
- KDT.10/KDT.11/KDT.12 and inverse increment-seed ownership;
- KDP.8-KDP.11 simulation semantics;
- R48/R50 row1-only `TestAugust -> Second`;
- target schemas and all six existing examples;
- technical Unit Test `Name` still uses the `TC_` grammar while Scenario `Name` still forbids it;
- Validator true tool-error/HUMAN behavior;
- no KDT ownership leaked into Generator/Validator.

## Final acceptance still required

Fresh live Pega should verify:

- `PXCONV-198061`: incomplete WITNESS cannot become REALIZED; corrected WITNESS includes every required DT before-state before commit; FREEZE adds no execution facts.
- PrepareCustomerCommunication: four Scenarios remain four; G003 source name is schema-safe before Projection persistence; Candidate copies it exactly; JsonValidationTool no longer rejects the name.
- A deliberate invalid Candidate Scenario name returns `JSON_SCHEMA_INVALID/GENERATOR_REPAIR`, while an actually malformed tool response still returns `JSON_VALIDATION_TOOL_ERROR/HUMAN`.
