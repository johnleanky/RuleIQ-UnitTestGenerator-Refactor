# RuleIQ — Fresh Continuation Bundle

This is a deliberately clean single-version continuation package.

## Contents

- `00_START_HERE/` — authoritative current status, R36 specification/validation, session handoff, and historical validation record.
- `01_PROMPTS/` — current Scenario Author, Unit Test Generator, Validator prompts.
- `02_KNOWLEDGE_AREAS/` — retained semantic/reference Knowledge Areas only.
- `03_TARGET_CONTRACTS/` — current Standard/MultiInput schemas and examples.
- `04_TOOLS/` — current Memory/tool contracts and required runtime-tool list.

No superseded prompt versions, validation scripts, hashes/checksums, or offline fixtures are included. `VALIDATION_HISTORY.md` is retained only as explicitly non-authoritative historical context.

## R36 current delta

Only `ScenarioAuthor_SystemPrompt.txt` changed from R35.

R36 keeps existing MAP `OUTCOME/COV/PDEF` planning but makes every cross-phase transition explicit and auditable:

- every MAP COV receives WITNESS `RESOLVE=REALIZED|BLOCKED`;
- WITNESS/FREEZE use complete compact `PATH` producer partitions;
- Standard FREEZE uses runtime `EFFECT` instead of verbose `PRODUCER` rows;
- WITNESS Scenario ids must survive unchanged into FREEZE;
- Standard AUDIT traverses the complete `MAP,WITNESS,FREEZE,DECIDE,BUILD` lineage;
- AUDIT FAIL emits deterministic `REPAIR` and triggers automatic generation invalidation/rebuild from the earliest owner.

See:

- `00_START_HERE/R36_LOSSLESS_COMPACT_SCENARIOTRACE_SPEC.md`
- `00_START_HERE/R36_LOSSLESS_COMPACT_SCENARIOTRACE_VALIDATION.md`
- `00_START_HERE/R36_BAD_CASE_SIMULATION.md`

Static/refactoring validation: Critical 0 / High 0 / Medium 0. Fresh live Pega R36 replay remains pending.
