# R36 Session Handoff

## Current release

R36 — Lossless Compact ScenarioTrace with End-to-End Audit and Self-Repair.

Start with:

1. `STATUS.md`
2. `R36_LOSSLESS_COMPACT_SCENARIOTRACE_SPEC.md`
3. `R36_LOSSLESS_COMPACT_SCENARIOTRACE_VALIDATION.md`
4. `01_PROMPTS/ScenarioAuthor_SystemPrompt.txt`

## What changed from R35

Only ScenarioAuthor runtime behavior changed.

### MAP

Keeps existing `OUTCOME/COV/PDEF` planning. Adds a hard integrity requirement: every required OUTCOME must have exactly one atomic COV.

### WITNESS

Every MAP COV gets exactly one:

```text
RESOLVE|COV|REALIZED|Scenario|-|-
```

or a grounded terminal:

```text
RESOLVE|COV|BLOCKED|-|canonical_reason|proof
```

No silent loss. Execution is stored as one complete `PATH(E/S/U)` per Scenario, not individual EXEC rows.

### FREEZE

Scenario ids must equal WITNESS exactly. FREEZE writes a fresh final PATH and compact EFFECT rows containing concrete source/target/before/after/index/value facts. It cannot silently drop or merge a Scenario.

### DECIDE / BUILD

Semantics intentionally remain explicit and largely unchanged. OUTPUT/DECISION are the final assertion authority; BUILD is a mechanical copy/materialization.

### AUDIT

Standard AUDIT BASE now includes WITNESS and audits the whole active lineage. On FAIL it emits one REPAIR directive naming the earliest owner. The same Author invalidates/rebuilds from that owner and retries, max five cycles. Repair counters/signatures come from committed transcript rows, not hidden memory.

## Regression files used

- `PXCONV-184033.txt` — successful R35 reference.
- `PXCONV-184052.txt` — silent-loss failure; R36 rejects its incomplete OUTCOME/COV shape.
- `PXCONV-184019.txt` — historical child producer/assertion/page loss; R36 preserves R35 safeguards with PDEF/PATH/EFFECT lineage.

## Validation result

Static/refactoring review:

```text
Critical 0
High     0
Medium   0
```

All runtime files other than ScenarioAuthor are direct-content unchanged from R35.

Prompt size:

```text
R35 143,875 chars
R36 142,603 chars
-0.884%
```

Recorded-trace serialization estimate (`PXCONV-184033`):

```text
17,171 -> 14,324 chars
~16.6% reduction
```

Fresh live Pega replay of R36 is still pending.

## If continuing development

Do not redesign MAP unless new evidence proves a MAP defect. The primary R36 invariant is transition conservation plus end-to-end AUDIT.

Any new optimization must preserve:

- exact COV disposition;
- Scenario identity WITNESS -> FREEZE;
- full PDEF PATH partition;
- child EFFECT completeness;
- source/target index separation;
- named-page rooted target lineage;
- exact Pega lexical expected values;
- OUTPUT/DECISION equality;
- deterministic AUDIT repair ownership.
