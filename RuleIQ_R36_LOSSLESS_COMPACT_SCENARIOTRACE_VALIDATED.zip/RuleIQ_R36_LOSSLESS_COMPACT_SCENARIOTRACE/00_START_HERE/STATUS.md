# RuleIQ Unit Test Pipeline — Current Status

**Bundle date:** 2026-09-19  
**Current release:** R36  
**Authority:** this bundle is the sole current project version. `STATUS.md` describes active behavior; `VALIDATION_HISTORY.md` is historical/non-authoritative.

## R36 current delta

Only the ScenarioAuthor runtime prompt changes from R35.

R36 fixes silent cross-phase semantic loss and compacts execution state without redesigning successful MAP planning:

- MAP retains `OUTCOME`, `COV`, `PDEF`.
- WITNESS must resolve every MAP COV exactly once with `RESOLVE=REALIZED|BLOCKED`; missing transition is malformed.
- Standard WITNESS and FREEZE use complete `PATH(E/S/U)` producer partitions instead of per-producer `EXEC` rows.
- FREEZE preserves exact WITNESS Scenario ids and uses compact runtime `EFFECT` rows instead of verbose Standard `PRODUCER` rows.
- DECIDE keeps explicit `OUTPUT` and `DECISION` as the assertion safety boundary.
- Standard AUDIT now references the complete active `MAP,WITNESS,FREEZE,DECIDE,BUILD` lineage and verifies every transition.
- `AUDIT=FAIL` emits exactly one deterministic `REPAIR(owner,code,affectedIds,action)`; the same Author invalidates the earliest owning generation and automatically rebuilds downstream before retrying AUDIT.
- Repair state is reconstructed from committed AUDIT/REPAIR rows, capped at five cycles, with deterministic no-progress detection.

The live `PXCONV-184052` failure is specifically blocked by a new planning-integrity gate requiring exactly one atomic COV for every required MAP OUTCOME and then exact MAP-COV/WITNESS-RESOLVE conservation.

See:

- `R36_LOSSLESS_COMPACT_SCENARIOTRACE_SPEC.md`
- `R36_LOSSLESS_COMPACT_SCENARIOTRACE_VALIDATION.md`
- `R36_BAD_CASE_SIMULATION.md`

## Active Standard ScenarioTrace

```text
MAP     : PHASE,HEAD,BASE,OUTCOME,COV,PDEF,COMMIT
WITNESS : PHASE,HEAD,BASE,RESOLVE,SCENARIO,PATH,[WHY],COMMIT
FREEZE  : PHASE,HEAD,BASE,SCENARIO,PATH,EFFECT,COMMIT
DECIDE  : PHASE,HEAD,BASE,OUTPUT,DECISION,COMMIT
BUILD   : PHASE,HEAD,BASE,GROUP,LOCATION,COMMIT
AUDIT   : PHASE,HEAD,BASE,AUDIT,[REPAIR],COMMIT
```

Core conservation rules:

```text
R OUTCOME <-> atomic COV
MAP COV == WITNESS RESOLVE
WITNESS Scenario ids == FREEZE Scenario ids
PATH.E union PATH.S union PATH.U == PDEF ids
executed effect-bearing PDEF -> exactly one EFFECT
OUTPUT ids == DECISION ids
DECISION ASSERT == normalized BUILD assertions
```

## AUDIT and repair

Standard AUDIT checks in order:

```text
MAP -> WITNESS
WITNESS -> FREEZE
PDEF -> PATH
PATH -> EFFECT
final state -> OUTPUT
OUTPUT -> DECISION
DECISION -> BUILD
```

Only active `AUDIT=PASS` may enter `PREPARE_ALL`.

On FAIL, AUDIT is diagnostic/control only. It identifies the earliest owner in:

```text
CRAWL -> MAP -> WITNESS -> FREEZE -> DECIDE -> BUILD
```

The owner is rebuilt through normal generation invalidation; AUDIT never patches committed semantic state directly.

## Downstream architecture

R34/R35 downstream boundaries remain unchanged:

- ScenarioAuthor materializes and self-validates `UnitTestProjectionV3` only after global AUDIT PASS.
- All Projections are prepared before any persistence.
- All prepared Projections are persisted before any Generator invocation.
- Generator owns technical Pega Unit Test naming and Candidate compilation/repair.
- Validator independently validates exact Projection + Candidate and never redefines Author semantics.
- Generator/Validator assistant prose is non-authoritative; exact Memory lifecycle state is authoritative.

## Naming / response contract

Unchanged from R34:

- ScenarioAuthor owns semantic Scenario names only.
- Generator alone applies `CM-NAME-001` and reuses the same target name for UnitTestRules[0].Name / pyPurpose / pyLabel.
- ScenarioAuthor terminal response has exactly `AIAgentResponseStatus` and `AIAgentErrorResponseMessage`.

## Validation boundary

Static/refactoring validation for R36: **PASS — Critical 0 / High 0 / Medium 0**.

Direct comparison confirms every runtime file except `ScenarioAuthor_SystemPrompt.txt` is unchanged from clean R35.

Recorded R35 trace estimate on `PXCONV-184033`:

```text
17,171 chars -> estimated 14,324 chars
reduction ~= 16.6%
```

The R36 ScenarioAuthor prompt itself is 0.884% smaller than R35 after cleanup.

Fresh live Pega execution/timing of the modified R36 prompt remains pending external evidence and must not be represented as completed.
