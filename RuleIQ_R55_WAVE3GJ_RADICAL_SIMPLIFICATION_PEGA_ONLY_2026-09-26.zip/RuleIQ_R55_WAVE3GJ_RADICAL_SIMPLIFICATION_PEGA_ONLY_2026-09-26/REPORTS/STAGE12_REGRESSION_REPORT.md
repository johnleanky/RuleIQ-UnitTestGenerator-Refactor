# W3GJ Stage 12 Regression Simulation Report

Status: 41/41 PASS

Basis: four supplied W3GI live conversations plus deterministic local simulations of the current owner algorithms. Local simulations validate algorithmic consequences; they are not a substitute for a fresh Pega live run.

| # | Test | Status | Detail |
|---:|---|---|---|
| 1 | LIVE Prepare run 104001 contains diagonal basis symptom | PASS |  |
| 2 | LIVE Prepare run 104003 contains diagonal basis symptom | PASS |  |
| 3 | LIVE DT run contains temp=3 bad-seed symptom | PASS |  |
| 4 | LIVE DT run contains committed invalidation symptom | PASS |  |
| 5 | LIVE runs contain PageList array carrier | PASS |  |
| 6 | Prepare reference is T2,T3,T5 | PASS | ['T2', 'T3', 'T5'] |
| 7 | Prepare linear basis exact | PASS | [('T1',), ('T2', 'T3', 'T5'), ('T2', 'T4', 'T5'), ('T2', 'T3', 'T6')] |
| 8 | Prepare diagonal T2,T4,T6 excluded | PASS |  |
| 9 | Prepare basis stable across 5 deterministic simulations | PASS |  |
| 10 | DetermineChannel has exactly 2 control edges | PASS | [('WHEN', 'TRUE'), ('WHEN', 'FALSE_CONTINUATION')] |
| 11 | SET creates no EDGEIR | PASS |  |
| 12 | DT temp3 matches row0 only | PASS | ([0], [(0, 'June', 'Test', 'TestJune')], 'TestJune', 'Second') |
| 13 | DT temp3 final TestJune/Second | PASS | ('TestJune', 'Second') |
| 14 | DT temp8 matches both rows | PASS | ([0, 1], [(0, 'June', 'Test', 'TestJune'), (1, 'August', 'TestJune', 'TestJuneAugust')], 'TestJuneAugust', 'First') |
| 15 | DT temp8 final TestJuneAugust/First | PASS | ('TestJuneAugust', 'First') |
| 16 | DT text99 matches none | PASS | ([], [], 'Test', 'Second') |
| 17 | DT text99 preserves Test/Second | PASS | ('Test', 'Second') |
| 18 | Negative DTA from unmatched row rejected | PASS |  |
| 19 | Negative contradictory matched set rejected | PASS |  |
| 20 | Valid both-row DTE accepted | PASS |  |
| 21 | PageList array accepted | PASS |  |
| 22 | Page-shaped PageList rejected | PASS |  |
| 23 | When remains CTX before provider closure | PASS |  |
| 24 | When class derives from provider pyPageClass | PASS |  |
| 25 | Caller Data-Customer cannot substitute provider class | PASS |  |
| 26 | Same-key occurrences remain two DEPIR rows | PASS |  |
| 27 | DetermineChannel output census includes Param.Run/pyName/pyValue | PASS |  |
| 28 | Param.Run is OMIT not dropped | PASS |  |
| 29 | DT caller-visible pyName is ASSERT eligible | PASS |  |
| 30 | Primary maps to RunRecordPrimaryPage by default | PASS |  |
| 31 | Primary maps to explicit primary.page | PASS |  |
| 32 | Named setup page preserved | PASS |  |
| 33 | No semantic AUDIT phase remains | PASS |  |
| 34 | No XMAP remains | PASS |  |
| 35 | No persisted WHY row remains | PASS |  |
| 36 | No ACQIR remains | PASS |  |
| 37 | WITNESS does not persist PATH | PASS |  |
| 38 | FREEZE Standard row set PATH/EFFECT only | PASS |  |
| 39 | PREPARE primary mapping explicit | PASS |  |
| 40 | All KA marker refs resolve | PASS | [] |
| 41 | Prompt smaller than W3GI | PASS | 186619->149629 (19.8% bytes reduction) |
