# W3GJ Stage 13 — Full Sequential Proofread Defect List

Status: COMPLETE — no fixes were applied during Stage 13.
Scope read sequentially: ScenarioAuthor prompt + all 6 production Knowledge Areas (1,929 lines total).
Evidence base: W3GI live runs GENUT-104001/104003/104004/104005 + Stage12 41/41 regression fixtures.

## Critical

### C01 — Model dependency extractor contradicts Model identity field
- Files: Rule-Obj-Model KA KT.4 vs KT.39.
- KT.4: APPLY_MODEL rule name is `pyPropertiesName`.
- KT.39 scans APPLY_MODEL `[pyModelName,pyParameters[]]`.
- Effect: same Model source can produce different/missing dependency occurrences; directly undermines deterministic DWL/DEPIR.
- Fix: KT.39 must use `pyPropertiesName` and the already-owned KT.4 semantics.

### C02 — RUF closure contract still uses removed DWL lifecycle states
- File: Rule-Utility-Function KA KRUF.13.
- References `REQUESTED|FETCHED|SCANNED`, removed in Stage 3 canonical DWL (`CTX|READY|CLOSED|BLOCKED`).
- Effect: closure condition is internally impossible/ambiguous.
- Fix: express only canonical Core states; fetched/tool lifecycle is evidence, not DWL state.

### C03 — Rule-Obj-When signature registry is incompatible with Core signature constructor
- File: Rule-Obj-When KA KW.26 vs Core §3.1.
- Core mechanically consumes `locator`; KW.26 registry omits `locator` from schema and both sourceUnit signatures.
- Effect: IR unitLocator is underdetermined for original When.
- Fix: restore canonical locator recipes (`pyCondition[index]`, `pyLogic`) and registry field.

### C04 — Data Page simulation has two owners
- Prompt §1.4/§3.5/§4.3/§4.4.
- WITNESS owns CARRIER and requires DP_SIM_READY, but §3.5 says FREEZE materializes SIM/DPA; FREEZE is forbidden to add/change carrier.
- Effect: same simulation may be interpreted/materialized twice or be unavailable at WITNESS commit.
- Fix: WITNESS owns REQUIRED_SIMS/DP_SIG/SIM/DPA + simulation CARRIER; FREEZE consumes unchanged.

### C05 — Observable-output ownership is circular and contradictory
- Prompt §1.2, §1.4, §3.4, §3.6, §5.1.
- FREEZE owns `RUT_OUTPUTS`, while earlier/stale text says ORACLE/§5.1 owns membership.
- ORACLE requires PropertyTrace/APB-derived context/support although PropertyTrace/APB run in DECIDE after ORACLE.
- Effect: output membership/context can be re-derived differently; recreates the old ORACLE/Projection silent-repair class of bugs.
- Fix: FREEZE owns target membership/order + runtime basePage/baseClass/relativeTarget and final effect facts; ORACLE is exact 1:1 serialization; DECIDE alone computes assertion support/representation.

### C06 — Direct primary Decision Table MAP depends on concrete WITNESS evidence before WITNESS exists
- Prompt §4.2 vs §4.3/KDT.11.
- MAP asks for distinct FINAL result classes supported by KDT.11 execution evidence; KDT.11 concrete DTE/DTA is WITNESS-owned.
- Effect: circular MAP↔WITNESS semantics.
- Fix: direct primary DT MAP uses static DTM source outcomes (row-match/default/no-match obligations); WITNESS provides concrete executions. No concrete DTE is required before WITNESS.

## High

### H01 — WITNESS CREATE still claims PATH ownership
- Prompt §4.3 CREATE includes `+ PATH`; phase table and Stage11 say PATH is FREEZE-only.
- Fix: remove PATH from WITNESS CREATE.

### H02 — Standard Scenario owner is still described as FREEZE in grouping/BUILD
- Prompt §4.5/§4.6 uses `FREEZE Scenario(s)` for Standard although Standard SCENARIO is WITNESS-owned and FREEZE no longer copies it.
- Fix: Standard grouping/BUILD consume active WITNESS Scenarios validated by FREEZE; original When consumes FREEZE Scenarios.

### H03 — RI/PC duplicate the same source/producer authority already owned by signatures + IR PROD
- Prompt §3.3 explicitly states PC and IR PROD are two representations of the same signature-derived classification.
- Effect: duplicate hidden authority, large token cost, second chance for mismatch.
- Fix: remove RI/PC as independent reasoning checkpoints. IR PROD is sole persisted producer/source identity; producer semantic signature is resolved by `PROD.stepPath` + primary KA signature.

### H04 — LPE/APB/LIC/PropertyTrace form a second verbose assertion-support graph instead of consuming FREEZE/OUTPUT lineage
- Prompt §3.3–§3.4/§5.1/§5.5.
- They are non-persisted prose/checkpoints; recent live runs give no observable evidence that they prevent incorrect assertions.
- They also create the APB-before-ORACLE circularity in C05.
- Fix: derive final presence/value/list index/count from FREEZE EFFECT/DTA state once; ORACLE copies target/context/lineage; DECIDE verifies sourceRefs against EFFECT/DTA and selects representation directly. Keep only transient final-state calculation, not named parallel records.

### H05 — §5.5 is a second semantic audit after owner commit gates
- Nine gates repeat Dependency/DT/DataPage/list/testability semantic checks although semantic AUDIT was removed.
- Effect: extra reasoning path, prompt bloat, historically false confidence; PREPARE must be compiler-only.
- Fix: reduce §5.5 to owner-completion/census readiness only; no semantic re-execution.

### H06 — KDP contains workflow/scenario instructions despite declaring KA domain-only
- KDP.4 says parameter refinement changes scenarios/testability; KDP.11 is named SimulationAudit; §3.5 also duplicates its ownership.
- Fix: KDP provides scope/binding/runtime-access/signature/materialization consistency facts only. Core owns scenario lifecycle/repair.

### H07 — RUF KA is still a workflow engine
- KRUF.4 constructs D rows, KRUF.5 derives scenarios/seeds/assertions, KRUF.9 designs seeds, KRUF.10 creates dependencies, KRUF.12 writes BlockingGaps/ReasoningTrace/omissions.
- Contradicts Core/DWL single ownership and KA boundary.
- Fix: compress KRUF to invocation identity/request shape, fetched parameter roles, context/rule-argument semantics, helper roles, nested evaluation, unknown-return semantics, signature registry. Core performs D creation/request/seeds/assertions/gaps.

### H08 — Rule-Obj-When domain markers still directly queue/fetch dependencies
- KW.3/KW.15/KW.16.2 retain queue/fetch/send-to-RuleCrawler instructions despite header saying Core owns lifecycle.
- Fix: rewrite as dependency facts/roles only; KW.26 occurrence extractor/Core DWL performs materialization and requests.

### H09 — Property KA describes Page as scalar in structure algorithm
- KP.2 `Value/Page -> scalar` conflicts typed carrier semantics where Page is an object.
- Effect: can reintroduce Page/PageList shape confusion.
- Fix: say Value/Page are non-collection references for assertion naming only; Page remains embedded page object.

### H10 — Property type/serialization ownership is duplicated between KP.3/KP.9 and Core v3 grammar
- KP.3 maps Integer→Decimal and Boolean/TrueFalse→Text while Core §6.4 permits/uses authoritative destination modes Integer/TrueFalse etc.; KP.9 also owns assertion-construction procedure.
- Effect: two interpretations for assertion mode/value serialization.
- Fix: KA supplies raw `pyStringType` + semantic scalar type; Core owns v3 assertion `mode`/lexical serialization through CAST/§3.6. Retain LocalList/PromptList domain facts without a second assertion procedure.

### H11 — Projection contract still claims producer-side semantic validation although PREPARE_ALL is wire-only
- Prompt §6.4 opening vs §7.1.
- Effect: invites semantic re-evaluation at Projection boundary.
- Fix: §6.4 is closed wire/copy contract only; semantic correctness must already be owner-committed.

### H12 — Physical grouping and BUILD are two packaging mechanisms
- §4.5 creates ScenarioGroups; §4.6 BUILD only persists GROUP/LOCATION.
- Effect: duplicate packaging step/terminology and stale ownership references.
- Fix: fold physical grouping rules into BUILD. BUILD applies one-group-per-Standard-Scenario or KW.20 grouping and emits GROUP/LOCATION once.

## Medium

### M01 — `Pass A` naming remains although no later WITNESS passes exist
- Fix: rename to `Linear construction`.

### M02 — WITNESS retains negative prose about removed profile/interaction/reduction mechanisms
- Examples: `No profile/cost function`, commit gate lists profile equivalence/interaction closure.
- Fix: replace with one short invariant: `BASE is not reduced or minimized`.

### M03 — Hard SCENARIO8 parse gate generically names WITNESS/FREEZE although Standard FREEZE owns no SCENARIO
- Fix: apply only to phases that own SCENARIO: WITNESS; and FREEZE only for original When.

### M04 — SCENARIO fact round-trip text still implies Standard FREEZE can own SCENARIO
- Prompt §4.1 line around SCENARIO encoding.
- Fix: owner-specific wording.

### M05 — KDP says “examples omitted” but retains KDP.3 examples block
- Fix: remove KDP.3 example body (or marker entirely if unreferenced).

### M06 — KDP.11 stale `SimulationAudit` name after semantic AUDIT removal
- Fix: rename marker title to `SimulationConsistency` without changing marker id.

### M07 — Property KP.8 is an empty examples marker but KP.9 still references it
- Fix: remove dead KP.8 references/marker or make no-op references disappear; no example-based validation.

### M08 — Model KT.31 is a retired counter retained only for historical traceability
- No current consumer/signature authority.
- Fix: remove KT.31 and CoverageMap mention.

### M09 — Model KT.29/KT.28.S2 use setup/seed workflow language inside KA
- Fix: retain domain source/target/binding semantics; Core decides carrier/setup materialization.

### M10 — Model has noncanonical `Use:` lines outside declared P/M/I/A/S canonical labels
- KT.30/KT.33.
- Fix: convert useful meaning to S/I or remove.

### M11 — Prompt retains acquisition micro-examples and projection shape examples after algorithms are closed
- §2.5 micro-examples and §6.2 examples are non-authoritative token overhead.
- Fix: remove when no ambiguity remains.

### M12 — Single-owner wording still says ORACLE owns membership / §5.1 alone defines membership
- Functional core covered by C05; clean all stale wording globally.

### M13 — `EXPECTED_OUTPUTS` terminology survives after FREEZE `RUT_OUTPUTS` became canonical
- Fix: use `RUT_OUTPUTS -> ORACLE OUTPUT`; delete parallel term.

### M14 — Pre-projection `Decision Table` gate rechecks internal DTE/DTA semantics
- Covered structurally by WITNESS commit; §5.5 should only require final committed evidence/census.
- Fix with H05.

### M15 — KW/RUF headers and rows retain `R:`/`X:` remnants despite examples/reference rows being declared noncanonical/removed
- Fix: remove residual inline `R:`/`X:` fragments where they add no domain meaning.

## Low / observations (do not auto-fix solely on this pass)

### L01 — KW.19 original-When reduction remains complex and currently lacks a fresh W3GI original-When live regression.
Keep for now because it is a dedicated established When mechanism and no current failure proves removal is safe. Add future original-When live regression before reconsidering it.

### L02 — UI `reasoningTrace` / `dependencyClosureTrace` remain verbose target metadata.
They are target-contract fields rather than ScenarioTrace semantic state. Optimize wording later only if Generator/UI contract permits.

### L03 — Numeric RuleCrawler caps and coercion matrix are large but have clear operational/domain roles.
Do not remove without evidence.
