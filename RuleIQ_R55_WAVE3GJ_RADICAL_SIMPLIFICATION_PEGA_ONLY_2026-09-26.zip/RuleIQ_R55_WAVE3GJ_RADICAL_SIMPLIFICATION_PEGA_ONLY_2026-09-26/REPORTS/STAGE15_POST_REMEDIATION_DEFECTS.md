# W3GJ Stage 15 — Post-remediation full proofread defects

Sequential proofread scope: full current ScenarioAuthor prompt + all six Knowledge Areas after Stage 14 remediation.
Rule: Critical/High/Medium are auto-fixed before finalization; Low is retained only when deliberate and documented.

## Critical
- **P01 CRITICAL — impossible PROD reconciliation.** MAP requires `PROD.producerId == PROD.stepPath`, while row grammar and live W3GI traces use independent ids (`P1|1`, `P2|2.1`, ...). This is an ignored/dead gate. Fix: require producer id/order preservation and `PROD.stepPath == source unitLocator`, never equality between id and locator.

## High
- **P02 HIGH — WITNESS CREATE claims PATH ownership.** §4.3 CREATE includes `+ PATH`, contradicting phase table/finalization/FREEZE ownership. Fix: remove PATH from WITNESS CREATE.
- **P03 HIGH — pre-BUILD physical grouping duplicates BUILD.** §1.4 step 8 materializes ScenarioGroups before BUILD although §4.5 makes BUILD sole packaging owner. Fix: step 8 becomes readiness only; BUILD alone materializes groups.
- **P04 HIGH — Projection entry wording omits BUILD authority.** §1.4 step 10 says Projection is materialized only from ORACLE+DECIDE, despite BUILD owning group/location packaging. Fix: Projection consumes BUILD plus frozen semantic authorities.
- **P05 HIGH — DT evidence lacks invocation identity.** DTM/DTE/DTA cannot distinguish two calls to the same Decision Table on the same page in one Scenario. Fix: add exact `at=<invocation unitLocator>` to all three evidence rows and joins/order.
- **P06 HIGH — DT executable procedure still split between Core and KDT.** KDT.5/.6/.8/.9 contain caller seeding/DTA construction/concrete execution instructions that Core §3.7 also owns. Fix: KDT states declarative domain semantics only; Core §3.7 owns concrete row evaluation, before-seed resolution and DTA construction.
- **P07 HIGH — KDT dependency/context markers mutate Core workflow.** KDT.3 says keep CTX/request providers; KDT.10 tells Core to create/close dependency rows. Fix: markers return unresolved/context/dependency-bearing fields only; Core/DWL owns state/request/closure.

## Medium
- **P08 MEDIUM — Property KA constructs physical assertions.** KP.4 sets `pyPropertyApplyToClass`; violates KA=domain/Core=representation boundary. Fix to embedded-class evidence only.
- **P09 MEDIUM — Property KA chooses OMIT/GAP/assertion outcomes.** KP.10 contains assertion/test-selection language. Fix to pure runtime presence/count semantics.
- **P10 MEDIUM — stale RI/PC names in Model registry.** KT.37 still says locator reused by RI/PC after those mechanisms were removed. Fix to D provenance/PROD/EDGEIR.
- **P11 MEDIUM — registry ranges name removed markers.** KT.37 `KT.1-KT.39` includes removed KT.31; KP.12 includes removed KP.8; KW.26 includes absent KW.8/KW.10; KDP registry/coverage includes removed KDP.3. Fix: say “preceding defined markers” and use explicit existing authorities.
- **P12 MEDIUM — KDP marker order is noncanonical.** KDP.5 precedes KDP.4 after KDP.3 removal. Fix file order only.
- **P13 MEDIUM — When logic operator text has mojibake.** `ANDâ‰¡&&` etc. Fix with plain ASCII equivalence wording.
- **P14 MEDIUM — RUF KA assigns Core D states.** KRUF.13 describes CLOSED/BLOCKED state mapping despite domain-only boundary. Fix to semantic sufficiency statuses; Core alone maps to DWL states.
- **P15 MEDIUM — KDP workflow leakage.** KDP.5/KDP.7 contain direct CRAWL/do-not-crawl lifecycle instructions. Fix to domain boundary/reachability facts; Core decides actions.
- **P16 MEDIUM — DTA grammar excludes default despite KDT default actions.** Fix `row=<n|default>`.
- **P17 MEDIUM — stale pseudo-row wording.** UI metadata and role text refer to `ASSERT/SIM/OMIT/GAP rows` although these are now decisions/carriers/limitations, not persisted row families. Fix terminology without changing semantics.
- **P18 MEDIUM — physical group key is regenerated downstream.** BUILD owns grouping but PREPARE_ALL independently derives `Gnnn` from order. Fix: BUILD assigns `groupId=Gnnn` once; Projection/PREPARE only copy it.
- **P19 HIGH — BUILD GROUP emission violates canonical row arity.** §4.5 emitted only groupId+scenarioIds while §4.1 GROUP requires claimIds. Fix: emit exact four-field GROUP; Standard copies DECIDE ASSERT claim ids, When uses `-`.
- **P20 HIGH — Decision Table registry creates a second generic coverage path.** `KDT.ROW_OUTCOME edges=MATCH,CONTINUE` would create IR EDGEIR although direct-DT coverage is explicitly MAP-owned from DTM. Fix: `edges=NONE`; MAP remains sole DT coverage owner.
- **P21 HIGH — DT invocation locator must be occurrence-unique and support primary DT.** A caller unitLocator can contain multiple DT calls and direct primary DT has no caller unit. Fix: `at=DTable depId` for dependency invocations and exact sentinel `PRIMARY_RUT` for directly tested DecisionTable.

## Low / retained
- **L01 LOW — original-When KW.19 reduction remains complex.** Retain: it is a dedicated original-When domain workflow, not the removed generic Model reduction; no fresh original-When regression was supplied to justify redesign.
- **L02 LOW — UI trace fields remain verbose.** Retain because they are target-facing metadata contract fields.
- **L03 LOW — numeric RuleCrawler caps/coercion matrix are large.** Retain because they have direct operational/semantic roles and were not shown dead in live runs.
