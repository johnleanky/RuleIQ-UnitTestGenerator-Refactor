# Stage 0 — Usage / Ownership Census

## Evidence base
- W3GI production prompt + Model/DecisionTable KA.
- Unchanged KAs from full production bundle.
- Four W3GI live runs: GENUT-104001, 104003, 104004, 104005.

## Findings

| Mechanism | Writer/owner in current design | Observed reader/effect in live runs | Decision |
|---|---|---|---|
| DWL / context-derived KEY | CRAWL/Core | Drives RuleCrawler and DEPIR, but occurrence census/order varies | KEEP, simplify to one exact transition |
| DEPIR | IR | Used as dependency evidence; differs between identical runs | KEEP, make pure serialization of finalized DWL |
| EDGEIR | IR | Drives MAP/WITNESS; extra/non-control outcomes observed | KEEP, restrict to actual control/termination outcomes |
| MAP/COV | MAP | Used by WITNESS; may become trivial one-COV-per-edge | KEEP initially; measure after WITNESS simplification |
| REFERENCE/ISO machinery | WITNESS | 4-scenario count stable but single-change basis still violated | REPLACE with shorter linear baseline/alternative algorithm |
| PROFILE / interaction / reduction | WITNESS prose | PROFILE rows absent in all four runs; diagonal scenario still survives | REMOVE |
| WHY | WITNESS/FREEZE explanatory | Repeats structured evidence; more rows in repair runs; no downstream authority | REMOVE routine WHY; keep only exceptional GAP/unknown reason text where needed |
| Failed committed WITNESS | WITNESS lifecycle | Appears in GENUT-104003/104005 and bloats context before replacement | REMOVE: self-check before commit |
| DTE/DTA | WITNESS | Useful lineage/output bridge; internal contradictions observed | KEEP; simplify and enforce locally at DTE construction |
| KDT.12 independent audit | DecisionTable KA + AUDIT | No observable rejection; wrong DTE/DTA reaches PASS | REMOVE |
| AUDIT phase | AUDIT | Always PASS in observed semantic contradictions; no effective repair | REMOVE semantic phase; distribute exact reconciliation to owner boundaries |
| ACQIR | IR | Duplicates tool history; no downstream row references A-ids | REMOVE from persisted ScenarioTrace |
| Typed CARRIER | WITNESS | Fixed PageList physical shape in all W3GI runs | KEEP |
| FREEZE replay boundary | FREEZE | Preserves committed scenario state; useful semantic boundary | KEEP, replay-only |
| EFFECT→RUT_OUTPUTS→ORACLE | FREEZE/ORACLE | Fixed DTA `.pyName` and Param.Run propagation | KEEP, simplify to direct projection |
| DECIDE ASSERT/OMIT | DECIDE | Correctly omits inactive Evaluate-All scalar and builds assertions | KEEP |
| BUILD | BUILD | Physical assertion grouping/copy | KEEP, mechanical only |
| PREPARE_ALL semantic self-validation | PREPARE_ALL | Failed to catch Primary→RunRecordPrimaryPage mismatch in live run | SIMPLIFY to deterministic wire mapping + shape checks |
| Generator validation | Generator | Correctly caught physical primary-page mismatch | KEEP UNCHANGED |

## Single-owner target map

- Dependency class: DWL provider-context transition only.
- Property mode/page class: fetched Property evidence only.
- DT static semantics: KDT field semantics; DT execution: Core/WITNESS DTE/DTA.
- Control outcomes: IR EDGEIR only.
- Scenario selection: WITNESS only.
- Replay/final effects: FREEZE only.
- Observable membership: RUT_OUTPUTS produced from FREEZE effects; ORACLE exact projection only.
- Assertion decision: DECIDE only.
- Physical grouping: BUILD only.
- Wire serialization: PREPARE_ALL only.

## Stage 0 conclusion
Current instability is primarily caused by duplicate semantic interpretation and prose-only validation, not missing validation layers.
