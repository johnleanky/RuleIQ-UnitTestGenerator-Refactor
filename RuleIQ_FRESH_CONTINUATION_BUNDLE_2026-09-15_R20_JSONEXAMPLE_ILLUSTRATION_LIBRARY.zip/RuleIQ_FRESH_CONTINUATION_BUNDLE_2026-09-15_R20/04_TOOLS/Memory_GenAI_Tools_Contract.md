# R9 Canonical Single-Record Memory Tool Contract

**Status:** CURRENT SYNCHRONIZED CONTRACT  
**Scope:** single-record `WriteMemory`, `GetMemory`, and `UpdateMemory`; success framing plus persisted lifecycle feedback.  
**Evidence boundary:** wrapper names and `IsSuccess` runtime types come from the supplied live Pega traces; for this cycle the deployed response case field is user-confirmed as `CaseID`. `ProcessingFeedback` is the R9 persisted field added by this refactor. Failure shapes remain unverified.

## 1. General parsing rule

A Memory operation is confirmed successful only when its response matches the applicable success shape below, including wrapper location, exact field names/casing, value types, and required correlation values.

Do not coerce or alias:
- `IsSuccess` to/from `success`;
- response `RouterKey` to/from input/storage `pyRouterKey`;
- response `CaseID` to/from `pxCaseID`;
- `ProcessingFeedback` to/from any feedback alias;
- string `"true"` to/from boolean `true`;
- missing fields to inferred defaults.

`pxCaseID` remains the Memory **input argument** name. `CaseID` is the Memory **response** field. These are not aliases that callers may interchange.

Any exception, uncertainty, missing required field, wrong field type, wrong wrapper, wrong correlation value, or otherwise nonconforming response means the operation is **not confirmed**. The caller follows its fail-closed tool-error path and MUST NOT retry an uncertain write/update.

No failure response shape is canonicalized here. Failure payloads remain `UNVERIFIED_RUNTIME_SHAPE`; callers MUST NOT branch on invented `errorCode`, `errorMessage`, `NOT_FOUND`, `WRITE_FAILED`, or `UPDATE_FAILED` fields.

---

## 2. Persisted record invariants

Every record persists exact case ownership, `pyGUID`, `pyType`, `pyGroup`, immutable `pyPayload`, lifecycle `pyStatusValue`, router state, and Text `ProcessingFeedback`.

- `pyPayload` and record identity are immutable after create.
- `ProcessingFeedback` is initialized to exact `""` on create.
- `UpdateMemory` atomically changes only `pyStatusValue`, router state, `ProcessingFeedback`, and implementation-owned update timestamp.
- Success terminal state uses exact `ProcessingFeedback=""`.
- Failed/non-OK terminal state uses nonempty `ProcessingFeedback`.
- Multiple feedback items use one item per LF/newline. Memory stores/transports the text and does not interpret it.
- A successful later update MUST overwrite stale feedback with exact `""`.

---

## 3. WriteMemory

### Input

```text
WriteMemory(
  pxCaseID,
  Type,
  pyGroup,
  pyPayload
)
```

### Canonical success response

```json
{
  "MemoryToolResponse": {
    "IsSuccess": "true",
    "CaseID": "<exact input pxCaseID>",
    "pxObjClass": "RuleIQ-Data-AgentMemory",
    "pyGroup": "<exact input pyGroup>",
    "pyGUID": "<new nonempty GUID>",
    "pyType": "<exact persisted artifact type>"
  }
}
```

Caller invariants:
- create-only; one call creates at most one record;
- require exact `CaseID`, `pyGroup`, expected `pyType`, carrier class, and a new nonempty GUID;
- created lifecycle/router state and `ProcessingFeedback` are empty;
- any nonconforming response means create is unconfirmed; do not continue and do not retry.

---

## 4. GetMemory

### Input

```text
GetMemory(
  pxCaseID,
  pyGUID
)
```

### Canonical success response

```json
{
  "IsSuccess": true,
  "CaseID": "<stored case id>",
  "pyGroup": "<stored group>",
  "RouterKey": "<stored router key or empty>",
  "ProcessingFeedback": "<stored feedback or empty>",
  "pyType": "<stored artifact type>",
  "pyPayload": "<stored immutable payload>",
  "pyStatusValue": "<stored lifecycle status or empty>",
  "pyGUID": "<exact requested GUID>"
}
```

Caller invariants:
- read-only exact one-record read;
- require exact `CaseID`, GUID, type, group/payload requirements owned by the caller, and exact string `ProcessingFeedback`;
- response router field is `RouterKey`, never `pyRouterKey`;
- never substitute another row, infer "latest", or reconstruct a missing record.

---

## 5. UpdateMemory

Canonical signature: `UpdateMemory(pxCaseID,pyGUID,pyStatusValue,pyRouterKey,ProcessingFeedback)`.

### Input

```text
UpdateMemory(
  pxCaseID,
  pyGUID,
  pyStatusValue,
  pyRouterKey,
  ProcessingFeedback
)
```

Input `ProcessingFeedback` is required Text and is stored exactly, including exact empty string or LF-delimited content.

Allowed lifecycle/router pairs:

```text
Passed + OK
Failed + GENERATOR_REPAIR
Failed + SEMANTIC_REJECT
Failed + HUMAN
```

### Canonical success response

```json
{
  "MemoryToolResponse": {
    "IsSuccess": "true",
    "CaseID": "<exact input pxCaseID>",
    "pxObjClass": "RuleIQ-Data-AgentMemory",
    "pyGUID": "<exact input GUID>",
    "pyStatusValue": "<exact stored status>",
    "RouterKey": "<exact stored router key>",
    "ProcessingFeedback": "<exact stored feedback>"
  }
}
```

Caller invariants:
- exact one-record atomic lifecycle update;
- require exact `CaseID`, GUID, requested status, requested router echo, and exact feedback echo;
- only status/router/feedback plus implementation-owned update timestamp may change;
- payload/type/group/identity remain immutable;
- any nonconforming response means update is unconfirmed; stop and do not retry.

---

## 6. Failure and batch boundary

There is no evidence-backed canonical Memory failure object. Any response not matching the applicable success parser is an unconfirmed operation; callers do not infer failure semantics from diagnostic text or aliases.

These tools intentionally do not support batch create/read/update, `pxResults[]`, `RequestsJSON`, `ResultsJSON`, `pyUpdates`, partial batch success, query by Type/Group, overwrite, or payload update. If batch behavior is required later, define a separate tool.
