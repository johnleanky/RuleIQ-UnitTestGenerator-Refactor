# RuleIQ R20 — Session Handoff

## Authority

This R20 bundle is the only current project source of truth. `STATUS.md` is authoritative for active behavior. `VALIDATION_HISTORY.md` is historical/non-authoritative and must not override current prompts or status.

`TEXT_SEMANTIC_ONLY=true`: use direct textual/structural/semantic comparison only; do not use hashes, checksums or fingerprints as acceptance evidence.

## Why R20 exists

R20 keeps the R19 schema-owned compiler unchanged and upgrades executable JsonExample artifacts into compact illustration libraries. Each file now has `Template` plus three complete candidates: no simulation, Page Data Page simulation, and List Data Page simulation. All new example identifiers use synthetic `ZqxExample-*` names. Generator may consult `Examples[]` only for HOW an already-required schema mapping looks; Projection + JsonSchema remain the sole WHAT authority. Validator ignores `Examples[]` for validation.

## Why R18 exists

R18 fixes a projection/materialization regression exposed by live Data Page simulation: ScenarioAuthor knew runtime/page classes but dropped them at the Projection boundary, reused a runtime page name as simulation `pySetupPageName`, and omitted that runtime page from `pyPagesAndClasses` input. R18 carries simulation setup class explicitly, preserves nested resolved page classes, requires runtime named pages in Projection `pages`, and makes Generator emit fixed `PrimaryPage`.

## Why R17 exists

R17 is a narrow CaseID source-of-truth correction on top of R16. Live behavior showed two plausible identifiers were visible to ScenarioAuthor: bare `GetCaseData.pyID` and full `application_context.caseID`. The Author now uses only exact `application_context.caseID` for Memory/transport CaseID. Generator and Validator continue to consume exact `Invocation.CaseID`. No new transport field or Memory Tool contract is introduced.

## Why R16 exists

R16 was introduced after three live problems were reported after the previous refactor:

1. Mixed-case Pega case identity such as `GenUT-91051` was being propagated as `GENUT-91051` in Memory/Agent calls.
2. UnitTestGenerator emitted a long response duplicating state already persisted through Agent Memory, although ScenarioAuthor ignores that response.
3. ScenarioAuthor appeared to stop after the first downstream generation, and it was impossible to tell whether only one physical scenario had been created or whether later scenarios existed but had never reached UnitTestGenerator.

R16 addresses these without changing Scenario semantics, dependency closure, target serialization or Validator fidelity logic.

## Active inherited + R20 decisions

### 1. Exact case identity

`CASE_ID_RAW` is opaque case-sensitive text.

- ScenarioAuthor: `CASE_ID_RAW := exact application_context.caseID`.
- Generator: `CASE_ID_RAW := exact Invocation.CaseID`.
- Validator: `CASE_ID_RAW := exact Invocation.CaseID`.

Every Memory `pxCaseID`, delegated Agent Invocation `CaseID`, and Validator `JsonValidationTool.CaseID` must use the exact lexical value without normalization.

`GetCaseData.pyID` is not a Memory/transport CaseID source. If a live tool call already contains the exact `application_context.caseID` but Pega later stores/returns a different value, that is a Pega implementation/mapping defect outside prompt control.

### 2. Projection page/simulation materialization

- Frozen non-primary runtime pages used by setup/action/assertion/CTX are emitted as `Projection.pages[page]=resolvedClass`.
- Data Page simulation setup source is `{class,data}`; nested resolved Page/PageList/PageGroup instances carry `pxObjClass` in `data`.
- Generator emits `pySetupPageName="PrimaryPage"` and `pyPageDetails.pxObjClass=class`; nested `data` is preserved.


### 3. Schema-owned target compiler

- Executable Generator/Validator acquire only selected JsonSchema + JsonExample.
- `x-ruleiq-compilerMappings` is the complete Projection->Candidate compiler authority: common `CM-EXEC-001` plus `CM-ASSERT-STD-001` or `CM-WHEN-001`, with `CM-NAME-001`.
- `JsonExample.Template` alone owns `pyRuleSet` and `pyRuleSetVersion`.
- `JsonExample.Examples[]` is non-authoritative illustration only; both Standard and MultInpComb libraries contain no-simulation, Page DP, and List DP examples.
- Target `Rule-Test-Unit-Case*_KnowledgeArea` artifacts are removed from active runtime.

### 4. Generator response

Generator returns exactly `ACK` after processing. The response contains no status or diagnostics and is non-authoritative.

- Generator reads Validator outcome from exact Candidate Memory.
- ScenarioAuthor reads Generator outcome from exact Projection Memory.

Do not reintroduce `GeneratorRunReport`, nested response parsing, or response-text status handling.

### 5. Projection-first orchestration

The old interleaved loop is superseded.

Current order:

```text
I -> W -> F -> B -> A
require A=PASS

PREPARE_ALL
  materialize + self-validate every UnitTestProjectionV3
  require exact census with frozen physical groups

PERSIST_ALL
  WriteMemory every prepared Projection in frozen order
  freeze PROJECTION_QUEUE(groupId, payload, GUID, PENDING)
  require exact census + distinct nonempty GUIDs
  any write/correlation/census failure => zero Generator calls

GENERATE_ALL
  take first PENDING queue row
  call UnitTestGenerator exactly once
  ignore ACK/any response text
  fresh-read exact Projection GUID
  TERMINAL_PASS => mark DONE
  otherwise stop; later persisted Projections remain visible/unprocessed

COMPLETE
  only when DONE_COUNT == QUEUE_COUNT and PENDING_COUNT == 0
```

The persisted `UnitTestProjectionV3` rows themselves are the materialized evidence of the complete frozen physical-group set. No separate `ScenarioPlanV1` or `ScenarioName` Memory field was added.

## What remains unchanged in R20

Do not reopen these unless new evidence requires it:

- ScenarioAuthor dependency/DWL semantics.
- Scenario Compiler `I -> W -> F -> B -> A` semantics.
- Physical grouping semantics.
- Validator source/candidate fidelity ownership.
- Candidate repair routing and `ProcessingFeedback` grammar.
- Target naming `CM-NAME-001` (`City Not Valid Exit -> TC_CityNotValidExit`).
- Source-side `singlePage` remains absent; physical `pyIsSinglePageImplementation` is target-owned.

## Runtime implementation boundary

Files under `04_TOOLS/*.md` are specifications for the Pega implementation; they are not runtime artifacts that Pega reads automatically.

For the next live test, do **not** change Pega Memory implementation first. Capture the actual boundary behavior:

1. `application_context.caseID` and, for contrast only, `GetCaseData.pyID`.
2. Author tool-call `pxCaseID` and Generator Invocation `CaseID`.
3. Generator tool-call `pxCaseID` and Validator Invocation `CaseID`.
4. Validator `JsonValidationTool.CaseID` and Memory arguments.
5. persisted/returned Memory case value.

Only if the prompt/tool-call argument already equals exact `application_context.caseID` but Pega changes it after the call boundary should the Pega implementation be modified.

## Expected live multi-group evidence

For a successful run with N frozen physical groups:

- N Projection rows exist before the first Generator invocation.
- first Generator call occurs only after the Nth Projection write succeeds.
- Generator invocation order matches frozen group order exactly.
- each persisted Projection is invoked at most once.
- Generator response is exactly `ACK`.
- ScenarioAuthor ignores response text and fresh-reads the exact Projection GUID.
- each successful Projection ends `Passed + OK + ProcessingFeedback=""`.
- final Author completion occurs only after all N queue rows are DONE.

Failure expectations:

- any Projection write failure => no Generator calls at all;
- Generator/Projection failure on group k => groups k+1..N remain persisted and unprocessed;
- any CaseID mismatch is fail-closed and must be traced to the layer that changed the exact `application_context.caseID` value.

## Validation status

- R15 final regression: `172/172 PASS`.
- R15 ScenarioAuthor §2-§4 semantic coverage: `133/133 PASS`.
- R16 core semantic/regression suite: `139/139 PASS`.
- R16 final cross-bundle synchronization gate: `147/147 PASS` (historical baseline before the R17 CaseID-source change).
- R17 CaseID-source change: contextual/textual semantic validation completed.
- R18 page/simulation projection change: static semantic/schema validation completed.
- R19 target compiler migration: Standard/MultiInput compiler mappings moved into selected JsonSchema extensions; target KnowledgeArea removed from runtime; static semantic/schema validation completed.

This validation does not prove live Pega behavior.

## Exact next action

Deploy R19 and replay the reported `PrepareCustomerCommunication`-style Data Page case. Verify `CustomerCommunication` is in Projection `pages`/Candidate `pyPagesAndClasses`, simulation setup source carries the resolved class, nested page items retain `pxObjClass`, and Candidate `pySetupPageName` is exactly `PrimaryPage`. Keep the R17 exact CaseID propagation check in the same trace.
