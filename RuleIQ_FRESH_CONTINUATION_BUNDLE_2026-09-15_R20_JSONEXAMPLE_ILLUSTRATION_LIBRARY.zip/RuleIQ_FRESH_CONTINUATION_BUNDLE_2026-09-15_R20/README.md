# RuleIQ — Fresh Continuation Bundle

This is a deliberately clean single-version continuation package.

## Contents

- `00_START_HERE/` — authoritative current status, new-session instruction, R20 session handoff, and historical validation record.
- `01_PROMPTS/` — current Scenario Author, Unit Test Generator, Validator prompts.
- `02_KNOWLEDGE_AREAS/` — retained semantic/reference Knowledge Areas only; target Rule-Test-Unit-Case compiler mappings live in schemas.
- `03_TARGET_CONTRACTS/` — Standard/MultiInput schemas including complete `x-ruleiq-compilerMappings` target compiler authority, plus `Template + Examples[]` target illustration libraries.
- `04_TOOLS/` — current single-record Memory contract, Pega implementation specification, and required runtime-tool list for authoritative Memory-state inter-agent handoffs.

No historical prompts, old project versions, validation scripts, hashes/checksums, or offline fixtures are included. `VALIDATION_HISTORY.md` is retained only as explicitly non-authoritative historical context.
