# W3GL Semantic Determinism Repair

Status: STAGED_OFFLINE / READY_FOR_LIVE_ACCEPTANCE

Production files changed: 3

1. `01_PROMPTS/ScenarioAuthor_SystemPrompt.txt`
2. `02_KNOWLEDGE_AREAS/Rule-Declare-DecisionTable_KnowledgeArea_REFERENCE.txt`
3. `02_KNOWLEDGE_AREAS/Rule-Obj-Model_KnowledgeArea_REFERENCE.txt`

## Repairs

- Decision Table DTM is now a complete normalized executable snapshot with closed cell/action roles; DTE/DTA use DTM only.
- IR performs a mechanical source-unit -> PROD/EDGEIR bijection check, preventing missing `ROM.UPDATE_PAGE` producers.
- DWL/KT.39 occurrence census is syntactic and closed rather than relevance-selected.
- ORACLE page context is mechanical: base page/class and untouched relative target are frozen separately from descendant `applyToClass`.
- Page assertions use generic semantic-target preservation: the asserted Page path must equal the exact frozen OUTPUT relative target; no child/property path may stand in for another semantic target. Base-page self-presence is omitted as `unsupported_page_self_presence` because current v3 Page grammar requires a nonempty path. No property-name-specific exception exists.
- Rule-Obj-Model scenario construction uses immutable reference outcome vectors and one-coordinate mutations; diagonal substitutes are rejected.
- Scenario names are mechanically `Scenario S<n>` and therefore target-length safe.
- DECISION rows use one canonical JSON envelope instead of fragile multi-pipe semantic fields.
- Invalid local phase drafts are discarded before MemoryTemp commit.
- W3GK RuleCrawler wire hotfix is preserved.

## Validation

Targeted static + fixture suite: **72/72 PASS**.

Covered live failure modes include:
- DT condition/action role confusion (`August` used as a condition);
- unmatched-row DTA;
- missing UPDATE_PAGE producer;
- `CustomerCommunication.Addresses(1).pyCity` collapsing to `.pyCity`;
- descendant item class replacing base-page class;
- diagonal scenario `[T2,T4,T6]`;
- scenario names over 50 characters;
- malformed DECISION serialization;
- `Page Exists` represented through an unrelated property path.

Generator and Validator are unchanged. The remaining four Knowledge Areas are unchanged.

Live acceptance should repeat identical RUTs at least 3x and compare DWL/DEPIR, IR PROD/EDGEIR, WITNESS vectors, DTM/DTE/DTA, ORACLE contexts, DECIDE assertions and Generator status byte-for-byte where applicable.
