# W3GP Change Summary

## Evidence basis
The change was derived from the live uploaded W3GO transfer bundle and the live `WAVE3GO0010.zip` Pega runs. The failing behavior showed a downstream append source being materialized even when its upstream produced index had not been executed consistently. The architectural fix below is based on that evidence plus deterministic compiler logic; it is not a new Pega execution result.

## Production footprint
Only `ScenarioAuthor_SystemPrompt.txt` changes. Generator, Validator, target JSON Schema/Example, and all Knowledge Areas remain byte-identical to W3GO.

## Algorithmic changes
1. `VECTOR_SET` is fully constructed and ordered from MAP control topology before seed or carrier work. Carrier feasibility and outputs cannot reorder or rewrite it.
2. Runtime execution is a state interpreter. It materializes pre-RUT state from CARRIER, traverses executable source in canonical order, reads operands from current state, evaluates the current operation/dependency, then applies that operation's transition.
3. Produced values do not exist until their producer transition executes. A downstream consumer can therefore use only the current state, never a desired vector/output or later branch.
4. `EXECUTE` accepts only `CARRIER`. VECTOR is deliberately not an execution argument; actual control outcomes are computed by execution and compared to the frozen target vector only when selecting a carrier.
5. Helper/function execution is contract-driven. The closed fetched/known contract defines traversal, predicate invocation, stopping, return/index/sentinel/null/error semantics, and side effects. WITNESS contains no dispatch by function name.
6. PATH and EFFECT are projections of the same executed transition stream. EFFECT cannot be inferred in a second pass from Scenario wording, expected assertions, later conditions, or a desired final state.
7. Context-bound helper discovery is generalized by contract-declared argument roles. The prompt no longer contains execution instructions for named page-list helper functions.

## Explicit non-changes
- No new hard-gate/validator barrier was introduced.
- STATIC_SCAN dependency semantics were not redesigned. Only named helper examples were generalized; no additional Property-order correctness mechanism was added.
- Page/Property assertion compiler logic was not changed.
- Page assertion physical contract remains `pyPropertyAbsolutePath = BASE_PAGE + relative page path`, with no `pyPageName` on the Page child.
