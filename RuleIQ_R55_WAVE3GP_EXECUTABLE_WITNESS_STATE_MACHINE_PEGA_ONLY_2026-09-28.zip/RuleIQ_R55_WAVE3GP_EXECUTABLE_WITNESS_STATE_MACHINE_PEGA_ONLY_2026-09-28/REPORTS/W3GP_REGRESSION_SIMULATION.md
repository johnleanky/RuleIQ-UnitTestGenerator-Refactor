# W3GP Targeted Regression Simulation

This is an offline deterministic fixture simulation of the new algorithm, not a live Pega run. The collection-call contract used by the fixture comes from the live RuleCrawler evidence: traverse to the first predicate-satisfying entry, return its 1-based index, and return `-1` when no entry matches. The new ScenarioAuthor does not identify or dispatch that behavior by function name; it consumes the closed contract.

| Fixture | Actual vector | AddressIndex | Appended item | ExitCode |
|---|---|---:|---|---|
| both addresses Postal; second code `3512EK` | `T2,T3,T5` | `1` | first: Amsterdam / `1000AA` / Main St 12 | `STOP POSTAL CODE` |
| both addresses non-Postal; second code `3512EK` | `T2,T4,T5` | `-1` | none | `STOP POSTAL CODE` |
| both addresses Postal; second code `1111BB` | `T2,T3,T6` | `1` | first: Amsterdam / `1000AA` / Main St 12 | not set by stop branch |

The key regression is the middle row: postal-validity selection and the later second-address postal-code condition are independent coordinates. No special rule is needed to enforce that independence; source-order execution produces it mechanically.
