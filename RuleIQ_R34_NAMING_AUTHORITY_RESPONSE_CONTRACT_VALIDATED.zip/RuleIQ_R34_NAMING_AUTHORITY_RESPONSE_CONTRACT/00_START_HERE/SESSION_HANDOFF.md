# RuleIQ R34 — Session Handoff

## Authority

This R34 bundle is the only current project source of truth. `STATUS.md` is authoritative for active behavior. `VALIDATION_HISTORY.md` is historical/non-authoritative and must not override current prompts or status.

`TEXT_SEMANTIC_ONLY=true`: use direct textual/structural/semantic comparison only; do not use hashes, checksums or fingerprints as acceptance evidence.


## Why R34 exists

Live `PXCONV-184014` exposed nondeterministic technical-name validation: Generator and Validator independently executed `CM-NAME-001`; Generator first emitted a 20-character RUT prefix while Validator recomputed 21 and returned `PF_RUT_CONTEXT_MISMATCH`. R34 makes `CM-NAME-001` Generator-only. ScenarioAuthor supplies semantic names, Candidate Scenario names copy them exactly, and Validator validates technical identity only through ordinary schema constraints plus candidate-internal `CF-IDENTITY-001`.

R34 also restores the ScenarioAuthor terminal envelope to exactly two fields: `AIAgentResponseStatus` and `AIAgentErrorResponseMessage`. No alias or additional field is legal. R33 Property-page context, Memory read, Generator aggregation, lifecycle, and all unrelated semantic behavior remain unchanged.



## Why R33 exists

R33 is a targeted contract cleanup over R32: unit-test rule names now include both RUT and Scenario (`TC_<RUT>_<Scenario>`), regular Property assertions carry the correct containing-page `pyPageName`, all agents use the real `GetAgentMemory` read interface with optional `SkipPayload`, and ScenarioAuthor processes recognized negative Generator outcomes best-effort instead of stopping at the first one. The Author's external response channel is strict JSON-only; any user-visible warning/error text is confined to `AIAgentErrorResponseMessage`. No testability status or new lifecycle status was introduced.


## Why R31 exists

Stored live conversation `PXCONV-163039` exposed an Author materialization gap unrelated to Generator: both persisted Standard Projections claimed `D_CustomerTestRef` simulation in inputs/simulation narrative and reasoning, but neither payload contained physical `simulations[]`. R30 semantic DP obligations and DPA could therefore be internally correct while §6.8 still accepted a physically missing simulation because `simulations` was unconditionally optional and the Standard shape example omitted it.

R31 makes Scenario simulation census deterministic and compact. Final RX `dpRefs` derive `REQUIRED_SIMS`: evaluated or unknown access requires simulation; a false guard still requires the Data Page used to obtain false; a skipped guarded action is irrelevant; exclusion requires every possible occurrence to be terminally `notEvaluated`. Each REQUIRED_SIM freezes one SIM. Projection materialization computes `REQSIM` from those frozen SIMs and `ACTSIM` from physical `simulations[]`; exact ordered equality is mandatory before PREPARE_ALL can pass. `simulations` is absent iff REQSIM is empty. `simulationsNarrative` is derived only from physical simulations. The external simulation object remains `{runtimeClass,rule,setupPages}`; no DP_SIG wire field is added.

R31 changes only ScenarioAuthor from R30. Static validation is 28/28 PASS; 12/12 adversarial cases PASS; the two defective PXCONV-163039 payloads are rejected; 6/6 target examples remain schema-valid. ScenarioAuthor grows 9,332 -> 9,524 words (+192, ~2.1%). Live Pega/Claude Opus 4.8 replay is pending.

## Why R30 exists

Live R29 replay showed that source-holder preservation was still downstream of the real failure: Opus could over-create crawl work from root `RuleJSON.pxRuleReferences[]`, making the root holder look internally consistent. The earlier stable prompt used an occurrence-driven flow instead. R30 restores that causal model in compact form: executable scan evidence creates each D occurrence, the occurrence carries immutable `src.holder`, and that source directly becomes `pyItemRuleId`. `pxRuleReferences[]` is used as identity/materialization lookup for already discovered work.

R30 removes active `CANDIDATE_HOLDERS` and `REQ=holder::KEY` planning, returns OUT/ACT to KEY census, and adds two short canonical examples for transitive crawl and metadata lookup. The exact RUF four-key shape from R29 is retained. ScenarioAuthor shrinks from 9,502 to 9,332 words. Focused static/adversarial validation is 25/25 PASS; all 6 target examples remain schema-valid. Live Pega/Claude Opus 4.8 replay is pending.

## Why R29 exists

Live R28 replay showed that R28 fixed only post-selection holder preservation. ScenarioAuthor still said effectively “select one valid holder” without defining validity from source provenance, so Opus could choose the RUT for every KEY and then pass the new OUT/ACT self-consistency gate. R29 freezes `SCAN_HOLDER` from each scanned RuleJSON/tool correlation, stores it in every D source occurrence, derives `CANDIDATE_HOLDERS(KEY)` only from those occurrences, and forbids selection/retry outside that list.

The same live trace also exposed a separate intermittent request-shape defect: RUF references were emitted with `"pxRuleClassName":""`. R29 makes the physical reference a closed discriminated shape before ACT census: non-RUF has exactly five keys including nonempty `pxRuleClassName`; RUF has exactly four keys and `pxRuleClassName` must be absent, with empty/null still invalid. The RUF KnowledgeArea repeats the same exact contract. A one-holder payload is not automatically invalid: it remains valid when all emitted dependencies actually have that holder as source provenance.

Static/adversarial validation rejects all-RUT collapse when nested KEYs have other source holders, wrong-holder, missing-key, extra-key, and observed empty-class RUF shapes; valid source grouping and valid four-key RUF pass. All 6 target examples remain schema-valid. ScenarioAuthor is 9,502 words; RUF KA is 888 words. Live Pega/Claude R29 replay remains pending.

## Why R28 exists

R28 fixes an intermittent ScenarioAuthor RuleCrawler request defect: R27 audited only flattened dependency KEYs, so dependencies from different selected holders could collapse under one `pyItemRuleId` and still pass `OUT==ACT`. R28 freezes `REQ=holder::KEY` after holder selection, groups physical `InterestedRules[]` only from those frozen pairs, and reconstructs ACT from actual `pyItemRuleId::KEY(reference)`. The external RuleCrawler payload is unchanged. ScenarioAuthor is 9,283 words (+71 from R27); Generator, Validator, KnowledgeAreas, schemas, examples and tool contracts are unchanged. Focused static validation is 17/17 PASS; live Pega replay remains pending.

## Why R27 exists

R27 closes the only defect found by the explicit post-R26 31-stage audit. R26 used the ambiguous phrase `rebuild/localize missing/inconsistent/UNKNOWN evidence`; R27 makes the routing deterministic without changing DT semantics: `missing/inconsistent→invalidate/rebuild; terminal UNKNOWN→localize`. This is the only runtime change from R26. ScenarioAuthor remains 9,212 words; all KnowledgeAreas, Generator, Validator, schemas and examples are unchanged from R26. Static audit is now 31/31 PASS; fresh live Pega replay remains pending.

## Why R26 exists

R26 resolves the semantic KnowledgeArea ownership conflicts identified in R24/R25 while preserving the established Author -> Projection -> Generator -> Validator architecture. Model KA now stops at PAGE/source/assertion semantics; Decision Table KA stops at DTM/DTA/DTE plus caller setup/ASSERT-OMIT obligations and performs its final audit before Projection; RUF KRUF.0 now separates caller orchestration from RUF contract ownership. ScenarioAuthor changes only one wording fragment (`repair` -> `rebuild/localize`); Generator, Validator, schemas/examples, Data Page KA and When KA are unchanged.

Static R26 validation: 65/65 PASS; 6/6 target examples schema-valid; changed-runtime word proxy 18,039 -> 17,535 (-504). Fresh live Pega replay is still pending.

## Why R25 exists

R25 adds a verbatim `Rule-Utility-Function_KnowledgeArea_REFERENCE.txt` on top of R24. No runtime prompt/schema/example behavior changes. Compatibility audit confirms KRUF.1/KRUF.4 identity/request shape, KRUF.5 concrete fetched-contract authority, KRUF.6-8 transitive dependencies, KRUF.10 known helpers, KRUF.11 nested evaluation, KRUF.12 unknown-return behavior, and KRUF.13 closure gate align with the current ScenarioAuthor RUF flow. Prompt duplication of some KRUF request-shape details is retained unchanged and recorded only as a future-drift risk.

## Why R24 exists

R24 added verbatim Rule-Obj-Model, Rule-Declare-Pages and Rule-Declare-DecisionTable reference KnowledgeAreas without changing runtime prompts. Those historical conflicts are resolved by R26; the R24 note is retained only as historical context.

## Why R23 exists

R23 preserves the R22 fix for nondeterministic assertion page ownership exposed by live `PXCONV-160066` and adds Scenario UI metadata plus deterministic required RuleCode metadata/constants. R22 originally fixed: ScenarioAuthor correctly traced writes under `UPDATE_PAGE CustomerCommunication` but materialized a List assertion as primary-relative `.Addresses` and omitted `Projection.pages.CustomerCommunication`. The cause was a conflicting global leading-dot rule plus incomplete page-preservation rules for non-Property assertion kinds. R22 makes final CTX/APB provenance authoritative for every non-Param assertion and requires exact non-primary `page` + `Projection.pages` class binding. R23 additionally extends Projection Scenario metadata, Generator/Validator pass-through fidelity, target schemas/examples, `RuleCode.pyDescription`, and required target constants; R22 page-provenance semantics remain unchanged.

## Why R21 exists

R21 corrects an unintended R20 scope regression: R20 replaced the existing coverage-rich canonical examples while adding simulation illustrations. R21 restores the exact R19 Standard and MultInpComb candidates as `Examples[0]` inside the new envelope, while retaining the R20 synthetic Page-DP and List-DP candidates as `Examples[1]` and `Examples[2]`. Generator/Validator illustration authority rules are unchanged.

## Why R20 exists

R20 introduced the `{Template,Examples[]}` illustration-library format and added causally coupled Page/List Data Page examples. R21 preserves that format but restores the pre-existing coverage-rich examples that R20 should not have removed.

## Why R18 exists

R18 fixes a projection/materialization regression exposed by live Data Page simulation: ScenarioAuthor knew runtime/page classes but dropped them at the Projection boundary, reused a runtime page name as simulation `pySetupPageName`, and omitted that runtime page from `pyPagesAndClasses` input. R18 carries simulation setup class explicitly, preserves nested resolved page classes, requires runtime named pages in Projection `pages`, and makes Generator emit fixed `PrimaryPage`.

## Why R17 exists

R17 is a narrow CaseID source-of-truth correction on top of R16. Live behavior showed two plausible identifiers were visible to ScenarioAuthor: bare `GetCaseData.pyID` and full `application_context.caseID`. The Author now uses only exact `application_context.caseID` for Memory/transport CaseID. Generator and Validator continue to consume exact `Invocation.CaseID`. No new transport field or Memory Tool contract is introduced.

## Why R16 exists

R16 was introduced after three live problems were reported after the previous refactor:

1. Mixed-case Pega case identity such as `GenUT-91051` was being propagated as `GENUT-91051` in Memory/Agent calls.
2. UnitTestGenerator emitted a long response duplicating state already persisted through Agent Memory, although ScenarioAuthor ignores that response.
3. ScenarioAuthor appeared to stop after the first downstream generation, and it was impossible to tell whether only one physical scenario had been created or whether later scenarios existed but had never reached UnitTestGenerator.

R16 addresses these without changing Scenario semantics, dependency closure, target serialization or Validator fidelity logic.

## Active inherited + R28 decisions

### 1. Exact case identity

`CASE_ID_RAW` is opaque case-sensitive text.

- ScenarioAuthor: `CASE_ID_RAW := exact application_context.caseID`.
- Generator: `CASE_ID_RAW := exact Invocation.CaseID`.
- Validator: `CASE_ID_RAW := exact Invocation.CaseID`.

Every Write/Update Memory `pxCaseID`, delegated Agent Invocation `CaseID`, Validator `JsonValidationTool.CaseID`, and returned GetAgentMemory `CaseID` correlation must use the exact lexical value without normalization.

`GetCaseData.pyID` is not a Memory/transport CaseID source. If a live tool call already contains the exact `application_context.caseID` but Pega later stores/returns a different value, that is a Pega implementation/mapping defect outside prompt control.

### 2. Projection page/simulation materialization

- `Primary.*` resolves from ROOT; leading-dot paths resolve through active rule-defined runtime CTX and fall back to ROOT only when no non-root CTX applies.
- Every non-Param assertion derives its base page from final CTX/APB before kind selection; kind conversion cannot change that owner. Primary assertions omit `page`; non-primary assertions require exact `page` and matching grounded `Projection.pages` class binding.
- Frozen non-primary runtime pages used by setup/action/assertion/CTX are emitted as `Projection.pages[page]=resolvedClass`.
- Data Page simulation setup source is `{class,data}`; nested resolved Page/PageList/PageGroup instances carry `pxObjClass` in `data`.
- Generator emits `pySetupPageName="PrimaryPage"` and `pyPageDetails.pxObjClass=class`; nested `data` is preserved.


### 3. Schema-owned target compiler

- Executable Generator/Validator acquire only selected JsonSchema + JsonExample.
- `x-ruleiq-compilerMappings` remains shared schema metadata, but every mapping declares `consumers`. `CM-NAME-001` lists only `UnitTestGenerator`; `CM-EXEC-001` and the mode mapping list Generator + Validator.
- `JsonExample.Template` alone owns `pyRuleSet` and `pyRuleSetVersion`.
- `JsonExample.Examples[]` is non-authoritative illustration only; both Standard and MultInpComb libraries contain no-simulation, Page DP, and List DP examples.
- Target `Rule-Test-Unit-Case*_KnowledgeArea` artifacts are removed from active runtime.

### 4. Generator response

Generator returns exactly `{"status":"ACK"}` after processing. The response contains no status or diagnostics and is non-authoritative.

- Generator reads Validator outcome from exact Candidate Memory.
- ScenarioAuthor reads Generator outcome from exact Projection Memory.

Do not reintroduce `GeneratorRunReport`, nested response parsing, or response-text status handling.

### 5. Projection-first orchestration

The old interleaved loop is superseded.

Current order:

```text
I -> W -> F -> B -> A
require A=PASS

PREPARE_ALL
  materialize + self-validate every UnitTestProjectionV3
  require exact census with frozen physical groups

PERSIST_ALL
  WriteMemory every prepared Projection in frozen order
  freeze PROJECTION_QUEUE(groupId, payload, GUID, PENDING)
  require exact census + distinct nonempty GUIDs
  any write/correlation/census failure => zero Generator calls

GENERATE_ALL
  take first PENDING queue row
  call UnitTestGenerator exactly once
  ignore the non-authoritative response text
  fresh-read exact Projection GUID with SkipPayload=true
  TERMINAL_PASS => mark DONE, success++
  recognized SEMANTIC_REJECT/HUMAN terminal => mark DONE, negative++, continue
  malformed/tool/correlation state => fail immediately

COMPLETE
  all rows DONE; success > 0 => Completed; all recognized negative => Failed
```

The persisted `UnitTestProjectionV3` rows themselves are the materialized evidence of the complete frozen physical-group set. No separate `ScenarioPlanV1` or `ScenarioName` Memory field was added.

## What remains unchanged from R22

Do not reopen these unless new evidence requires it:

- ScenarioAuthor dependency/DWL semantics.
- Scenario Compiler `I -> W -> F -> B -> A` semantics.
- Physical grouping semantics.
- Validator source/candidate fidelity ownership.
- Candidate repair routing and `ProcessingFeedback` grammar.
- Target naming `CM-NAME-001`: Generator alone creates technical `TC_<RUT>_<Scenario>`; candidate Scenario names copy Projection semantic names exactly; Validator does not recompute technical naming.
- Source-side `singlePage` remains absent; physical `pyIsSinglePageImplementation` is target-owned.

## Runtime implementation boundary

Files under `04_TOOLS/*.md` are specifications for the Pega implementation; they are not runtime artifacts that Pega reads automatically.

For the next live test, do **not** change Pega Memory implementation first. Capture the actual boundary behavior:

1. `application_context.caseID` and, for contrast only, `GetCaseData.pyID`.
2. Author tool-call `pxCaseID` and Generator Invocation `CaseID`.
3. Generator tool-call `pxCaseID` and Validator Invocation `CaseID`.
4. Validator `JsonValidationTool.CaseID` and Memory arguments.
5. persisted/returned Memory case value.

Only if the prompt/tool-call argument already equals exact `application_context.caseID` but Pega changes it after the call boundary should the Pega implementation be modified.

## Expected live multi-group evidence

For a successful run with N frozen physical groups:

- N Projection rows exist before the first Generator invocation.
- first Generator call occurs only after the Nth Projection write succeeds.
- Generator invocation order matches frozen group order exactly.
- each persisted Projection is invoked at most once.
- Generator response is exactly `ACK`.
- ScenarioAuthor ignores response text and fresh-reads the exact Projection GUID.
- successful Projection rows end `Passed + OK + ProcessingFeedback=""`; recognized negative Projection rows may end `Failed + SEMANTIC_REJECT|HUMAN + nonempty feedback`.
- final Author response occurs only after all N queue rows are DONE when all Generator outcomes are recognized.

Failure expectations:

- any Projection write failure => no Generator calls at all;
- a recognized negative Generator result on group k does not block groups k+1..N; malformed/tool/correlation failures remain fail-closed;
- any CaseID mismatch is fail-closed and must be traced to the layer that changed the exact `application_context.caseID` value.

## Validation status

- R15 final regression: `172/172 PASS`.
- R15 ScenarioAuthor §2-§4 semantic coverage: `133/133 PASS`.
- R16 core semantic/regression suite: `139/139 PASS`.
- R16 final cross-bundle synchronization gate: `147/147 PASS` (historical baseline before the R17 CaseID-source change).
- R17 CaseID-source change: contextual/textual semantic validation completed.
- R18 page/simulation projection change: static semantic/schema validation completed.
- R19 target compiler migration: Standard/MultiInput compiler mappings moved into selected JsonSchema extensions; target KnowledgeArea removed from runtime; static semantic/schema validation completed.
- R20/R21 JsonExample library migration/restoration: all 6 candidates schema-valid; coverage-rich Examples[0] restored.
- R22 assertion-page provenance: static semantic A-H regression and supplied live PXCONV-160066 acceptance analysis completed; fresh live Pega replay remains pending.
- R26 KnowledgeArea boundary cleanup: 65/65 static architecture/semantic checks PASS; a later explicit 31-stage audit found one wording precision issue.
- R27 audit closure: 31/31 planned stages PASS; runtime delta from R26 is one deterministic ScenarioAuthor wording replacement; 6/6 examples schema-valid.
- R28 holder-provenance repair: 17/17 focused static checks PASS; holder-collapse, wrong-holder, missing and extra-reference adversarial cases fail the new preCall identity gate as intended.

This validation does not prove live Pega behavior.

## Exact next action

Deploy R31 and replay `PrepareCustomerCommunication`. Capture final RX `dpRefs`/evalState, REQUIRED_SIMS, frozen SIM census and persisted Projection `simulations[]` for each physical group. A Data Page evaluated by a false guard must remain simulated even when its action is skipped; a Data Page terminally proven `notEvaluated` must not be simulated. Require simulationsNarrative to match only the physical set. Also retain R30 RuleCrawler scan/holder/shape checks as regression evidence, then replay one Decision Table case and one Model PAGE-parameter case.
