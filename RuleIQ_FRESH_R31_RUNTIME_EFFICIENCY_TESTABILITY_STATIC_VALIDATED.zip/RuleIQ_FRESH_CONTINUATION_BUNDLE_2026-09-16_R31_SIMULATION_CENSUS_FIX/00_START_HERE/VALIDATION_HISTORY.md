# R30 validation — 2026-09-16

- Live R29 behavior plus comparison to the earlier stable Main Agent prompt identified the earlier root boundary: crawl work must be created by executable scan occurrences, while raw `RuleJSON.pxRuleReferences[]` serves identity/materialization after discovery.
- Removed active `CANDIDATE_HOLDERS` and `REQ=holder::KEY`; each READY KEY now uses its first eligible D occurrence and `pyItemRuleId=src.holder`. OUT/ACT are KEY-based again with a separate source-holder equality check.
- Added compact positive examples for transitive source propagation and raw-metadata subset behavior.
- RUF exact four-key materialization remains; RUF KA terminology aligned to chosen READY occurrence.
- 25/25 focused static/adversarial checks PASS; 6/6 Standard/MultiInput JsonExamples remain schema-valid.
- ScenarioAuthor word proxy: 9,502 -> 9,332 (-170, ~1.8%); RUF KA: 888 -> 892 (+4). Generator, Validator, other four KAs, target contracts and tools unchanged.
- Live Pega/Claude Opus 4.8 replay remains pending.

---

# R29 validation — 2026-09-16

- Live R28 replay exposed two gaps: holder selection lacked a source-provenance definition, and RUF sometimes inherited the generic five-field shape with `pxRuleClassName:""`.
- ScenarioAuthor now freezes `SCAN_HOLDER`, records immutable D `src.holder`, derives `CANDIDATE_HOLDERS(KEY)` only from READY occurrences, and rejects any physical holder outside that provenance set.
- RuleCrawler reference rendering is closed/discriminated: exact five-key non-RUF; exact four-key RUF; RUF `pxRuleClassName` is invalid even empty/null. Physical shape validation precedes ACT census.
- RUF KnowledgeArea KRUF.1/KRUF.4 now states the same exact four-key contract and immutable invocation-holder provenance.
- In-memory adversarial checks reject all-RUT collapse for nested-source KEYs, wrong holder, missing key, and the observed empty-class RUF; valid provenance grouping and four-key RUF pass.
- 6/6 Standard/MultiInput JsonExample candidates validate against unchanged Draft-2020-12 schemas. Generator, Validator, other four semantic KAs, schemas/examples and tool contracts are unchanged.
- ScenarioAuthor word proxy: 9,283 -> 9,502 (+219, ~2.4%); RUF KA: 874 -> 888 (+14). No fixtures or hash/checksum/fingerprint acceptance gates were added.
- Fresh live Pega/Claude R29 replay remains pending; a single-holder request is allowed when all emitted KEYs truly share that source holder.

---

# R28 validation — 2026-09-16

- Fixed ScenarioAuthor RuleCrawler holder-provenance loss without changing the external `InterestedRules[]` wire contract.
- Canonical post-selection request identity is now `REQ=holder::KEY`; OUT is the intended REQ list and ACT is independently reconstructed from physical `pyItemRuleId::KEY(reference)`.
- Physical materialization may only group frozen REQs; holder fallback/reselection is forbidden. Response correlation remains KEY-based after preCall proves holder correctness.
- Focused direct textual/semantic checks: 17/17 PASS, including valid grouping PASS and holder-collapse/wrong-holder/missing/extra adversarial cases rejected.
- ScenarioAuthor word proxy: 9,212 -> 9,283 (+71, ~0.8%). Generator, Validator, KnowledgeAreas, schemas, examples and tool contracts unchanged.
- No fixtures or hash/checksum/fingerprint acceptance gates were introduced.
- Fresh live Pega/Claude R28 replay remains pending.

---

# R27 validation — 2026-09-16

- Closed the only two PARTIAL results from the explicit R26 31-stage audit; both were caused by one ambiguous ScenarioAuthor wording.
- Runtime delta from R26: exactly one ScenarioAuthor phrase, now `missing/inconsistent→invalidate/rebuild; terminal UNKNOWN→localize`.
- ScenarioAuthor word proxy remains 9,212; all five KnowledgeAreas are byte-identical to R26.
- Generator, Validator, both target schemas/examples, Data Page KA and When KA unchanged.
- Full planned-stage audit: 31/31 PASS (static/textual/structural).
- 6/6 Standard/MultiInput JsonExample candidates validate against unchanged Draft-2020-12 schemas.
- Fresh live Pega R27 replay remains pending.

---

# R26 validation — 2026-09-16

- Semantic KnowledgeArea boundary cleanup implemented only in Model KT.11/KT.12/KT.26/KT.29, Decision Table KDT.6/KDT.11/KDT.12, RUF KRUF.0, plus one ScenarioAuthor wording replacement.
- 65/65 direct textual/structural/semantic checks PASS.
- 6/6 Standard/MultiInput JsonExample candidates validate against unchanged Draft-2020-12 schemas.
- Generator, Validator, both schemas/examples, Rule-Declare-Pages KA and Rule-Obj-When KA unchanged from R25.
- R22 assertion-page provenance retained.
- Changed-runtime word proxy reduced 18,039 -> 17,535 (-504); ScenarioAuthor remains 9,212.
- No new fields, fixtures, tools or target compiler behavior.
- Fresh live Pega R26 replay remains pending.

---

## R23 — Selective metadata merge over R22 (2026-09-16)

- Preserved R22 active-CTX / `ASSERT_PAGE_CONTEXT` / non-primary `Projection.pages` provenance rules unchanged.
- Added Author-owned Scenario `description`, `type`, `inputsNarrative`, `assertionsNarrative`, `simulationsNarrative`; Generator copies them exactly and Validator checks exact fidelity.
- Added schema-owned `RuleCode.pyDescription = LF-join(scenarios[].description)` and required constants `pyIsInactive="false"`, `pyCleanUpTestData="true"`, `pyTypeOfSetupPageSelection="CUSTOMPAGES"`.
- Standard and MultiInput schemas are Draft-2020-12 valid; all six merged JsonExample candidates validate; removing only the new metadata fields from merged examples reproduces the R22 examples exactly.
- Static merge validation only; fresh live Pega replay remains pending.

# RuleIQ Unit Test Pipeline — Validation / Refactoring History

> Historical reference only. This file is **not** the active runtime contract. Current authoritative state is in `STATUS.md` and the active prompts/contracts. Historical observations may contain superseded field names or transports (for example old response `pxCaseID` or ValidatorReport-era behavior) and must not override the current bundle.

## R22 — Assertion runtime-page provenance lock (2026-09-15)

- Replaced the conflicting global `Leading-dot/Primary.* -> ROOT` rule: `Primary.*` remains ROOT; leading-dot paths now follow active rule-defined runtime CTX and fall back to ROOT only without non-root CTX.
- Added one `ASSERT_PAGE_CONTEXT` owner for Property/Page/List/ResultCount: final CTX/APB fixes assertion base; non-primary base requires exact `page` and grounded `Projection.pages` binding; kind conversion cannot change owner.
- Strengthened pre-projection validation to compare assertion materialization against frozen CTX/APB provenance and reject ROOT rebasing repair.
- Supplied live `PXCONV-160066` analysis confirms the former G002 defect (`List(.Addresses)` with no page/pages) and the deterministic R22 expectation `page=CustomerCommunication`, `pages.CustomerCommunication=Data-Customer`; Param assertion and Data Page simulation are unaffected.
- Static A-H context regression PASS. Generator, Validator, both production schemas, and both JsonExample libraries are direct-text unchanged from R21. ScenarioAuthor word proxy: 8,934 -> 9,095 (+161). Fresh live Pega replay remains pending.

## R21 — Restore coverage-rich examples in illustration envelope (2026-09-15)

- Restored the exact R19 Standard candidate as `Rule-Test-Unit-Case_JsonExample.Examples[0]`; comparator/assertion breadth is preserved.
- Restored the exact R19 MultInpComb candidate as `Rule-Test-Unit-Case_MultInpComb-JsonExample.Examples[0]`.
- Retained R20 synthetic Page-DP and List-DP candidates as `Examples[1]` and `Examples[2]`.
- No prompt, production schema, ScenarioAuthor semantics, Generator compiler mapping, or Validator authority change.
- Validation: all 6 examples pass their selected Draft-2020-12 schema; restored Standard comparator inventory includes `Contains`, `Exists`, `Not exists`, `Is Empty`, `Is True`, `Is False`, `Starts With`, error-state comparators, `Is Greater Than`, and `Is Equals To`; MultInpComb row signatures/results remain valid.


# RuleIQ Unit Test Pipeline — Current Status

**Bundle date:** 2026-09-15  
**Authority:** this bundle contains the only current project version. No superseded prompts, historical plans, hashes/checksums, or regression fixtures are included.

## Current architecture

- **Scenario Author** owns RUT semantics, dependency closure, Pega casting/type semantics, scenario construction/grouping, assertions/simulations, and `UnitTestProjectionV3`. It consumes Generator outcome only from the exact Projection Memory row after Generator returns.
- **Unit Test Generator** deterministically compiles `UnitTestProjectionV3 -> UnitTestCandidate`, owns Candidate repair/retry orchestration, consumes Validator outcome only from exact Candidate Memory state, and writes terminal Generator outcome only to the exact source Projection lifecycle fields.
- **Validator** independently reads Projection + Candidate, checks schema/fidelity/target invariants without redefining Author semantics, and is the sole writer of Candidate validation lifecycle state.
- Delegated Agent assistant responses are non-authoritative transport noise at both inter-agent boundaries; `pyStatusValue + RouterKey + ProcessingFeedback` on exact Memory rows are authoritative.

## Current execution order

```text
Global dependency closure + semantic execution
-> I -> W -> F
-> freeze complete physical group set
-> B -> A, require A=PASS
-> for each frozen physical group in order:
     Author materializes + self-validates one Projection
     -> WriteMemory(Projection; lifecycle empty)
     -> invoke Generator once; ignore Generator assistant response
        -> Generator reads exact Projection
        -> compiles + WriteMemory(Candidate; lifecycle empty)
        -> invoke Validator; ignore Validator assistant response
           -> Validator validates exact Projection + Candidate
           -> UpdateMemory(Candidate status/router/ProcessingFeedback)
        -> Generator fresh GetMemory(exact Candidate GUID)
        -> repair/new Candidate loop if GENERATOR_REPAIR
        -> UpdateMemory(exact Projection terminal status/router/ProcessingFeedback)
     -> Author fresh GetMemory(exact Projection GUID)
     -> next group only on Passed + OK + ProcessingFeedback=""
```

Dependencies are resolved globally before Projection processing. Reused dependencies should therefore reuse already resolved evidence rather than being re-crawled per Projection. Parameterized Data Page invocations may still have distinct normalized invocation semantics even when the rule definition is reused.

After the first successful Projection `WriteMemory`, any need for semantic regrouping/reinterpretation terminates that Author run; already persisted artifacts remain immutable.

## Current contracts

- Memory tools are strictly single-record: `WriteMemory`, `GetMemory`, `UpdateMemory`. Input case argument remains `pxCaseID`; all Memory success responses use `CaseID`.
- `UpdateMemory` atomically updates only `pyStatusValue`, router state, `ProcessingFeedback`, and implementation-owned timestamp.
- `ProcessingFeedback` is exact Text: success clears it to `""`; failed/non-OK state requires nonempty feedback; Validator multi-issue feedback uses one item per LF line.
- `pyPayload`, identity, type, group and case ownership are immutable after create.
- Candidate lifecycle owner = Validator; consumer = Generator. Projection terminal lifecycle owner = Generator; consumer = ScenarioAuthor.
- Generator/Validator share the Standard and MultiInput target contracts/Knowledge Areas in this bundle.
- Target examples are the current coverage-rich canonical examples and retain separator-free `TC_` Pascal-token naming from R8.

## Evidence boundary

Static/contract validation has been completed for the current design, including R14 lifecycle replay. Fresh live Pega redeployment/replay of the R9-R14 Memory-state handoff (including `ProcessingFeedback` and response `CaseID`) remains external evidence and must not be claimed as completed. Live KnowledgeTool deployment verification also remains external evidence where not separately confirmed.

---

## Pending Refactoring Plan — 2026-09-14

**Plan status:** `R0-R14 PASS (STATIC) / LIVE PEGA REDEPLOY-REPLAY PENDING`  
**Execution status:** R9-R14 implementation completed sequentially after explicit user approval; each stage passed its mandatory static gate before the next stage.  
**Analysis-mode flag:** `TEXT_SEMANTIC_ONLY=true`  
**Hashing prohibition:** when reading, comparing, validating, or tracing bundle files, do not compute or use SHA/SHA-1/SHA-2/SHA-256/SHA-512, MD5, CRC, checksums, content hashes, hash-derived fingerprints, or hash-based equality/provenance. File validation must be based on direct textual parsing plus semantic/structural comparison of the actual file contents. Filename, size, timestamps, or archive metadata may be used only for navigation and never as proof of semantic equality.  
**Scope rule:** each stage is atomic. The next stage may start only after the current stage's mandatory validation is recorded as `PASS`. A failed validation leaves the stage `BLOCKED`; do not compensate by changing a later stage.

### Refactoring tracker

| Stage | Scope | Status | Mandatory validation |
|---|---|---|---|
| R0 | Freeze observed runtime contracts and change surface | PASS | Evidence matrix complete; no implementation files changed |
| R1 | Synchronize JsonValidation/Memory runtime contracts to observed tool responses | PASS | Contract/prompt field census + response-shape tests PASS |
| R2 | Remove `singlePage` from `UnitTestProjectionV3` | PASS | Projection grammar/mapping/schema cross-check + executable fixtures PASS |
| R3 | Remove `physicalGroupKey` from `CM-NAME-001` only; retain `Gnnn` as correlation/group id | PASS | Naming determinism/length/uniqueness/correlation tests PASS |
| R4 | Correct `_DWLPlan` `OUT`/`ACT` materialization | PASS | Canonical-plan grammar + physical census tests PASS |
| R5 | Lock Validator KnowledgeTool scope; forbid RUT semantic KnowledgeAreas | PASS | Tool-call allowlist/matrix tests PASS |
| R6 | Structurally enforce `ValidatorReport` | PASS | Raw-JSON/schema/parser negative+positive tests PASS |
| R7 | Full cross-bundle consistency and end-to-end readiness validation | PASS | Static cross-contract suite PASS; live Pega trial remains explicit external evidence |
| R8 | Separator-free `TC_` naming for candidate unit-test and Scenario names | PASS | Pascal-token naming/schema/example/collision regression tests PASS |
| R9 | Synchronize Memory lifecycle contract: response `CaseID` + universal `ProcessingFeedback` | PASS | Memory success-shape fixtures, alias rejection, LF round-trip and parameter census PASS |
| R10 | Validator persists authoritative Candidate validation state through `UpdateMemory` | PASS | Validator state-write matrix + newline feedback fixtures PASS |
| R11 | Generator consumes Validator result only through fresh Candidate `GetMemory` | PASS | Prose-response-ignore + repair/terminal routing fixtures PASS |
| R12 | Generator reports terminal result to Author through Projection Memory state | PASS | Projection lifecycle handoff + Author fresh-read fixtures PASS |
| R13 | Remove obsolete ValidatorReport/GeneratorRunReport transport contracts | PASS | No active report-response dependency remains anywhere; obsolete schema deleted |
| R14 | Full cross-prompt/tool synchronization and end-to-end static replay | PASS | 88/88 synchronization + lifecycle replay checks PASS |

### R0 — Freeze observed runtime truth and exact change surface

**Goal:** prevent refactoring against remembered or idealized tool shapes.

1. Record the actual successful Memory responses observed in the supplied conversations as runtime facts:
   - Write: wrapper `MemoryToolResponse`, success field `IsSuccess`, plus observed `pxObjClass`, `pyGroup`, `pyGUID`, `pyType`.
   - Get: top-level `IsSuccess`, `pxCaseID`, `pyGroup`, `RouterKey`, `pyType`, `pyPayload`, `pyStatusValue`, `pyGUID`.
   - Update: wrapper `MemoryToolResponse`, `IsSuccess`, `pxObjClass`, `pyGUID`, `pyStatusValue`, `RouterKey`.
2. Record the observed successful JsonValidation response as runtime fact: `IsValid` + `message` (for example `JSON_VALID| ...`).
3. Do **not** invent unobserved failure fields/shapes. Any failure response not evidenced by the supplied traces is marked `UNVERIFIED_RUNTIME_SHAPE` and must be confirmed from Pega before a strict failure parser is finalized.
4. Build a change-surface matrix covering:
   - `01_PROMPTS/ScenarioAuthor_SystemPrompt.txt`
   - `01_PROMPTS/UnitTestGenerator_SystemPrompt.txt`
   - `01_PROMPTS/Validator_SystemPrompt.txt`
   - both target JSON schemas and examples
   - both target Knowledge Areas where mappings/examples reference affected fields
   - `04_TOOLS/Memory_GenAI_Tools_Contract.md`
   - `04_TOOLS/Memory_GenAI_Tools_Pega_Implementation_Spec.md`
   - `04_TOOLS/Required_Runtime_Tools.md`
   - this status/tracker.

**Mandatory validation R0:** evidence-to-file matrix has one owner for every changed concept; observed fields are distinguished from assumptions; implementation-file diff is empty except this planning section. All file comparison/evidence is produced under `TEXT_SEMANTIC_ONLY=true` from parsed text/content structure; no hash/checksum/fingerprint may be generated or used. Record `R0=PASS` before R1.


### R0 execution record — PASS — 2026-09-14

**Execution scope:** evidence freeze and change-surface mapping only. No prompt, schema, KnowledgeArea, example, or runtime-tool implementation file was changed in R0. `TEXT_SEMANTIC_ONLY=true` was used throughout; no hash/checksum/fingerprint was generated or used.

#### Observed runtime facts from the supplied conversations

These are direct observations, not inferred aliases:

| Tool operation | Observed successful response shape | Runtime-fact status |
|---|---|---|
| `WriteMemory` / `WriteAgentMemory` | top-level `MemoryToolResponse`; inside it `IsSuccess` observed as string `"true"`, plus `pxObjClass`, `pyGroup`, `pyGUID`, `pyType` | OBSERVED |
| `GetMemory` / `GetAgentMemory` | top-level `IsSuccess` observed as boolean `true`, plus `pxCaseID`, `pyGroup`, `RouterKey`, `pyType`, `pyPayload`, `pyStatusValue`, `pyGUID` | OBSERVED |
| `UpdateMemory` / `UpdateAgentMemory` | top-level `MemoryToolResponse`; inside it `IsSuccess` observed as string `"true"`, plus `pxObjClass`, `pyGUID`, `pyStatusValue`, `RouterKey` | OBSERVED |
| `JsonValidationTool` | top-level `IsValid` boolean plus `message` string; observed success message begins `JSON_VALID|` | OBSERVED |

Not observed in the supplied successful responses: canonical `success`, `errorCode`, `errorMessage`, `pyRouterKey`, JsonValidation `Success`, `ValidationMessage`, `ErrorCode`, or `ErrorMessage`. Their presence in current bundle contracts is therefore **not runtime evidence**.

**Failure-shape boundary:** no Memory/JsonValidation failure response shape in the supplied traces is sufficient to define a strict canonical failure parser. All such shapes remain `UNVERIFIED_RUNTIME_SHAPE` until confirmed from live Pega evidence. R1 must not invent them.

#### R0 change-surface / ownership matrix

| Changed concept | Runtime/factual authority | Bundle owner for the refactor | Required consumers / mirrors to update in later stage | Stage |
|---|---|---|---|---|
| Memory success response wrappers and field names | observed Pega Memory tool responses | `04_TOOLS/Memory_GenAI_Tools_Contract.md` | `Memory_GenAI_Tools_Pega_Implementation_Spec.md`; ScenarioAuthor/Generator/Validator caller checks; `Required_Runtime_Tools.md` | R1 |
| Memory failure response fields | live Pega failure response, not yet observed | `04_TOOLS/Memory_GenAI_Tools_Contract.md` may document only confirmed fields | implementation spec and caller failure handling only after evidence exists | R1 |
| JsonValidation success response shape | observed `JsonValidationTool` response | `04_TOOLS/Required_Runtime_Tools.md` records external-runtime contract boundary; `Validator_SystemPrompt.txt` owns consumption behavior | Validator schema-gate logic | R1 |
| JsonValidation failure response shape | live Pega failure response, not yet observed | `04_TOOLS/Required_Runtime_Tools.md` marks `UNVERIFIED_RUNTIME_SHAPE` | Validator must fail closed without invented field semantics until confirmed | R1 |
| `UnitTestProjectionV3.rut.singlePage` | no independent runtime fact; current bundle contract only | `01_PROMPTS/ScenarioAuthor_SystemPrompt.txt` owns Projection producer grammar | Generator source grammar/fidelity; Validator fidelity; Standard/MultiInput target mapping/Knowledge/examples where referenced | R2 |
| physical PegaUnit `pyIsSinglePageImplementation` | selected target contract | Standard/MultiInput target JsonSchema mapping/invariant for applicable RUT type | Generator target compilation; Validator target validation; Knowledge/examples as demonstrations only | R2 |
| `CM-NAME-001` deterministic test identity | selected target JsonSchema | `03_TARGET_CONTRACTS/Rule-Test-Unit-Case_JsonSchema.txt` and MultiInput counterpart, each owning its own target schema mapping | Generator and Validator consume mapping; target KnowledgeAreas/examples mirror/demonstrate it | R3 |
| `physicalGroupKey` / `Gnnn` correlation identity | Author physical-group order + Memory `pyGroup` correlation | `ScenarioAuthor_SystemPrompt.txt` for Projection/group creation | Generator/Validator correlation only after R3; target naming must not consume it | R3 |
| `_DWLPlan.OUT` and `_DWLPlan.ACT` semantics | ScenarioAuthor canonical DWL state and physically emitted request | `01_PROMPTS/ScenarioAuthor_SystemPrompt.txt` | every DWL example/request projection in the same prompt | R4 |
| Validator KnowledgeTool acquisition scope | Validator closed tool/acquisition contract | `01_PROMPTS/Validator_SystemPrompt.txt` | Generator target acquisition remains separate; ScenarioAuthor remains sole RUT-semantic KnowledgeArea consumer | R5 |
| `ValidatorReport` logical schema and issue/action catalog | Validator contract + Generator correlation requirements | R6 will introduce one machine-readable structural report contract as the authoritative boundary artifact | Validator output instructions and Generator parser/consumer become consumers of that structural contract | R6 |

#### Textual change-surface census frozen by R0

The current bundle was semantically scanned before implementation changes. The following affected files contain relevant current references and are therefore explicitly in-scope for later stages:

- `01_PROMPTS/ScenarioAuthor_SystemPrompt.txt` — Projection `singlePage`, `physicalGroupKey`, `_DWLPlan`, Memory write checks, semantic KnowledgeArea acquisition.
- `01_PROMPTS/UnitTestGenerator_SystemPrompt.txt` — Memory Get/Write/Update checks, Projection `singlePage`, `physicalGroupKey`, `CM-NAME-001`, `ValidatorReport` consumption.
- `01_PROMPTS/Validator_SystemPrompt.txt` — JsonValidation response expectations, Memory Get checks, target KnowledgeTool scope, `CM-NAME-001`, `ValidatorReport`.
- `02_KNOWLEDGE_AREAS/Rule-Test-Unit-Case_KnowledgeArea.txt` — Standard target mapping/reference material for `singlePage`/naming.
- `02_KNOWLEDGE_AREAS/Rule-Test-Unit-Case_MultInpComb-KnowledgeArea.txt` — MultiInput naming target reference.
- `03_TARGET_CONTRACTS/Rule-Test-Unit-Case_JsonSchema.txt` — Standard `CM-NAME-001` and target physical-field constraints.
- `03_TARGET_CONTRACTS/Rule-Test-Unit-Case_MultInpComb-JsonSchema.txt` — MultiInput `CM-NAME-001` and target physical-field constraints.
- `03_TARGET_CONTRACTS/Rule-Test-Unit-Case_JsonExample.txt` and `Rule-Test-Unit-Case_MultInpComb-JsonExample.txt` — target fixtures to revalidate whenever physical mappings change.
- `04_TOOLS/Memory_GenAI_Tools_Contract.md` — current idealized Memory response contract; canonical refactor owner in R1.
- `04_TOOLS/Memory_GenAI_Tools_Pega_Implementation_Spec.md` — implementation/spec mirror of Memory shapes.
- `04_TOOLS/Required_Runtime_Tools.md` — external `JsonValidationTool` boundary documentation.

#### Mandatory validation R0 result

- Observed successful runtime fields are explicitly separated from unverified/future failure shapes: **PASS**.
- Every planned changed concept has one explicit bundle owner and named downstream consumers/mirrors: **PASS**.
- Direct textual comparison against the input `PLANNED_v2` bundle shows no implementation-file content change in R0; only `00_START_HERE/STATUS.md` changed to record this execution evidence: **PASS**.
- No SHA/MD5/CRC/checksum/content fingerprint/hash-based comparison was used: **PASS**.

**R0 disposition:** `PASS`. Per the execution protocol, R1 is now eligible to start, but remains `NOT STARTED` until the user explicitly requests continuation.

### R1 — Synchronize JsonValidation and Memory response contracts with live runtime

**Goal:** make bundle contracts describe the tools that actually respond in Pega, rather than requiring agents to translate an idealized shape.

1. Rewrite the Memory tool contract/spec and all caller checks to use the **actual observed field names and wrappers as canonical success shapes**, especially `IsSuccess` and `RouterKey` rather than silently treating `success` / `pyRouterKey` as equivalent.
2. Preserve semantic invariants: exact GUID correlation, exact group correlation where the tool returns group, immutable payload, single-record cardinality, and no retry on uncertain writes/updates.
3. Align JsonValidation consumption to the observed success shape (`IsValid`, `message`). Remove requirements for success fields not returned by the actual tool unless Pega runtime is first changed to return them.
4. For failure handling, use only fields actually confirmed from Pega. If failure shape remains unverified, document it as an explicit runtime dependency rather than inventing `Success`, `ValidationMessage`, `ErrorCode`, or `ErrorMessage` fields.
5. Remove permissive alias interpretation from prompts: callers accept exactly the canonical live contract defined by this stage.

**Mandatory validation R1:**
- field-by-field census finds no stale required aliases (`success`, `pyRouterKey`, `Success`, `ValidationMessage`, etc.) unless deliberately documented as actual runtime fields;
- observed Write/Get/Update responses from the supplied conversations validate against the rewritten contracts;
- observed JsonValidation success response validates against its rewritten contract;
- malformed/unknown response samples fail closed instead of being semantically guessed.

### R1 execution record — PASS — 2026-09-14

**Execution scope:** response-contract synchronization only. R1 changed caller parsing and bundle tool-response documentation; it did not change Projection semantics, target schemas/examples, naming, DWL, Validator KnowledgeTool scope, or ValidatorReport structure. `TEXT_SEMANTIC_ONLY=true` remained active; no hash/checksum/fingerprint was generated or used.

#### Canonical Memory success shapes now enforced

- Write: `MemoryToolResponse.IsSuccess` must be the string `"true"`; response must carry observed `pxObjClass="RuleIQ-Data-AgentMemory"`, exact `pyGroup`, nonempty `pyGUID`, and exact `pyType`.
- Get: top-level `IsSuccess` must be boolean `true`; canonical response fields are `pxCaseID,pyGroup,RouterKey,pyType,pyPayload,pyStatusValue,pyGUID`.
- Update: `MemoryToolResponse.IsSuccess` must be the string `"true"`; response must carry `pxObjClass`, exact `pyGUID`, exact `pyStatusValue`, and response `RouterKey` equal to the requested input `pyRouterKey`.
- No alias/coercion is allowed between `success`/`IsSuccess`, response `pyRouterKey`/`RouterKey`, or boolean/string true.
- Memory failure/non-success shape remains `UNVERIFIED_RUNTIME_SHAPE`; no branchable error fields were invented.

The supplied live Pega message names were `WriteAgentMemory`, `GetAgentMemory`, and `UpdateAgentMemory`. The bundle retains the logical operation labels `WriteMemory`, `GetMemory`, and `UpdateMemory`; renaming invocation surfaces was not part of R1.

#### JsonValidation success boundary now enforced

Observed success is exactly based on top-level `IsValid=true` plus `message` beginning `JSON_VALID|`. The previous required `Success`, `ValidationMessage`, `ErrorCode`, and `ErrorMessage` fields were removed from Validator consumption.

The exact schema-invalid/non-success response remains `UNVERIFIED_RUNTIME_SHAPE`. Until live evidence is available, such a response takes `JSON_VALIDATION_TOOL_ERROR/HUMAN_REVIEW`; Validator may not infer `JSON_SCHEMA_INVALID` or `JSON_SCHEMA_MASS_FAILURE` from undocumented fields/message text.

#### Files changed by R1

- `01_PROMPTS/ScenarioAuthor_SystemPrompt.txt`
- `01_PROMPTS/UnitTestGenerator_SystemPrompt.txt`
- `01_PROMPTS/Validator_SystemPrompt.txt`
- `04_TOOLS/Memory_GenAI_Tools_Contract.md`
- `04_TOOLS/Memory_GenAI_Tools_Pega_Implementation_Spec.md`
- `04_TOOLS/Required_Runtime_Tools.md`
- `00_START_HERE/STATUS.md` only for this execution record/tracker update.

No target JsonSchema, JsonExample, KnowledgeArea, README, or start-session file was changed.

#### Mandatory validation R1 result

- Direct parsing of supplied live conversations found and validated: 2 Write success responses, 3 Get success responses, 1 Update success response, and 1 JsonValidation success response: **PASS**.
- Negative response-shape tests rejected old `success` aliases, wrong `IsSuccess` types/wrappers, response `pyRouterKey` aliasing, missing fields, the old five-field JsonValidation shape, undocumented `IsValid=false`, and invalid success-message framing: **PASS**.
- Prompt/tool-contract field census contains no stale **required** response aliases. Remaining `pyRouterKey` occurrences are deliberately input/persistent-field references; remaining old names appear only in explicit prohibition/evidence text, not as accepted response fields: **PASS**.
- Direct textual content comparison against the R0 input confirms that only the six R1 implementation/contract files above plus this `STATUS.md` record changed: **PASS**.
- No SHA/MD5/CRC/checksum/content fingerprint/hash-based comparison was used: **PASS**.

**R1 disposition:** `PASS`. R2 is eligible to start, but remains `NOT STARTED` until the user explicitly requests continuation.

### R2 — Delete `singlePage` from `UnitTestProjectionV3`

**Goal:** remove target-specific PegaUnit representation from Author-owned semantic projection.

1. Change executable Projection RUT shape from `{name,applyToClass,singlePage}` to exactly `{name,applyToClass}`. Do not make `singlePage` optional; remove it completely from the v3 grammar.
2. Remove all Author materialization, self-validation, canonicalization and trace rules that create/check/copy `singlePage`.
3. Remove Generator/Validator source-fidelity checks that expect Projection `singlePage`.
4. Make `pyIsSinglePageImplementation` solely target-owned. Its value must come from the selected target JsonSchema / target mapping for the applicable RUT type, never from Projection semantics.
5. Update Standard and MultiInput schemas/Knowledge mapping/examples wherever they currently describe a Projection-to-target `singlePage` transform.
6. Remove `singlePage` from all Projection examples and source-target conflict examples that depend on it.

**Mandatory validation R2:**
- repository-wide exact search returns no Projection grammar/mapping/reference to `singlePage`;
- `pyIsSinglePageImplementation` remains present only as target/PegaUnit representation where required;
- a `Rule-Obj-Model` Projection with `{name,applyToClass}` compiles deterministically to the schema-owned physical value without semantic conflict;
- Generator G7 and Validator fidelity specifications agree that no source comparison exists for this target-only field.

### R2 execution record — PASS — 2026-09-14

**Execution scope:** deleted the Projection-owned `singlePage` coordinate and moved `pyIsSinglePageImplementation` fully to target ownership. No R3+ naming/group, DWL, KnowledgeTool-scope, or ValidatorReport refactor was started. `TEXT_SEMANTIC_ONLY=true` was used; no hash/checksum/fingerprint was generated or used.

**Files changed in R2:**
- `01_PROMPTS/ScenarioAuthor_SystemPrompt.txt` — executable `rut` is now exactly `{name,applyToClass}` in examples and the closed v3 producer grammar.
- `01_PROMPTS/UnitTestGenerator_SystemPrompt.txt` — source grammar no longer accepts the deleted field; `pyIsSinglePageImplementation` is explicitly target-owned, has no Projection source coordinate, and is emitted only when target authority uniquely determines it.
- `01_PROMPTS/Validator_SystemPrompt.txt` — target field is explicitly excluded from Projection fidelity; Validator checks only selected target authority and uses HUMAN when a required target value is not uniquely determined.
- `02_KNOWLEDGE_AREAS/Rule-Test-Unit-Case_KnowledgeArea.txt` — removed the Projection-to-target transform and replaced it with target-owned selection semantics.
- `03_TARGET_CONTRACTS/Rule-Test-Unit-Case_JsonSchema.txt` — Standard physical field description now declares target ownership; existing Rule-Obj-Model conditional remains the unique owner of value `"false"` for that RUT type.
- `03_TARGET_CONTRACTS/Rule-Test-Unit-Case_MultInpComb-JsonSchema.txt` — existing Rule-Obj-When `const:"false"` is explicitly documented as target-owned with no Projection source coordinate.

**Validation-scope clarification:** this tracker necessarily retains historical/planning references to the deleted source field so the refactor remains auditable. Therefore the R2 exact-term absence gate is applied to every implementation/reference artifact **except this `STATUS.md` history/tracker**. This clarifies the mechanical check without changing the R2 architectural goal.

**Mandatory validation evidence:**
- Direct textual scan of every implementation/reference artifact outside this tracker finds zero occurrences of the deleted Projection field name: **PASS**.
- ScenarioAuthor and Generator closed executable grammars both require exactly `rut={name,applyToClass}`: **PASS**.
- Standard schema, MultiInput schema, and both canonical JsonExamples parse successfully; each example validates against its corresponding Draft-2020-12 schema: **PASS**.
- Standard `Rule-Obj-Model` fixture with Projection RUT keys exactly `{name,applyToClass}` deterministically obtains target `pyIsSinglePageImplementation="false"` from the schema conditional and requires no source comparison: **PASS**.
- MultiInput `Rule-Obj-When` target retains machine-enforced `pyIsSinglePageImplementation="false"`: **PASS**.
- Generator G7 explicitly treats the field as target-owned and Validator fidelity explicitly states that it has no Projection source coordinate: **PASS**.
- For a Standard RUT type where selected target authority leaves multiple required values legal, Generator/Validator fail closed to HUMAN rather than inventing a value or emitting `PF_SOURCE_TARGET_CONFLICT`: **PASS**.
- Direct textual comparison against the R1 input shows changes only in the six R2-owned implementation/reference files above plus this tracker: **PASS**.
- No SHA/MD5/CRC/checksum/content fingerprint/hash-based comparison was used: **PASS**.

**R2 disposition:** `PASS`. R3 is eligible to start, but remains `NOT STARTED` until the user explicitly requests continuation.

### R3 — Remove `physicalGroupKey` from `CM-NAME-001`; keep `Gnnn` correlation-only

**Goal:** produce human-readable test identities without mechanical `G001`, while preserving physical-group correlation.

1. Keep `physicalGroupKey=Gnnn` in `UnitTestProjectionV3` and `pyGroup` as internal physical-group/correlation identity.
2. Remove `physicalGroupKey` / `GROUP` from **both** Standard and MultiInput `CM-NAME-001` inputs and generated test identity.
3. Update Generator and Validator naming rules to compute identity from the revised schema mapping only; neither may append a group suffix independently.
4. Preserve `Scenarios[n].Name` as the exact Author semantic scenario name.
5. Define deterministic collision handling **without** reintroducing `Gnnn` into the user-facing name. Prefer semantic uniqueness enforced by Author/test-label generation; if target-level collision handling is required, it must be a separately specified deterministic rule with an explicit owner.
6. Recalculate length budgeting so the mapping cannot reproduce the observed manual 25-vs-26 character counting failure. Prefer a mapping that avoids LLM arithmetic/counting where possible.

**Mandatory validation R3:**
- no `CM-NAME-001` implementation/reference consumes `physicalGroupKey`;
- generated `Name`, `pyPurpose`, and `pyLabel` remain exactly equal;
- `Gnnn` still correlates Projection/Candidate/Validator lifecycle through Memory `pyGroup` and report `groupId` only;
- boundary tests cover maximum label length, long RUT names, normalization, and two physical groups in one run;
- no generated test name ends in `_Gnnn` solely because of correlation.

### R3 execution record — PASS — 2026-09-14

**Historical R3 identity rule (superseded by R8 formatting only):** both Standard and MultiInput `CM-NAME-001` consumed exactly frozen `UnitTestProjection.testLabel`. At R3 the deterministic target identity was `TC_` plus underscore-preserving label canonicalization. R8 keeps the same ownership/correlation boundary but changes only the physical target-name formatting to separator-free `TC_` + Pascal-token concatenation. `rut.name` and `physicalGroupKey` are explicitly non-inputs. No RUT-name truncation, length allocation, group suffix, counter, ordinal, hash, or collision suffix participates.

**Correlation boundary:** `physicalGroupKey=Gnnn` remains mandatory in UnitTestProjectionV3 and continues to correlate Projection/Memory/Candidate/Validator lifecycle through `pyGroup`/`groupId`; ScenarioAuthor, Generator, and Validator explicitly forbid using it in `Name`, `pyPurpose`, or `pyLabel`.

**Semantic uniqueness rule:** before persistence, ScenarioAuthor must ensure physical-group `testLabel` values remain distinct after the same target-safe label canonicalization. Any collision must be resolved by an evidence-backed semantic Scenario name before B/A; group id, ordinal, counter, hash, or mechanical suffix is forbidden. If no semantic distinction exists, the pre-projection gate fails rather than manufacturing identity.

**Length contract adjustment:** target identity `minLength` is now 4 so the valid source label `A` maps to `TC_A`; `maxLength` remains 53 because source `testLabel` is capped at 50 characters. This removes all prior manual `BASE_ALLOC` / RUT-prefix counting.

**Mandatory validation evidence:**
- Both target schemas parse as Draft-2020-12 schemas and both canonical JsonExamples validate with zero errors: **PASS**.
- R3-time examples used `TC_Happy_Path` / `TC_True_Standard`; this historical formatting is superseded by R8. Current examples are `TC_HappyPath` / `TC_TrueStandard`, with executable `Name == pyPurpose == pyLabel`: **PASS**.
- R3-time boundary fixture used underscore-preserving `TC_City_Not_Valid_Exit`; R8 supersedes only that formatting. One-character/max-length/RUT-independence constraints remain unchanged.
- Two physical groups with the same long RUT but semantic labels `City Not Valid Exit` / `Valid Postal Address` produce distinct names without `_G001/_G002`: **PASS**.
- Collision fixture `A B` versus `A__B` canonicalizes to the same target name and is detected as a pre-persistence semantic-label collision; no mechanical repair is authorized: **PASS**.
- Direct text scan finds no generated target example/name ending in `_Gnnn` and no obsolete `BASE_ALLOC`, `RUT_BASE_FINAL`, `GROUP = physicalGroupKey`, or `rut.name + testLabel + physicalGroupKey` naming logic: **PASS**.
- Direct textual comparison against the R2 input shows changes only in the three prompts, two target KnowledgeAreas, four target schema/example files, plus this tracker: **PASS**.
- `TEXT_SEMANTIC_ONLY=true` was respected; no SHA/MD5/CRC/checksum/content fingerprint/hash-based comparison was used: **PASS**.

**R3 disposition:** `PASS`. R4 is eligible to start, but remains `NOT STARTED` until the user explicitly requests continuation.

### R4 — Correct `_DWLPlan` materialization

**Goal:** make the non-waivable dependency plan self-consistent and machine-auditable.

1. Canonical plan contains exactly one `OUT=<ordered unique KEY list>`.
2. Canonical plan contains exactly one `ACT=<exact ordered KEY list physically emitted>`.
3. Remove count overloads such as `OUT=12`, `ACT=12`. If counts are useful, give them distinct explicitly named fields or derive them; do not overload `OUT`/`ACT`.
4. Require literal ordered equality `OUT == ACT` after holder selection/deduplication and before every RuleCrawler call.
5. Update all examples/instructions that permit or encourage duplicate `OUT` fields or numeric `ACT`.

**Mandatory validation R4:**
- parser/census test rejects `...|OUT=<keys>|OUT=12|...|ACT=12|...`;
- valid fixture has one OUT list and one identical ACT list;
- physical `pxRuleReferences[]` census maps 1:1 to ACT and OUT;
- `STATECHECK.preCall=PASS` is impossible when OUT/ACT differ, duplicate, or contain counts instead of keys.

### R4 execution record — PASS — 2026-09-14

**Implemented DWL plan contract:** `_DWLPlan` now serializes each field exactly once. `OUT` and `ACT` are list-valued canonical KEY sequences only. Numeric/cardinality overloads such as `OUT=12` or `ACT=12`, duplicate `OUT`/`ACT` fields, scalar substitutes, and non-list values are explicitly invalid and force `STATECHECK.preCall=FIX`.

**Materialization order:** `SCAN` preserves READY occurrence ids and internal `READY_KEYS` preserves the stable unique READY KEY projection. Holder selection, source/request-shape gates, deduplication and holder grouping are completed before `OUT` is serialized. `OUT` then records the intended final physical payload's canonical KEYs in deterministic wire order. `ACT` is independently rebuilt by flattening the actual final `InterestedRules[].pxRuleReferences[]` in that exact wire order and mapping each physical reference back to one canonical KEY without guessing. This removes the prior ordering ambiguity when holder grouping changes physical wire order.

**Non-waivable pre-call gate:** `STATECHECK.preCall=PASS` now requires `len(ACT) == len(OUT) == len(READY_KEYS)`, every READY key exactly once, no unmappable/out-of-plan physical reference, one nonempty physical reference set per retained holder, and literal ordered `OUT == ACT`. Any value/order/multiplicity/representation/cardinality mismatch forbids RuleCrawler.

**Mandatory validation evidence:**
- Canonical valid fixture with one list-valued `OUT` and one identical list-valued `ACT`: **PASS**.
- Observed malformed shape `OUT=[keys]|OUT=12|...|ACT=12` rejected because `OUT` occurs more than once and `ACT` is not a KEY list: **PASS**.
- Numeric-only `ACT`, ordered OUT/ACT mismatch, and extra physical reference fixtures are each rejected before a RuleCrawler-eligible state: **PASS**.
- Physical census fixture maps the actual flattened `pxRuleReferences[]` 1:1 to both OUT and ACT: **PASS**.
- Holder-group reordering fixture proves wire-order OUT materialization remains deterministic and allows exact `OUT == ACT` without relying on pre-group READY order: **PASS**.
- Direct textual scan of the active prompt confirms the only `OUT=12` / `ACT=12` mentions are explicit invalid examples; no active grammar or positive instruction permits count-valued OUT/ACT: **PASS**.
- Direct textual comparison against the R3 input shows implementation changes only in `01_PROMPTS/ScenarioAuthor_SystemPrompt.txt`; this tracker is the only additional changed file: **PASS**.
- `TEXT_SEMANTIC_ONLY=true` was respected; no SHA/MD5/CRC/checksum/content fingerprint/hash-based comparison was used: **PASS**.

**R4 disposition:** `PASS`. R5 is eligible to start, but remains `NOT STARTED` until the user explicitly requests continuation.

### R5 — Lock Validator KnowledgeTool scope and forbid RUT semantic KnowledgeAreas

**Goal:** keep Validator independent but target-focused; it must not reacquire Author semantic guidance.

1. Explicitly forbid Validator requests for semantic RUT adapters such as `Rule-Obj-Model_KnowledgeArea`, `Rule-Obj-When_KnowledgeArea`, dependency KnowledgeAreas, property/RUF KnowledgeAreas, etc.
2. Validator may use only the target artifacts explicitly required by its closed validation matrix. Any target `Rule-Test-Unit-Case...` KnowledgeArea usage must be justified solely by target/Pega structural validation, never by RUT semantic reasoning.
3. Re-evaluate whether executable Validator actually needs `Rule-Test-Unit-Case_KnowledgeArea` at all after R2/R3. If all deterministic checks are fully owned by JsonSchema mappings/invariants, reduce Validator acquisition to schema (and only the minimum target artifact still required). Do not retain KnowledgeArea by inertia.
4. Keep ScenarioAuthor as the sole consumer of `RUT_TYPE + "_KnowledgeArea"` semantic adapters.

**Observed-trace note:** in the supplied Validator conversation the visible request is `Rule-Test-Unit-Case_KnowledgeArea,Rule-Test-Unit-Case_JsonSchema,Rule-Test-Unit-Case_JsonExample`, not `Rule-Obj-Model_KnowledgeArea`. The prohibition above is nevertheless made explicit so a Validator can never request the latter.

**Mandatory validation R5:**
- static tool-call matrix proves Validator cannot request `<RUTType>_KnowledgeArea`;
- negative fixture containing `Rule-Obj-Model_KnowledgeArea` is rejected as an invalid Validator acquisition;
- every retained Validator target artifact has at least one named validation responsibility; unused acquisitions are removed;
- ScenarioAuthor semantic acquisition remains unchanged except where separately modified by R2/R4.

#### R5 execution record — 2026-09-14

**Execution scope:** Validator target-acquisition boundary only. No ScenarioAuthor semantic acquisition, Generator target acquisition, target schema/example/KnowledgeArea content, Memory contract, DWL, naming, or ValidatorReport structure was changed in R5. `TEXT_SEMANTIC_ONLY=true` remained active; no SHA/MD5/CRC/checksum/content fingerprint/hash-based comparison was used.

**Implemented:**
- Validator KnowledgeTool acquisition is now a closed four-row matrix selected only from source mode + immutable `RUTType`.
- Any extra/substituted Area is rejected before KnowledgeTool invocation. `<RUTType>_KnowledgeArea` is never appended. `Rule-Obj-Model_KnowledgeArea`, `Rule-Obj-When_KnowledgeArea`, property/RUF/Data Page/dependency semantic KnowledgeAreas are explicitly forbidden.
- ScenarioAuthor remains the sole consumer of RUT/dependency semantic KnowledgeAreas.
- The executable target `Rule-Test-Unit-Case..._KnowledgeArea` remains intentionally retained because the current JsonSchemas do not encode the complete Projection→Candidate serialization mapping (typed/wrapped values, executable context, setup/simulation/assertion or Decision-cell serialization). This target KnowledgeArea is explicitly non-semantic with respect to RUT meaning.
- The executable JsonExample remains retained only for the designated template-owned `RuleCode.pyRuleSet` and `RuleCode.pyRuleSetVersion` values; Validator section 5.2 now gives those fields an explicit validation responsibility.
- JsonSchema remains owner of formal shape, `CM-NAME-001`, `CF-*`, and schema-owned target constants/relationships.

**Mandatory validation R5:**
- Static acquisition matrix has only the four exact permitted target batches and contains no RUT/dependency semantic adapter in any positive row: **PASS**.
- Negative fixture `EXECUTABLE_STANDARD + Rule-Obj-Model_KnowledgeArea` differs from the permitted batch and is rejected before KnowledgeTool call: **PASS**.
- Every retained target artifact has a named responsibility: JsonSchema=formal shape/CM/CF/constants; target KnowledgeArea=remaining deterministic executable serialization; JsonExample=only `pyRuleSet`/`pyRuleSetVersion`: **PASS**.
- Both retained target KnowledgeAreas contain the shared deterministic mapping reference used by section 4, and both retained JsonExamples contain the two designated template fields: **PASS**.
- ScenarioAuthor prompt is textually unchanged from the R4 input, so semantic acquisition behavior was not modified by R5: **PASS**.
- Direct textual comparison against the R4 input shows implementation changes only in `01_PROMPTS/Validator_SystemPrompt.txt`; this tracker is the only additional changed file: **PASS**.
- `TEXT_SEMANTIC_ONLY=true` was respected; no hash/checksum/fingerprint was generated or used: **PASS**.

**R5 disposition:** `PASS`. R6 is eligible to start, but remains `NOT STARTED` until the user explicitly requests continuation.

### R6 — Structurally enforce `ValidatorReport`

**Goal:** make `raw JSON only` a runtime contract, not a prose instruction that the model may ignore.

1. Define a machine-readable `ValidatorReport` schema matching the synchronized issue/action catalog, required identities, route, counters, and closed issue object.
2. Put a structural adapter/parser at the Validator invocation boundary. The nested Validator response must parse as exactly one JSON object and validate against `ValidatorReport` schema **before** Generator can consume it.
3. Reject any response with prefix/suffix prose, Markdown, code fences, multiple JSON values, unknown fields, invalid code/action pairs, wrong counts, or identity/correlation mismatch.
4. Generator must never substring-extract JSON from a prose response and must never use Validator prose as repair input.
5. Keep the Validator prompt's raw-JSON instruction as defense-in-depth, but runtime structural validation is authoritative.

**Mandatory validation R6:**
- the observed bad response (`Now I have all required information...` + Markdown + final JSON) is rejected;
- a valid raw report object passes;
- raw JSON with an extra field fails;
- valid JSON with an unlisted issue/action pair fails;
- valid schema report with wrong `sourceUUID`, Candidate UUID, group correlation, `blocking`, or route precedence fails;
- Generator receives no semantic issue list when structural validation fails.

### R6 execution record — PASS — 2026-09-14

**Execution scope:** introduced one authoritative machine-readable ValidatorReport boundary contract plus deterministic adapter requirements. No Projection semantics, target Candidate schema/mapping, KnowledgeArea acquisition, naming, DWL, or Memory response contract was changed. `TEXT_SEMANTIC_ONLY=true` remained active; no SHA/MD5/CRC/checksum/content-fingerprint comparison was used.

**Files changed in R6:**
- `04_TOOLS/ValidatorReport_JsonSchema.txt` — new authoritative Draft-2020-12 structural report schema with closed root/issue objects, exact issue/action pairs, route-shape constraints and explicit runtime invariants.
- `04_TOOLS/Required_Runtime_Tools.md` — specifies the required non-LLM boundary adapter over the observed delegated `{response:<string>}` envelope; the adapter accepts/rejects only and may not repair/extract/normalize model output.
- `01_PROMPTS/UnitTestGenerator_SystemPrompt.txt` — Generator may consume only an adapter-accepted parsed ValidatorReport; a raw delegated response reaching Generator is noncompliant and fails `VALIDATOR_RESPONSE_INVALID` without substring recovery.
- `01_PROMPTS/Validator_SystemPrompt.txt` — raw-JSON-only remains defense-in-depth and explicitly mirrors the authoritative structural boundary.
- `README.md` — indexes the new ValidatorReport schema artifact.
- `00_START_HERE/STATUS.md` — this execution record/tracker update only.

**Structural boundary now required:**
1. delegated envelope is exactly one object containing exactly one string field `response`;
2. the entire response string is parsed as one finite duplicate-key-free JSON object; prose, Markdown/code fences, multiple JSON values, prefix/suffix text, duplicate keys and non-finite numbers fail closed;
3. the parsed object validates against `ValidatorReport_JsonSchema.txt`;
4. exact invocation identities and group correlation are checked;
5. `blocking == len(issues)` and `warnings == 0`;
6. code/action pairs are closed by schema and route is recomputed with precedence `HUMAN_REVIEW > REJECT_SEMANTICS > repair > OK`;
7. any failure exposes neither raw nested-agent text nor semantic issues to Generator and terminates that validation path as `VALIDATOR_RESPONSE_INVALID`.

**Mandatory validation evidence:**
- The actual supplied `PXCONV-144029` Validator tool response whose nested text begins `Now I have all required information. Let me perform the full analysis.` and contains Markdown before a trailing JSON report is rejected by whole-string JSON parsing before any issue extraction: **PASS**.
- A valid raw `OK` ValidatorReport with exact invocation/correlation values validates and is accepted: **PASS**.
- Extra report field, extra outer-envelope field, code fence, prose prefix, multiple JSON values and duplicate report key are rejected: **PASS**.
- An unlisted `PF_ASSERTION_MISMATCH/FIX_JSON` pair is rejected by the machine-readable schema: **PASS**.
- Wrong `sourceUUID`, wrong `UnitTestCandidateUUID`, wrong `groupId`, wrong `blocking` count and route-precedence contradiction are rejected by schema/runtime invariants: **PASS**.
- A valid `HUMAN` report with `AMBIGUOUS/HUMAN_REVIEW` passes, proving the route gate is not reject-all: **PASS**.
- Machine-readable schema catalog contains exactly the same 14 issue/action pairs as Generator and Validator prompts; exact root report field set is synchronized in all three: **PASS**.
- Direct textual content comparison against the R5 input finds only the five R6 implementation/contract files above plus this tracker changed, with the ValidatorReport schema newly added: **PASS**.
- Structural-failure reference adapter returns no parsed report/issue list to its caller; it fails before semantic consumption: **PASS**.
- Live Pega deployment of this non-LLM adapter has **not** been claimed or tested; it remains external runtime evidence for execution readiness: **PASS boundary statement**.

**R6 disposition:** `PASS`. R7 is eligible to start, but remains `NOT STARTED` until the user explicitly requests continuation.

### R7 — Cross-bundle consistency and execution-readiness validation

**Goal:** prove the six refactors compose without weakening existing non-waivable gates.

1. Run exact-term and semantic cross-checks across all prompts, target schemas/examples, KnowledgeAreas and tool contracts under `TEXT_SEMANTIC_ONLY=true`; do not use hashes/checksums/fingerprints as equality or regression evidence.
2. Verify ownership boundaries:
   - Author owns semantics/dependency closure/scenario formation;
   - Projection contains no `singlePage`;
   - `physicalGroupKey` is correlation-only;
   - Generator owns target serialization;
   - Validator validates target/fidelity but does not reacquire RUT semantics;
   - runtime adapters own tool/report structural response validation.
3. Replay the three supplied conversations as regression evidence at contract level and document which former behaviors must now fail earlier/differently.
4. Confirm no stage accidentally relaxes immutable Memory semantics, commit boundary, G7, source-preservation, Validator issue catalog, or DWL non-waivability.

**Mandatory validation R7:** all static/cross-contract checks PASS and every planned regression has an expected disposition. Live Pega KnowledgeTool/tool deployment and a new end-to-end Pega run remain explicit external validation steps and must not be marked complete until actually executed.


### R7 execution record — PASS (static) — 2026-09-14

**Execution scope:** full cross-bundle semantic/structural regression validation only. No prompt, target schema/example, KnowledgeArea, Memory contract/spec, or runtime-contract implementation text was changed in R7. Only this status/tracker was updated after validation. `TEXT_SEMANTIC_ONLY=true` was used throughout; no SHA/MD5/CRC/checksum/content fingerprint/hash-based equality was generated or used.

#### Static cross-contract suite

The final R7 suite completed **59/59 checks PASS**. The checks covered:

- all three machine-readable JSON Schemas (`Standard`, `MultiInput`, `ValidatorReport`) are valid Draft 2020-12 schemas;
- both canonical Candidate JsonExamples validate against their selected schemas;
- no active implementation/reference file contains the removed Projection source coordinate `singlePage`;
- physical `pyIsSinglePageImplementation` remains target-owned only; Standard `Rule-Obj-Model` selects `"false"` and MultiInput `Rule-Obj-When` selects `"false"` without a Projection source field;
- each target schema contains exactly one `CM-NAME-001`; the mapping input is only `UnitTestProjection.testLabel`; `rut.name`, `physicalGroupKey`, counters/hashes/group suffixes do not participate;
- no active target/example name ends in `_Gnnn`, and the obsolete `BASE_ALLOC` / `RUT_BASE_FINAL` naming arithmetic is absent;
- naming fixtures including one-character and 50-character labels satisfy the target lexical/length contract. R8 supersedes the R7-time underscore format; current mapping is `City Not Valid Exit -> TC_CityNotValidExit` independently of group id;
- `_DWLPlan` has one canonical grammar; `OUT` and `ACT` are list-valued exactly once, numeric overloads are invalid, and `STATECHECK.preCall` requires literal exact ordered `OUT == ACT`;
- Memory caller checks, Memory contract/spec, and JsonValidation success parsing use the observed R1 runtime fields/wrappers without alias coercion;
- Validator has the closed four-row target-artifact KnowledgeTool matrix and explicitly forbids semantic RUT/dependency KnowledgeAreas; ScenarioAuthor remains the semantic KnowledgeArea owner;
- Generator, Validator, and `ValidatorReport_JsonSchema.txt` contain the same exact **14** issue/action pairs;
- positive `OK`, `GENERATOR_REPAIR`, `SEMANTIC_REJECT`, and `HUMAN` ValidatorReport fixtures validate, while route-inconsistent fixtures fail;
- the non-LLM ValidatorReport boundary requires whole-response parsing and forbids substring/Markdown/code-fence recovery;
- Author commit boundary, DWL non-waivability, Generator G7, create-only Candidate persistence, immutable Candidate payload, source preservation, and Validator no-semantic-repair boundaries remain intact.

#### Contract-level replay of supplied conversations

The old conversations are regression evidence, not expected-to-pass current executions. Under the refactored contracts their expected earliest/next dispositions are:

| Supplied trace | Former behavior | Current required disposition |
|---|---|---|
| `PXCONV-144028` ScenarioAuthor | RuleCrawler was called with malformed `_DWLPlan` containing duplicate/count-valued `OUT`/`ACT` | `STATECHECK.preCall=FIX`; **RuleCrawler call is forbidden** until one list-valued OUT and one independently materialized ACT are literally equal in ordered content |
| `PXCONV-144029` Generator | old Projection was accepted and target acquisition continued | the persisted old Projection contains removed `rut.singlePage`, so current closed v3 source grammar yields **`SOURCE_INVALID` before KnowledgeTool** |
| `PXCONV-144029` Generator, after hypothetically replacing only the old Projection with a current R2-compliant Projection | Standard target batch in the supplied live trace returned empty `Rule-Test-Unit-Case_KnowledgeArea.Description` but compilation continued | current Generator requires every requested target Area exactly once and nonempty, therefore **`KNOWLEDGE_FAILED` before Candidate persistence** |
| `PXCONV-144030` Validator | observed JsonValidation success was interpreted using invented legacy fields, then old Projection was analyzed | observed `{IsValid:true,message:"JSON_VALID|..."}` is now a valid R1 success response; however the old Projection still contains removed `singlePage`, so current source-mode gate yields **`AMBIGUOUS/HUMAN_REVIEW` before target KnowledgeTool** |
| `PXCONV-144030` Validator, with a current Projection but the supplied old live target deployment | empty Standard target KnowledgeArea was tolerated | current closed target batch requires nonempty exact results, therefore **`AMBIGUOUS/HUMAN_REVIEW`** |
| old persisted Candidate, if evaluated under current source+target contracts | Name/pyPurpose/pyLabel contained `..._G001`; Validator also treated `singlePage=true` as a source fact | current name after R8 is **`TC_CityNotValidExit`**; the old mechanical name is `PF_RUT_CONTEXT_MISMATCH`. `pyIsSinglePageImplementation="false"` is target-owned for Rule-Obj-Model and **does not create a source semantic conflict** |
| old delegated Validator response | prose/Markdown preceded the final JSON report and Generator still consumed it | R6 boundary rejects the entire nested response; **`VALIDATOR_RESPONSE_INVALID`**, with no issue list exposed to Generator |

The previously identified quote/double-wrapper assertion issue is intentionally **outside this refactoring scope** and is not claimed as fixed by R0-R7.

#### External runtime evidence still required

R7 proves static bundle consistency only. The following remain external before claiming live end-to-end completion:

1. Deploy/verify the current target KnowledgeTool content. The bundle contains a nonempty Standard target KnowledgeArea, but the supplied live Generator/Validator traces returned an empty `Rule-Test-Unit-Case_KnowledgeArea.Description`; no later live deployment evidence was supplied.
2. Deploy the deterministic non-LLM ValidatorReport boundary adapter defined in `Required_Runtime_Tools.md` and verify that raw delegated `{response:<string>}` output never reaches Generator unvalidated.
3. Execute a fresh live Pega Author -> Generator -> Validator run with the current bundle and verify actual persistence/lifecycle behavior and target rule creation.
4. Capture real Memory/JsonValidation non-success responses if strict typed failure parsing beyond the current fail-closed behavior is required; those shapes remain `UNVERIFIED_RUNTIME_SHAPE`.
5. The supplied historical traces also showed platform bootstrap calls such as `application_context` / `data_from_all_sources` outside the prompts' semantic closed-tool allowlists. R0-R7 did not change platform tool exposure. Strict closed-tool compliance therefore still requires live verification/removal or an explicitly documented platform-bootstrap exception.

**R7 disposition:** `PASS (STATIC)`. Refactoring stages R0-R7 are complete. Live Pega deployment/replay is not complete and must not be represented as completed evidence.


### R8 — Separator-free `TC_` physical naming for unit tests and Scenarios

**Goal:** change physical Pega target names from underscore-separated semantic words (for example `TC_City_Not_Valid_Exit`) to separator-free `TC_` + Pascal-token form (`TC_CityNotValidExit`) without changing Projection semantic names, correlation identity, or ownership boundaries.

1. Keep Author/Projection `testLabel` and `scenarios[].name` as semantic human-readable source strings (for example `City Not Valid Exit`).
2. `CM-NAME-001` owns one deterministic `TARGET_NAME(label)` function for both unit-test identity and target Scenario names:
   - split on maximal runs of ASCII spaces or underscores;
   - discard empty edge tokens;
   - uppercase the first character of each token only when it is ASCII `a-z`;
   - preserve every remaining token character exactly;
   - concatenate tokens with no separator;
   - prefix exactly `TC_`.
3. Apply `TARGET_NAME(testLabel)` to `UnitTestRules[0].Name`; for executable candidates `CF-IDENTITY-001` keeps `RuleCode.pyPurpose` and `RuleCode.pyLabel` equal to the same value.
4. Apply `TARGET_NAME(scenarios[n].name)` independently to every candidate `Scenarios[n].Name`.
5. `physicalGroupKey/Gnnn`, RUT name, counters, ordinals, hashes/checksums/fingerprints and collision suffixes remain forbidden naming inputs.
6. Author must prevent two physical groups from producing the same `TARGET_NAME(testLabel)` and must prevent two Scenarios inside one physical group from producing the same `TARGET_NAME(scenario.name)`. Collision disambiguation must remain semantic.

**R8 execution record — PASS — 2026-09-14**

- Standard and MultiInput schemas each contain exactly one `CM-NAME-001` with the same `TARGET_NAME` algorithm: **PASS**.
- Physical unit-test `Name`, `pyPurpose`, `pyLabel`, and target Scenario `Name` patterns are `^TC_[A-Za-z0-9]+$`; underscore is permitted only in the fixed `TC_` prefix: **PASS**.
- Source Projection grammar remains human-readable/non-`TC_`; no semantic source name is rewritten in place: **PASS**.
- Standard canonical example now uses `TC_HappyPath` for both unit-test identity and its single target Scenario: **PASS**.
- MultiInput canonical example uses unit-test identity `TC_TrueStandard` and target Scenario names `TC_TrueStandard`, `TC_HighRisk`, `TC_EmployeeExpress`: **PASS**.
- Mapping fixtures: `City Not Valid Exit -> TC_CityNotValidExit`; `City   Not__Valid Exit -> TC_CityNotValidExit`; `customer ID valid -> TC_CustomerIDValid`; one-character `A -> TC_A`; 50-character alphanumeric label -> target length 53: **PASS**.
- Collision fixture `A B` vs `AB` produces the same `TC_AB` and therefore must be rejected by the Author pre-projection uniqueness gate rather than repaired by suffix: **PASS**.
- Both canonical JsonExamples validate against their corresponding Draft-2020-12 schemas after the change: **PASS**.
- Generator G7 and Validator fidelity independently recompute target Scenario names from source semantic names through `CM-NAME-001`; verbatim source-name equality is no longer required at the target boundary: **PASS**.
- Direct textual comparison against the R7 input shows only R8-owned naming files plus this tracker changed; Memory/DWL/ValidatorReport/runtime-response contracts are unchanged: **PASS**.
- `TEXT_SEMANTIC_ONLY=true` was respected; no SHA/MD5/CRC/checksum/content fingerprint/hash-based comparison was used: **PASS**.

**R8 disposition:** `PASS (STATIC)`. Live Pega redeploy/replay remains external evidence.

### R9-R14 — Memory-state inter-agent handoff refactoring plan — 2026-09-15

**Planning status:** `IMPLEMENTATION COMPLETE — R9-R14 PASS (STATIC)`  
**Execution lock:** R9 may start only after explicit user instruction. Each later stage requires the previous stage to record `PASS`.  
**Scope:** replace conversational Agent-response transport between Validator→Generator and Generator→Author with authoritative state persisted on the existing Memory records. No new tool and no new feedback record is introduced.

#### Frozen target interface for this cycle

Memory **input argument names are not renamed by this plan unless the deployed tool schema itself changes**. In particular, existing call arguments such as `pxCaseID` remain valid input names. The user's runtime fact for this cycle is that **all Memory success responses return `CaseID`, not `pxCaseID`**.

Target success fields:

| Tool | Target response correlation fields |
|---|---|
| `WriteMemory` | `MemoryToolResponse.IsSuccess="true"`, `CaseID`, `pxObjClass`, `pyGroup`, `pyGUID`, `pyType` |
| `GetMemory` | top-level `IsSuccess=true`, `CaseID`, `pyGroup`, `RouterKey`, `ProcessingFeedback`, `pyType`, `pyPayload`, `pyStatusValue`, `pyGUID` |
| `UpdateMemory` | `MemoryToolResponse.IsSuccess="true"`, `CaseID`, `pxObjClass`, `pyGUID`, `pyStatusValue`, `RouterKey`, `ProcessingFeedback` |

Target update call:

`UpdateMemory(pxCaseID,pyGUID,pyStatusValue,pyRouterKey,ProcessingFeedback)`

`ProcessingFeedback` is one persisted Text field shared by all agent handoffs:
- success terminal state: exact empty string `""`;
- failed/non-OK terminal state: nonempty;
- multiple feedback items: one item per LF/newline, never `;`-delimited;
- no CR/LF inside one item and no blank feedback lines;
- current producer owns the line grammar; Memory stores/transports the text without interpreting it;
- a successful later processing attempt MUST overwrite/clear stale feedback to `""`.

Authoritative lifecycle combinations:

**Candidate row, written by Validator and read by Generator**
- `Passed + OK + ProcessingFeedback=""`;
- `Failed + GENERATOR_REPAIR + nonempty ProcessingFeedback`;
- `Failed + SEMANTIC_REJECT + nonempty ProcessingFeedback`;
- `Failed + HUMAN + nonempty ProcessingFeedback`.

**Projection row, written by Generator and read by Author**
- `Passed + OK + ProcessingFeedback=""`;
- `Failed + SEMANTIC_REJECT + nonempty ProcessingFeedback`;
- `Failed + HUMAN + nonempty ProcessingFeedback`.

`GENERATOR_REPAIR` is internal to Generator↔Validator and MUST NOT be surfaced on the Projection row. Generator operational/contract failures that cannot complete automatically route to `Failed + HUMAN` with a concise machine-oriented failure code in `ProcessingFeedback`. If Generator cannot safely confirm the Projection update itself, Author will observe no valid terminal Projection state and fail closed.

Validator repair feedback line grammar:
`<ISSUE_CODE> | scenario=<n|null> | path=<path> | <short message>`

The existing synchronized issue-code catalog remains authoritative. `|` is the intra-line separator; the final message must not contain `|` or CR/LF. Generator may use issue code/scenario/path as deterministic repair context but Validator must still not provide replacement semantic values.

Generator→Author feedback line grammar:
`<GENERATOR_CODE> | <short message>`

The line identifies why the current Projection could not complete automatically. It is diagnostic/routing context only; Author never repairs Candidate content.

---

#### Planning completeness audit before R9

Direct scan of the active R8 bundle confirms the old transport is still present **only because R9-R14 have not started**. The new plan owns every active stale surface found:

- `ValidatorReport` active references: `01_PROMPTS/Validator_SystemPrompt.txt`, `01_PROMPTS/UnitTestGenerator_SystemPrompt.txt`, `04_TOOLS/Required_Runtime_Tools.md`, `04_TOOLS/ValidatorReport_JsonSchema.txt`, and `README.md` -> owned by R10/R11/R13.
- `GeneratorRunReport` active references: `01_PROMPTS/ScenarioAuthor_SystemPrompt.txt` and `01_PROMPTS/UnitTestGenerator_SystemPrompt.txt` -> owned by R12/R13.
- Memory response `pxCaseID` parsing/fixtures: Memory contract/spec plus Generator/Validator response parsers -> owned by R9. Input-side `pxCaseID` call arguments are intentionally not treated as stale response fields.
- Validator currently forbids `UpdateMemory` -> R10 explicitly changes its closed allowlist and makes Validator the Candidate lifecycle writer.
- Generator currently owns Candidate lifecycle `UpdateMemory` and consumes ValidatorReport -> R11 explicitly removes both responsibilities, adds fresh Candidate `GetMemory`, and keeps only Projection terminal `UpdateMemory` for R12.
- ScenarioAuthor currently forbids `GetMemory` and consumes GeneratorRunReport -> R12 explicitly adds exact Projection `GetMemory` after Generator and ignores delegated response text.
- `ProcessingFeedback` is absent from the active R8 implementation, as expected before R9; R9 adds it to Memory storage/API and R10-R12 add the producer/consumer semantics.
- No active `ValidationFeedback` field exists, so there is no conflicting legacy alias to migrate.

**Parameter synchronization target:** the same exact case/casing is frozen across all planned consumers: response `CaseID`; response `RouterKey`; input `pyRouterKey`; state `pyStatusValue`; feedback `ProcessingFeedback`; immutable payload `pyPayload`; exact record identity `pyGUID`; correlation group `pyGroup`.

This audit is a planning completeness check only. It does **not** claim that the R8 prompts already implement the R9-R14 behavior.

### R9 — Synchronize Memory API/storage contract

**Goal:** make one Memory contract authoritative before changing any agent consumer.

1. Add persisted Text property `ProcessingFeedback`, initialized to `""` on create.
2. Extend `UpdateMemory` with exact input `ProcessingFeedback`; update `pyStatusValue`, `pyRouterKey`, and `ProcessingFeedback` atomically on the targeted row while keeping `pyPayload` and identity immutable.
3. `GetMemory` returns exact `ProcessingFeedback`.
4. All Memory success responses use exact response field `CaseID`; active response contracts/prompts must no longer require response `pxCaseID`.
5. `UpdateMemory` success echoes exact requested `pyStatusValue`, response `RouterKey`, and exact `ProcessingFeedback`.
6. Keep tool input `pxCaseID` unchanged unless actual deployed input schema evidence says otherwise; do not confuse input naming with response naming.

**Owned files:**
- `04_TOOLS/Memory_GenAI_Tools_Contract.md`
- `04_TOOLS/Memory_GenAI_Tools_Pega_Implementation_Spec.md`
- `04_TOOLS/Required_Runtime_Tools.md`
- all three prompts only where they parse/describe Memory responses or signatures; behavioral handoff changes remain for R10-R12.

**Mandatory validation R9:**
- positive Write/Get/Update success fixtures use response `CaseID` and exact runtime types/wrappers;
- any active response parser requiring `pxCaseID` fails the stage;
- input-side `pxCaseID` references are classified explicitly as tool arguments, not mistaken for stale response fields;
- Get/Update round-trip preserves exact `ProcessingFeedback`, including `""` and multiline LF-delimited text;
- Update changes only lifecycle/router/feedback plus implementation-owned timestamp; payload/identity remain immutable;
- textual census across prompts/contracts shows exact spelling/casing `ProcessingFeedback` everywhere and no `ValidationFeedback` alias.

#### R9 execution result — PASS

- Memory contract/spec now use response `CaseID`; `pxCaseID` remains input/storage-side only.
- Added persisted Text `ProcessingFeedback`, create default `""`, exact Get response field, and atomic Update input/echo.
- Write/Get/Update positive fixtures and alias/type-negative fixtures PASS.
- LF-delimited feedback round-trip and exact empty-string clearing fixture PASS.
- Active Generator/Validator response parsers require `CaseID`, not response `pxCaseID`; exact `ProcessingFeedback` casing is synchronized and `ValidationFeedback` aliases are absent.
- R9 change surface is limited to the three Memory/runtime contract files, the three prompts where Memory response/signature parsing is described, and this tracker.
- `TEXT_SEMANTIC_ONLY=true`; no hash/checksum/fingerprint validation was used.

### R10 — Make Validator the authoritative Candidate-state writer

**Goal:** stop using Validator assistant text as a data contract.

1. Add exactly one allowed `UpdateMemory` call after Validator completes all checks for the current Candidate.
2. Validator derives its final internal issue set and route as today, then materializes `ProcessingFeedback` from issues in validation order, one issue per LF line.
3. Validator writes exactly one Candidate terminal state using the frozen matrix above.
4. `OK` MUST write `Passed/OK/""`; any non-OK state MUST be `Failed` with nonempty feedback.
5. Candidate `pyPayload`, `pyType`, `pyGroup`, GUID and case identity remain immutable.
6. Remove Validator's authoritative `ValidatorReport` response responsibility. Assistant response after a confirmed state update is non-authoritative transport noise and must contain no information required by Generator.
7. If `UpdateMemory` is unconfirmed, Validator does not retry. Candidate remains without a confirmed terminal validation state; Generator detects that through fresh `GetMemory`.

**Owned file:** `01_PROMPTS/Validator_SystemPrompt.txt` plus R9 tool-contract references only if required.

**Mandatory validation R10:**
- zero issues → exact `Passed + OK + ""`;
- one/multiple repair issues → exact `Failed + GENERATOR_REPAIR + newline-delimited feedback`;
- HUMAN and SEMANTIC_REJECT fixtures use exact routes and nonempty feedback;
- stale feedback is explicitly cleared on success;
- `;` is not used as issue delimiter;
- Validator has no downstream-critical result encoded only in assistant response;
- no replacement semantic value appears in feedback.

#### R10 execution result — PASS

- Validator Candidate/Projection payloads remain read-only; Validator now owns exactly one terminal Candidate `UpdateMemory`.
- Final route maps to `Passed/OK/""` or `Failed/<non-OK>/<nonempty ProcessingFeedback>`.
- Feedback uses one issue per LF line with exact code/scenario/path/message grammar; `;` is not an item delimiter and replacement semantic values remain forbidden.
- Update confirmation requires exact `CaseID`, Candidate GUID, status, `RouterKey`, and exact feedback echo; stale feedback is cleared on success.
- Validator assistant response is explicitly non-authoritative and carries no downstream-required state.
- OK, one/multiple repair, HUMAN and SEMANTIC_REJECT fixtures PASS.
- `TEXT_SEMANTIC_ONLY=true`; no hash/checksum/fingerprint validation was used.

### R11 — Make Generator consume Validator state only from Candidate Memory

**Goal:** replace `ValidatorReport` parsing with fresh exact-row state read.

1. After every `UnitTestValidator(question)` call, ignore its returned `response` string completely; never parse, inspect, regex, substring-extract, or use it for repair.
2. Immediately call fresh `GetMemory` for the exact current Candidate GUID.
3. Require exact `CaseID`, GUID, type, group correlation and the Candidate lifecycle matrix.
4. `Passed/OK/""` completes that Candidate version.
5. `Failed/GENERATOR_REPAIR/nonempty feedback` parses LF-delimited Validator feedback and applies only repairs authorized by the synchronized issue catalog and existing repair budget.
6. `Failed/HUMAN` and `Failed/SEMANTIC_REJECT` are terminal for the current Generator run.
7. Empty/pending/unknown status, invalid route/feedback combination, stale nonempty feedback on OK, malformed feedback line, or Candidate read failure is fail-closed; do not fall back to agent response text.
8. Generator no longer performs Candidate lifecycle `UpdateMemory`; Validator owns that row's validation state.

**Owned file:** `01_PROMPTS/UnitTestGenerator_SystemPrompt.txt`.

**Mandatory validation R11:**
- the supplied prose-heavy Validator response is ignored and cannot affect routing;
- same prose response + Candidate `Passed/OK/""` → accepted;
- same prose response + Candidate repair state → repairs come only from `ProcessingFeedback`;
- two feedback lines preserve order and are separately classified;
- invalid issue code/path/route combination fails closed;
- successful repaired Candidate has empty feedback after Validator's next successful update;
- no active Generator dependency remains on ValidatorReport JSON/framing/count fields.

#### R11 execution result — PASS

- Generator ignores delegated Validator `response` completely and performs one fresh exact Candidate `GetMemory` after every Validator invocation.
- Candidate lifecycle acceptance is closed to `Passed/OK/""`, `Failed/GENERATOR_REPAIR/nonempty`, `Failed/SEMANTIC_REJECT/nonempty`, or `Failed/HUMAN/nonempty`.
- LF feedback parser validates code/scenario/path/message, preserves order, rejects duplicates/malformed lines, and recomputes route from the synchronized catalog.
- Generator performs no Candidate lifecycle `UpdateMemory`; Validator is sole Candidate state writer.
- Prose response, perfect-JSON response with invalid Memory state, two-line repair feedback, stale feedback, unknown code and route mismatch fixtures PASS.
- Obsolete `VALIDATOR_RESPONSE_INVALID`/Candidate lifecycle merge dependencies were removed from Generator.
- `TEXT_SEMANTIC_ONLY=true`; no hash/checksum/fingerprint validation was used.

### R12 — Replace GeneratorRunReport with Projection Memory handoff to Author

**Goal:** make Generator→Author use the same stateful pattern as Validator→Generator.

1. Generator uses `UpdateMemory` only for the original `UnitTestProjectionV3` terminal handoff to Author.
2. On terminal success write Projection `Passed + OK + ""`.
3. On semantic rejection write `Failed + SEMANTIC_REJECT + nonempty ProcessingFeedback`.
4. Any terminal condition requiring operator/intervention, including unrecoverable Generator/tool/contract failure after a safely correlated Projection read, writes `Failed + HUMAN + nonempty ProcessingFeedback`.
5. Generator's assistant response becomes non-authoritative and may not carry information required by Author.
6. ScenarioAuthor adds exact post-Generator `GetMemory` of the Projection GUID, ignores Generator assistant response, and requires exact `CaseID`, GUID/type/group plus one valid Projection terminal combination.
7. Only `Passed/OK/""` permits Author to advance to the next frozen physical group. Any failed terminal state stops; `GENERATOR_REPAIR` on Projection is invalid because repair is internal to Generator.
8. If no terminal Projection state is confirmed after Generator returns, Author fails closed rather than interpreting Generator prose.

**Owned files:**
- `01_PROMPTS/UnitTestGenerator_SystemPrompt.txt`
- `01_PROMPTS/ScenarioAuthor_SystemPrompt.txt`

**Mandatory validation R12:**
- successful Generator run updates exact Projection row and Author advances only after fresh read;
- semantic reject and HUMAN stop Author with feedback preserved;
- arbitrary/narrative Generator response has zero effect;
- wrong GUID/group/type/CaseID or nonterminal Projection state blocks next group;
- Author never reads Candidate payload/state directly;
- Generator repair loop remains invisible to Author.

#### R12 execution result — PASS

- Generator uses `UpdateMemory` only for terminal state on the exact original Projection; Candidate lifecycle remains Validator-owned.
- Generator success writes `Passed/OK/""`; semantic reject writes `Failed/SEMANTIC_REJECT/<feedback>`; other safely correlated terminal failures write `Failed/HUMAN/<feedback>`.
- Projection feedback is exactly one `<GENERATOR_CODE> | <short message>` line; `GENERATOR_REPAIR` is forbidden on Projection.
- ScenarioAuthor ignores Generator response, performs one exact post-Generator Projection `GetMemory`, verifies CaseID/GUID/type/group/payload and accepts only the closed terminal matrix.
- Arbitrary prose, response-claims-success with blank/failed state, semantic reject, HUMAN, wrong correlation, stale feedback and invalid Projection repair-state fixtures PASS.
- Author never reads Candidate Memory and Generator repair remains invisible upstream.
- `TEXT_SEMANTIC_ONLY=true`; no hash/checksum/fingerprint validation was used.

### R13 — Remove obsolete response-report transport

**Goal:** leave one inter-agent transport mechanism only: Memory state.

1. Remove active `ValidatorReport` response schema/adapter flow from Validator, Generator and runtime-tool documentation.
2. Delete `04_TOOLS/ValidatorReport_JsonSchema.txt` from the active bundle after all consumers are removed; update `README.md` accordingly.
3. Remove `GeneratorRunReport` as Author↔Generator transport; Author uses Projection Memory terminal state only.
4. Remove instructions that require parsing delegated agent `response` fields for semantic/lifecycle data.
5. Keep agent assistant-response formatting only as cosmetic/token-efficiency guidance, never as a correctness boundary.

**Owned files:**
- `01_PROMPTS/ScenarioAuthor_SystemPrompt.txt`
- `01_PROMPTS/UnitTestGenerator_SystemPrompt.txt`
- `01_PROMPTS/Validator_SystemPrompt.txt`
- `04_TOOLS/Required_Runtime_Tools.md`
- `README.md`
- delete `04_TOOLS/ValidatorReport_JsonSchema.txt` only after textual consumer census is zero.

**Mandatory validation R13:**
- no active prompt/tool contract references `ValidatorReport_JsonSchema`, `valid ValidatorReport`, report substring parsing, or `GeneratorRunReport` handoff;
- no consumer uses delegated `response` text as authoritative data;
- all route/feedback ownership is represented by Memory lifecycle fields;
- deletion of the ValidatorReport schema occurs only after all active references are removed.

#### R13 execution result — PASS

- Removed active ValidatorReport structural adapter/runtime contract and deleted `04_TOOLS/ValidatorReport_JsonSchema.txt` after consumer census reached zero.
- Removed README indexing of the obsolete report schema and replaced runtime documentation with the Memory-state inter-agent boundary.
- No active prompt/tool contract references `ValidatorReport`, `GeneratorRunReport`, report substring parsing, or `VALIDATOR_RESPONSE_INVALID`.
- Delegated assistant response text is explicitly non-authoritative at both handoffs; lifecycle/feedback ownership is entirely represented by Memory fields.
- `TEXT_SEMANTIC_ONLY=true`; no hash/checksum/fingerprint validation was used.

### R14 — Full synchronization and static end-to-end replay

**Goal:** prove that every prompt and tool contract speaks the same lifecycle protocol.

**Exact cross-file census must prove:**
- Memory response case field is exactly `CaseID` everywhere; response `pxCaseID` is absent;
- input `pxCaseID` remains only where it is the actual tool argument name;
- field name is exactly `ProcessingFeedback` everywhere; `ValidationFeedback`, `processingFeedback`, `pyProcessingFeedback`, etc. are absent;
- Candidate state owner = Validator; Candidate state consumer = Generator;
- Projection state owner = Generator; Projection state consumer = Author;
- `pyPayload` remains immutable on both artifact types;
- `RouterKey` response vs `pyRouterKey` input distinction remains consistent;
- success always clears feedback to exact `""`;
- failed/non-OK state always has nonempty feedback;
- newline is the only inter-item feedback delimiter; no semicolon-list contract remains;
- Generator and Author ignore delegated downstream agent response text;
- no ValidatorReport/GeneratorRunReport response transport remains active.

**Mandatory replay fixtures:**
1. Validator returns long prose but writes Candidate `Passed/OK/""` → Generator accepts from Memory only.
2. Validator returns perfect JSON but Candidate state is blank/invalid → Generator rejects; response cannot rescue it.
3. Validator writes two repair feedback lines → Generator reads both in order and applies only catalog-authorized repair.
4. Revalidation succeeds → Candidate feedback is cleared to `""` and stale prior text cannot survive.
5. Generator returns arbitrary prose but Projection is `Passed/OK/""` → Author advances.
6. Generator response says success but Projection is blank/failed → Author stops.
7. Generator semantic reject → Projection `Failed/SEMANTIC_REJECT/<feedback>` → Author stops without inspecting Candidate.
8. Generator internal repair never appears as Projection `GENERATOR_REPAIR`.
9. Wrong `CaseID`, GUID, group, type, router/status/feedback combination at either handoff fails closed.
10. Standard and MultiInput candidate generation/naming from R2-R8 remains unchanged by this lifecycle refactor.

**R14 completion condition:** all static fixtures PASS under `TEXT_SEMANTIC_ONLY=true`, and only then mark the bundle internally synchronized. Fresh live Pega redeploy/replay remains separate external evidence and must not be claimed by static validation.

#### R14 execution result — PASS

- Final cross-file synchronization/replay suite: **88/88 PASS**.
- Exact response field is `CaseID`; input `pxCaseID` remains only input/storage-side terminology, not a response parser key.
- `ProcessingFeedback` spelling/casing is synchronized; no `ValidationFeedback`/case aliases remain.
- Candidate owner/consumer is Validator -> Generator; Projection owner/consumer is Generator -> ScenarioAuthor.
- Validator and Generator share the same exact 14 issue-code/action mappings; Generator reconstructs route from feedback codes and never trusts assistant response text.
- Prose-vs-Memory, perfect-JSON-vs-invalid-Memory, two-line repair order, stale-feedback clearing, Generator-prose-vs-Projection-state, semantic reject, invalid Projection repair-state, and wrong CaseID/GUID/group/type/status/router/feedback fixtures all PASS.
- Standard and MultiInput JsonSchema/JsonExample pairs validate; all R8 target schemas/examples/Knowledge Areas are textually unchanged, preserving `TC_CityNotValidExit`-style naming and prior R2-R8 target behavior.
- R14 cleanup removed leftover report-only `blocking/warnings/severity` transport language and synchronized the literal canonical `UpdateMemory(pxCaseID,pyGUID,pyStatusValue,pyRouterKey,ProcessingFeedback)` signature across prompts/tool docs.
- `TEXT_SEMANTIC_ONLY=true`; validation used direct text/JSON/schema/fixture semantics only, with no SHA/MD5/CRC/checksum/content-fingerprint/hash-based equality.
- **External evidence still required:** deploy the updated Memory property/tool contract and prompts in live Pega, then run a fresh end-to-end model/runtime replay.


---

### Execution protocol after approval

When implementation is approved for a fresh rebuild, the historical R0-R8 cycle is complete. For this new lifecycle cycle execute strictly `R9 -> R10 -> R11 -> R12 -> R13 -> R14`. After each stage:

1. change only that stage's owned files;
2. run its mandatory validation using direct textual semantic/structural inspection only (`TEXT_SEMANTIC_ONLY=true`);
3. record `PASS`/`BLOCKED` plus concise textual evidence in this tracker;
4. stop immediately on `BLOCKED` and do not start the next stage;
5. do not rewrite earlier stage intent silently; any required scope change must be recorded here before continuing.

## R15 — Semantic-preserving token optimization — COMPLETE / PASS (STATIC)

**Constraint:** R15 changes prompt representation only. Runtime architecture, ownership, target contracts, Knowledge Areas, Memory contract, naming, lifecycle states and semantic behavior from R0-R14 remain unchanged. Validation uses direct text/structure/fixture semantics only under `TEXT_SEMANTIC_ONLY=true`; no SHA/MD5/CRC/checksum/content fingerprint/hash-based equality.

### R15.1 — Compact repeated Memory framing — PASS
- Defined each Memory success shape once per consuming prompt (`MEM_GET_OK`, `MEM_WRITE_OK`, `MEM_UPDATE_OK` as applicable); call sites now add only local correlation/echo constraints.
- Preserved exact response `CaseID`, input `pxCaseID`, `RouterKey`/`pyRouterKey`, `ProcessingFeedback`, wrapper names and boolean/string `IsSuccess` types.
- Gate: **29/29 PASS**; no lifecycle/ownership change.

### R15.2 — Compact synchronized issue catalogs — PASS
- Replaced repeated prose lists with closed tables carrying exact `CODE | ACTION | OWNER/GENERATOR CLASS`.
- Generator and Validator retained the same code/action census and route precedence.
- Gate: exact 14/14 catalog equality before dead-branch removal.

### R15.3 — Remove unreachable validation branches — PASS
- Removed active `JSON_SCHEMA_INVALID`, `JSON_SCHEMA_MASS_FAILURE`, `FIX_JSON`, and `REBUILD_JSON_FROM_PROJECTION` because the deployed JsonValidation non-success shape remains `UNVERIFIED_RUNTIME_SHAPE` and cannot safely produce those dispositions.
- Active catalog is now 12 reachable codes. Every remaining code has Validator producer/reference evidence and Generator consumer coverage.
- Any non-success/nonconforming JsonValidation result remains `JSON_VALIDATION_TOOL_ERROR/HUMAN_REVIEW` until live evidence defines another shape.

### R15.4 — Closed positive invariants for external actions — PASS
- Replaced repeated tool prohibitions in Author/Generator/Validator with closed external-action tables plus local invariants.
- Preserved exact tool cardinality/scope, no-retry-on-uncertainty policy, payload immutability, Candidate writer ownership, Projection writer ownership, and Validator semantic-Knowledge exclusion.
- Local high-risk prohibitions remain where they convey distinct semantics.

### R15.5 — ScenarioAuthor §2–§4 semantic compression — PASS
- Reworked dependency closure, semantic execution and Scenario Compiler into denser tables/state invariants while preserving all subsection identities `§2.1–§4.7` and downstream references.
- Preserved every legacy uppercase/state identifier used in those sections, including DWL/STATECHECK/RUF/DP/CAST/RX/producer/Decision Table/Scenario Compiler/cap/error identifiers.
- Restored exact examples/labels where compression would reduce clarity (`OUT=12/ACT=12`, helper-call examples, `PLAN_MISS`, cap codes, KRUF reference, conversion synonyms, `Code-Pega-List`, navigation-depth formula, KDT records, etc.).
- Semantic coverage gate: **133/133 PASS**; subsection heading sequence is identical.
- §2–§4 word count reduced by about **42.5%** without removing a checked semantic invariant.

### R15.6 — Full cross-bundle semantic regression — PASS
- Final static suite: **172/172 PASS**.
- Both Standard/MultiInput JSON Schemas are valid Draft 2020-12 and both canonical examples validate.
- R2-R14 behavior remains intact: no Projection `singlePage`; `Gnnn` correlation-only; PascalCase `TC_CityNotValidExit` naming; target-only `pyIsSinglePageImplementation`; exact Memory state handoffs; LF `ProcessingFeedback`; Candidate owner Validator -> Generator; Projection owner Generator -> Author; downstream assistant response ignored; DWL `OUT==ACT`; Validator target-only Knowledge matrix; stale-feedback clearing and fail-closed lifecycle matrices.
- All `02_KNOWLEDGE_AREAS`, `03_TARGET_CONTRACTS`, `04_TOOLS`, and `README.md` are direct-text identical to the R14 input bundle; only the three prompts and this tracker changed in R15.

### R15 size result (word-count proxy, not Claude tokenizer count)

| Prompt | R14 words | R15 words | Change |
|---|---:|---:|---:|
| ScenarioAuthor | 12,695 | 8,675 | -31.7% |
| Generator | 3,820 | 3,752 | -1.8% |
| Validator | 3,353 | 3,225 | -3.8% |
| **Total** | **19,868** | **15,652** | **-21.2%** |

ScenarioAuthor bytes: 101,368 -> 74,291. Generator: 33,742 -> 32,699. Validator: 29,146 -> 27,921. These are direct file-size/word proxies only; no claim is made about exact Claude Opus tokenization.

**R15 conclusion:** prompt density and instruction salience improved without an intended behavioral change. Fresh live Pega/Claude Opus runtime replay remains external evidence and is not claimed by this static refactor.



## R18 — Data Page simulation/page projection stabilization — COMPLETE / PASS (STATIC)

**Scope:** preserve already-resolved page/class facts across ScenarioAuthor -> UnitTestProjectionV3 -> Generator. No new dependency analysis is added to Generator. Validation is direct textual/structural/semantic review; no fixtures were created/updated and no hash/checksum/fingerprint acceptance checks were used.

1. **Author simulation projection — PASS:** simulation setup source changed from `{name,data}` to `{class,data}`; root class is explicit, resolved nested Page/PageList/PageGroup instances retain `pxObjClass`, and old simulation setup-page `name` source grammar is absent.
2. **Runtime named pages — PASS:** frozen non-primary pages used by setup/action/assertion/CTX must be copied to Projection `pages`; runtime page names are forbidden as Data Page simulation setup identity.
3. **Generator/Knowledge mapping — PASS:** Generator source grammar matches `{class,data}`; Standard and MultiInput mappings deterministically emit `pySetupPageName="PrimaryPage"` and `pyPageDetails={pxObjClass:class,...data}` while preserving nested payload.
4. **Target schema — PASS:** both target schemas are valid JSON; simulation `pySetupPageName` is `const PrimaryPage`; root simulation `pyPageDetails.pxObjClass` is required; both existing canonical examples validate unchanged.
5. **Cross-bundle semantic pass — PASS:** no active competing `{name,data}` simulation-source contract or "preserve Projection page name" simulation rule remains. Live Pega/Claude replay is external evidence and is not claimed here.


## R19 — schema-owned target compiler migration

Static validation only. Moved normative executable Projection->Candidate mapping from `Rule-Test-Unit-Case*_KnowledgeArea` into selected JsonSchema `x-ruleiq-compilerMappings`; removed those target KnowledgeArea artifacts and runtime acquisition from Generator/Validator. Both schemas parsed; canonical examples remained schema-valid; contextual searches found no active target-KnowledgeArea dependency. JsonExamples unchanged. No fixtures or SHA/hash/checksum/fingerprint acceptance gates. Live Pega replay remains pending.


## R20 — JsonExample illustration-library migration (2026-09-15)

Static validation only; no live Pega/Claude runtime replay.

- Both executable JsonExample files parse as one `{Template,Examples[]}` JSON object.
- Standard Examples: no-simulation, Page DP, List DP — 3/3 pass Standard Draft-2020-12 schema.
- MultInpComb Examples: no-simulation, Page DP, List DP — 3/3 pass MultInpComb Draft-2020-12 schema.
- Page examples use `PrimaryPage`, root `pxObjClass`, and grounded nested page class metadata.
- List examples preserve `Code-Pega-List`, `pyObjClass`, and per-item `pxObjClass`.
- Simulation data is causally referenced by each example RUT/result narrative; synthetic identifiers use `ZqxExample-*`.
- Generator treats `Examples[]` as non-authoritative HOW-only illustration; Validator ignores `Examples[]` as validation evidence.
- ScenarioAuthor and both production JsonSchema files are unchanged.

## R24 — KnowledgeArea references + compatibility audit
- Added verbatim reference files: Rule-Obj-Model, Rule-Declare-Pages, Rule-Declare-DecisionTable.
- Runtime prompts, target schemas and JsonExamples remain byte-identical to R23.
- Static validation: 29/29 compatibility/contract checks passed; all 6/6 JsonExample candidates validate against Draft-2020-12 production schemas.
- Compatible: Rule-Declare-Pages semantics; Rule-Obj-Model runtime CTX/Primary/UPDATE_PAGE/APPEND_AND_MAP_TO semantics align with R22/R23 assertion-page provenance.
- Review required before literal runtime use: Rule-Obj-Model KT.29 target-JSON scope leak; Rule-Declare-DecisionTable target-facing KDT clauses requiring final RuleCode/candidate inspection conflict with ScenarioAuthor's no-Candidate/RuleCode boundary while ScenarioAuthor also requires KDT.4-KDT.12.
- Rule-Obj-Model KT.2 lexicographic pyPropertyStepId execution ordering is not contradicted by the current prompt and therefore needs separate runtime verification before treating it as trusted execution semantics.


## R25 — Rule-Utility-Function KnowledgeArea reference integration

- Added `02_KNOWLEDGE_AREAS/Rule-Utility-Function_KnowledgeArea_REFERENCE.txt` verbatim from supplied source.
- Runtime ScenarioAuthor/Generator/Validator prompts, both target schemas, and both JsonExamples unchanged from R24.
- Compatibility audit: KRUF.0-13 aligns with current ScenarioAuthor RUF identity, request, concrete-contract, transitive dependency, helper, unknown-return, and closure behavior.
- Recorded one soft duplication risk: ScenarioAuthor repeats KRUF.1/KRUF.4 exact RUF request-shape/source-gate details although KRUF.0 declares those KnowledgeArea-owned. Current wording is consistent; no runtime conflict.
- R24 Model/Decision Table boundary conflicts remain unresolved and unchanged.
- Static worktree validation: PASS; runtime prompts/schemas/examples byte-identical to R24, RUF reference verbatim, both schemas valid, 6/6 examples valid, KRUF contract checks PASS. Post-package ZIP validation also required.


## R31 — Data Page simulation census / projection closure — COMPLETE / PASS (STATIC)

**Observed defect:** `PXCONV-163039` persisted two executable Standard Projections whose metadata claimed `D_CustomerTestRef` simulation while physical `simulations[]` was absent. The defect occurs at ScenarioAuthor Projection materialization, before Generator.

- Added final Scenario `REQUIRED_SIMS` derived from RX `dpRefs`: evaluated/unknown access is required; false guard keeps the evaluated Data Page; action skip is irrelevant; only terminally proven `notEvaluated` occurrences are excluded.
- Each required DP_SIG freezes exactly one internal SIM and no extra SIM.
- External Projection simulation shape remains `{runtimeClass,rule,setupPages}`. `SIM_WIRE` maps frozen SIMs to `REQSIM`; final physical `simulations[]` maps to `ACTSIM`; exact ordered `REQSIM==ACTSIM` is mandatory.
- `simulations` is absent iff REQSIM is empty; otherwise it is required. `simulationsNarrative` is derived only from physical simulations.
- PREPARE_ALL cannot pass if the simulation census fails; persistence/generation therefore cannot begin for the observed defect.
- Runtime delta from R30: ScenarioAuthor only. Generator, Validator, all KnowledgeAreas, schemas/examples and tools unchanged.
- Validation: 28/28 focused static checks PASS; 12/12 adversarial cases PASS; observed G001/G002 defect rejected 2/2; four target JSON files parse; 6/6 examples Draft-2020-12 schema-valid.
- ScenarioAuthor word proxy: 9,332 -> 9,524 (+192, ~2.1%). No fixtures or hash/SHA/checksum/fingerprint acceptance gates used.
- Live Pega/Claude Opus 4.8 replay remains external evidence and is not claimed.
