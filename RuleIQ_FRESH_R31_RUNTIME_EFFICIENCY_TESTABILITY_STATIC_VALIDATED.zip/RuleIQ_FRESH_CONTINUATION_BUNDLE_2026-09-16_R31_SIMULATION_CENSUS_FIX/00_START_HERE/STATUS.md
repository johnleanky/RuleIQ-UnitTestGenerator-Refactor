# RuleIQ Unit Test Pipeline — Current Status

**Bundle date:** 2026-09-16  
**Current release:** R31  
**Authority:** this bundle is the sole current project version. `STATUS.md` describes only active behavior. `00_START_HERE/VALIDATION_HISTORY.md` is historical/non-authoritative.

## Current architecture

- **Scenario Author** owns RUT semantics, dependency closure, Scenario Compiler `I -> W -> F -> B -> A`, physical grouping and immutable `UnitTestProjectionV3` source materialization.
- **Unit Test Generator** deterministically compiles one persisted Projection into Candidate versions, owns Candidate repair/retry orchestration, consumes Validator outcome only from exact Candidate Memory state, and writes the terminal Generator outcome only to the exact source Projection lifecycle fields.
- **Validator** independently reads the exact Projection + Candidate, validates schema/fidelity/target invariants without redefining Author semantics, and is the sole writer of Candidate validation lifecycle state.
- Delegated Agent assistant responses are non-authoritative. Generator returns exactly `ACK`; Author ignores it. Memory row state is the correctness boundary.

## Exact case identity

`CASE_ID_RAW` is opaque case-sensitive text.

- Author owner: exact `application_context.caseID`.
- Generator owner: exact `Invocation.CaseID` received from Author.
- Validator owner: exact `Invocation.CaseID` received from Generator.
- Every Memory `pxCaseID`, Validator `JsonValidationTool.CaseID`, and delegated Agent Invocation `CaseID` must preserve `CASE_ID_RAW` character-for-character.

Example: if `application_context.caseID` is `RULEIQ-WORK GENUT-91061`, that exact full value must propagate; bare `GetCaseData.pyID=GENUT-91061` is not an equivalent Memory/transport CaseID.

## Current execution order

```text
Global dependency closure + semantic execution
-> I -> W -> F
-> freeze complete physical group set
-> B -> A; require A=PASS

PREPARE_ALL
-> materialize + self-validate one complete UnitTestProjectionV3 per frozen group
-> require exact group/projection census
-> zero Memory writes / zero Generator calls on preparation failure

PERSIST_ALL
-> WriteMemory every prepared Projection in frozen order
-> freeze ordered PROJECTION_QUEUE(groupId, projectionPayload, projectionGUID, PENDING)
-> require exact census and distinct nonempty GUIDs
-> any write/correlation/census failure stops the run with zero Generator calls

GENERATE_ALL
-> NEXT = first PENDING queue row
-> invoke Generator exactly once; ignore assistant response
-> fresh GetMemory(exact Projection GUID)
-> Passed + OK + ProcessingFeedback="" => PENDING -> DONE
-> otherwise stop Failed; later persisted Projections remain unchanged/unprocessed
-> continue until no PENDING row remains

COMPLETE
-> legal only when DONE_COUNT == QUEUE_COUNT and PENDING_COUNT == 0
```

No UnitTestGenerator call is legal until **all** frozen physical groups have successfully persisted Projections. This makes the full ScenarioAuthor output set materially visible in Agent Memory before downstream generation begins.

## Active Memory / lifecycle contract

- Tool input case argument remains `pxCaseID`; successful Memory responses use `CaseID`.
- Canonical lifecycle fields: `pyStatusValue`, response `RouterKey`, input `pyRouterKey`, and `ProcessingFeedback`.
- Success terminal state requires exact `ProcessingFeedback=""`; failed/non-OK state requires nonempty feedback.
- `pyPayload`, identity, type, group, GUID and case ownership are immutable after create.
- **Candidate lifecycle owner:** Validator; **consumer:** Generator.
- **Projection terminal lifecycle owner:** Generator; **consumer:** Scenario Author.
- `GENERATOR_REPAIR` is internal to Generator <-> Validator and is invalid on Projection.

## Active Projection / target invariants

- Source `UnitTestProjectionV3.rut` has `{name,applyToClass}` only; source-side `singlePage` is absent.
- Every frozen non-primary runtime page used by setup/action/assertion/CTX is emitted in Projection `pages` with its grounded class and becomes `pyPagesAndClasses` downstream.
- Assertion page context is provenance-locked: `Primary.*` resolves from ROOT; leading-dot paths resolve through active rule-defined runtime CTX. Every non-Param assertion derives its base from final CTX/APB; non-primary assertions require exact `page` plus the matching grounded `Projection.pages` binding, and assertion-kind conversion cannot change owner page.
- Data Page simulation setup source is `{class,data}`; root `data` omits `pxObjClass`, while resolved nested Page/PageList/PageGroup instances retain exact `pxObjClass`.
- Scenario Data Page simulation is RX-driven: final `REQUIRED_SIMS` contains stable unique DP_SIGs for linked accesses with `evalState=evaluated|unknown`; a false guard still requires the Data Page used to evaluate it, while only terminally proven `notEvaluated` occurrences are excluded. Each required signature has exactly one frozen SIM.
- Projection simulation presence is conditional and census-locked: `REQSIM=[]` iff `simulations` is absent; otherwise physical `ACTSIM` must exactly equal frozen `REQSIM`. `simulationsNarrative` is derived only from the physical simulation set.
- Generator serializes every Data Page simulation setup with fixed `pySetupPageName="PrimaryPage"` and `pyPageDetails.pxObjClass=class`; it does not infer classes.
- Physical `pyIsSinglePageImplementation` is target-owned.
- `physicalGroupKey/Gnnn` is correlation/group identity only and never participates in target naming.
- `CM-NAME-001` derives separator-free `TC_` names only from semantic labels, e.g. `City Not Valid Exit -> TC_CityNotValidExit`.
- ScenarioAuthor is occurrence-driven: executable scan evidence creates each D occurrence with immutable `src.holder`; each READY KEY is requested through its first eligible source occurrence, so `pyItemRuleId=that occurrence's src.holder`. `pxRuleReferences[]` is identity/materialization lookup for scan-created work, not the crawl inventory.
- RuleCrawler reference shape is kind-discriminated before physical census: non-RUF is exact five-key `NON_RUF_REF`; RUF is exact four-key `RUF_REF` and `pxRuleClassName` must be absent (empty/null is invalid).
- Executable target compilation is schema-owned: Generator/Validator request only selected JsonSchema + JsonExample; target KnowledgeArea is not part of runtime.
- JsonExample envelope is `{Template,Examples[]}`: `Template` alone owns `pyRuleSet`/`pyRuleSetVersion`; `Examples[]` is non-authoritative serialization illustration. `Examples[0]` preserves the pre-R20 coverage-rich Standard/MultInpComb canonical example; `Examples[1]` and `[2]` add causally coupled Page-DP and List-DP simulation candidates.
- Semantic RUT/dependency Knowledge Areas remain ScenarioAuthor-only.


## Active semantic KnowledgeArea references

Current bundle contains semantic references for `Rule-Obj-When`, `Rule-Obj-Model`, `Rule-Declare-Pages`, `Rule-Declare-DecisionTable`, and `Rule-Utility-Function`; ScenarioAuthor is their only runtime consumer. R26 resolved the R24/R25 ownership conflicts; R27 made KDT evidence routing deterministic. R28/R29 explored explicit holder auditing. R30 simplifies this to the older stable occurrence-driven model: scan evidence creates D work and its source holder directly drives request grouping; RUF exact-shape protection remains.

- Model KT.11/KT.12 no longer mix test-target parameter fields into Model RuleJSON semantics; KT.26 emits semantic error-ASSERT intent; KT.29 emits PAGE source/setup obligations only and leaves target serialization downstream.
- Decision Table KDT.6/KDT.11/KDT.12 now stop at semantic setup/evidence/ASSERT-OMIT obligations. KDT.12 is a pre-Projection audit; no KDT rule reads, builds or repairs Candidate/RuleCode. DTM/DTA/DTE, OR/raw-pyRowNum, range, inverse-seed, inactive-scalar and existence semantics are retained.
- KRUF.0 ownership split remains; R30 aligns KRUF terminology with READY-occurrence selection while retaining exact four-key RUF request shape and immutable invocation-holder provenance.
- Rule-Declare-Pages and Rule-Obj-When KnowledgeAreas are unchanged from R25.

## Active issue / repair behavior

- Validator and Generator share one closed active catalog with **12 reachable codes**.
- JsonValidation non-success shapes remain unverified and fail closed through `JSON_VALIDATION_TOOL_ERROR/HUMAN_REVIEW`.
- Validator writes Candidate lifecycle; Generator ignores Validator assistant response and fresh-reads Candidate Memory.
- Generator returns exactly `ACK`; Author ignores it and fresh-reads Projection Memory.

## Validation state

**Historical static baseline:** `R0-R16 PASS (STATIC)`  
**R15 final regression:** `172/172 PASS`  
**R15 ScenarioAuthor §2-§4 semantic coverage:** `133/133 PASS`  
**R16 core semantic/regression suite:** `139/139 PASS`  
**R16 final cross-bundle synchronization gate:** `147/147 PASS`  
**R17 CaseID-source validation:** `PASS (contextual/textual semantic review)`  
**R18 simulation/page materialization validation:** `PASS (static semantic/schema review; live Pega replay pending)`
**R19 schema-owned target compiler validation:** `PASS (static semantic/schema review; live Pega replay pending)`  
**R20 JsonExample illustration-library validation:** `PASS (6/6 example candidates schema-valid; static semantic review; live Pega replay pending)`  
**R21 restored-coverage example validation:** `PASS (6/6 candidates schema-valid; restored Examples[0] equal R19 content by direct structural comparison)`  
**R23 merged metadata + R22 assertion-page provenance validation:** `PASS (static semantic regression + supplied live PXCONV-160066 acceptance analysis; fresh live Pega replay pending)`  
**R24 KnowledgeArea reference integration:** `PASS (Rule-Obj-Model/Rule-Declare-Pages/Rule-Declare-DecisionTable added verbatim; compatibility audit recorded; runtime prompts unchanged)`  
**R25 RUF KnowledgeArea reference integration:** `PASS (Rule-Utility-Function added verbatim; KRUF contract compatible with current RUF flow; runtime prompts unchanged)`  
**R26 semantic KnowledgeArea boundary cleanup:** `PASS (65/65 static architecture/semantic checks; 6/6 target examples schema-valid; later 31-stage audit found one wording precision issue)`  
**R27 R26-audit closure:** `PASS (31/31 planned stages satisfied; runtime delta from R26 is one deterministic ScenarioAuthor wording replacement; 6/6 examples schema-valid; fresh live Pega replay pending)`  
**R28 RuleCrawler holder-provenance repair:** `PASS (17/17 focused static contract/adversarial checks; holder-collapse/wrong-holder/missing/extra cases rejected; ScenarioAuthor 9212 -> 9283 words; live Pega replay pending)`  
**R29 RuleCrawler source/shape repair:** `STATIC PASS; subsequent live replay showed the planning model still overused root metadata/holder`  
**R30 occurrence-driven RuleCrawler:** `PASS (25/25 focused static/adversarial checks; 6/6 examples schema-valid; ScenarioAuthor 9502 -> 9332 words; live Pega/Opus replay pending)`  
**Analysis mode:** `TEXT_SEMANTIC_ONLY=true`

R23 preserves all R22 assertion-page provenance behavior and adds only Scenario UI metadata plus required RuleCode target metadata/constants:
- remove the contradictory global `leading-dot -> ROOT` rule; `Primary.*` remains ROOT while relative paths follow active rule-defined CTX;
- add one `ASSERT_PAGE_CONTEXT` owner across Property/Page/List/ResultCount; non-primary `page` and matching `Projection.pages` class binding are mandatory;
- pre-projection validation compares each non-Param assertion to final CTX/APB provenance and forbids ROOT rebasing repair;
- Generator, Validator, both production schemas, and both JsonExample libraries are unchanged from R21.

R22 prompt word-count proxy versus R21 remains historical context; R23 additionally extends Scenario metadata contracts and deterministic target mappings.

| Prompt | R21 | R22 | Delta |
|---|---:|---:|---:|
| ScenarioAuthor | 8,934 | 9,095 | +161 |
| Generator | 3,289 | 3,289 | 0 |
| Validator | 2,846 | 2,846 | 0 |
| **Total** | **15,069** | **15,230** | **+161** |

R20 changes only target-example consumption on top of R19:
- both executable JsonExample artifacts use `{Template,Examples[]}`;
- `Template` preserves the existing two target-owned ruleset fields;
- each `Examples[]` library contains compact no-simulation, Page DP, and List DP full candidates with synthetic `ZqxExample-*` names;
- Generator may use examples only to illustrate HOW an already-required schema mapping is serialized; Validator ignores examples for validation.

R18 adds one projection/materialization correction on top of R17:
- Author carries already-resolved simulation setup-page class as `{class,data}` and preserves resolved nested page classes in `data`;
- frozen non-primary runtime named pages must reach Projection `pages`;
- Generator maps simulation setup deterministically to fixed `PrimaryPage` plus `pyPageDetails.pxObjClass=class`;
- Standard/MultiInput target schemas enforce `PrimaryPage` and root simulation `pxObjClass`.

R19 moves target compiler mapping from target Knowledge Areas into selected JsonSchema extensions; JsonExample remains template-only (`pyRuleSet`/`pyRuleSetVersion`).

R19 prompt word-count proxy versus R18 (word proxy only, not exact Claude tokenization):

| Prompt | R18 | R19 | Delta |
|---|---:|---:|---:|
| ScenarioAuthor | 8,934 | 8,934 | 0 |
| Generator | 3,797 | 3,269 | -528 |
| Validator | 3,249 | 2,888 | -361 |
| **Total** | **15,980** | **15,091** | **-889** |

Historical R18 prompt word-count proxy versus R17:

| Prompt | R17 | R18 | Delta |
|---|---:|---:|---:|
| ScenarioAuthor | 8,863 | 8,934 | +71 |
| Generator | 3,793 | 3,797 | +4 |
| Validator | 3,249 | 3,249 | 0 |
| **Total** | **15,905** | **15,980** | **+75** |

R18 execution/validation checkpoints completed:
- Author simulation source grammar and nested-class materialization reviewed in context;
- named runtime page -> Projection `pages` propagation reviewed against ROOT/CTX/assertion rules;
- Generator grammar and both target schema mappings synchronized;
- Standard/MultiInput schemas parse as JSON and their canonical examples still validate;
- whole-bundle contextual search found no active `{name,data}` simulation setup-page source contract or rule preserving a runtime page name as Data Page `pySetupPageName`.

No fixtures were created/updated and no SHA/hash/checksum/fingerprint acceptance checks were used.

## External evidence still pending

Static validation does not prove live Pega behavior. Run a fresh multi-group E2E replay and verify:

1. exact `application_context.caseID` reaches Author Memory calls -> Generator Invocation/Memory calls -> Validator Invocation/JsonValidationTool/Memory calls character-for-character unchanged, even when `GetCaseData.pyID` differs;
2. all Projection rows are persisted before the first Generator invocation;
3. if a Projection write fails, no Generator is invoked;
4. Generator returns only `ACK`, and Author routing depends only on fresh Projection Memory;
5. when a Generator stops on an early group, later Projection rows remain visible and unprocessed;
6. all persisted queue entries are invoked exactly once on a successful run.

If the actual tool-call argument already equals exact `application_context.caseID` but Pega itself stores/returns a different value, treat that as a Pega implementation/mapping defect; prompt changes cannot repair runtime changes after the call boundary.

## Exact next action

Deploy R31 and replay `PrepareCustomerCommunication`. Verify both executable scenarios persist physical `simulations[]` matching frozen REQUIRED_SIMS; `simulationsNarrative` must be empty iff physical simulations are absent. Add/inspect one scenario where a Data Page is evaluated in a guard returning false: simulation must remain required although the guarded action is skipped. Also verify a terminally proven `notEvaluated` Data Page is omitted. Capture the existing R30 RuleCrawler occurrence evidence as a regression check, then replay one Decision Table path and one PAGE-parameter Model path.


## R19 target-compiler migration

- `Rule-Test-Unit-Case*_KnowledgeArea` runtime artifacts removed.
- Standard schema owns `CM-EXEC-001` + `CM-ASSERT-STD-001`; MultiInput owns `CM-EXEC-001` + `CM-WHEN-001`; both retain `CM-NAME-001`.
- Generator/Validator executable KnowledgeTool batches are now JsonSchema + JsonExample only.
- JsonExamples were not changed.
- No fixtures or SHA/hash/checksum/fingerprint acceptance checks were used.


## R24 KnowledgeArea references added
- Added verbatim Rule-Obj-Model, Rule-Declare-Pages and Rule-Declare-DecisionTable reference files under `02_KNOWLEDGE_AREAS`.
- Runtime prompts/contracts remain R23-equivalent. See `00_START_HERE/KNOWLEDGEAREA_COMPATIBILITY_R24.md` for compatibility findings.


## R26 semantic KnowledgeArea boundary cleanup
- ScenarioAuthor runtime behavior is unchanged except `repair` wording is narrowed to `rebuild/localize` for KDT evidence.
- Generator, Validator, both target schemas/examples, Rule-Declare-Pages KA and Rule-Obj-When KA are unchanged from R25.
- Changed-runtime word proxy: 18,039 -> 17,535 (-504); ScenarioAuthor remains 9,212.
- Static validation: 65/65 PASS; all 6 target examples validate. No new fields, fixtures or runtime tools were introduced.


## R27 R26-audit closure
- Closed the only two PARTIAL results from the explicit R26 31-stage audit; both came from one ambiguous ScenarioAuthor phrase.
- Replaced `KDT.11-KDT.12 rebuild/localize missing/inconsistent/UNKNOWN evidence.` with deterministic `KDT.11-KDT.12: missing/inconsistent→invalidate/rebuild; terminal UNKNOWN→localize.`
- ScenarioAuthor word proxy remains 9,212; Model/DecisionTable/RUF KnowledgeAreas are byte-identical to R26.
- Generator, Validator, both target schemas/examples, Data Page KA and When KA remain unchanged.
- Full R27 audit: 31/31 PASS (static/textual/structural); fresh live Pega replay remains pending.


## R30 occurrence-driven RuleCrawler simplification
- Live R29 replay showed that preserving/auditing a chosen holder still allowed the crawl inventory itself to be over-created from root metadata.
- R30 makes dependency work occurrence-driven: executable scan evidence creates D; its immutable `src.holder` directly supplies `pyItemRuleId`. Raw `RuleJSON.pxRuleReferences[]` is a lookup/materialization source only after D exists.
- Removed `CANDIDATE_HOLDERS` and `REQ=holder::KEY` from active planning. OUT/ACT are canonical KEY lists again; preCall separately verifies the physical holder equals the chosen D occurrence source.
- Added two compact behavioral anchors: transitive `RootRule -> A/B; A -> C; B -> D/E`, and metadata A/B/C/D with scan-created A/C -> request A/C only.
- RUF exact four-key shape remains; RUF KA wording now references chosen READY occurrence rather than a separate holder-selection abstraction.
- Static/adversarial validation: 25/25 PASS; 6/6 target examples schema-valid. ScenarioAuthor 9502 -> 9332 words (-170, ~1.8%). Live Pega/Claude Opus 4.8 replay remains pending.


## R29 RuleCrawler source-holder + RUF-shape repair
- Live R28 replay proved the post-selection `REQ=holder::KEY` audit was insufficient: holder selection itself was undefined, so an incorrect all-RUT plan could still be self-consistent.
- `SCAN_HOLDER` is now frozen from each scanned RuleJSON/tool correlation; D `src` carries immutable `holder=<...>;at=<...>` provenance. `CANDIDATE_HOLDERS(KEY)` comes only from READY source occurrences; no arbitrary/alias holder or out-of-provenance alternate is legal.
- RuleCrawler wire references are explicitly discriminated: non-RUF exact five-key shape; RUF exact four-key shape. RUF `pxRuleClassName` is forbidden even as `""`/null. Physical shape is validated before ACT census.
- The observed R28 RUF object containing `"pxRuleClassName":""` is rejected by the new pre-call gate.
- ScenarioAuthor word proxy 9,283 -> 9,502 (+219, ~2.4%); RUF KA 874 -> 888 (+14). Generator, Validator, other four KAs, target schemas/examples and tool contracts are unchanged.
- Static semantic/adversarial validation passes; 6/6 target examples remain schema-valid. Live Pega/Claude R29 replay is still required.


## R28 RuleCrawler holder-provenance repair
- Root cause: R27 `_DWLPlan.OUT/ACT` audited canonical KEY only, so a physical request could move a dependency to the wrong `pyItemRuleId` while preserving the same flattened KEY census.
- After holder selection ScenarioAuthor now freezes `REQ=holder::KEY`; physical grouping is derived only from frozen REQs and holder fallback/reselection during serialization is illegal.
- `ACT` is independently reconstructed from actual `pyItemRuleId::KEY(reference)` values; ordered `OUT==ACT` plus READY_KEYS projection is the pre-call gate.
- RuleCrawler wire schema, KEY construction, READY/BLOCKED semantics, response correlation-by-KEY, Generator, Validator, schemas, examples, tools and KnowledgeAreas are unchanged.
- Focused static validation: 17/17 PASS; ScenarioAuthor word proxy 9,212 -> 9,283 (+71, ~0.8%). Live Pega/Claude replay remains pending.


## R31 Data Page simulation census fix
- Live stored conversation `PXCONV-163039` showed semantic/narrative simulation intent could survive while physical `UnitTestProjectionV3.simulations[]` was omitted.
- Final Scenario RX now owns `REQUIRED_SIMS`: evaluated or unknown Data Page access requires simulation; false guard result does not remove it; only terminally proven `notEvaluated` occurrences are excluded.
- Each REQUIRED_SIM freezes exactly one SIM; Projection materialization derives `REQSIM` from frozen SIMs and `ACTSIM` from physical `simulations[]`, requiring exact ordered equality.
- `simulations` is absent iff REQSIM is empty; otherwise required. `simulationsNarrative` is derived only from the physical simulation set.
- External Projection simulation shape is unchanged; no DP_SIG wire field was added. Generator, Validator, all KnowledgeAreas, target schemas/examples and tools are unchanged.
- Validation: 28/28 static checks PASS; 12/12 adversarial cases PASS; observed G001/G002 defect is rejected 2/2; 6/6 target examples schema-valid. ScenarioAuthor 9,332 -> 9,524 words (+192, ~2.1%). Live Pega/Claude replay remains pending.
